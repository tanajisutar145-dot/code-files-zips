"""
API endpoints that work without Neo4j (semantic model, standards, health) and graceful degradation when the
database is down. Neo4j access is stubbed so the tests are fast and deterministic.
"""

import pytest
from fastapi.testclient import TestClient


@pytest.fixture(scope="module")
def client():
    from app.graph.neo4j_client import neo4j_client
    from app.main import app

    neo4j_client.verify_connectivity = lambda cache_seconds=5.0: False   # database "down"
    return TestClient(app)


def test_root_and_health_report_degraded(client):
    assert "Oil & Gas" in client.get("/").json()["message"]
    h = client.get("/health").json()
    assert h["status"] == "degraded"
    assert h["services"]["neo4j"] in ("disconnected", "not_configured")
    assert h["services"]["semantic_model"] == "built"
    assert client.get("/api/health").json()["services"] == h["services"]


def test_model_endpoint(client):
    m = client.get("/api/model/").json()
    assert len(m["tables"]) == 56
    assert m["standard"]["short"]
    assert {r["type"] for r in m["extra_relationships"]} >= {"IDENTIFIED_BY", "SAME_FACILITY_AS"}
    well = next(t for t in m["tables"] if t["label"] == "DrillingWell")
    assert well["standard_class"] == "Wellbore" and well["columns"]


def test_standards_endpoint(client):
    s = client.get("/api/model/standards").json()
    assert len(s["classes"]) >= 40
    assert len(s["attributes"]) >= 100
    assert sorted(s["use_cases"]) == ["UC1", "UC2", "UC3", "UC4", "UC5"]


def test_pipeline_status(client):
    p = client.get("/api/model/pipeline").json()
    assert p["model_step"]["classes"] == 56
    assert p["neo4j"]["connected"] is False
    assert p["commands"]["load"] == "python -m app.kg run --step load"


def test_use_cases_degrade_gracefully(client, monkeypatch):
    import app.services.usecase_service as ucs

    def down(*args, **kwargs):
        raise RuntimeError("Neo4j is not reachable")

    monkeypatch.setattr(ucs, "query", down)
    ucs_list = client.get("/api/usecases/").json()
    assert [u["id"] for u in ucs_list] == ["UC1", "UC2", "UC3", "UC4", "UC5"]
    assert all("error" in u["kpis"] for u in ucs_list)
    assert all(len(u["questions"]) == 3 for u in ucs_list)


def test_graph_endpoints_return_503_without_database(client):
    assert client.get("/api/dashboard/summary").status_code == 503
    assert client.get("/api/assets/overview").status_code == 503


def test_verification_queue_roundtrip(client, tmp_path, monkeypatch):
    from app.services.verification_service import verification_service

    monkeypatch.setattr(verification_service, "path", tmp_path / "queue.json", raising=False)
    item = client.post("/api/verification/flag", json={"question": "q", "answer": "a", "confidence": 0.3}).json()
    assert item["status"] == "pending"
    reviewed = client.post(f"/api/verification/review/{item['id']}", json={"decision": "approved", "comment": "ok"}).json()
    assert reviewed["status"] == "approved"
    assert client.get("/api/verification/stats").json()["approved"] >= 1
