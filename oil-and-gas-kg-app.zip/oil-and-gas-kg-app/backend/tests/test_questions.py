"""Demo questions (user_questions/questions.yaml): structure, retrievers, templates and fact scoring."""

from app.kg.rag.retrievers import RETRIEVERS
from app.kg.rag.runner import score_answer, text2cypher_examples


def test_fifteen_demo_questions_three_per_use_case(questions):
    qs = questions["questions"]
    assert [q["id"] for q in qs] == [f"Q{i}" for i in range(1, 16)]
    per_uc = {}
    for q in qs:
        per_uc.setdefault(q["use_case"].split()[0], []).append(q["id"])
    assert sorted(per_uc) == ["UC1", "UC2", "UC3", "UC4", "UC5"]
    assert all(len(v) == 3 for v in per_uc.values())


def test_question_fields_and_references(questions, kg_settings):
    templates = set(kg_settings.section("rag")["templates"])
    for q in questions["questions"] + questions["sample_questions"]:
        assert q["best_retriever"] in RETRIEVERS, q["id"]
        assert q["retrieval_template"] in templates, q["id"]
        assert q["question"].strip()
    for q in questions["questions"]:
        for key in ("ground_truth_cypher", "subgraph_cypher", "expected_answer", "must_contain", "why_best", "pattern"):
            assert q.get(key), f"{q['id']} lacks {key}"


def test_text2cypher_examples_are_rendered_for_the_prompt(questions):
    examples = text2cypher_examples(questions)
    assert len(examples) == len(questions["text2cypher_examples"]) >= 10
    assert all(e.startswith("USER INPUT: '") and " QUERY: MATCH" in e or " QUERY: WITH" in e for e in examples)


def test_score_answer_alternatives_and_number_formats():
    must = ["FD1-K-201", ["27,500", "27500"], "INS-2025-0001"]
    score, matched, missing = score_answer("Compressor FD1-K-201 leaked; repair cost USD 27500.", must)
    assert round(score, 2) == 0.67
    assert missing == ["INS-2025-0001"]
    assert score_answer("", must)[0] == 0.0
