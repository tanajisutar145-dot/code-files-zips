"""Answer verification, entity linking and document parsing / chunking (offline)."""

import json

from app.documents.chunker import DocumentChunker
from app.documents.entity_linker import EntityLinker
from app.documents.models import Chunk, Document
from app.documents.parsers import get_parser_for_file
from app.verification.answer_verifier import AnswerVerifier

CONTEXT = [
    "SOURCE ROW: FailureReport FR-2025-0001 {failure_date: 2025-09-18, repair_cost: 27500, production_impact_boe: 1850}",
    "SOURCE ROW: InspectionEvent INS-2025-0001 {inspection_date: 2025-08-20, inspection_findings: 38% wall loss}",
    "SOURCE ROW: DrillingWell Red Mesa 12-2H {api_well_number: 42-301-43582-00-00}",
]


class FakeNeo4j:
    """Answers the two queries of the entity linker from an in-memory caption list."""

    def __init__(self, captions, identities):
        self.captions = captions
        self.identities = identities

    def execute_query(self, cypher, params=None):
        if "WellIdentity" in cypher:
            return [{"id": self.identities[params["a"]]}] if params["a"] in self.identities else []
        return [{"caption": c, "label": lbl, "id": f"id:{c}"} for c, lbl in self.captions]


def test_grounded_answer_is_verified():
    v = AnswerVerifier().verify(
        "FD1-K-201 failed (FR-2025-0001) 29 days after INS-2025-0001; repair cost USD 27,500 and 1,850 BOE deferred.",
        CONTEXT, "q")
    assert "FR-2025-0001" in v.supported_claims and "INS-2025-0001" in v.supported_claims
    assert "27500" in v.supported_claims and "1850" in v.supported_claims
    assert "FD1-K-201" in v.unsupported_claims        # the tag is not in this context
    assert 0.0 < v.grounding_score < 1.0


def test_invented_figures_and_phrases_are_flagged():
    v = AnswerVerifier().verify("Based on my knowledge the repair cost USD 99,000 for FR-2025-0001.", CONTEXT, "q")
    assert "99000" in v.unsupported_claims
    assert any("ungrounded" in w for w in v.warnings)
    assert v.verified is False


def test_empty_context_cannot_be_grounded():
    v = AnswerVerifier().verify("WCE-2024-0001 was a kick.", [], "q")
    assert v.verified is False and v.grounding_score <= 0.5
    assert any("no context" in g for g in v.evidence_gaps)


def test_ground_truth_score_is_blended():
    gt = {"score": 1.0, "matched": ["FR-2025-0001"], "missing": []}
    v = AnswerVerifier().verify("FR-2025-0001 cost USD 27,500.", CONTEXT, "q", gt)
    assert v.grounding_score == 1.0 and v.verified


def test_entity_linker_matches_captions_longest_first_and_api_numbers():
    neo = FakeNeo4j([("Red Mesa 12-3H", "DrillingWell"), ("Red Mesa 12-3H ST01", "DrillingWell"), ("FD1-K-201", "Equipment"),
                     ("CTB", "AssetFacility")],
                    {"4230143582": "id:API"})
    linker = EntityLinker(neo)
    doc = Document(document_id="DOC-T", title="t", content="Sidetrack Red Mesa 12-3H ST01 and compressor FD1-K-201; API 42-301-43582-00-00.")
    refs = {r.caption: r for r in linker.link_document_entities(doc)}
    assert "Red Mesa 12-3H ST01" in refs and "Red Mesa 12-3H" not in refs       # overlapping shorter caption skipped
    assert refs["FD1-K-201"].entity_type == "Equipment"
    assert any(r.entity_type == "WellIdentity" and r.entity_id == "id:API" for r in refs.values())
    assert "CTB" not in refs                                                     # too short / no digit: not an identifier
    assert linker.link_chunk_entities(Chunk(chunk_id="c", document_id="DOC-T", chunk_index=0, text="FD1-K-201 tripped")) == ["FD1-K-201"]


def test_parsers_and_chunker_keep_provenance():
    text = "Lessons learned LL-2024-007\n\nRaise mud weight before the Wolfcamp B top.\n\nRun pressure-while-drilling."
    parsed = get_parser_for_file("ll.txt").parse(text.encode("utf-8"), "ll.txt")
    assert parsed.format == "txt" and len(parsed.sections) == 3
    data = json.dumps({"document_id": "DOC-X", "title": "x", "content": "y"}).encode("utf-8")
    assert get_parser_for_file("x.json").parse(data, "x.json").content
    csv_doc = get_parser_for_file("t.csv").parse(b"tag,finding\nFD1-K-201,38% wall loss\n", "t.csv")
    assert "FD1-K-201" in csv_doc.content

    doc = Document(document_id="DOC-LL", title=parsed.title, content=parsed.content,
                   metadata={"sections": [s.model_dump() for s in parsed.sections]})
    chunks = DocumentChunker(chunk_size=200, overlap=20).chunk_document(doc)
    assert chunks and all(c.document_id == "DOC-LL" for c in chunks)
    assert "Wolfcamp B" in " ".join(c.text for c in chunks)


def test_sample_documents_are_synthetic_and_loadable(kg_settings):
    from app.documents.__main__ import to_document

    folder = kg_settings.path("data/documents")
    files = sorted(folder.glob("*.json"))
    assert len(files) >= 4
    for f in files:
        doc = to_document(f)
        assert doc.document_id.startswith("DOC-")
        assert doc.content.startswith("SYNTHETIC DOCUMENT")
        assert doc.linked_records
