"""
Static checks of Cypher text against the semantic model (no database needed).

For every query it verifies that
* node labels exist (oil_gas classes, the derived WellIdentity hub, the semantic / lexical layer);
* relationship types exist, and that a pattern ``(a:A)-[:T]->(b:B)`` follows a real foreign key or derived rule
  in that direction;
* properties used on a variable bound to a data label (``n.prop`` and ``(n:L {prop: ...})``) are columns of the
  table or properties written by the load step / derived rules.

It is a lint, not a parser: it handles the patterns used in this project (single-line node patterns, no
nested parentheses inside node patterns).
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from app.kg.ontology.extract import SemanticModel

WELL_LABELS = ("DrillingWell", "ExplorationWell", "ProductionWell", "WellAsset")
# relationships created by graph.derived_relationships in config.yaml: (from, type, to)
DERIVED = [(w, "IDENTIFIED_BY", "WellIdentity") for w in WELL_LABELS] + [
    ("ProductionWell", "NAME_MATCH_API_CONFLICT", "DrillingWell"),
    ("ProductionFacility", "SAME_FACILITY_AS", "AssetFacility"),
    ("Hierarchy", "LOCATES", "Equipment"),
    ("Hierarchy", "LOCATES", "AssetFacility"),
    ("Hierarchy", "CHILD_OF", "Hierarchy"),
    ("WellProgram", "PROGRAM_FOR", "DrillingWell"),
]
LAYER_LABELS = {"WellIdentity", "OntologyClass", "OntologyProperty", "StandardClass", "StandardAttribute", "SubjectArea",
                "Document", "Chunk", "__Entity__", "__KGBuilder__"}
LAYER_TYPES = {"INSTANCE_OF", "SPECIALIZES", "SUBCLASS_OF", "MAPS_TO", "HAS_PROPERTY", "IN_SUBJECT_AREA", "HAS_NARRATIVE",
               "MENTIONS_RECORD", "FROM_DOCUMENT", "NEXT_CHUNK", "MENTIONS", "FROM_CHUNK", "HAS_ENTITY"}
LOAD_PROPS = {"caption", "std_class", "std_match", "std_package", "std_standard", "subject_area", "source_table", "geo_point"}
DERIVED_PROPS = {w: {"api10", "api_wellbore_code"} for w in WELL_LABELS}
DERIVED_PROPS["WellIdentity"] = {"api10", "caption", "std_class", "std_match", "std_standard", "subject_area"}

_NODE_LABEL = re.compile(r"(?<![\w.$'])([a-z_]\w*)\s*:\s*`?([A-Z][A-Za-z0-9_]*)`?")
_REL = re.compile(r"\[\s*(\w*)\s*:\s*([A-Z_|\s]+?)\s*(\*[\d.]*)?\s*(\{[^\]]*\})?\s*\]")
_CHAIN = re.compile(r"(?=\((?P<a>[^()]*)\)\s*(?P<l><)?-\[(?P<r>[^\]]*)\]-(?P<g>>)?\s*\((?P<b>[^()]*)\))")
_NODE = re.compile(r"^\s*(\w*)\s*(?::\s*`?([A-Za-z_]\w*)`?)?\s*(\{.*\})?\s*$", re.S)
_PROP_USE = re.compile(r"(?<![\w.$])([a-z_]\w*)\.([a-z_]\w*)\b(?!\s*\()")
_MAP_KEY = re.compile(r"([a-z_]\w*)\s*:")
_STRING = re.compile(r"'(?:[^'\\]|\\.)*'")


@dataclass
class Finding:
    query: str
    problem: str


@dataclass
class Model:
    labels: set[str]
    props: dict[str, set[str]]
    triples: set[tuple[str, str, str]]
    types: set[str] = field(default_factory=set)

    @classmethod
    def from_semantic(cls, sem: SemanticModel) -> "Model":
        labels = {t.label for t in sem.tables.values()}
        props = {t.label: {c.column for c in t.columns} | LOAD_PROPS | DERIVED_PROPS.get(t.label, set()) for t in sem.tables.values()}
        props["WellIdentity"] = DERIVED_PROPS["WellIdentity"] | {"geo_point"}
        triples = {(sem.label(r.from_table), r.rel_type, sem.label(r.to_table)) for r in sem.relationships} | set(DERIVED)
        return cls(labels=labels | LAYER_LABELS, props=props, triples=triples, types={t for _, t, _ in triples} | LAYER_TYPES)


def lint(query: str, model: Model) -> list[Finding]:
    out: list[Finding] = []
    q = _STRING.sub("''", query)                      # string literals cannot contain labels or properties
    flat = " ".join(q.split())

    # relationship types
    rel_spans = []
    for m in _REL.finditer(flat):
        rel_spans.append(m.span())
        for t in (x.strip() for x in m.group(2).split("|")):
            if t and t not in model.types:
                out.append(Finding(query, f"unknown relationship type {t}"))
    no_rels = flat
    for a, b in reversed(rel_spans):
        no_rels = no_rels[:a] + " " * (b - a) + no_rels[b:]
    # coalesce(x.a, x.b, ...) lists fallbacks for heterogeneous records: only the first argument must exist
    no_rels = re.sub(r"coalesce\(\s*([^,()]+)(,[^()]*)\)", r"coalesce(\1)", no_rels)

    # labels and variable bindings (from node patterns and WHERE x:Label)
    bindings: dict[str, set[str]] = {}
    for var, label in _NODE_LABEL.findall(no_rels):
        if label.startswith("STD_"):
            continue
        if label not in model.labels:
            out.append(Finding(query, f"unknown label {label}"))
        bindings.setdefault(var, set()).add(label)

    def label_of(node_text: str) -> str | None:
        m = _NODE.match(node_text)
        if not m:
            return None
        var, label = m.group(1), m.group(2)
        if label:
            return label
        ls = bindings.get(var, set())
        return next(iter(ls)) if len(ls) == 1 else None

    # direction of relationship patterns between known labels
    for m in _CHAIN.finditer(flat):
        rm = re.match(r"\s*\w*\s*:\s*([A-Z_|\s]+?)\s*(\*[\d.]*)?\s*(\{.*\})?\s*$", m.group("r"))
        if not rm:
            continue
        a, b = label_of(m.group("a")), label_of(m.group("b"))
        if m.group("l") and not m.group("g"):
            a, b = b, a
        elif not m.group("g"):
            continue                                     # undirected pattern
        types = [t.strip() for t in rm.group(1).split("|") if t.strip()]
        data_types = [t for t in types if t not in LAYER_TYPES]
        if not data_types or (a is None and b is None):
            continue
        ok = [t for t in data_types if any((a in (None, f)) and (b in (None, to)) and t == ty for f, ty, to in model.triples)]
        if not ok:
            out.append(Finding(query, f"no relationship ({a or '?'})-[:{'|'.join(data_types)}]->({b or '?'}) in the model"))

    # properties of variables bound to exactly one data label
    for var, labels in bindings.items():
        if len(labels) != 1:
            continue
        label = next(iter(labels))
        known = model.props.get(label)
        if known is None:
            continue
        for v, prop in _PROP_USE.findall(no_rels):
            if v == var and prop not in known:
                out.append(Finding(query, f"{label} has no property {prop} ({var}.{prop})"))
    for m in re.finditer(r"\(\s*(\w*)\s*:\s*([A-Z]\w*)\s*\{([^}]*)\}", no_rels):
        known = model.props.get(m.group(2))
        if known is None:
            continue
        for key in _MAP_KEY.findall(m.group(3)):
            if key not in known:
                out.append(Finding(query, f"{m.group(2)} has no property {key} (map pattern)"))
    return out


def python_queries(path: Path) -> list[str]:
    """String constants / f-strings of a module that look like Cypher queries."""
    tree = ast.parse(path.read_text(encoding="utf-8"))
    found: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            text = node.value
        elif isinstance(node, ast.JoinedStr):
            text = "".join(v.value if isinstance(v, ast.Constant) else " " for v in node.values)
        else:
            continue
        if re.search(r"\bMATCH\b", text):
            found.append(text)
    return found


def lint_all(queries: Iterable[str], model: Model) -> list[Finding]:
    return [f for q in queries for f in lint(q, model)]
