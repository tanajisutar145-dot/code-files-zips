"""Model step: DDL + OWL ontology + standards alignment -> semantic model."""


def test_scope_and_alignment(sem):
    assert len(sem.tables) == 56
    assert all(t.standard_class for t in sem.tables.values()), "every class is aligned to a standard class"
    assert len(sem.relationships) == 297
    assert len({t.schema for t in sem.tables.values()}) == 10


def test_standard_classes_of_key_entities(sem):
    expected = {
        "DrillingWell": "Wellbore",
        "WellAsset": "Well",
        "Equipment": "Equipment",
        "FailureReport": "FailureEvent",
        "ProcessSafetyEvent": "ProcessSafetyEvent",
        "ReservesEstimate": "ReservesEstimate",
        "CustodyTransfer": "CustodyTransfer",
    }
    for label, std in expected.items():
        assert sem.by_label(label).standard_class == std, label
    assert sem.by_label("DrillingWell").standard_package.startswith("OSDU")


def test_use_case_subject_areas(sem):
    tagged = {uc: [t.label for t in sem.tables.values() if uc in t.subject_areas] for uc in ("UC1", "UC2", "UC3", "UC4", "UC5")}
    assert all(tagged.values()), tagged
    assert "DrillingWell" in tagged["UC1"] and "NptEvent" in tagged["UC2"] and "InspectionEvent" in tagged["UC3"]
    assert "ProcessSafetyEvent" in tagged["UC4"] and "CustodyTransfer" in tagged["UC5"]


def test_units_and_standard_attributes(sem):
    col = sem.by_label("WellControlEvent").column("pit_gain_volume_bbl")
    assert col.unit == "bbl"
    assert col.standard_attribute
    assert sum(1 for t in sem.tables.values() for c in t.columns if c.standard_attribute) >= 100


def test_foreign_keys_become_typed_relationships(sem):
    rels = {(sem.label(r.from_table), r.rel_type, sem.label(r.to_table)) for r in sem.relationships}
    for triple in [
        ("NptEvent", "DRILLING_WELL", "DrillingWell"),
        ("DrillingWell", "PARENT_WELLBORE_DRILLING_WELL", "DrillingWell"),
        ("FailureReport", "INSPECTION_EVENT", "InspectionEvent"),
        ("FailureReport", "PREVIOUS_FAILURE_REPORT", "FailureReport"),
        ("HseCorrectiveAction", "PREVIOUS_ACTION_HSE_CORRECTIVE_ACTION", "HseCorrectiveAction"),
        ("ProductionAllocation", "CUSTODY_TRANSFER", "CustodyTransfer"),
        ("ProductionAllocation", "METER_STATION", "MeterStation"),
        ("Incident", "PERMIT_TO_WORK", "PermitToWork"),
    ]:
        assert triple in rels, triple
