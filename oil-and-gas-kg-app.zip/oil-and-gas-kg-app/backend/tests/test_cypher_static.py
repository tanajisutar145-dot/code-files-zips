"""
Every Cypher query of the app, checked against the semantic model without a database: labels, relationship
types and directions, and properties (see cypher_lint.py).
"""

from pathlib import Path

import pytest

from cypher_lint import lint, lint_all, python_queries

BACKEND = Path(__file__).resolve().parents[1]
MODULES = [
    "app/services/usecase_service.py",
    "app/services/dashboard_service.py",
    "app/services/asset_service.py",
    "app/services/model_service.py",
    "app/services/graph_service.py",
    "app/services/search_service.py",
    "app/services/document_service.py",
    "app/documents/loader.py",
]


def _report(findings):
    return "\n".join(f"{f.problem}: {' '.join(f.query.split())[:160]}" for f in findings)


@pytest.mark.parametrize("module", MODULES)
def test_service_cypher_matches_model(module, lint_model):
    queries = python_queries(BACKEND / module)
    findings = lint_all(queries, lint_model)
    assert not findings, _report(findings)


def test_use_case_service_has_queries():
    assert len(python_queries(BACKEND / "app/services/usecase_service.py")) >= 30


def test_questions_cypher_matches_model(questions, lint_model):
    queries = [e["cypher"] for e in questions["text2cypher_examples"]]
    queries += [q[k] for q in questions["questions"] for k in ("ground_truth_cypher", "subgraph_cypher")]
    findings = lint_all(queries, lint_model)
    assert not findings, _report(findings)


def test_derived_relationship_rules_match_model(kg_settings, lint_model):
    rules = kg_settings.section("graph")["derived_relationships"]
    assert {r["name"] for r in rules} == {"IDENTIFIED_BY", "NAME_MATCH_API_CONFLICT", "SAME_FACILITY_AS", "LOCATES", "CHILD_OF", "PROGRAM_FOR"}
    findings = lint_all([r["cypher"] for r in rules], lint_model)
    assert not findings, _report(findings)


def test_retrieval_templates_match_model(kg_settings, sem, lint_model):
    from app.kg.rag.retrievers import CypherFragments

    fragments = CypherFragments(kg_settings, sem)
    for name, tpl in kg_settings.section("rag")["templates"].items():
        for rel in (tpl.get("relationships") or []) if isinstance(tpl, dict) else []:
            assert rel in lint_model.types, f"template {name}: unknown relationship {rel}"
        findings = lint(fragments.template(name), lint_model)
        assert not findings, f"template {name}:\n" + _report(findings)


def test_lint_catches_mistakes(lint_model):
    """The lint itself: wrong label, property, type and direction are reported."""
    bad = {
        "MATCH (x:Equipmnt) RETURN x": "unknown label",
        "MATCH (f:FailureReport)-[:EQUIPMENT]->(e:Equipment) RETURN e.tagg": "no property tagg",
        "MATCH (w:WellControlEvent)-[:DRILING_WELL]->(d) RETURN d": "unknown relationship type",
        "MATCH (n:NptEvent)<-[:DRILLING_WELL]-(d:DrillingWell) RETURN n": "no relationship",
        "MATCH (c:CustodyTransfer {transfer_ref: $r}) RETURN c": "no property transfer_ref",
    }
    for query, problem in bad.items():
        assert any(problem in f.problem for f in lint(query, lint_model)), query
    assert not lint("MATCH (d:DrillingWell)-[:IDENTIFIED_BY]->(i:WellIdentity) WHERE d.api_wellbore_code = '00' RETURN i.api10", lint_model)
