"""
Shared fixtures for the offline backend tests (no Neo4j, no LLM needed).

Run from backend/:  .venv\\Scripts\\python -m pytest -q
The semantic model is read from build/semantic_model.json; when it is missing it is built from the DDL and
ontology (model step) first.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

BACKEND = Path(__file__).resolve().parents[1]
PROJECT = BACKEND.parent
sys.path.insert(0, str(BACKEND))
sys.path.insert(0, str(Path(__file__).resolve().parent))


@pytest.fixture(scope="session")
def kg_settings():
    from app.core.config import kg_settings as _kg

    return _kg()


@pytest.fixture(scope="session")
def sem(kg_settings):
    from app.kg.ontology.extract import SemanticModel

    if not (kg_settings.build_dir / "semantic_model.json").exists():
        from app.kg.cli import main

        assert main(["run", "--step", "model"]) in (0, None)
    return SemanticModel.load(kg_settings)


@pytest.fixture(scope="session")
def lint_model(sem):
    from cypher_lint import Model

    return Model.from_semantic(sem)


@pytest.fixture(scope="session")
def questions(kg_settings):
    from app.kg.rag.runner import load_questions

    return load_questions(kg_settings)


@pytest.fixture(scope="session")
def input_dir() -> Path:
    return PROJECT / "input_data"
