"""
Synthetic dataset (input_data/): one CSV per in-scope table that matches the oil_gas data model, unique primary
keys, resolvable foreign keys, synthetic labelling, and the planted facts the demo questions rely on.
"""

import csv
import json
from datetime import date

import pytest


def _rows(input_dir, table_id):
    schema, table = table_id.split(".")
    with open(input_dir / schema / f"{table}.csv", encoding="utf-8") as f:
        return list(csv.DictReader(f))


@pytest.fixture(scope="module")
def data(sem, input_dir):
    return {tid: _rows(input_dir, tid) for tid in sem.tables}


def test_one_file_per_table_with_model_columns(sem, input_dir, data):
    for tid, t in sem.tables.items():
        path = input_dir / tid.split(".")[0] / f"{tid.split('.')[1]}.csv"
        assert path.exists(), tid
        with open(path, encoding="utf-8") as f:
            header = next(csv.reader(f))
        model_cols = {c.column for c in t.columns}
        assert set(header) <= model_cols, f"{tid}: columns not in the DDL: {set(header) - model_cols}"
        assert t.primary_key in header
        assert 1 <= len(data[tid]) <= 60, f"{tid}: {len(data[tid])} rows"


def test_primary_keys_unique(sem, data):
    for tid, t in sem.tables.items():
        keys = [r[t.primary_key] for r in data[tid]]
        assert all(keys) and len(keys) == len(set(keys)), tid


def test_foreign_keys_resolve(sem, data):
    pks = {tid: {r[t.primary_key] for r in data[tid]} for tid, t in sem.tables.items()}
    missing = []
    for r in sem.relationships:
        for row in data[r.from_table]:
            v = row.get(r.from_column)
            if v and v not in pks[r.to_table]:
                missing.append(f"{r.from_table}.{r.from_column}={v} -> {r.to_table}")
    assert not missing, missing[:10]


def test_manifest_and_readme_label_data_as_synthetic(input_dir):
    manifest = json.loads((input_dir / "manifest.json").read_text(encoding="utf-8"))
    assert manifest
    readme = (input_dir / "README.md").read_text(encoding="utf-8").lower()
    assert "synthetic" in readme


def test_api_numbers_follow_ppdm_format(data):
    for row in data["drilling.drilling_well"]:
        api = row["api_well_number"]
        parts = api.split("-")
        assert len(parts) == 5 and [len(p) for p in parts] == [2, 3, 5, 2, 2], api
        assert parts[0] in ("42", "30"), api              # Texas, New Mexico state codes


def test_planted_facts_used_by_demo_questions(data):
    eq = {r["equipment_id"]: r for r in data["asset.equipment"]}
    ins = {r["inspection_event_id"]: r for r in data["asset.inspection_event"]}
    fr = next(r for r in data["asset.failure_report"] if r["failure_report_number"] == "FR-2025-0001")
    i = ins[fr["inspection_event_id"]]
    assert eq[fr["equipment_id"]]["tag"] == "FD1-K-201" and i["inspection_number"] == "INS-2025-0001"
    assert (date.fromisoformat(fr["failure_date"][:10]) - date.fromisoformat(i["inspection_date"][:10])).days == 29

    wce = next(r for r in data["drilling.well_control_event"] if r["event_number"] == "WCE-2024-0001")
    assert wce["event_type"] == "kick" and float(wce["pit_gain_volume_bbl"]) == 18.0

    ptw = {r["permit_to_work_id"]: r for r in data["hse.permit_to_work"]}
    under = [i for i in data["hse.incident"] if i.get("permit_to_work_id")]
    assert len(data["hse.incident"]) == 50 and len(under) == 15
    assert sum(1 for i in under if ptw[i["permit_to_work_id"]]["permit_type"] == "electrical_isolation") == 5

    ct = next(r for r in data["logistics.custody_transfer"] if r["transfer_reference_number"] == "CT-2026-0815")
    allocated = sum(float(a["gross_oil_volume_bbl"]) for a in data["production.production_allocation"]
                    if a["custody_transfer_id"] == ct["custody_transfer_id"])
    assert round(allocated) == 115108
