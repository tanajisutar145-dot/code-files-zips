"""
Answer verification for GraphRAG responses.

Two independent checks, combined into one ``VerificationResult``:

1. **Grounding** (every answer): identifiers (event / work-order / NOV numbers, equipment tags, API
   numbers, well names) and figures quoted in the answer must appear in the context that the
   retriever actually sent to the LLM; hallucination phrases are flagged and acknowledged
   uncertainty is recognised.
2. **Ground truth** (curated demo questions): the share of expected facts (``must_contain`` in
   ``user_questions/questions.yaml``) found in the answer, computed by the QA engine against a
   deterministic Cypher query.
"""

from __future__ import annotations

import logging
import re
from typing import Any, Dict, List, Optional

from app.intelligence.models import VerificationResult

logger = logging.getLogger(__name__)

# record identifiers: upper-case segments joined by hyphens with at least one letter and one digit
# (NPT-2024-0001, NOV-RRC-2024-0001, FD1-K-201, R104-TD, CF-LACT-02); "API-10" is a term, not a record
_ID = re.compile(r"\b(?=[A-Z0-9-]*\d)(?=[A-Z0-9-]*[A-Z])(?!API-\d+\b)[A-Z0-9]+(?:-[A-Z0-9]+)+\b")
_API = re.compile(r"\b\d{2}-\d{3}-\d{5}(?:-\d{2}-\d{2})?\b|\b\d{10}(?:\d{4})?\b")  # API / US Well Numbers
_NUM = re.compile(r"(?<![\w.-])\d{1,3}(?:,\d{3})+(?:\.\d+)?(?![\w-])|(?<![\w.-])\d{3,}(?:\.\d+)?(?![\w-])")


def _norm_num(s: str) -> str:
    s = s.replace(",", "")
    return s[:-2] if s.endswith(".0") else s


class AnswerVerifier:
    """Verifies GraphRAG answers against their retrieved evidence."""

    def __init__(self):
        self.hallucination_patterns = [
            r"based on my knowledge", r"generally speaking", r"in my experience", r"it is (?:common|usual|normal)",
            r"from what I (?:know|understand)", r"as (?:far as|much as) I know", r"industry average",
        ]
        self.uncertainty_patterns = [
            r"insufficient evidence", r"not enough information", r"cannot determine", r"unclear from",
            r"does not (?:contain|include|mention)", r"no (?:records|information) (?:were|was)? ?(?:found|returned)",
            r"unable to (?:determine|find)", r"is missing",
        ]

    # ------------------------------------------------------------------ public
    def verify(self, answer: str, context: List[str], question: str,
               ground_truth: Optional[Dict[str, Any]] = None) -> VerificationResult:
        text = answer or ""
        evidence = "\n".join(context or [])
        ev_norm = evidence.replace(",", "")
        supported, unsupported, warnings, gaps = [], [], [], []

        ids = sorted(set(_ID.findall(text)) | set(_API.findall(text)))
        for ident in ids:
            (supported if ident in evidence else unsupported).append(ident)
        numbers = {_norm_num(n) for n in _NUM.findall(text)} - {i.replace(",", "") for i in ids}
        numbers = {n for n in numbers if not re.fullmatch(r"(19|20)\d\d", n)}      # years are not claims
        unsupported_numbers = sorted(n for n in numbers if n not in ev_norm)
        supported += sorted(n for n in numbers if n in ev_norm)
        if unsupported_numbers:
            warnings.append(f"Figures not found in the retrieved context: {', '.join(unsupported_numbers[:6])}")
        unsupported += unsupported_numbers
        for pattern in self.hallucination_patterns:
            m = re.search(pattern, text, re.I)
            if m:
                warnings.append(f"Possible ungrounded statement: '{m.group(0)}'")
        acknowledges = any(re.search(p, text, re.I) for p in self.uncertainty_patterns)
        if not evidence.strip():
            gaps.append("The retriever returned no context; the answer cannot be grounded.")
        if acknowledges:
            gaps.append("The answer states that part of the requested information is missing from the graph.")

        claims = len(supported) + len(unsupported)
        grounding = (len(supported) / claims) if claims else (0.6 if evidence.strip() else 0.0)
        grounding -= 0.1 * sum(1 for w in warnings if w.startswith("Possible ungrounded"))
        if ground_truth and ground_truth.get("score") is not None and (ground_truth.get("matched") or ground_truth.get("missing")):
            gt = float(ground_truth["score"])
            grounding = 0.5 * grounding + 0.5 * gt
            missing = ground_truth.get("missing") or []
            if missing:
                gaps.append(f"Expected facts not found in the answer: {', '.join(missing[:6])}")
        grounding = max(0.0, min(1.0, grounding))
        verified = grounding >= 0.7 and not any(w.startswith("Possible ungrounded") for w in warnings) and bool(evidence.strip())
        return VerificationResult(verified=verified, grounding_score=round(grounding, 3), supported_claims=supported[:30],
                                  unsupported_claims=unsupported[:30], warnings=warnings, evidence_gaps=gaps)


answer_verifier = AnswerVerifier()
