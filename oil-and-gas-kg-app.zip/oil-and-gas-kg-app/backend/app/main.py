"""
Main FastAPI application entry point

Run:  python -m app.main            (or: uvicorn app.main:app --reload --port 8000)
Docs: http://127.0.0.1:8000/docs
"""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app import __version__
from app.api.middleware import setup_middleware
from app.api.routes import api_router, health_payload
from app.core.config import kg_settings, settings
from app.graph.neo4j_client import neo4j_client
from app.kg.log import setup_logging

setup_logging(False)
logger = logging.getLogger(__name__)

_project = kg_settings().section("project")


@asynccontextmanager
async def lifespan(_app: FastAPI):
    yield
    neo4j_client.close()


app = FastAPI(title=_project.get("name", settings.app_name), description=_project.get("subtitle", "Knowledge Graph Intelligence"),
              version=__version__, debug=settings.debug, lifespan=lifespan)

setup_middleware(app, kg_settings().config)

_origins = list(dict.fromkeys([settings.frontend_url, *kg_settings().section("api").get("cors_origins", [])]))
app.add_middleware(CORSMiddleware, allow_origins=_origins, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

app.include_router(api_router, prefix="/api")


@app.get("/health")
async def health_check():
    """Backend, Neo4j, graph, semantic model, LLM and embedder status"""
    return health_payload()


@app.get("/")
async def root():
    return {"message": f"Welcome to the {_project.get('name', settings.app_name)} API", "version": __version__,
            "docs": "/docs", "health": "/health"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app.main:app", host=settings.api_host, port=settings.api_port, reload=settings.debug)
