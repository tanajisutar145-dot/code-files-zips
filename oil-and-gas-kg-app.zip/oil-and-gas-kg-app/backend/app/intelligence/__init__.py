"""
AI intelligence module - GraphRAG question answering (routing, fallback, evidence graph, trace, verification)
"""

from .models import (
    GraphRAGRequest, GraphRAGResponse, GraphRAGAnswer,
    ConfidenceLevel, EvidenceReference, VerificationResult, ContextConfig
)
from .graphrag_service import GraphRAGService, graphrag_service

__all__ = [
    "GraphRAGRequest", "GraphRAGResponse", "GraphRAGAnswer",
    "ConfidenceLevel", "EvidenceReference", "VerificationResult", "ContextConfig",
    "GraphRAGService", "graphrag_service",
]
