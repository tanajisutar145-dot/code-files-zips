"""
GraphRAG service for grounded question answering.

Wraps the knowledge-graph QA engine (``app.kg.qa.engine``, ported from utility-knowledge-graph-v3):

* routing - Text2Cypher for exact sets, counts, traces and rankings; vector / hybrid search with a graph
  expansion template (causal chain, well identity, lineage, equipment peers) for narrative questions;
* fallback - Text2Cypher errors or empty results fall back to hybrid search and vice versa;
* evidence graph - the records behind the answer, with standard classes and WGS84 positions;
* trace - every backend step with timings, the generated Cypher or retrieval query and the context;
* verification - grounding against the retrieved context (``app.verification``) and, for the curated
  demo questions, a deterministic ground-truth fact check.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Any, Dict, List, Optional

from app.core.config import kg_settings, settings
from app.intelligence.models import ConfidenceLevel, GraphRAGRequest, GraphRAGResponse, VerificationResult
from app.services.common import semantic_model
from app.verification import answer_verifier

logger = logging.getLogger(__name__)

MODES = {"auto", "compare", "text2cypher", "vector_cypher", "hybrid_cypher"}


class GraphRAGService:
    """Lazily started, process-wide QA engine (one Neo4j driver, one LLM and embedder)."""

    def __init__(self):
        self._engine = None
        self._error: Optional[str] = None
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ engine
    def engine(self):
        if self._engine is not None:
            return self._engine
        with self._lock:
            if self._engine is None:
                from app.kg.qa.engine import QAEngine

                try:
                    self._engine = QAEngine(kg_settings(), semantic_model())
                    self._error = None
                except SystemExit as exc:       # configuration / connection problems are reported, not raised
                    self._error = str(exc)
                    raise RuntimeError(f"Knowledge graph QA engine unavailable: {exc}") from exc
        return self._engine

    def status(self) -> Dict[str, Any]:
        return {"started": self._engine is not None, "error": self._error}

    def info(self) -> Dict[str, Any]:
        return self.engine().info()

    # ------------------------------------------------------------------ jobs
    def submit(self, request: GraphRAGRequest) -> Dict[str, Any]:
        """Start answering; returns either an immediate reply (small talk) or a job id to poll."""
        eng = self.engine()
        reply = eng.small_talk(request.question)
        if reply is not None:
            return {"reply": reply}
        if len(request.question.strip()) < 4:
            return {"reply": "Could you ask a full question? For example: which equipment failures were preceded by an "
                             "inspection finding? Or type help to see what I can do."}
        mode = request.mode if request.mode in MODES else "auto"
        if mode in ("vector_cypher", "hybrid_cypher") and not eng.has_chunks:
            raise ValueError("No embedded narrative chunks are loaded; run `python -m app.kg run --step load` with an embedder configured.")
        job = eng.submit(request.question, mode, request.history)
        return {"job_id": job.id}

    def job(self, job_id: str) -> Dict[str, Any]:
        j = self.engine().jobs.get(job_id)
        if j is None:
            raise KeyError(job_id)
        return j.to_json()

    def latest(self) -> Optional[Dict[str, Any]]:
        eng = self.engine()
        return eng.jobs[eng.latest_id].to_json() if eng.latest_id else None

    # ------------------------------------------------------------------ synchronous
    def ask_question(self, request: GraphRAGRequest) -> GraphRAGResponse:
        """Answer a question and wait for the result (reference API contract)."""
        if not request.question.strip():
            raise ValueError("Question cannot be empty")
        t0 = time.time()
        started = self.submit(request)
        if "reply" in started:
            return self._small_talk_response(request.question, started["reply"], time.time() - t0)
        eng = self.engine()
        job = eng.wait(started["job_id"], timeout=settings.ask_timeout_seconds)
        if job.status not in ("done", "error"):
            raise RuntimeError(f"The answer is still being generated (job {job.id}); poll /api/intelligence/jobs/{job.id}.")
        return self._response(job, request, time.time() - t0)

    def response_for_job(self, job_id: str, request: GraphRAGRequest | None = None) -> GraphRAGResponse:
        job = self.engine().jobs[job_id]
        return self._response(job, request or GraphRAGRequest(question=job.question, mode=job.mode), (job.finished or time.time()) - job.started)

    # ------------------------------------------------------------------ mapping
    def _small_talk_response(self, question: str, reply: str, elapsed: float) -> GraphRAGResponse:
        return GraphRAGResponse(question=question, answer=reply, confidence=ConfidenceLevel.HIGH,
                                verification=VerificationResult(verified=True, grounding_score=1.0,
                                                                warnings=["Conversational reply; no graph lookup."]),
                                evidence={"semantic_results": [], "graph_evidence": {"entities": [], "relationships": []},
                                          "evidence_graph": {"nodes": [], "edges": []}},
                                sources={"documents": [], "entities": []},
                                metadata={"execution_time": elapsed, "retrieval_method": "small_talk"})

    def _response(self, job, request: GraphRAGRequest, elapsed: float) -> GraphRAGResponse:
        primary = next((r for r in job.runs if r["retriever"] == job.retriever), job.runs[0] if job.runs else {})
        context: List[str] = primary.get("context", []) if primary else []
        verify_step = next((s for s in job.steps if s.key == "verify"), None)
        gt = job.verification
        if request.include_verification:
            verification = answer_verifier.verify(job.answer, context, job.question, gt)
        else:
            verification = VerificationResult(verified=False, grounding_score=0.5, warnings=["Answer was not verified"])
        if job.status == "error":
            verification.warnings.append(job.error or "The question failed.")
        confidence = self._confidence(verification, context, job.status)
        semantic_results = [{"chunk_id": f"{job.id}#{i}", "document_id": self._source_of(c), "document_title": self._source_of(c),
                             "text": c, "score": 0.0, "source": primary.get("retriever"), "metadata": {}}
                            for i, c in enumerate(context) if c.startswith("SOURCE ROW:")]
        nodes = job.graph.get("nodes", [])
        edges = job.graph.get("edges", [])
        entities = [{"entity_id": n["id"], "entity_type": n["group"], "properties": {**n.get("props", {}), "caption": n["label"],
                                                                                      "std": n.get("std"), "evidence": n.get("evidence")}}
                    for n in nodes]
        by_id = {n["id"]: n for n in nodes}
        relationships = [{"source_id": e["from"], "target_id": e["to"], "relationship_type": e["label"],
                          "source_type": by_id.get(e["from"], {}).get("group", ""), "target_type": by_id.get(e["to"], {}).get("group", ""),
                          "properties": {"std_association": e.get("std")}} for e in edges]
        llm = kg_settings().llm
        return GraphRAGResponse(
            question=job.question, answer=job.answer or (f"**Error:** {job.error}" if job.error else ""), confidence=confidence,
            verification=verification,
            evidence={"semantic_results": semantic_results, "graph_evidence": {"entities": entities, "relationships": relationships},
                      "evidence_graph": job.graph},
            sources={"documents": sorted({r["document_id"] for r in semantic_results}),
                     "entities": [n["label"] for n in nodes if n.get("evidence")]},
            metadata={"execution_time": elapsed, "retrieval_method": job.retriever, "status": job.status,
                      "llm_model": f"{llm.provider}/{llm.model}" if llm else None, "verification_enabled": request.include_verification,
                      "question_id": (job.step("route").detail or {}).get("question_id"),
                      "ground_truth": gt, "cypher": primary.get("cypher"), "retrieval_query": primary.get("retrieval_query"),
                      "verify_summary": verify_step.summary if verify_step else None},
            retriever=job.retriever, runs=job.runs,
            trace=[{"key": s.key, "title": s.title, "status": s.status, "seconds": s.seconds, "summary": s.summary, "detail": s.detail}
                   for s in job.steps],
            job_id=job.id)

    @staticmethod
    def _source_of(item: str) -> str:
        first = item.split("\n", 1)[0].replace("SOURCE ROW:", "").strip()
        return first.split(" {")[0][:80]

    @staticmethod
    def _confidence(v: VerificationResult, context: List[str], status: str) -> ConfidenceLevel:
        if status == "error" or not context:
            return ConfidenceLevel.VERY_LOW
        evidence_strength = min(1.0, len(context) / 5)
        score = (v.grounding_score + evidence_strength) / 2
        if score >= 0.8 and v.verified:
            return ConfidenceLevel.HIGH
        if score >= 0.6:
            return ConfidenceLevel.MEDIUM
        if score >= 0.4:
            return ConfidenceLevel.LOW
        return ConfidenceLevel.VERY_LOW


graphrag_service = GraphRAGService()
