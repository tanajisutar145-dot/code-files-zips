"""
Models for GraphRAG intelligence operations
"""

from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class ConfidenceLevel(str, Enum):
    """Confidence levels for GraphRAG answers"""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    VERY_LOW = "very_low"


class EvidenceReference(BaseModel):
    """Reference to supporting evidence"""
    evidence_id: str = Field(..., description="Evidence identifier (record id, chunk id)")
    evidence_type: str = Field(..., description="Type of evidence (record, chunk, relationship)")
    reason: str = Field(..., description="Why this evidence supports the claim")
    relevance_score: Optional[float] = Field(None, description="Relevance score if available")


class VerificationResult(BaseModel):
    """Result from answer verification process"""
    verified: bool = Field(..., description="Whether answer is verified against evidence")
    grounding_score: float = Field(..., description="Overall grounding score (0.0 to 1.0)")
    supported_claims: List[str] = Field(default_factory=list, description="Claims supported by evidence")
    unsupported_claims: List[str] = Field(default_factory=list, description="Claims not supported by evidence")
    warnings: List[str] = Field(default_factory=list, description="Verification warnings")
    evidence_gaps: List[str] = Field(default_factory=list, description="Areas where evidence is insufficient")


class GraphRAGAnswer(BaseModel):
    """Complete GraphRAG answer with verification"""
    question: str
    answer: str
    confidence: ConfidenceLevel
    supporting_evidence: List[EvidenceReference] = Field(default_factory=list)
    verification: VerificationResult
    metadata: Dict[str, Any] = Field(default_factory=dict)


class GraphRAGRequest(BaseModel):
    """Request for GraphRAG question answering"""
    question: str = Field(..., description="Natural language question", min_length=1, max_length=2000)
    mode: str = Field("auto", description="auto | compare | text2cypher | vector_cypher | hybrid_cypher")
    history: List[Dict[str, str]] = Field(default_factory=list, description="Previous turns: [{role, content}]")
    top_k: int = Field(5, description="Number of chunks to retrieve (vector / hybrid)", ge=1, le=20)
    graph_depth: int = Field(1, description="Graph expansion depth for /search/retrieve", ge=0, le=3)
    min_similarity: float = Field(0.0, description="Minimum similarity threshold", ge=0.0, le=1.0)
    include_verification: bool = Field(True, description="Whether to include verification step")


class GraphRAGResponse(BaseModel):
    """Complete GraphRAG API response (reference contract + retriever, trace and evidence graph)"""
    question: str
    answer: str
    confidence: ConfidenceLevel
    verification: VerificationResult
    evidence: Dict[str, Any] = Field(..., description="semantic_results, graph_evidence, evidence_graph")
    sources: Dict[str, List[str]] = Field(..., description="documents, entities")
    metadata: Dict[str, Any] = Field(..., description="execution_time, retriever, models, question id, ground truth")
    retriever: str = Field("", description="Retriever that produced the answer")
    runs: List[Dict[str, Any]] = Field(default_factory=list, description="Every retriever run (compare mode)")
    trace: List[Dict[str, Any]] = Field(default_factory=list, description="Routing, retrieval, context, generation, graph, verification")
    job_id: Optional[str] = None


class ContextConfig(BaseModel):
    """Configuration for context building"""
    max_chunks: int = 10
    max_chunk_length: int = 1000
    max_entities: int = 20
    max_relationships: int = 30
    include_metadata: bool = True
    truncate_long_text: bool = True
