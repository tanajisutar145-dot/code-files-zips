"""
Document chunking service for processing unstructured content with format-aware provenance
"""

import re
from typing import List, Dict, Any, Optional
from .models import Document, Chunk


class DocumentChunker:
    """Service for chunking documents into manageable pieces with structure awareness"""

    def __init__(self, chunk_size: int = 1000, overlap: int = 100):
        self.chunk_size = chunk_size
        self.overlap = overlap

    def chunk_document(self, document: Document) -> List[Chunk]:
        """
        Chunk a document into smaller text segments preserving section-level provenance.

        Args:
            document: Document to chunk

        Returns:
            List of chunks with source metadata
        """
        sections = document.metadata.get("sections") if document.metadata else None

        # If document has structured sections (from PDF pages, Excel rows, Word sections, etc.)
        if sections and isinstance(sections, list) and len(sections) > 0:
            return self._chunk_structured_sections(document, sections)

        # Baseline chunking for unsectioned plain text
        return self._chunk_plain_text(document, document.content)

    def _chunk_structured_sections(self, document: Document, sections: List[Any]) -> List[Chunk]:
        """Chunk document along section boundaries, attaching provenance to every chunk"""
        chunks: List[Chunk] = []
        chunk_index = 0

        for sec in sections:
            # Handle both dicts and ExtractedSection instances
            if hasattr(sec, "model_dump"):
                sec_dict = sec.model_dump()
            elif isinstance(sec, dict):
                sec_dict = sec
            else:
                sec_dict = getattr(sec, "__dict__", {})

            sec_content = sec_dict.get("content", "").strip()
            if not sec_content:
                continue

            sec_meta: Dict[str, Any] = {}
            if sec_dict.get("page_number") is not None:
                sec_meta["page_number"] = sec_dict["page_number"]
            if sec_dict.get("sheet_name"):
                sec_meta["sheet_name"] = sec_dict["sheet_name"]
            if sec_dict.get("row_start") is not None and sec_dict.get("row_end") is not None:
                sec_meta["row_start"] = sec_dict["row_start"]
                sec_meta["row_end"] = sec_dict["row_end"]
                sec_meta["row_range"] = f"Rows {sec_dict['row_start']}-{sec_dict['row_end']}"
            elif sec_dict.get("row_start") is not None:
                sec_meta["row_start"] = sec_dict["row_start"]
                sec_meta["row_range"] = f"Row {sec_dict['row_start']}"
            if sec_dict.get("section_title"):
                sec_meta["section_title"] = sec_dict["section_title"]
            elif sec_dict.get("title"):
                sec_meta["section_title"] = sec_dict["title"]

            # If section content fits within chunk_size, keep it intact
            if len(sec_content) <= self.chunk_size:
                chunk = self._create_chunk(
                    document.document_id,
                    chunk_index,
                    sec_content,
                    document,
                    extra_meta=sec_meta,
                )
                chunks.append(chunk)
                chunk_index += 1
            else:
                # Sub-chunk the section content while retaining section provenance
                sub_chunks = self._split_text_to_chunks(
                    sec_content,
                    document.document_id,
                    start_index=chunk_index,
                    document=document,
                    extra_meta=sec_meta,
                )
                chunks.extend(sub_chunks)
                chunk_index += len(sub_chunks)

        # Fallback if all sections were empty
        if not chunks and document.content.strip():
            return self._chunk_plain_text(document, document.content)

        return chunks

    def _chunk_plain_text(self, document: Document, text: str) -> List[Chunk]:
        """Baseline sentence-splitting chunker preserving legacy behavior"""
        return self._split_text_to_chunks(text, document.document_id, 0, document)

    def _split_text_to_chunks(
        self,
        text: str,
        document_id: str,
        start_index: int,
        document: Document,
        extra_meta: Optional[Dict[str, Any]] = None,
    ) -> List[Chunk]:
        """Split text into sentence-aware chunks with overlap"""
        sentences = self._split_into_sentences(text)
        chunks: List[Chunk] = []
        current_chunk = ""
        current_length = 0
        chunk_index = start_index

        for sentence in sentences:
            sentence_length = len(sentence)

            if current_length + sentence_length > self.chunk_size and current_chunk:
                chunk = self._create_chunk(
                    document_id,
                    chunk_index,
                    current_chunk.strip(),
                    document,
                    extra_meta=extra_meta,
                )
                if chunk.text.strip():
                    chunks.append(chunk)
                    chunk_index += 1

                current_chunk = self._get_overlap_text(current_chunk)
                current_length = len(current_chunk)

            current_chunk += sentence + " "
            current_length += sentence_length + 1

        if current_chunk.strip():
            chunk = self._create_chunk(
                document_id,
                chunk_index,
                current_chunk.strip(),
                document,
                extra_meta=extra_meta,
            )
            if chunk.text.strip():
                chunks.append(chunk)

        return chunks

    def _split_into_sentences(self, text: str) -> List[str]:
        """Split text into sentences using regex"""
        sentences = re.split(r'[.!?]+\s+|\n\n+', text)
        return [s.strip() for s in sentences if s.strip()]

    def _get_overlap_text(self, text: str) -> str:
        """Get overlap text from end of current chunk"""
        if len(text) <= self.overlap:
            return text

        overlap_point = len(text) - self.overlap
        space_pos = text.find(' ', overlap_point)

        if space_pos != -1:
            return text[space_pos + 1:]
        else:
            return text[overlap_point:]

    def _create_chunk(
        self,
        document_id: str,
        chunk_index: int,
        text: str,
        document: Document,
        extra_meta: Optional[Dict[str, Any]] = None,
    ) -> Chunk:
        """Create a Chunk object with complete document and section metadata"""
        chunk_id = f"{document_id}_chunk_{chunk_index:03d}"

        metadata: Dict[str, Any] = {
            "document_type": document.document_type if isinstance(document.document_type, str) else document.document_type.value,
            "document_title": document.title,
            "source": document.source,
            "created_date": document.created_date.isoformat(),
            "chunk_length": len(text),
        }

        # Add document-level source info if present
        if document.metadata:
            for k in ["format", "source_filename", "page_count", "sheet_names", "table_count"]:
                if document.metadata.get(k) is not None:
                    metadata[k] = document.metadata[k]

        # Add section provenance
        if extra_meta:
            for k, v in extra_meta.items():
                if v is not None:
                    metadata[k] = v

        # Record identifiers named in the document metadata
        if document.linked_records:
            metadata["linked_records"] = list(document.linked_records)

        return Chunk(
            chunk_id=chunk_id,
            document_id=document_id,
            chunk_index=chunk_index,
            text=text,
            metadata=metadata,
        )