"""
Document loader for Neo4j.

Uploaded documents are written in the same lexical-graph shape the pipeline uses for record narratives, so
GraphRAG retrieves them with the same vector / full-text indexes and graph expansions:

    (:Document {path: 'upload/<document_id>', document_id, title, document_type, ...})
    (:Chunk {id, chunk_id, text, index, embedding, page_number, section_title, ...})-[:FROM_DOCUMENT]->(:Document)
    (record)-[:HAS_NARRATIVE]->(:Document)            for every record the document mentions
    (:Document)-[:MENTIONS_RECORD {confidence, context}]->(record)
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from app.core.config import kg_settings

from .models import Chunk, Document, EntityReference
from .processor import DocumentProcessor

logger = logging.getLogger(__name__)

_WRITE_DOC = """
MERGE (d:Document {path: $doc.path})
SET d += $doc.props, d.caption = $doc.props.title
"""
_WRITE_CHUNKS = """
MATCH (d:Document {path: $path})
UNWIND $chunks AS ch
MERGE (c:Chunk {id: ch.id})
SET c.chunk_id = ch.chunk_id, c.document_id = $document_id, c.text = ch.text, c.index = ch.index,
    c.page_number = ch.page_number, c.sheet_name = ch.sheet_name, c.section_title = ch.section_title, c.row_range = ch.row_range,
    c.embedding = ch.embedding, c.embedding_model = ch.embedding_model, c.caption = ch.chunk_id
MERGE (c)-[:FROM_DOCUMENT]->(d)
"""
_LINK = """
MATCH (d:Document {path: $path})
UNWIND $refs AS ref
MATCH (n) WHERE elementId(n) = ref.id
MERGE (d)-[m:MENTIONS_RECORD]->(n) SET m.confidence = ref.confidence, m.context = ref.context, m.caption = ref.caption
MERGE (n)-[:HAS_NARRATIVE]->(d)
"""
_DELETE = """
MATCH (d:Document {document_id: $document_id})
OPTIONAL MATCH (c:Chunk)-[:FROM_DOCUMENT]->(d)
WITH d, collect(c) AS cs
FOREACH (c IN cs | DETACH DELETE c)
DETACH DELETE d
RETURN count(*) AS deleted
"""


class DocumentLoader:
    """Loads documents and chunks (with embeddings when an embedder is configured) into Neo4j."""

    def __init__(self, neo4j_client, embed_fn=None, embedding_model: Optional[str] = None, chunk_size: int = 1000, overlap: int = 120):
        self.neo4j_client = neo4j_client
        self.processor = DocumentProcessor(neo4j_client=neo4j_client, chunk_size=chunk_size, overlap=overlap)
        self.embed_fn = embed_fn
        self.embedding_model = embedding_model

    def create_document_schema(self) -> None:
        for stmt in ("CREATE CONSTRAINT uploaded_document_id IF NOT EXISTS FOR (d:Document) REQUIRE d.document_id IS UNIQUE",
                     "CREATE INDEX document_type_idx IF NOT EXISTS FOR (d:Document) ON (d.document_type)",
                     "CREATE INDEX chunk_document_id_idx IF NOT EXISTS FOR (c:Chunk) ON (c.document_id)"):
            try:
                self.neo4j_client.execute_write(stmt)
            except Exception as e:  # noqa: BLE001
                logger.warning(f"Schema statement failed ({stmt[:40]}...): {e}")

    def ensure_vector_index(self, dimensions: int) -> None:
        """Create the chunk vector / full-text indexes when the pipeline has not created them yet."""
        idx = kg_settings().section("indexes")
        vec, ft = idx.get("vector", {}), idx.get("fulltext", {})
        try:
            self.neo4j_client.execute_write(
                f"CREATE VECTOR INDEX {vec.get('name', 'chunk_embeddings')} IF NOT EXISTS FOR (c:{vec.get('label', 'Chunk')}) "
                f"ON (c.{vec.get('property', 'embedding')}) OPTIONS {{indexConfig: {{`vector.dimensions`: {int(dimensions)}, "
                f"`vector.similarity_function`: '{vec.get('similarity', 'cosine')}'}}}}")
            self.neo4j_client.execute_write(
                f"CREATE FULLTEXT INDEX {ft.get('name', 'chunk_fulltext')} IF NOT EXISTS FOR (c:{ft.get('label', 'Chunk')}) ON EACH [c.text]")
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Could not ensure vector index: {e}")

    # ------------------------------------------------------------------ load
    def load_document(self, document: Document) -> Dict[str, Any]:
        try:
            existing = self.neo4j_client.execute_query("MATCH (d:Document {document_id: $id}) RETURN d.content_hash AS h", {"id": document.document_id})
            if existing and existing[0]["h"] == document.content_hash:
                return {"document_id": document.document_id, "action": "skipped", "reason": "unchanged_content", "chunks_created": 0,
                        "relationships_created": 0, "entity_links": 0, "embedded": False}
            if not existing:
                dup = self.neo4j_client.execute_query("MATCH (d:Document {content_hash: $h}) WHERE d.document_id IS NOT NULL RETURN d.document_id AS id",
                                                      {"h": document.content_hash})
                if dup:
                    return {"document_id": dup[0]["id"], "action": "skipped", "reason": "duplicate_content_hash", "chunks_created": 0,
                            "relationships_created": 0, "entity_links": 0, "embedded": False}
            else:
                self.delete(document.document_id)
            self.create_document_schema()
            chunks = self.processor.chunker.chunk_document(document)
            refs = self.processor.entity_linker.link_document_entities(document)
            embedded = self._write(document, chunks, refs)
            return {"document_id": document.document_id, "action": "updated" if existing else "created", "chunks_created": len(chunks),
                    "relationships_created": len(chunks) + 2 * len(refs), "entity_links": len(refs), "embedded": embedded,
                    "linked_records": [{"type": r.entity_type, "caption": r.caption} for r in refs]}
        except Exception as e:  # noqa: BLE001
            logger.error(f"Document load failed: {e}", exc_info=True)
            return {"document_id": document.document_id, "action": "failed", "error": str(e), "chunks_created": 0, "relationships_created": 0,
                    "entity_links": 0, "embedded": False}

    def load_documents(self, documents: List[Document]) -> Dict[str, Any]:
        results = [self.load_document(d) for d in documents]
        return {"documents": len(results), "results": results,
                "created": sum(r["action"] == "created" for r in results), "updated": sum(r["action"] == "updated" for r in results),
                "skipped": sum(r["action"] == "skipped" for r in results), "failed": sum(r["action"] == "failed" for r in results)}

    def _write(self, document: Document, chunks: List[Chunk], refs: List[EntityReference]) -> bool:
        path = f"upload/{document.document_id}"
        meta = document.metadata or {}
        props = {"document_id": document.document_id, "title": document.title, "document_type": document.document_type,
                 "source": document.source, "source_reference": document.source_reference, "created_date": document.created_date.isoformat(),
                 "content": document.content, "content_hash": document.content_hash, "processing_status": "completed",
                 "format": meta.get("format"), "source_filename": meta.get("source_filename"),
                 "warnings": [str(w) for w in meta.get("warnings", [])], "kind": "uploaded", "source_label": "UploadedDocument"}
        self.neo4j_client.execute_write(_WRITE_DOC, {"doc": {"path": path, "props": {k: v for k, v in props.items() if v is not None}}})
        embedded = False
        payload = []
        for c in chunks:
            vec = None
            if self.embed_fn is not None:
                try:
                    vec = self.embed_fn(c.text)
                    embedded = True
                except Exception as e:  # noqa: BLE001
                    logger.warning(f"Embedding failed for {c.chunk_id}: {e}")
            m = c.metadata or {}
            payload.append({"id": f"{path}#{c.chunk_index}", "chunk_id": c.chunk_id, "text": c.text, "index": c.chunk_index,
                            "page_number": m.get("page_number"), "sheet_name": m.get("sheet_name"), "section_title": m.get("section_title"),
                            "row_range": f"{m.get('row_start')}-{m.get('row_end')}" if m.get("row_start") is not None else None,
                            "embedding": vec, "embedding_model": self.embedding_model if vec else None})
        if embedded:
            self.ensure_vector_index(len(next(p["embedding"] for p in payload if p["embedding"])))
        self.neo4j_client.execute_write(_WRITE_CHUNKS, {"path": path, "document_id": document.document_id, "chunks": payload})
        if refs:
            self.neo4j_client.execute_write(_LINK, {"path": path, "refs": [{"id": r.entity_id, "confidence": r.confidence, "context": r.context[:300],
                                                                              "caption": r.caption} for r in refs]})
        return embedded

    def delete(self, document_id: str) -> bool:
        res = self.neo4j_client.execute_write(_DELETE, {"document_id": document_id})
        return res.get("nodes_deleted", 0) > 0
