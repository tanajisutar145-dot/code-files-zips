"""
Entity linking: connect documents to the records of the knowledge graph they mention.

Model-agnostic: instead of hard-coded id patterns, the linker uses the graph itself - every data record has a
``caption`` (well name, equipment tag, event / work-order / NOV number...) written at load time. Captions that
look like identifiers (contain a digit, or are long names) are matched in the text, and API / US Well Numbers
in any format are resolved to their ``WellIdentity`` (API-10).
"""

from __future__ import annotations

import logging
import re
import threading
import time
from typing import Dict, List, Optional, Tuple

from .models import Chunk, Document, EntityReference

logger = logging.getLogger(__name__)

_API = re.compile(r"\b(\d{2})-?(\d{3})-?(\d{5})(?:-?\d{2}-?\d{2})?\b")
_SKIP_LABELS = ("Chunk", "Document", "OntologyClass", "StandardClass", "OntologyProperty", "StandardAttribute", "SubjectArea")


class EntityLinker:
    """Links documents and chunks to graph records by caption and API number."""

    def __init__(self, neo4j_client=None, refresh_seconds: float = 300.0):
        self.neo4j_client = neo4j_client
        self.refresh_seconds = refresh_seconds
        self._index: List[Tuple[str, str, str]] = []   # (caption, label, elementId)
        self._loaded = 0.0
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ caption index
    def _caption_index(self) -> List[Tuple[str, str, str]]:
        if self.neo4j_client is None:
            return []
        with self._lock:
            if time.time() - self._loaded > self.refresh_seconds:
                try:
                    rows = self.neo4j_client.execute_query(
                        "MATCH (n) WHERE n.caption IS NOT NULL AND none(l IN labels(n) WHERE l IN $skip) "
                        "RETURN n.caption AS caption, [l IN labels(n) WHERE NOT l STARTS WITH 'STD_' AND NOT l STARTS WITH '__'][0] AS label, "
                        "elementId(n) AS id", {"skip": list(_SKIP_LABELS)})
                    idx = [(r["caption"], r["label"], r["id"]) for r in rows
                           if r["caption"] and (any(ch.isdigit() for ch in r["caption"]) and len(r["caption"]) >= 5 or len(r["caption"]) >= 14)]
                    self._index = sorted(idx, key=lambda x: -len(x[0]))       # longest first: "Falcon Draw 10-1H ST01" before "Falcon Draw 10-1H"
                    self._loaded = time.time()
                except Exception as e:  # noqa: BLE001
                    logger.warning(f"Entity linker could not read the caption index: {e}")
            return self._index

    # ------------------------------------------------------------------ public
    def link_document_entities(self, document: Document) -> List[EntityReference]:
        refs = self._find(document.content)
        for name in document.linked_records:
            for ref in self._find(name):
                ref.confidence, ref.context = 1.0, "document metadata"
                refs.append(ref)
        seen: Dict[str, EntityReference] = {}
        for r in refs:
            if r.entity_id not in seen or seen[r.entity_id].confidence < r.confidence:
                seen[r.entity_id] = r
        return list(seen.values())

    def link_chunk_entities(self, chunk: Chunk) -> List[str]:
        return sorted({r.caption for r in self._find(chunk.text)})

    # ------------------------------------------------------------------ matching
    def _find(self, text: str) -> List[EntityReference]:
        out: List[EntityReference] = []
        if not text:
            return out
        lowered = text.lower()
        taken: List[Tuple[int, int]] = []
        for caption, label, eid in self._caption_index():
            pos = lowered.find(caption.lower())
            if pos < 0 or any(a <= pos < b for a, b in taken):
                continue
            taken.append((pos, pos + len(caption)))
            out.append(EntityReference(entity_type=label or "Entity", entity_id=eid, caption=caption, confidence=0.9,
                                       context=text[max(0, pos - 60): pos + len(caption) + 60].strip()))
        for m in _API.finditer(text):
            api10 = "".join(m.groups())
            ident = self._well_identity(api10)
            if ident:
                out.append(EntityReference(entity_type="WellIdentity", entity_id=ident, caption=f"API {m.group(0)}", confidence=0.95,
                                           context=text[max(0, m.start() - 60): m.end() + 60].strip()))
        return out

    def _well_identity(self, api10: str) -> Optional[str]:
        if self.neo4j_client is None:
            return None
        try:
            rows = self.neo4j_client.execute_query("MATCH (i:WellIdentity {api10: $a}) RETURN elementId(i) AS id", {"a": api10})
            return rows[0]["id"] if rows else None
        except Exception:  # noqa: BLE001
            return None

    def get_document_entity_links(self, document: Document) -> Dict[str, List[str]]:
        links: Dict[str, List[str]] = {}
        for ref in self.link_document_entities(document):
            links.setdefault(ref.entity_type, [])
            if ref.caption not in links[ref.entity_type]:
                links[ref.entity_type].append(ref.caption)
        return links
