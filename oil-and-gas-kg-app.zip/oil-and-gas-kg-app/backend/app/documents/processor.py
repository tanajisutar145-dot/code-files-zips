"""
Document processing pipeline for unstructured content
"""

import json
from typing import List, Dict, Any, Optional
from pathlib import Path
from .models import Document, Chunk, DocumentProcessingResult, ProcessingStatus
from .chunker import DocumentChunker
from .entity_linker import EntityLinker


class DocumentProcessor:
    """Main document processing pipeline"""
    
    def __init__(self, neo4j_client=None, chunk_size: int = 1000, overlap: int = 100):
        self.neo4j_client = neo4j_client
        self.chunker = DocumentChunker(chunk_size=chunk_size, overlap=overlap)
        self.entity_linker = EntityLinker(neo4j_client=neo4j_client)
    
    def process_document(self, document: Document) -> DocumentProcessingResult:
        """
        Process a single document through the complete pipeline
        
        Args:
            document: Document to process
            
        Returns:
            Processing result with statistics
        """
        try:
            # Update processing status
            document.processing_status = ProcessingStatus.PROCESSING
            
            # Chunk the document
            chunks = self.chunker.chunk_document(document)
            
            # Link entities for each chunk
            for chunk in chunks:
                chunk.referenced_entities = self.entity_linker.link_chunk_entities(chunk)
            
            # Link document-level entities
            entity_refs = self.entity_linker.link_document_entities(document)
            entity_links = len(entity_refs)
            
            # Update processing status
            document.processing_status = ProcessingStatus.COMPLETED
            
            return DocumentProcessingResult(
                document_id=document.document_id,
                chunks_created=len(chunks),
                entity_links=entity_links,
                processing_status=ProcessingStatus.COMPLETED
            )
            
        except Exception as e:
            document.processing_status = ProcessingStatus.FAILED
            return DocumentProcessingResult(
                document_id=document.document_id,
                chunks_created=0,
                entity_links=0,
                processing_status=ProcessingStatus.FAILED,
                error_message=str(e)
            )
    
    def process_documents(self, documents: List[Document]) -> List[DocumentProcessingResult]:
        """
        Process multiple documents
        
        Args:
            documents: List of documents to process
            
        Returns:
            List of processing results
        """
        results = []
        for document in documents:
            result = self.process_document(document)
            results.append(result)
        
        return results
    
    def load_document_from_json(self, file_path: Path) -> Document:
        """
        Load a document from JSON file
        
        Args:
            file_path: Path to JSON document file
            
        Returns:
            Document object
        """
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        return Document(**data)
    
    def discover_documents(self, directory_path: Path) -> List[Document]:
        """
        Discover and load all documents from a directory
        
        Args:
            directory_path: Directory containing document files
            
        Returns:
            List of loaded documents
        """
        documents = []
        
        # Find all JSON files in directory
        json_files = list(directory_path.glob("*.json"))
        
        for file_path in json_files:
            try:
                document = self.load_document_from_json(file_path)
                documents.append(document)
            except Exception as e:
                print(f"Error loading document {file_path}: {e}")
        
        return documents
    
    def validate_document(self, document: Document) -> Dict[str, Any]:
        """
        Validate document structure and content
        
        Args:
            document: Document to validate
            
        Returns:
            Validation result dictionary
        """
        issues = []
        
        # Check required fields
        if not document.document_id:
            issues.append("Missing document_id")
        
        if not document.content or len(document.content.strip()) == 0:
            issues.append("Empty or missing content")
        
        if not document.title:
            issues.append("Missing title")
        
        # Check content length
        if len(document.content) < 50:
            issues.append("Content too short (< 50 characters)")
        
        # Check for duplicate content hash if processing multiple documents
        # This would need to be implemented at the batch level
        
        return {
            "document_id": document.document_id,
            "valid": len(issues) == 0,
            "issues": issues,
            "content_length": len(document.content),
            "content_hash": document.content_hash
        }
    
    def get_processing_statistics(self, results: List[DocumentProcessingResult]) -> Dict[str, Any]:
        """
        Generate processing statistics from results
        
        Args:
            results: List of processing results
            
        Returns:
            Statistics dictionary
        """
        total_docs = len(results)
        completed = sum(1 for r in results if r.processing_status == ProcessingStatus.COMPLETED)
        failed = sum(1 for r in results if r.processing_status == ProcessingStatus.FAILED)
        total_chunks = sum(r.chunks_created for r in results)
        total_links = sum(r.entity_links for r in results)
        
        return {
            "total_documents": total_docs,
            "completed": completed,
            "failed": failed,
            "success_rate": completed / total_docs if total_docs > 0 else 0,
            "total_chunks": total_chunks,
            "total_entity_links": total_links,
            "average_chunks_per_document": total_chunks / total_docs if total_docs > 0 else 0
        }