"""
Document CLI: ``python -m app.documents load [folder]`` | ``list`` | ``delete <document_id>``.

Loads every supported file in a folder (default ``data/documents``) the same way the upload API does: parse,
chunk, embed (when an embedder is configured), link to the records it mentions and write to Neo4j.
JSON files that contain ``document_id`` / ``title`` / ``content`` are read as Document records directly.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from app.core.config import settings
from app.documents.loader import DocumentLoader
from app.documents.models import Document, DocumentType
from app.documents.parsers import get_parser_for_file, get_supported_extensions
from app.graph.neo4j_client import neo4j_client
from app.kg.log import setup_logging
from app.llm.client import llm_client


def to_document(path: Path) -> Document:
    if path.suffix.lower() == ".json":
        data = json.loads(path.read_text(encoding="utf-8"))
        if {"document_id", "title", "content"} <= set(data):
            return Document(**data)
    parsed = get_parser_for_file(path.name).parse(path.read_bytes(), path.name)
    meta = dict(parsed.metadata)
    doc_type = meta.get("document_type", DocumentType.OPERATIONAL_NOTE.value)
    return Document(document_id=meta.get("document_id") or f"DOC-{path.stem.upper()[:24]}", title=parsed.title, document_type=doc_type,
                    source=meta.get("source", "file"), source_reference=path.name, content=parsed.content,
                    metadata={"format": parsed.format, "source_filename": path.name, "sections": [s.model_dump() for s in parsed.sections],
                              "warnings": parsed.warnings})


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m app.documents")
    sub = parser.add_subparsers(dest="command", required=True)
    load = sub.add_parser("load", help="load all supported files of a folder")
    load.add_argument("folder", nargs="?", default=None)
    sub.add_parser("list", help="list uploaded documents")
    rm = sub.add_parser("delete", help="delete one uploaded document")
    rm.add_argument("document_id")
    args = parser.parse_args(argv)
    setup_logging(False)
    if not neo4j_client.verify_connectivity():
        print("Neo4j is not reachable: check NEO4J_* in backend/.env and start the database.", file=sys.stderr)
        return 2
    embed = llm_client.embed if llm_client.embedder_configured() else None
    loader = DocumentLoader(neo4j_client, embed_fn=embed, embedding_model=llm_client.describe()["embedder"])
    if args.command == "list":
        for r in neo4j_client.execute_query("MATCH (d:Document) WHERE d.document_id IS NOT NULL "
                                            "RETURN d.document_id AS id, d.title AS title, d.document_type AS type ORDER BY id"):
            print(f"{r['id']:<28} {r['type']:<26} {r['title']}")
        return 0
    if args.command == "delete":
        print("deleted" if loader.delete(args.document_id) else "not found")
        return 0
    folder = settings.path(args.folder or settings.documents_dir)
    files = [p for p in sorted(folder.iterdir()) if p.suffix.lower() in get_supported_extensions() + [".md"]]
    docs = []
    for p in files:
        try:
            docs.append(to_document(p) if p.suffix.lower() != ".md" else
                        Document(document_id=f"DOC-{p.stem.upper()[:24]}", title=p.stem.replace("_", " "), content=p.read_text(encoding="utf-8"),
                                 source="file", source_reference=p.name, metadata={"format": "md", "source_filename": p.name}))
        except Exception as e:  # noqa: BLE001
            print(f"skip {p.name}: {e}", file=sys.stderr)
    result = loader.load_documents(docs)
    for r in result["results"]:
        links = ", ".join(x["caption"] for x in r.get("linked_records", [])[:6])
        print(f"{r['document_id']:<28} {r['action']:<8} chunks={r['chunks_created']:<3} links={r['entity_links']:<3} {links}")
    print(f"{result['created']} created, {result['updated']} updated, {result['skipped']} skipped, {result['failed']} failed")
    return 0 if not result["failed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
