"""
Modular document parsers package
"""

from .base import BaseParser, ExtractedDocument, ExtractedSection
from .pdf_parser import PDFParser
from .excel_parser import ExcelParser
from .csv_parser import CSVParser
from .docx_parser import WordParser
from .text_parser import TextParser
from .json_parser import JSONParser
from .factory import get_parser_for_file, get_supported_extensions, SUPPORTED_EXTENSIONS

__all__ = [
    "BaseParser",
    "ExtractedDocument",
    "ExtractedSection",
    "PDFParser",
    "ExcelParser",
    "CSVParser",
    "WordParser",
    "TextParser",
    "JSONParser",
    "get_parser_for_file",
    "get_supported_extensions",
    "SUPPORTED_EXTENSIONS",
]
