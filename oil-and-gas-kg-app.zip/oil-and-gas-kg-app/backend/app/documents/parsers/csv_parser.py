"""
CSV Document Parser supporting robust encoding detection and bounded batching
"""

import csv
import io
from pathlib import Path
from typing import List, Dict, Any

from .base import BaseParser, ExtractedDocument, ExtractedSection


class CSVParser(BaseParser):
    """
    Parser for CSV files handling encoding fallbacks, header detection,
    quoted fields, and record-aware batching.
    """

    BATCH_SIZE = 25  # Number of rows per structured section

    @property
    def supported_extensions(self) -> List[str]:
        return [".csv"]

    def parse(self, file_content: bytes, filename: str) -> ExtractedDocument:
        if not file_content:
            raise ValueError("CSV file is empty (0 bytes).")

        # Robust encoding detection
        text_content = ""
        for encoding in ["utf-8", "utf-8-sig", "latin-1", "cp1252"]:
            try:
                text_content = file_content.decode(encoding)
                break
            except (UnicodeDecodeError, LookupError):
                continue

        if not text_content:
            raise ValueError("Unable to decode CSV file with supported encodings (UTF-8, Latin-1).")

        clean_name = Path(filename).stem.replace("_", " ").replace("-", " ")
        title = clean_name.title() or "CSV Data"

        stream = io.StringIO(text_content)

        # Detect delimiter safely
        sample = text_content[:4096]
        delimiter = ","
        try:
            sniffer = csv.Sniffer()
            dialect = sniffer.sniff(sample)
            delimiter = dialect.delimiter
        except Exception:
            # Fall back to comma
            delimiter = ","

        stream.seek(0)
        try:
            reader = csv.reader(stream, delimiter=delimiter)
            rows = [row for row in reader if any(cell.strip() for cell in row)]
        except Exception as e:
            raise ValueError(f"Malformed CSV content: {e}")

        if not rows:
            return ExtractedDocument(
                title=title,
                content=f"[Document: {title} | Empty CSV file]",
                format="csv",
                source_filename=filename,
                sections=[],
                metadata={"total_data_rows": 0},
                warnings=["CSV file contains no readable rows."],
            )

        headers = [h.strip() if h.strip() else f"Column_{i+1}" for i, h in enumerate(rows[0])]
        data_rows = rows[1:]

        sections: List[ExtractedSection] = []
        full_text_parts: List[str] = []
        warnings: List[str] = []

        if not data_rows:
            warnings.append("CSV contains headers but no data rows.")
            header_str = f"Headers: {' | '.join(headers)}"
            sections.append(
                ExtractedSection(
                    title="CSV Headers",
                    content=header_str,
                    row_start=1,
                    row_end=1,
                    metadata={"header_count": len(headers)},
                )
            )
            full_text_parts.append(header_str)
        else:
            for i in range(0, len(data_rows), self.BATCH_SIZE):
                batch = data_rows[i : i + self.BATCH_SIZE]
                row_start_num = i + 2  # 1-indexed (row 1 is header)
                row_end_num = row_start_num + len(batch) - 1

                lines = [
                    f"CSV File: {filename} | Rows: {row_start_num}-{row_end_num}",
                    f"Headers: {' | '.join(headers)}"
                ]

                for r_offset, r_vals in enumerate(batch):
                    actual_row = row_start_num + r_offset
                    row_items = []
                    for h_idx, val in enumerate(r_vals):
                        val_str = val.strip()
                        if val_str:
                            col_name = headers[h_idx] if h_idx < len(headers) else f"Col_{h_idx+1}"
                            row_items.append(f"{col_name}: {val_str}")
                    if row_items:
                        lines.append(f"Row {actual_row}: {', '.join(row_items)}")

                section_text = "\n".join(lines)
                sections.append(
                    ExtractedSection(
                        title=f"Rows {row_start_num}-{row_end_num}",
                        content=section_text,
                        row_start=row_start_num,
                        row_end=row_end_num,
                        metadata={
                            "row_start": row_start_num,
                            "row_end": row_end_num,
                            "record_count": len(batch),
                            "delimiter": delimiter,
                        },
                    )
                )
                full_text_parts.append(section_text)

        consolidated_text = "\n\n".join(full_text_parts)

        return ExtractedDocument(
            title=title,
            content=consolidated_text,
            format="csv",
            source_filename=filename,
            sections=sections,
            metadata={
                "total_data_rows": len(data_rows),
                "header_count": len(headers),
                "headers": headers,
                "delimiter": delimiter,
            },
            warnings=warnings,
            table_count=1,
        )
