"""
Word (.docx) Document Parser using python-docx preserving document ordering and heading hierarchy
"""

import io
from pathlib import Path
from typing import List, Dict, Any, Optional
import docx
from docx.text.paragraph import Paragraph
from docx.table import Table

from .base import BaseParser, ExtractedDocument, ExtractedSection


class WordParser(BaseParser):
    """
    Parser for Microsoft Word (.docx) documents.
    Preserves document ordering across paragraphs and tables while maintaining section/heading context.
    """

    @property
    def supported_extensions(self) -> List[str]:
        return [".docx"]

    def parse(self, file_content: bytes, filename: str) -> ExtractedDocument:
        if not file_content:
            raise ValueError("Word document is empty (0 bytes).")

        try:
            doc = docx.Document(io.BytesIO(file_content))
        except Exception as e:
            raise ValueError(f"Failed to open Word document. File may be corrupt or encrypted: {e}")

        # Extract core properties
        doc_meta: Dict[str, Any] = {}
        title: Optional[str] = None
        try:
            props = doc.core_properties
            if props.title and props.title.strip():
                title = props.title.strip()
                doc_meta["core_title"] = title
            if props.author:
                doc_meta["author"] = props.author
            if props.created:
                doc_meta["created"] = str(props.created)
        except Exception:
            pass

        if not title:
            clean_name = Path(filename).stem.replace("_", " ").replace("-", " ")
            title = clean_name.title() or "Word Document"

        sections: List[ExtractedSection] = []
        full_text_parts: List[str] = []
        warnings: List[str] = []
        table_count = 0

        current_heading = "Introduction"
        current_section_texts: List[str] = []

        def flush_current_section():
            nonlocal current_section_texts, current_heading
            if current_section_texts:
                combined = "\n\n".join(t for t in current_section_texts if t.strip())
                if combined.strip():
                    sections.append(
                        ExtractedSection(
                            title=current_heading,
                            content=combined,
                            section_title=current_heading,
                            metadata={"section_title": current_heading},
                        )
                    )
                    full_text_parts.append(f"## {current_heading}\n{combined}")
                current_section_texts = []

        # Traverse body in exact document order
        for child in doc.element.body:
            tag = child.tag.lower()
            if tag.endswith("p"):
                p = Paragraph(child, doc)
                text = p.text.strip()
                if not text:
                    continue

                style_name = p.style.name if p.style else ""
                is_heading = (
                    style_name.startswith("Heading")
                    or style_name in ["Title", "Subtitle"]
                )

                if is_heading:
                    flush_current_section()
                    current_heading = text
                else:
                    current_section_texts.append(text)

            elif tag.endswith("tbl"):
                table_count += 1
                tbl = Table(child, doc)
                tbl_rows: List[List[str]] = []
                for row in tbl.rows:
                    row_cells = [cell.text.strip().replace("\n", " ") for cell in row.cells]
                    if any(c for c in row_cells):
                        tbl_rows.append(row_cells)

                if tbl_rows:
                    # Render as readable table block
                    headers = tbl_rows[0]
                    tbl_lines = [
                        f"[Table: {current_heading}]",
                        " | ".join(headers),
                        " | ".join(["---"] * len(headers))
                    ]
                    for r in tbl_rows[1:]:
                        tbl_lines.append(" | ".join(r))
                    tbl_text = "\n".join(tbl_lines)
                    current_section_texts.append(tbl_text)

        flush_current_section()

        if not sections and not full_text_parts:
            warnings.append("Word document contains no readable paragraphs or tables.")
            consolidated_text = f"[Document: {title} | Empty document]"
        else:
            consolidated_text = "\n\n".join(full_text_parts)

        return ExtractedDocument(
            title=title,
            content=consolidated_text,
            format="docx",
            source_filename=filename,
            sections=sections,
            metadata={
                **doc_meta,
                "table_count": table_count,
                "section_count": len(sections),
            },
            warnings=warnings,
            table_count=table_count,
        )
