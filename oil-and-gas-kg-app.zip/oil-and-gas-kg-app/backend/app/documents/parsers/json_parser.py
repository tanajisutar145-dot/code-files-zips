"""
JSON Document Parser preserving baseline structure while supporting nested records
"""

import json
from pathlib import Path
from typing import List, Dict, Any, Union

from .base import BaseParser, ExtractedDocument, ExtractedSection


class JSONParser(BaseParser):
    """
    Parser for JSON documents.
    Supports both existing Utility Document schema and arbitrary structured nested JSON.
    Preserves meaningful field names for searchability.
    """

    @property
    def supported_extensions(self) -> List[str]:
        return [".json"]

    def parse(self, file_content: bytes, filename: str) -> ExtractedDocument:
        if not file_content:
            raise ValueError("JSON file is empty (0 bytes).")

        try:
            text = file_content.decode("utf-8")
        except UnicodeDecodeError:
            try:
                text = file_content.decode("latin-1")
            except Exception as e:
                raise ValueError(f"Failed to decode JSON file: {e}")

        try:
            data = json.loads(text)
        except json.JSONDecodeError as e:
            raise ValueError(f"Malformed JSON content (line {e.lineno}, col {e.colno}): {e.msg}")

        clean_name = Path(filename).stem.replace("_", " ").replace("-", " ")
        title = clean_name.title() or "JSON Document"

        sections: List[ExtractedSection] = []
        doc_meta: Dict[str, Any] = {}
        content_text = ""

        if isinstance(data, dict):
            # Check if this is the native Document schema
            if "title" in data and isinstance(data["title"], str):
                title = data["title"]
            if "metadata" in data and isinstance(data["metadata"], dict):
                doc_meta = dict(data["metadata"])

            # Preserve top-level entity fields
            for entity_key in ["document_id", "document_type", "asset_id", "unit_id", "inspection_id", "failure_id", "work_order_id", "source", "source_reference"]:
                if entity_key in data and data[entity_key]:
                    doc_meta[entity_key] = data[entity_key]

            # If it has a primary content field (existing system behavior)
            if "content" in data and isinstance(data["content"], str) and data["content"].strip():
                content_text = data["content"].strip()
                # If there are additional structured fields, append them
                extra_fields = []
                for k, v in data.items():
                    if k not in ["content", "title", "metadata", "document_id", "document_type", "asset_id", "unit_id", "inspection_id", "failure_id", "work_order_id", "source", "source_reference"] and v is not None:
                        extra_fields.append(f"{k}: {v}")
                if extra_fields:
                    content_text = f"{content_text}\n\n" + "\n".join(extra_fields)

                sections.append(
                    ExtractedSection(
                        title="Document Content",
                        content=content_text,
                        section_title="Document Content",
                        metadata={"type": "standard_document_json"},
                    )
                )
            else:
                # Structured dictionary: convert fields preserving keys
                lines = self._flatten_json_to_lines(data)
                content_text = "\n".join(lines)

                # Create sections per top-level key
                for k, v in data.items():
                    sub_lines = self._flatten_json_to_lines({k: v})
                    sub_text = "\n".join(sub_lines)
                    if sub_text.strip():
                        sections.append(
                            ExtractedSection(
                                title=str(k),
                                content=sub_text,
                                section_title=str(k),
                                metadata={"top_level_field": str(k)},
                            )
                        )

        elif isinstance(data, list):
            # Array of items
            lines = self._flatten_json_to_lines(data)
            content_text = "\n".join(lines)

            # Group array items into sections
            batch_size = 10
            for i in range(0, len(data), batch_size):
                batch = data[i : i + batch_size]
                b_lines = self._flatten_json_to_lines(batch, prefix=f"item[{i}..{i+len(batch)-1}]")
                b_text = "\n".join(b_lines)
                sections.append(
                    ExtractedSection(
                        title=f"Records {i+1}-{i+len(batch)}",
                        content=b_text,
                        row_start=i + 1,
                        row_end=i + len(batch),
                        metadata={"record_count": len(batch)},
                    )
                )
        else:
            content_text = str(data)
            sections.append(
                ExtractedSection(
                    title="Value",
                    content=content_text,
                )
            )

        if not content_text.strip():
            raise ValueError("JSON file contains no meaningful text content.")

        return ExtractedDocument(
            title=title,
            content=content_text,
            format="json",
            source_filename=filename,
            sections=sections,
            metadata=doc_meta,
            warnings=[],
        )

    def _flatten_json_to_lines(self, obj: Any, prefix: str = "") -> List[str]:
        """Convert nested JSON structure into readable field-value lines preserving keys"""
        lines = []
        if isinstance(obj, dict):
            for k, v in obj.items():
                p = f"{prefix}.{k}" if prefix else str(k)
                if isinstance(v, (dict, list)):
                    lines.extend(self._flatten_json_to_lines(v, prefix=p))
                elif v is not None:
                    lines.append(f"{p}: {v}")
        elif isinstance(obj, list):
            for idx, item in enumerate(obj):
                p = f"{prefix}[{idx}]"
                if isinstance(item, (dict, list)):
                    lines.extend(self._flatten_json_to_lines(item, prefix=p))
                elif item is not None:
                    lines.append(f"{p}: {item}")
        else:
            lines.append(f"{prefix}: {obj}" if prefix else str(obj))
        return lines
