"""
Excel (.xlsx) Document Parser using openpyxl in data_only mode
"""

import io
from pathlib import Path
from typing import List, Dict, Any, Optional
import openpyxl

from .base import BaseParser, ExtractedDocument, ExtractedSection


class ExcelParser(BaseParser):
    """
    Parser for Excel (.xlsx) spreadsheets.
    Strictly reads cached formula values and never executes formulas or macros.
    """

    BATCH_SIZE = 25  # Number of rows per structured section for coherent chunking

    @property
    def supported_extensions(self) -> List[str]:
        return [".xlsx"]

    def parse(self, file_content: bytes, filename: str) -> ExtractedDocument:
        if not file_content:
            raise ValueError("Excel file is empty (0 bytes).")

        try:
            wb = openpyxl.load_workbook(
                filename=io.BytesIO(file_content),
                data_only=True,   # Reads cached formula values, never executes formulas
                read_only=True    # Safe streaming mode, disables macros
            )
        except Exception as e:
            raise ValueError(f"Failed to open Excel workbook. File may be corrupt or encrypted: {e}")

        try:
            sheet_names = wb.sheetnames
            if not sheet_names:
                raise ValueError("Excel workbook contains no worksheets.")

            sections: List[ExtractedSection] = []
            full_text_parts: List[str] = []
            warnings: List[str] = []
            total_rows_extracted = 0

            clean_name = Path(filename).stem.replace("_", " ").replace("-", " ")
            title = clean_name.title() or "Excel Spreadsheet"

            for sheet_name in sheet_names:
                ws = wb[sheet_name]

                # Extract all non-empty rows
                rows_data: List[List[Any]] = []
                for row in ws.iter_rows(values_only=True):
                    # Check if row is not all None or empty strings
                    if any(c is not None and str(c).strip() != "" for c in row):
                        rows_data.append([str(c).strip() if c is not None else "" for c in row])

                if not rows_data:
                    continue

                # Header is the first row
                headers = [h if h else f"Column_{idx+1}" for idx, h in enumerate(rows_data[0])]
                data_rows = rows_data[1:]

                if not data_rows:
                    # Only headers present
                    header_line = " | ".join(headers)
                    section_content = f"Worksheet: {sheet_name}\nHeaders: {header_line}\n(No data rows)"
                    sections.append(
                        ExtractedSection(
                            title=f"Worksheet: {sheet_name}",
                            content=section_content,
                            sheet_name=sheet_name,
                            row_start=1,
                            row_end=1,
                            metadata={"sheet_name": sheet_name, "row_count": 0},
                        )
                    )
                    full_text_parts.append(section_content)
                    continue

                total_rows_extracted += len(data_rows)

                # Batch data rows into record-aware groupings
                for i in range(0, len(data_rows), self.BATCH_SIZE):
                    batch = data_rows[i : i + self.BATCH_SIZE]
                    row_start_num = i + 2  # 1-indexed, +1 for 0-index, +1 for header
                    row_end_num = row_start_num + len(batch) - 1

                    lines = [
                        f"Worksheet: {sheet_name} | Rows: {row_start_num}-{row_end_num}",
                        f"Headers: {' | '.join(headers)}"
                    ]

                    for r_offset, r_vals in enumerate(batch):
                        actual_row = row_start_num + r_offset
                        # Build record string with field names
                        row_items = []
                        for h_idx, val in enumerate(r_vals):
                            if val:
                                col_name = headers[h_idx] if h_idx < len(headers) else f"Col_{h_idx+1}"
                                row_items.append(f"{col_name}: {val}")
                        if row_items:
                            lines.append(f"Row {actual_row}: {', '.join(row_items)}")

                    section_content = "\n".join(lines)
                    sections.append(
                        ExtractedSection(
                            title=f"{sheet_name} (Rows {row_start_num}-{row_end_num})",
                            content=section_content,
                            sheet_name=sheet_name,
                            row_start=row_start_num,
                            row_end=row_end_num,
                            metadata={
                                "sheet_name": sheet_name,
                                "row_start": row_start_num,
                                "row_end": row_end_num,
                                "record_count": len(batch),
                            },
                        )
                    )
                    full_text_parts.append(section_content)

            if total_rows_extracted == 0 and not sections:
                warnings.append("Excel workbook has worksheets but no readable tabular data rows.")
                consolidated_text = f"[Document: {title} | Empty workbook]"
            else:
                consolidated_text = "\n\n".join(full_text_parts)

            return ExtractedDocument(
                title=title,
                content=consolidated_text,
                format="xlsx",
                source_filename=filename,
                sections=sections,
                metadata={
                    "sheet_names": sheet_names,
                    "total_data_rows": total_rows_extracted,
                    "sheet_count": len(sheet_names),
                },
                warnings=warnings,
                sheet_names=sheet_names,
                table_count=len(sheet_names),
            )
        finally:
            wb.close()
