"""
PDF Document Parser using pypdf (pure Python)
"""

import io
from pathlib import Path
from typing import Any, Dict, List

from pypdf import PdfReader

from .base import BaseParser, ExtractedDocument, ExtractedSection


class PDFParser(BaseParser):
    """Parser for PDF documents extracting text page-by-page with provenance"""

    @property
    def supported_extensions(self) -> List[str]:
        return [".pdf"]

    def parse(self, file_content: bytes, filename: str) -> ExtractedDocument:
        if not file_content:
            raise ValueError("PDF file is empty (0 bytes).")
        try:
            reader = PdfReader(io.BytesIO(file_content))
            if reader.is_encrypted:
                try:
                    reader.decrypt("")
                except Exception as e:  # noqa: BLE001
                    raise ValueError(f"PDF is encrypted and cannot be read: {e}")
            page_count = len(reader.pages)
        except ValueError:
            raise
        except Exception as e:  # noqa: BLE001
            raise ValueError(f"Failed to open PDF document. File may be corrupt or encrypted: {e}")
        if page_count == 0:
            raise ValueError("PDF document has 0 pages.")

        doc_meta: Dict[str, Any] = {}
        if reader.metadata:
            for k, v in reader.metadata.items():
                if v and isinstance(v, (str, int, float, bool)):
                    doc_meta[k.lstrip("/").lower()] = v
        title = str(doc_meta.get("title") or "").strip() or Path(filename).stem.replace("_", " ").replace("-", " ").title() or "PDF Document"

        sections: List[ExtractedSection] = []
        parts: List[str] = []
        total = 0
        has_images = False
        for idx, page in enumerate(reader.pages):
            num = idx + 1
            try:
                text = (page.extract_text() or "").strip()
            except Exception:  # noqa: BLE001
                text = ""
            try:
                has_images = has_images or bool(page.images)
            except Exception:  # noqa: BLE001
                pass
            total += len(text)
            if text:
                parts.append(f"--- Page {num} ---\n{text}")
                sections.append(ExtractedSection(title=f"Page {num}", content=text, page_number=num, metadata={"char_count": len(text)}))
        warnings: List[str] = []
        if total < 50:
            warnings.append("Scanned or image-only PDF detected. OCR is required to extract full text." if has_images or total == 0
                            else "PDF contains very little extractable text (<50 characters).")
        content = "\n\n".join(parts) or f"[Document: {title} | {page_count} pages | No extractable text]"
        return ExtractedDocument(title=title, content=content, format="pdf", source_filename=filename, sections=sections,
                                 metadata={**doc_meta, "total_pages": page_count, "has_images": has_images, "total_characters": total},
                                 warnings=warnings, page_count=page_count)
