"""
Document domain models for unstructured content (uploaded reports, bulletins, investigation summaries)
"""

import hashlib
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator


class DocumentType(str, Enum):
    DRILLING_REPORT = "drilling_report"
    WELL_TEST_REPORT = "well_test_report"
    INSPECTION_REPORT = "inspection_report"
    FAILURE_ANALYSIS = "failure_analysis"
    INCIDENT_INVESTIGATION = "incident_investigation"
    HSE_BULLETIN = "hse_bulletin"
    LESSONS_LEARNED = "lessons_learned"
    ENGINEERING_NOTE = "engineering_note"
    REGULATORY_CORRESPONDENCE = "regulatory_correspondence"
    EMISSIONS_REPORT = "emissions_report"
    OPERATIONAL_NOTE = "operational_note"


class ProcessingStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


class Document(BaseModel):
    """Document model for unstructured content"""

    document_id: str = Field(..., description="Unique document identifier")
    document_type: DocumentType = Field(DocumentType.OPERATIONAL_NOTE, description="Type of document")
    title: str = Field(..., description="Document title")
    source: str = Field("upload", description="Source system or author")
    source_reference: Optional[str] = Field(None, description="External reference ID")
    created_date: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), description="Document creation date")
    linked_records: List[str] = Field(default_factory=list, description="Record identifiers named in the metadata (tags, event numbers, well names)")
    content: str = Field(..., description="Document text content")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")
    processing_status: ProcessingStatus = Field(ProcessingStatus.PENDING, description="Processing status")
    content_hash: str = Field("", description="Content hash for idempotency")

    @field_validator("content_hash", mode="before")
    @classmethod
    def _keep(cls, v):
        return v or ""

    def model_post_init(self, __context: Any) -> None:
        if not self.content_hash and self.content:
            self.content_hash = hashlib.sha256(self.content.encode("utf-8")).hexdigest()[:16]

    model_config = {"use_enum_values": True}


class Chunk(BaseModel):
    """Text chunk model for document processing"""

    chunk_id: str
    document_id: str
    chunk_index: int
    text: str
    metadata: Dict[str, Any] = Field(default_factory=dict)
    referenced_entities: List[str] = Field(default_factory=list, description="Captions of records referenced in the chunk")

    model_config = {"use_enum_values": True}


class DocumentProcessingResult(BaseModel):
    document_id: str
    chunks_created: int
    entity_links: int
    processing_status: ProcessingStatus
    error_message: Optional[str] = None

    model_config = {"use_enum_values": True}


class EntityReference(BaseModel):
    """Record of the knowledge graph referenced in document content"""

    entity_type: str = Field(..., description="Ontology class label (DrillingWell, Equipment, NptEvent...)")
    entity_id: str = Field(..., description="Neo4j elementId of the record")
    caption: str = Field("", description="Record caption matched in the text")
    confidence: float = Field(..., description="Confidence score for the match")
    context: str = Field(..., description="Text context where the reference was found")

    model_config = {"use_enum_values": True}
