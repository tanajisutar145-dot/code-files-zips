"""
LLM and embedding client for the API.

Replaces the reference project's Groq-only client with the pipeline's pluggable providers
(``LLM_PROVIDER`` / ``EMBEDDING_PROVIDER``: openai, openai_compatible - e.g. Groq or vLLM -,
azure_openai, anthropic (LLM only) or ollama). Models are created lazily and reused.
"""

from __future__ import annotations

import logging
import threading
from typing import Any, List, Optional

from app.core.config import kg_settings
from app.kg.settings import missing_model_keys

logger = logging.getLogger(__name__)


class LLMClient:
    def __init__(self):
        self._llm = None
        self._embedder = None
        self._lock = threading.Lock()

    # -- status ---------------------------------------------------------------------
    def is_configured(self) -> bool:
        return not missing_model_keys(kg_settings(), ("LLM",))

    def embedder_configured(self) -> bool:
        return not missing_model_keys(kg_settings(), ("EMBEDDING",))

    def describe(self) -> dict[str, str]:
        s = kg_settings()
        return {"llm": f"{s.llm.provider} / {s.llm.model}" if s.llm else "not configured",
                "embedder": f"{s.embedding.provider} / {s.embedding.model}" if s.embedding else "not configured",
                "embedding_dimensions": str(s.embedding.dimensions) if s.embedding and s.embedding.dimensions else "auto"}

    # -- models ---------------------------------------------------------------------
    def llm(self):
        from app.kg.rag.providers import create_llm

        with self._lock:
            if self._llm is None:
                self._llm = create_llm(kg_settings())
        return self._llm

    def embedder(self):
        from app.kg.rag.providers import create_embedder

        with self._lock:
            if self._embedder is None:
                self._embedder = create_embedder(kg_settings())
        return self._embedder

    # -- convenience ----------------------------------------------------------------
    def chat_completion(self, system_prompt: str, user_prompt: str) -> Optional[str]:
        """Single-turn completion; returns None when no LLM is configured or the call fails."""
        if not self.is_configured():
            return None
        try:
            return self.llm().invoke(user_prompt, system_instruction=system_prompt).content
        except Exception as e:  # noqa: BLE001
            logger.error(f"LLM call failed: {e}")
            return None

    def embed(self, text: str) -> List[float]:
        return [float(x) for x in self.embedder().embed_query(text)]


llm_client = LLMClient()


def describe_models() -> dict[str, Any]:
    return llm_client.describe()
