"""
Oil & Gas Knowledge Intelligence - backend application
"""

__version__ = "1.0.0"
