"""Entry point for ``python -m app.kg``."""

from app.kg.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
