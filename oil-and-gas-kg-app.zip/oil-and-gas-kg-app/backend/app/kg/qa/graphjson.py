"""Evidence-graph JSON for the UI (vis-network): nodes with standard alignment, colour, tooltip and WGS84 position."""

from __future__ import annotations

import json
from typing import Any

import neo4j

from app.kg.ontology.extract import SemanticModel
from app.kg.settings import Settings
from app.kg.viz.render import LEXICAL, Styler, VizGraph


def vis_json(settings: Settings, styler: Styler, g: VizGraph, highlight: set[str] | None = None) -> dict[str, Any]:
    gp = settings.section("gis").get("point_property", "geo_point")
    highlight = highlight or set()
    nodes, edges = [], []
    for nid, n in g.nodes.items():
        if n["label"] in LEXICAL:
            continue
        props = n["props"]
        point = props.get(gp)
        lat = getattr(point, "y", None) if point is not None else None
        lon = getattr(point, "x", None) if point is not None else None
        clean = {k: (v.isoformat() if hasattr(v, "isoformat") else (None if k == gp else v)) for k, v in props.items()
                 if k not in ("caption",)}
        clean = json.loads(json.dumps(clean, default=str))
        nodes.append({"id": nid, "label": styler.caption(n["label"], props), "group": n["label"],
                      "domain": styler.domain(n["label"], props), "color": styler.color(n["label"], props),
                      "title": styler.tooltip(n["label"], clean), "evidence": nid in highlight, "props": clean,
                      "std": {k: props.get(k) for k in ("std_class", "std_match", "std_package", "std_standard")},
                      "std_labels": n.get("std_labels", []), "lat": lat, "lon": lon})
    ids = {n["id"] for n in nodes}
    for eid, e in g.edges.items():
        if e["src"] in ids and e["dst"] in ids:
            edges.append({"id": eid, "from": e["src"], "to": e["dst"], "label": e["type"],
                          "std": (e.get("props") or {}).get("std_association")})
    return {"nodes": nodes, "edges": edges}


class GraphJsonBuilder:
    """Runs a read query and converts every node / relationship / path in the result into vis JSON."""

    def __init__(self, settings: Settings, sem: SemanticModel):
        self.settings = settings
        self.styler = Styler(settings, sem)
        self.std_prefix = self.styler.captioner.std_prefix

    def from_records(self, records: list[neo4j.Record], highlight: set[str] | None = None) -> dict[str, Any]:
        g = VizGraph(std_prefix=self.std_prefix)
        for rec in records:
            for v in rec.values():
                g.absorb(v)
        return vis_json(self.settings, self.styler, g, highlight)
