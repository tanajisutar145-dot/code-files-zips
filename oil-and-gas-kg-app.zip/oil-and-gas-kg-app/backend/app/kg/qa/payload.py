"""Semantic-model payload for the Model & Standards explorer (works without Neo4j: read from build/semantic_model.json)."""

from __future__ import annotations

from typing import Any

from app.kg.ontology.extract import SemanticModel
from app.kg.settings import Settings


def model_payload(settings: Settings, sem: SemanticModel) -> dict[str, Any]:
    colors = settings.section("viz").get("domain_colors", {})
    return {
        "project": settings.section("project"),
        "standard": sem.standard,
        "namespace": sem.namespace,
        "sources": sem.sources,
        "domains": [{"domain": d, "color": colors.get(d, "#888"), "comment": sem.schemas.get(d, "")}
                    for d in dict.fromkeys(t.schema for t in sem.tables.values())],
        "colors": colors,
        "tables": [{"table": t.table_id, "schema": t.schema, "label": t.label, "class_iri": t.class_iri, "description": t.description,
                    "primary_key": t.primary_key, "standard_class": t.standard_class, "standard_match": t.standard_match,
                    "standard_package": t.standard_package, "standard_standard": t.standard_standard,
                    "standard_ancestors": t.standard_ancestors, "subject_areas": t.subject_areas,
                    "data_classification": t.data_classification, "location_role": t.location_role,
                    "standard_reference": t.standard_reference, "resolution": t.resolution,
                    "columns": [{"column": c.column, "sql_type": c.sql_type, "nullable": c.nullable, "label": c.label,
                                 "description": c.description, "business_term": c.business_term,
                                 "standard_attribute": c.standard_attribute, "standard_match": c.standard_match,
                                 "datatype": c.datatype, "unit": c.unit, "enum_values": c.enum_values,
                                 "sensitivity": c.sensitivity, "resolution": c.resolution} for c in t.columns]}
                   for t in sem.tables.values()],
        "relationships": [{"from": sem.label(r.from_table), "to": sem.label(r.to_table), "type": r.rel_type,
                           "fk": f"{r.from_table}.{r.from_column}", "standard_association": r.standard_association,
                           "cross_domain": r.cross_domain, "resolution": r.resolution} for r in sem.relationships],
        "extra_relationships": [{"type": p["type"], "table": p["table"], "kind": "polymorphic", "std": p.get("std_association")}
                                for p in settings.section("graph").get("polymorphic_links", [])]
                               + [{"type": d["name"], "kind": "derived", "std": d.get("description")}
                                  for d in settings.section("graph").get("derived_relationships", [])],
        "standard_classes": sem.standard_classes,
        "subject_areas": sem.subject_areas,
    }
