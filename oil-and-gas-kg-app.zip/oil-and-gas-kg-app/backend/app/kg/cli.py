"""Command line: ``python -m app.kg run --step all|model|load|rag|viz``.

The web API and UI are served by the FastAPI application (``python -m app.main``); this CLI runs
the pipeline steps that build and check the knowledge graph.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from app.kg.log import setup_logging
from app.kg.settings import load_settings
from app.kg.steps import run


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m app.kg", description="Oil & gas knowledge graph pipeline")
    sub = parser.add_subparsers(dest="command", required=True)
    r = sub.add_parser("run", help="run one step or the whole pipeline")
    r.add_argument("--step", choices=["all", "model", "load", "rag", "viz"], default="all",
                   help="model = parse DDL/TTL/data, validate, extract ontology + schema (offline); load = Neo4j; "
                        "rag = answer the demo questions; viz = HTML renderings")
    r.add_argument("--config", type=Path, default=None, help="path to config.yaml (default: $OGKG_CONFIG or backend/config.yaml)")
    r.add_argument("--reset", action="store_true", help="empty the Neo4j database before loading")
    r.add_argument("--skip-text", action="store_true", help="structured load only (no embeddings, no LLM)")
    r.add_argument("--question", help="only this question id for rag/viz (e.g. Q2)")
    r.add_argument("-v", "--verbose", action="store_true", help="debug logging (includes library prompts)")
    args = parser.parse_args(argv)

    setup_logging(args.verbose)
    settings = load_settings(args.config)
    run(settings, args.step, reset=args.reset, skip_text=args.skip_text, question=args.question)
    return 0
