"""Oil & gas knowledge-graph pipeline (ported from utility-knowledge-graph-v3).

Builds a configurable, ontology-guided knowledge graph from three inputs - SQL DDL, an OWL/RDF
ontology (TTL, aligned to oil & gas industry standards) and data files - and answers graph-shaped
questions with GraphRAG. Nothing in this package names an oil_gas table: everything model-specific
lives in ``backend/config.yaml``.
"""

__version__ = "1.0.0"
