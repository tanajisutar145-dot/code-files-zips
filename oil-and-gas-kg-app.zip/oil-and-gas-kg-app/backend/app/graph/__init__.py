"""
Graph database operations module
"""