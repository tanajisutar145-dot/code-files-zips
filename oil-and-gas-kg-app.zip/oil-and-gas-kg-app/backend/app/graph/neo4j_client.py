"""
Neo4j database client for the API services.

Uses the same connection settings as the knowledge-graph pipeline (``NEO4J_URI``, ``NEO4J_USER`` /
``NEO4J_USERNAME``, ``NEO4J_PASSWORD``, ``NEO4J_DATABASE``) and runs every API query against the
configured database. Queries from the API are read-only unless ``execute_write`` is used.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

import neo4j
from neo4j import GraphDatabase

from app.core.config import kg_settings

logger = logging.getLogger(__name__)


class Neo4jClient:
    """Thin, lazily connected Neo4j client."""

    def __init__(self):
        self._driver: Optional[neo4j.Driver] = None
        self._last_check: float = 0.0
        self._last_ok: bool = False

    # -- connection -----------------------------------------------------------------
    @property
    def database(self) -> str:
        cfg = kg_settings().neo4j
        return cfg.database if cfg else "neo4j"

    def is_configured(self) -> bool:
        return kg_settings().neo4j is not None

    def _get_driver(self) -> Optional[neo4j.Driver]:
        if self._driver is None:
            cfg = kg_settings().neo4j
            if cfg is None:
                logger.warning("Neo4j is not configured (NEO4J_URI missing in .env)")
                return None
            try:
                self._driver = GraphDatabase.driver(cfg.uri, auth=(cfg.user, cfg.password) if cfg.password else None,
                                                    connection_timeout=5, max_transaction_retry_time=5)
            except Exception as e:  # noqa: BLE001
                logger.error(f"Failed to initialize Neo4j driver: {e}")
                return None
        return self._driver

    def verify_connectivity(self, cache_seconds: float = 5.0) -> bool:
        """True when the database answers (cached for a few seconds; failures for longer so a stopped database does not slow every request)."""
        now = time.time()
        if now - self._last_check < (cache_seconds if self._last_ok else 3 * cache_seconds):
            return self._last_ok
        driver = self._get_driver()
        ok = False
        if driver is not None:
            try:
                # auto-commit query: fails fast instead of being retried like a managed transaction
                with driver.session(database=self.database) as session:
                    record = session.run("RETURN 1 AS health").single()
                ok = record is not None and record["health"] == 1
            except Exception as e:  # noqa: BLE001
                logger.warning(f"Neo4j connectivity check failed: {e}")
                ok = False
        self._last_check, self._last_ok = now, ok
        return ok

    def close(self) -> None:
        if self._driver:
            self._driver.close()
            self._driver = None

    # -- queries ----------------------------------------------------------------------
    def execute_query(self, cypher: str, parameters: Dict[str, Any] | None = None) -> List[Dict[str, Any]]:
        """Run a read query and return the records as dictionaries."""
        driver = self._get_driver()
        if not driver:
            raise RuntimeError("Neo4j driver not available")
        records, _, _ = driver.execute_query(cypher, parameters or {}, database_=self.database,
                                             routing_=neo4j.RoutingControl.READ)
        return [r.data() for r in records]

    def execute_records(self, cypher: str, parameters: Dict[str, Any] | None = None) -> List[neo4j.Record]:
        """Run a read query and return raw records (graph values preserved)."""
        driver = self._get_driver()
        if not driver:
            raise RuntimeError("Neo4j driver not available")
        records, _, _ = driver.execute_query(cypher, parameters or {}, database_=self.database,
                                             routing_=neo4j.RoutingControl.READ)
        return records

    def execute_write(self, cypher: str, parameters: Dict[str, Any] | None = None) -> Dict[str, Any]:
        """Run a write query and return the update counters."""
        driver = self._get_driver()
        if not driver:
            raise RuntimeError("Neo4j driver not available")
        _, summary, _ = driver.execute_query(cypher, parameters or {}, database_=self.database)
        c = summary.counters
        return {"nodes_created": c.nodes_created, "nodes_deleted": c.nodes_deleted,
                "relationships_created": c.relationships_created, "relationships_deleted": c.relationships_deleted,
                "properties_set": c.properties_set}

    def get_node_count(self, label: str | None = None) -> int:
        cypher = f"MATCH (n:`{label}`) RETURN count(n) AS count" if label else "MATCH (n) RETURN count(n) AS count"
        result = self.execute_query(cypher)
        return result[0]["count"] if result else 0

    def get_relationship_count(self, rel_type: str | None = None) -> int:
        cypher = f"MATCH ()-[r:`{rel_type}`]->() RETURN count(r) AS count" if rel_type else "MATCH ()-[r]->() RETURN count(r) AS count"
        result = self.execute_query(cypher)
        return result[0]["count"] if result else 0


# Global Neo4j client instance
neo4j_client = Neo4jClient()
