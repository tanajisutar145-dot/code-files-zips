"""
Dashboard Pydantic response models
"""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class KpiGroup(BaseModel):
    """A titled group of headline indicators"""
    title: str
    values: Dict[str, Any] = Field(default_factory=dict)


class DashboardGraphStats(BaseModel):
    """Knowledge graph node and relationship statistics"""
    total_nodes: int
    total_relationships: int
    data_nodes: int = Field(..., description="Nodes loaded from the oil_gas tables")
    semantic_nodes: int = Field(..., description="Ontology / standards layer nodes")
    document_nodes: int = Field(..., description="Document and chunk nodes")
    identity_nodes: int = Field(0, description="Derived WellIdentity hubs")
    nodes_by_domain: Dict[str, int] = Field(default_factory=dict)
    aligned_classes: int = Field(0, description="Ontology classes aligned to an industry standard")
    standard_classes: int = Field(0)


class DashboardDocumentStats(BaseModel):
    """Narrative documents, uploaded documents and vector index"""
    total_documents: int
    uploaded_documents: int
    total_chunks: int
    embedded_chunks: int
    embedding_model: str
    embedding_dimension: Optional[int] = None
    vector_index_name: str
    vector_index_status: str
    vector_index_population: float


class DashboardSummaryResponse(BaseModel):
    """Complete dashboard response model"""
    generated_at: str
    status: str
    project: Dict[str, Any] = Field(default_factory=dict)
    as_of: str
    kpis: Dict[str, KpiGroup] = Field(default_factory=dict)
    graph: DashboardGraphStats
    documents: DashboardDocumentStats
    use_cases: List[Dict[str, Any]] = Field(default_factory=list)
    trends: Dict[str, List[Dict[str, Any]]] = Field(default_factory=dict)
    highlights: List[Dict[str, Any]] = Field(default_factory=list, description="Live findings with the use case they belong to")
