"""
Pydantic models for the Assets (equipment integrity) API
"""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class AssetOverviewResponse(BaseModel):
    total_equipment: int
    safety_critical: int
    overdue_inspections: int
    failures: int
    open_work_orders: int
    criticality_counts: Dict[str, int] = Field(default_factory=dict)
    class_counts: Dict[str, int] = Field(default_factory=dict, description="Equipment by ISO 14224 class")
    facility_counts: Dict[str, int] = Field(default_factory=dict)
    as_of: str


class AssetListItem(BaseModel):
    equipment_id: int
    tag: str
    name: str
    equipment_type: Optional[str] = None
    facility: Optional[str] = None
    facility_code: Optional[str] = None
    criticality: Optional[str] = None
    safety_critical: bool = False
    maintenance_strategy: Optional[str] = None
    next_inspection_due_date: Optional[str] = None
    inspection_overdue: bool = False
    failure_count: int = 0
    inspection_count: int = 0
    work_order_count: int = 0
    last_failure_date: Optional[str] = None
    mtbf_hours: Optional[float] = None
    std_class: Optional[str] = None


class AssetListResponse(BaseModel):
    assets: List[AssetListItem] = Field(default_factory=list)
    total: int
    skip: int
    limit: int
    filters_applied: Dict[str, Any] = Field(default_factory=dict)


class AssetDetailResponse(BaseModel):
    asset: Dict[str, Any]
    facility: Optional[Dict[str, Any]] = None
    parent: Optional[Dict[str, Any]] = None
    children: List[Dict[str, Any]] = Field(default_factory=list)
    functional_location: List[Dict[str, Any]] = Field(default_factory=list, description="ISO 14224 taxonomy path")
    maintenance_plans: List[Dict[str, Any]] = Field(default_factory=list)
    integrity_programs: List[Dict[str, Any]] = Field(default_factory=list)
    inspections: List[Dict[str, Any]] = Field(default_factory=list)
    failures: List[Dict[str, Any]] = Field(default_factory=list)
    work_orders: List[Dict[str, Any]] = Field(default_factory=list)
    downtime: List[Dict[str, Any]] = Field(default_factory=list)
    hse_events: List[Dict[str, Any]] = Field(default_factory=list)
    drilling_npt: List[Dict[str, Any]] = Field(default_factory=list)
    graph: Dict[str, Any] = Field(default_factory=dict)
