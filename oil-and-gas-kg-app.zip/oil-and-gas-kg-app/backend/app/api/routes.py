"""
Main API router that includes all endpoint routers
"""

from typing import Any, Dict

from fastapi import APIRouter

from app.api.endpoints import assets, dashboard, documents, graph, intelligence, model, search, usecases, verification
from app.core.config import settings
from app.graph.neo4j_client import neo4j_client
from app.llm.client import llm_client
from app.services.common import semantic_model

api_router = APIRouter()

api_router.include_router(dashboard.router, prefix="/dashboard", tags=["dashboard"])
api_router.include_router(usecases.router, prefix="/usecases", tags=["use cases"])
api_router.include_router(documents.router, prefix="/documents", tags=["documents"])
api_router.include_router(assets.router, prefix="/assets", tags=["assets"])
api_router.include_router(graph.router, prefix="/graph", tags=["graph"])
api_router.include_router(search.router, prefix="/search", tags=["search"])
api_router.include_router(intelligence.router, prefix="/intelligence", tags=["intelligence"])
api_router.include_router(verification.router, prefix="/verification", tags=["verification"])
api_router.include_router(model.router, prefix="/model", tags=["model & standards"])


def health_payload() -> Dict[str, Any]:
    neo4j_status = "connected" if neo4j_client.verify_connectivity() else ("disconnected" if neo4j_client.is_configured() else "not_configured")
    graph_loaded = False
    if neo4j_status == "connected":
        try:
            graph_loaded = neo4j_client.execute_query("MATCH (n) WHERE n.source_table IS NOT NULL RETURN count(n) > 0 AS ok")[0]["ok"]
        except Exception:  # noqa: BLE001
            graph_loaded = False
    sem = semantic_model(optional=True)
    models = llm_client.describe()
    services = {
        "backend": "healthy",
        "neo4j": neo4j_status,
        "graph": "loaded" if graph_loaded else "empty",
        "semantic_model": "built" if sem is not None else "missing",
        "llm": "configured" if llm_client.is_configured() else "not_configured",
        "embedder": "configured" if llm_client.embedder_configured() else "not_configured",
    }
    status = "healthy" if neo4j_status == "connected" and graph_loaded and services["llm"] == "configured" else "degraded"
    return {"status": status, "application": settings.app_name, "environment": settings.app_env, "services": services,
            "models": models, "database": neo4j_client.database}


@api_router.get("/health")
async def api_health_check():
    """Health check under /api (same payload as /health)."""
    return health_payload()
