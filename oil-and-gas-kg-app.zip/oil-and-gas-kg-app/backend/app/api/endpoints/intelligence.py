"""
Intelligence API endpoints - GraphRAG question answering
"""

from typing import List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.intelligence import GraphRAGRequest, GraphRAGResponse, graphrag_service
from app.llm.client import llm_client
from app.services.verification_service import verification_service
from app.verification import answer_verifier

router = APIRouter()


def _unavailable(e: Exception) -> HTTPException:
    return HTTPException(status_code=503, detail=str(e))


@router.get("/info")
async def info():
    """Engine status: models, database, label counts, demo and sample questions, retrievers."""
    try:
        return graphrag_service.info()
    except RuntimeError as e:
        raise _unavailable(e)


@router.post("/ask", response_model=GraphRAGResponse)
def graphrag_ask(request: GraphRAGRequest):
    """
    GraphRAG question answering with grounded evidence (waits for the answer).

    Routes the question (Text2Cypher / vector + graph / hybrid + graph, with fallback), generates the answer from the
    retrieved context only, builds the evidence graph and verifies the answer (grounding + ground truth for demo questions).
    """
    try:
        response = graphrag_service.ask_question(request)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        raise _unavailable(e)
    if response.metadata.get("retrieval_method") != "small_talk" and response.verification.grounding_score < 0.5:
        verification_service.enqueue(response.question, response.answer, response.verification.grounding_score,
                                     "low grounding score", response.job_id, response.retriever)
    return response


class SimpleAskRequest(BaseModel):
    question: str = Field(..., description="Natural language question")
    mode: str = Field("auto")


@router.post("/ask/simple")
def simple_ask(request: SimpleAskRequest):
    """Answer, confidence and verification flag only."""
    try:
        r = graphrag_service.ask_question(GraphRAGRequest(question=request.question, mode=request.mode))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        raise _unavailable(e)
    return {"question": r.question, "answer": r.answer, "confidence": r.confidence, "verified": r.verification.verified,
            "retriever": r.retriever, "execution_time": r.metadata.get("execution_time")}


# ---- asynchronous jobs (live trace in the UI) -------------------------------------
@router.post("/jobs")
def submit_job(request: GraphRAGRequest):
    """Start answering; returns {reply} for small talk or {job_id} to poll."""
    try:
        return graphrag_service.submit(request)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        raise _unavailable(e)


@router.get("/jobs/latest")
def latest_job():
    try:
        job = graphrag_service.latest()
    except RuntimeError as e:
        raise _unavailable(e)
    if job is None:
        raise HTTPException(status_code=404, detail="no question asked yet")
    return job


@router.get("/jobs/{job_id}")
def get_job(job_id: str):
    """Job state: trace steps, answer, retriever runs, evidence graph, verification."""
    try:
        return graphrag_service.job(job_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="unknown job")
    except RuntimeError as e:
        raise _unavailable(e)


@router.get("/jobs/{job_id}/response", response_model=GraphRAGResponse)
def job_response(job_id: str):
    """The finished job in the /ask response format (with grounding verification)."""
    try:
        return graphrag_service.response_for_job(job_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="unknown job")
    except RuntimeError as e:
        raise _unavailable(e)


# ---- reference endpoints kept for compatibility -----------------------------------
class IntelligenceQuery(BaseModel):
    query: str
    context: Optional[List[str]] = None
    model: Optional[str] = None


class FactCheckQuery(BaseModel):
    statement: str
    context: Optional[List[str]] = None


class SummarizeRequest(BaseModel):
    content: str
    max_length: int = 200


@router.post("/query")
def intelligent_query(query: IntelligenceQuery):
    """Answer a query; uses the knowledge graph unless an explicit context is given."""
    if not query.context:
        r = graphrag_ask(GraphRAGRequest(question=query.query))
        return {"response": r.answer, "confidence": r.verification.grounding_score, "sources": r.sources.get("entities", [])[:20],
                "reasoning": f"Retriever {r.retriever}; {len(r.trace)} traced steps."}
    answer = llm_client.chat_completion("Answer using only the context provided. Say what is missing if the context is insufficient.",
                                        "Context:\n" + "\n---\n".join(query.context) + f"\n\nQuestion: {query.query}")
    if answer is None:
        raise HTTPException(status_code=503, detail="LLM not configured (LLM_* in backend/.env)")
    v = answer_verifier.verify(answer, query.context, query.query)
    return {"response": answer, "confidence": v.grounding_score, "sources": ["provided context"], "reasoning": "Context-only answer."}


@router.post("/fact-check")
def fact_check(query: FactCheckQuery):
    """Check whether the identifiers and figures of a statement are supported by the context (or by a graph lookup)."""
    context = query.context
    if not context:
        r = graphrag_ask(GraphRAGRequest(question=f"Is the following statement supported by the records? {query.statement}"))
        context = [str(x.get("text", "")) for x in r.evidence.get("semantic_results", [])] + [r.answer]
    v = answer_verifier.verify(query.statement, context, query.statement)
    verdict = "true" if v.verified else ("false" if v.unsupported_claims else "uncertain")
    return {"statement": query.statement, "verdict": verdict, "confidence": v.grounding_score, "evidence": v.supported_claims,
            "explanation": "; ".join(v.warnings + v.evidence_gaps) or "All identifiers and figures were found in the evidence."}


@router.post("/summarize")
def summarize_content(req: SummarizeRequest):
    if len(req.content) <= req.max_length:
        return {"summary": req.content}
    summary = llm_client.chat_completion("Summarise oil and gas operational text faithfully. Keep identifiers and figures.",
                                         f"Summarise in at most {req.max_length} characters:\n{req.content}")
    return {"summary": (summary or req.content[:req.max_length] + "...")[: req.max_length + 40]}
