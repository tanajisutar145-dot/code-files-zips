"""
Use-case API endpoints: the five knowledge-graph use cases (deterministic, read-only Cypher; no LLM).
"""

from typing import Optional

from fastapi import APIRouter, HTTPException, Query

from app.services.usecase_service import usecase_service

router = APIRouter()


@router.get("/")
def list_use_cases():
    """The five use cases with owner, standards, demo questions and live headline KPIs."""
    return usecase_service.overview()


# ---- UC1 Well & subsurface 360 ------------------------------------------------------
@router.get("/uc1/wells")
def wells():
    """One row per physical well (PPDM API-10 identity) with the registers it appears in."""
    return usecase_service.wells()


@router.get("/uc1/wells/{api10}")
def well_360(api10: str):
    """Everything known about one well across exploration, drilling, production and asset registers."""
    result = usecase_service.well_360(api10)
    if not result.get("found"):
        raise HTTPException(status_code=404, detail=f"No well with API-10 {api10}")
    return result


@router.get("/uc1/identity-issues")
def identity_issues():
    """API conflicts, production records without an asset record, name aliases, single-register wells."""
    return usecase_service.identity_issues()


@router.get("/uc1/formation-wells")
def formation_wells(formation: str = Query("Wolfcamp A")):
    """Wellbores targeting a formation, with their best well test and reserves categories."""
    return usecase_service.formation_wells(formation)


# ---- UC2 Drilling -------------------------------------------------------------------
@router.get("/uc2/npt")
def npt_summary():
    return usecase_service.npt_summary()


@router.get("/uc2/programs")
def programs():
    return usecase_service.programs()


@router.get("/uc2/offset-brief")
def offset_brief(program: str = Query(..., description="Well program number, e.g. WP-2026-022")):
    """Offset-well risk brief for a planned well program: events, NPT and lessons in wells into the same formation."""
    return usecase_service.offset_brief(program)


@router.get("/uc2/well-control-chains")
def well_control_chains():
    """Well control events with their incident, violation, PSE, NPT, flaring and downtime consequences."""
    return usecase_service.well_control_chains()


# ---- UC3 Asset integrity --------------------------------------------------------------
@router.get("/uc3/precursors")
def precursors():
    """Failures preceded by an inspection finding (inspection -> failure -> work order -> downtime)."""
    return usecase_service.precursors()


@router.get("/uc3/bad-actors")
def bad_actors():
    return usecase_service.bad_actors()


@router.get("/uc3/overdue")
def overdue():
    """Safety-critical equipment past its inspection due date and not-fit-for-service results."""
    return usecase_service.overdue()


@router.get("/uc3/hierarchy")
def hierarchy(facility_code: Optional[str] = Query(None)):
    """ISO 14224 functional-location tree with the equipment / installation each node locates."""
    return usecase_service.hierarchy(facility_code)


# ---- UC4 HSE ----------------------------------------------------------------------------
@router.get("/uc4/pse")
def pse_list():
    return usecase_service.pse_list()


@router.get("/uc4/pse/{pse_number}")
def pse_story(pse_number: str):
    """Full story of a process safety event: equipment, incident, PTW, investigation, CAPAs, spill, violation."""
    result = usecase_service.pse_story(pse_number)
    if not result.get("event"):
        raise HTTPException(status_code=404, detail=f"Process safety event {pse_number} not found")
    return result


@router.get("/uc4/root-causes")
def root_causes():
    return usecase_service.root_causes()


@router.get("/uc4/ptw-incidents")
def ptw_incidents():
    return usecase_service.ptw_incidents()


# ---- UC5 Traceability -------------------------------------------------------------------
@router.get("/uc5/custody-transfers")
def custody_transfers():
    return usecase_service.custody_transfers()


@router.get("/uc5/custody-transfers/{ref}/lineage")
def lineage(ref: str):
    """Trace a custody transfer back to allocations, wells (API identity), meters and measurement points."""
    return usecase_service.lineage(ref)


@router.get("/uc5/emissions")
def emissions():
    return usecase_service.emissions()


@router.get("/uc5/allocation-variance")
def allocation_variance(threshold: float = Query(150.0, ge=0)):
    return usecase_service.allocation_variance(threshold)
