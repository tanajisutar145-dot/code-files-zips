"""
Search API endpoints
"""

from typing import List, Optional

from fastapi import APIRouter, Query
from pydantic import BaseModel

from app.retrieval import RetrievalRequest, semantic_retriever
from app.services.search_service import SearchService

router = APIRouter()
search_service = SearchService()


class SearchQuery(BaseModel):
    query: str
    filters: Optional[dict] = None
    limit: int = 50


class SearchResult(BaseModel):
    id: str
    title: str
    content: str
    type: str
    score: float
    metadata: dict


class SearchResponse(BaseModel):
    results: List[SearchResult]
    total: int
    query_time: float


@router.post("/semantic", response_model=SearchResponse)
def semantic_search(search_query: SearchQuery):
    """Vector search over narrative chunks with graph expansion (compact result list)."""
    result = semantic_retriever.retrieve(RetrievalRequest(query=search_query.query, top_k=min(search_query.limit, 20), graph_depth=1))
    return SearchResponse(results=[SearchResult(id=r.chunk_id, title=r.document_title, content=r.text, type="chunk", score=r.score,
                                                metadata={"document_id": r.document_id, "source": r.source, **r.metadata})
                                   for r in result.semantic_results],
                          total=len(result.semantic_results), query_time=result.metadata.get("execution_time", 0.0))


@router.post("/retrieve")
def semantic_retrieve(request: RetrievalRequest):
    """Vector search + graph expansion (full result: chunks, entities, relationships)."""
    return semantic_retriever.retrieve(request)


@router.post("/keyword", response_model=SearchResponse)
async def keyword_search(search_query: SearchQuery):
    """Record captions and full-text indexes (record narratives and document chunks)."""
    return await search_service.keyword_search(search_query.query, search_query.filters, search_query.limit)


@router.get("/similar/{item_id:path}", response_model=List[SearchResult])
async def find_similar(item_id: str, limit: int = Query(10, le=50)):
    """Chunks most similar to a chunk, document or record (by caption or elementId)."""
    return await search_service.find_similar(item_id, limit)
