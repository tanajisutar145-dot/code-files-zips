"""
Asset (equipment integrity) API endpoints
"""

from typing import Optional

from fastapi import APIRouter, HTTPException, Query

from app.models.assets import AssetDetailResponse, AssetListResponse, AssetOverviewResponse
from app.services.asset_service import asset_service

router = APIRouter()


@router.get("/overview", response_model=AssetOverviewResponse)
def get_assets_overview():
    """Equipment register statistics: safety-critical items, overdue inspections, failures, classes, facilities."""
    return asset_service.get_overview()


@router.get("/", response_model=AssetListResponse)
def list_assets(
    search: Optional[str] = Query(None, description="Matches tag or equipment name"),
    equipment_type: Optional[str] = Query(None, description="ISO 14224 equipment class (compressor, vessel, valve...)"),
    criticality: Optional[str] = Query(None, description="critical | high | medium | low"),
    facility_code: Optional[str] = Query(None, description="Asset facility code, e.g. FD-CTB1"),
    safety_critical: Optional[bool] = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
):
    """Equipment with integrity counters (failures, inspections, work orders, overdue inspection)."""
    return asset_service.list_assets(search=search, equipment_type=equipment_type, criticality=criticality,
                                     facility_code=facility_code, safety_critical=safety_critical, skip=skip, limit=limit)


@router.get("/{asset_key}", response_model=AssetDetailResponse)
def get_asset(asset_key: str):
    """Full relational context of one equipment item (tag or equipment_id)."""
    asset = asset_service.get_asset_detail(asset_key)
    if not asset:
        raise HTTPException(status_code=404, detail=f"Equipment '{asset_key}' not found")
    return asset
