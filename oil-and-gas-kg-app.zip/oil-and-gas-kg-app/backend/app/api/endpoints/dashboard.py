"""
Dashboard API endpoints - Executive intelligence summary
"""

from fastapi import APIRouter, HTTPException
from app.models.dashboard import DashboardSummaryResponse
from app.services.dashboard_service import dashboard_service

router = APIRouter()


@router.get("/summary", response_model=DashboardSummaryResponse)
def get_dashboard_summary():
    """
    Live executive dashboard: wells & identity, production, drilling NPT, asset integrity, HSE / process safety and
    emissions KPIs, graph and document statistics, use-case tiles, trends and highlights. Read-only queries.
    """
    return dashboard_service.get_dashboard_summary()
