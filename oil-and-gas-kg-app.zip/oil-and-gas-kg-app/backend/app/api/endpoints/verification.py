"""
Verification API endpoints (human review of GraphRAG answers)
"""

from enum import Enum
from typing import List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.services.verification_service import verification_service

router = APIRouter()


class VerificationStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class VerificationItem(BaseModel):
    id: str
    content: str
    type: str
    status: VerificationStatus
    confidence: float
    created_at: str
    question: Optional[str] = None
    reason: Optional[str] = None
    job_id: Optional[str] = None
    retriever: Optional[str] = None
    reviewed_at: Optional[str] = None
    reviewer: Optional[str] = None
    comment: Optional[str] = None


class VerificationDecision(BaseModel):
    decision: VerificationStatus
    comment: Optional[str] = None
    reviewer: Optional[str] = "reviewer"


class FlagRequest(BaseModel):
    question: str
    answer: str
    confidence: float = 0.0
    reason: str = "flagged by user"
    job_id: Optional[str] = None
    retriever: Optional[str] = None


@router.get("/pending", response_model=List[VerificationItem])
async def get_pending_verifications():
    return await verification_service.get_pending_items()


@router.get("/items", response_model=List[VerificationItem])
async def get_all_items():
    return await verification_service.get_items()


@router.post("/flag", response_model=VerificationItem)
def flag_answer(req: FlagRequest):
    """Queue an answer for human review."""
    return verification_service.enqueue(req.question, req.answer, req.confidence, req.reason, req.job_id, req.retriever)


@router.post("/review/{item_id}", response_model=VerificationItem)
async def review_item(item_id: str, decision: VerificationDecision):
    try:
        return await verification_service.review_item(item_id, decision.decision.value, decision.comment, decision.reviewer or "reviewer")
    except KeyError:
        raise HTTPException(status_code=404, detail=f"Verification item '{item_id}' not found")


@router.get("/stats")
async def get_verification_stats():
    return await verification_service.get_stats()
