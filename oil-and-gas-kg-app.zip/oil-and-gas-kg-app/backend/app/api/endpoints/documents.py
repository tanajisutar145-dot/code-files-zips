"""
Document management API endpoints
"""

from typing import Optional

from fastapi import APIRouter, File, HTTPException, Query, UploadFile

from app.models.documents import DocumentDetailResponse, DocumentListResponse, DocumentOverviewResponse, DocumentUploadResult
from app.services.document_service import document_service

router = APIRouter()


@router.get("/overview", response_model=DocumentOverviewResponse)
def get_documents_overview():
    """Documents, chunks, embeddings and vector index status."""
    return document_service.get_overview()


@router.get("/", response_model=DocumentListResponse)
def list_documents(
    search: Optional[str] = Query(None, description="Matches title or document id"),
    document_type: Optional[str] = Query(None, description="Document type, or the source class of a record narrative"),
    kind: Optional[str] = Query(None, description="uploaded | record_narrative"),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
):
    return document_service.list_documents(search=search, document_type=document_type, kind=kind, skip=skip, limit=limit)


@router.get("/{document_id:path}/detail", response_model=DocumentDetailResponse)
def get_document_by_path(document_id: str):
    """Detail for ids that contain '/' (record narratives are identified by '<schema>.<table>/<pk>')."""
    doc = document_service.get_document_detail(document_id)
    if not doc:
        raise HTTPException(status_code=404, detail=f"Document '{document_id}' not found")
    return doc


@router.get("/{document_id}", response_model=DocumentDetailResponse)
def get_document(document_id: str):
    """Text, chunks (with provenance and embedding status) and linked graph records."""
    doc = document_service.get_document_detail(document_id)
    if not doc:
        raise HTTPException(status_code=404, detail=f"Document '{document_id}' not found")
    return doc


@router.post("/upload", response_model=DocumentUploadResult)
async def upload_document(file: UploadFile = File(...)):
    """Upload and ingest a document (.pdf, .xlsx, .csv, .docx, .txt, .json): parse, chunk, embed, link to records."""
    return await document_service.upload_document(file)


@router.delete("/{document_id}")
def delete_document(document_id: str):
    """Delete an uploaded document and its chunks (record narratives are managed by the pipeline)."""
    if not document_service.delete_document(document_id):
        raise HTTPException(status_code=404, detail=f"Uploaded document '{document_id}' not found")
    return {"message": f"Document '{document_id}' deleted successfully", "document_id": document_id}
