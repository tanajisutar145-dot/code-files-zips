"""
Model & Standards API endpoints (semantic model works before the graph is loaded) and pipeline status.
"""

from fastapi import APIRouter, Query

from app.services.model_service import model_service, system_service

router = APIRouter()


@router.get("/")
def get_model():
    """Semantic model: classes by subject area, standard alignment, columns -> standard attributes + units, relationships."""
    return model_service.model()


@router.get("/standards")
def get_standards():
    """Standards alignment grouped by standard class (OSDU, PPDM, Energistics, PRMS, ISO 14224, API RP 754...)."""
    return model_service.standards()


@router.get("/class/{label}")
def class_sample(label: str, limit: int = Query(12, ge=1, le=40)):
    """A few instances of a class with their neighbours, as an evidence-style graph."""
    return model_service.class_sample(label, limit)


@router.get("/pipeline")
def pipeline_status():
    """Model / validation / load step artefacts and the commands that produce them."""
    return system_service.pipeline_status()
