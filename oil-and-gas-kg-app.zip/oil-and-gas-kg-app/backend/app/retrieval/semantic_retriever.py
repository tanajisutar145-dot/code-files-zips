"""
Semantic retrieval with graph expansion (Search page and ``/api/search/*``).

1. Vector search over the narrative chunk index built by the pipeline (``indexes.vector`` in config.yaml);
   chunks come from record narratives (lessons learned, investigation findings, inspection findings...)
   and from uploaded documents.
2. Graph expansion: each chunk's source record(s) (``HAS_NARRATIVE``) and, up to ``graph_depth`` hops,
   their FK / derived neighbours, returned as typed entities and relationships with their standard class.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List

from app.core.config import kg_settings
from app.graph.neo4j_client import neo4j_client
from app.llm.client import llm_client
from app.services.common import LEXICAL_LABELS, SEMANTIC_LABELS, clean_props, primary_label

from .models import GraphEntity, GraphEvidence, GraphRelationship, RetrievalRequest, RetrievalResult, SemanticSearchResult

logger = logging.getLogger(__name__)

_VECTOR = """
CALL db.index.vector.queryNodes($index, $k, $vector) YIELD node, score
WHERE score >= $min_score
MATCH (node)-[:FROM_DOCUMENT]->(d:Document)
OPTIONAL MATCH (d)<-[:HAS_NARRATIVE]-(src)
RETURN node.id AS chunk_id, node.text AS text, node.index AS chunk_index, score,
       d.path AS document_id, coalesce(d.title, d.path) AS title, d.source_label AS source_label,
       collect(DISTINCT elementId(src)) AS sources
ORDER BY score DESC
"""


class SemanticRetriever:
    """Vector search + bounded graph expansion."""

    def retrieve(self, request: RetrievalRequest) -> RetrievalResult:
        t0 = time.time()
        idx = kg_settings().section("indexes").get("vector", {}).get("name", "chunk_embeddings")
        if not neo4j_client.verify_connectivity():
            return RetrievalResult(query=request.query, metadata={"execution_time": 0.0, "error": "Neo4j unavailable"})
        if not llm_client.embedder_configured():
            return RetrievalResult(query=request.query, metadata={"execution_time": 0.0, "error": "No embedder configured (EMBEDDING_* in .env)"})
        try:
            vector = llm_client.embed(request.query)
            rows = neo4j_client.execute_query(_VECTOR, {"index": idx, "k": request.top_k, "vector": vector,
                                                        "min_score": request.min_similarity})
        except Exception as exc:  # noqa: BLE001 - index missing or embedder down
            logger.warning("Vector search failed: %s", exc)
            return RetrievalResult(query=request.query, metadata={"execution_time": time.time() - t0, "error": str(exc)})
        results = [SemanticSearchResult(chunk_id=r["chunk_id"] or "", document_id=r["document_id"] or "", document_title=r["title"] or "",
                                        text=r["text"] or "", score=float(r["score"]), source=r["source_label"],
                                        metadata={"chunk_index": r["chunk_index"], "source_records": len(r["sources"])})
                   for r in rows]
        seeds = sorted({s for r in rows for s in r["sources"]})
        evidence = self._expand(seeds, request.graph_depth) if seeds and request.graph_depth > 0 else self._seeds_only(seeds)
        return RetrievalResult(query=request.query, semantic_results=results, graph_evidence=evidence,
                               metadata={"execution_time": time.time() - t0, "retrieval_method": "vector + graph expansion",
                                         "top_k": request.top_k, "graph_depth": request.graph_depth, "min_similarity": request.min_similarity,
                                         "semantic_results_count": len(results), "graph_entities_count": len(evidence.entities),
                                         "graph_relationships_count": len(evidence.relationships), "vector_index": idx})

    # ------------------------------------------------------------------ expansion
    def _seeds_only(self, seeds: List[str]) -> GraphEvidence:
        if not seeds:
            return GraphEvidence()
        recs = neo4j_client.execute_records("MATCH (n) WHERE elementId(n) IN $ids RETURN n", {"ids": seeds})
        return GraphEvidence(entities=[self._entity(r["n"]) for r in recs])

    def _expand(self, seeds: List[str], depth: int) -> GraphEvidence:
        skip = list(LEXICAL_LABELS | SEMANTIC_LABELS)
        recs = neo4j_client.execute_records(
            f"MATCH (s) WHERE elementId(s) IN $ids "
            f"OPTIONAL MATCH p = (s)-[*1..{int(depth)}]-(m) WHERE none(x IN nodes(p) WHERE any(l IN labels(x) WHERE l IN $skip)) "
            "AND all(r IN relationships(p) WHERE r.fk_column IS NOT NULL OR r.derived) "
            "WITH s, collect(p)[..60] AS ps RETURN s, ps", {"ids": seeds, "skip": skip})
        entities: Dict[str, GraphEntity] = {}
        rels: Dict[str, GraphRelationship] = {}
        for rec in recs:
            entities[rec["s"].element_id] = self._entity(rec["s"])
            for p in rec["ps"] or []:
                for n in p.nodes:
                    entities.setdefault(n.element_id, self._entity(n))
                for r in p.relationships:
                    rels.setdefault(r.element_id, GraphRelationship(
                        source_id=r.start_node.element_id, target_id=r.end_node.element_id, relationship_type=r.type,
                        source_type=primary_label(list(r.start_node.labels)), target_type=primary_label(list(r.end_node.labels)),
                        properties=clean_props(dict(r))))
            if len(entities) > 120:
                break
        return GraphEvidence(entities=list(entities.values()), relationships=list(rels.values()))

    @staticmethod
    def _entity(n: Any) -> GraphEntity:
        return GraphEntity(entity_id=n.element_id, entity_type=primary_label(list(n.labels)), properties=clean_props(dict(n)))


semantic_retriever = SemanticRetriever()
