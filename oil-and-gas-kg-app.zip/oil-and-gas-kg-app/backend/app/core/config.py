"""
Application configuration.

Two layers, as in the reference projects:

* ``settings`` (pydantic-settings, from ``.env``) - API host/port, CORS, upload limits;
* ``kg_settings()`` - the knowledge-graph pipeline settings (``backend/config.yaml`` + the Neo4j,
  LLM and embedding keys in ``.env``), shared by the API services and ``python -m app.kg``.
"""

from pathlib import Path
from typing import Optional

from pydantic_settings import BaseSettings, SettingsConfigDict

from app.kg.settings import PROJECT_ROOT, Settings as KGSettings, get_settings


class Settings(BaseSettings):
    """Application settings loaded from environment variables (``backend/.env``)."""

    model_config = SettingsConfigDict(env_file=str(PROJECT_ROOT / ".env"), env_file_encoding="utf-8",
                                      case_sensitive=False, extra="ignore")

    # Application
    app_name: str = "Oil & Gas Knowledge Intelligence"
    app_env: str = "development"
    debug: bool = True

    # API
    api_host: str = "127.0.0.1"
    api_port: int = 8000
    frontend_url: str = "http://localhost:3000"

    # Directories and uploads
    upload_dir: str = "./data/uploads"
    documents_dir: str = "./data/documents"
    output_dir: str = "./outputs"
    max_upload_size_bytes: int = 5 * 1024 * 1024  # 5 MB

    # Long-running GraphRAG calls (local LLMs are slow on CPU)
    ask_timeout_seconds: int = 600

    # Optional override of the pipeline config file
    ogkg_config: Optional[str] = None

    def path(self, value: str) -> Path:
        p = Path(value)
        return p if p.is_absolute() else (PROJECT_ROOT / p).resolve()


settings = Settings()


def kg_settings() -> KGSettings:
    """Pipeline settings (config.yaml + .env), loaded once per process."""
    return get_settings()
