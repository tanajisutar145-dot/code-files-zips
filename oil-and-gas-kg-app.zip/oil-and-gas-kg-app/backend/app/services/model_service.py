"""
Model & Standards explorer (semantic model; works before the graph is loaded) and pipeline / system status.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import HTTPException

from app.core.config import kg_settings
from app.graph.neo4j_client import neo4j_client
from app.kg.qa.payload import model_payload
from app.services.common import ensure_neo4j, semantic_model


class ModelService:
    def model(self) -> Dict[str, Any]:
        return model_payload(kg_settings(), semantic_model())

    def class_sample(self, label: str, limit: int = 12) -> Dict[str, Any]:
        from app.kg.qa.graphjson import GraphJsonBuilder

        sem = semantic_model()
        if sem.by_label(label) is None:
            raise HTTPException(status_code=404, detail=f"Unknown class '{label}'")
        ensure_neo4j()
        recs = neo4j_client.execute_records(
            f"MATCH (n:`{label}`) WITH n LIMIT $limit OPTIONAL MATCH (n)-[r]-(m) WHERE (r.fk_column IS NOT NULL OR r.derived) "
            "AND NOT m:Chunk AND NOT m:Document RETURN n, collect(r)[..6] AS rels", {"limit": max(1, min(limit, 40))})
        return GraphJsonBuilder(kg_settings(), sem).from_records(recs)

    def standards(self) -> Dict[str, Any]:
        """Standards alignment summary: standard class -> ontology classes, and attribute mappings."""
        sem = semantic_model()
        by_std: Dict[str, Any] = {}
        for t in sem.tables.values():
            if not t.standard_class:
                continue
            info = sem.standard_classes.get(t.standard_class, {})
            entry = by_std.setdefault(t.standard_class, {"standard_class": t.standard_class, "package": info.get("package"),
                                                         "standard": info.get("standard"), "parents": t.standard_ancestors, "classes": []})
            entry["classes"].append({"label": t.label, "table": t.table_id, "match": t.standard_match})
        attrs = [{"class": t.label, "column": c.column, "standard_attribute": c.standard_attribute, "match": c.standard_match, "unit": c.unit}
                 for t in sem.tables.values() for c in t.columns if c.standard_attribute]
        return {"standard": sem.standard, "classes": sorted(by_std.values(), key=lambda x: x["standard_class"]), "attributes": attrs,
                "use_cases": {k: v for k, v in sem.subject_areas.items() if k.startswith("UC")}}


class SystemService:
    def _json(self, path: Path) -> Optional[Dict[str, Any]]:
        try:
            return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None
        except Exception:  # noqa: BLE001
            return None

    def pipeline_status(self) -> Dict[str, Any]:
        s = kg_settings()
        build, out = s.build_dir, s.output_dir
        validation = self._json(out / "data_validation.json")
        load = self._json(out / "load_summary.json")
        sem = semantic_model(optional=True)
        return {
            "config": str(s.root / "config.yaml"),
            "model_step": {"semantic_model": (build / "semantic_model.json").exists(), "graph_schema": (build / "graph_schema.json").exists(),
                           "ontology_subset": (build / "ontology_subset.ttl").exists(),
                           "classes": len(sem.tables) if sem else 0, "relationships": len(sem.relationships) if sem else 0,
                           "aligned_classes": sum(1 for t in sem.tables.values() if t.standard_class) if sem else 0},
            "validation": {"passed": validation.get("passed"), "rows": validation.get("rows"), "foreign_keys": validation.get("foreign_keys"),
                           "issues": validation.get("issues")} if validation else None,
            "load_step": load,
            "report": (out / "report.md").exists(),
            "neo4j": {"configured": neo4j_client.is_configured(), "connected": neo4j_client.verify_connectivity(), "database": neo4j_client.database},
            "commands": {"model": "python -m app.kg run --step model", "load": "python -m app.kg run --step load",
                         "rag": "python -m app.kg run --step rag", "viz": "python -m app.kg run --step viz", "all": "python -m app.kg run --step all"},
        }


model_service = ModelService()
system_service = SystemService()
