"""
Helpers shared by the API services: JSON-safe values, node display information, semantic model access.
"""

from __future__ import annotations

import logging
import threading
from datetime import date, datetime
from typing import Any, Dict, List, Tuple

from fastapi import HTTPException

from app.core.config import kg_settings
from app.graph.neo4j_client import neo4j_client

logger = logging.getLogger(__name__)

_sem_lock = threading.Lock()
_sem_cache: dict[str, Any] = {}

# labels that are infrastructure, not domain records
LEXICAL_LABELS = {"Document", "Chunk"}
SEMANTIC_LABELS = {"OntologyClass", "StandardClass", "OntologyProperty", "StandardAttribute", "SubjectArea"}


def serialize_property_value(val: Any) -> Any:
    """Convert Neo4j values (temporal, spatial, vectors) to JSON-serializable primitives."""
    if val is None:
        return None
    if isinstance(val, (datetime, date)):
        return val.isoformat()
    if hasattr(val, "iso_format"):
        return val.iso_format()
    if hasattr(val, "isoformat"):
        return val.isoformat()
    if hasattr(val, "srid") and hasattr(val, "x") and hasattr(val, "y"):
        return {"latitude": val.y, "longitude": val.x}
    if hasattr(val, "to_native"):
        native = val.to_native()
        return native.isoformat() if hasattr(native, "isoformat") else str(native)
    if isinstance(val, (int, float, bool, str)):
        return val
    if isinstance(val, list):
        if len(val) > 20 and all(isinstance(x, (int, float)) for x in val[:5]):
            return f"[{len(val)} dimensions vector]"
        return [serialize_property_value(x) for x in val]
    if isinstance(val, dict):
        return {k: serialize_property_value(v) for k, v in val.items()}
    return str(val)


def clean_props(props: Dict[str, Any]) -> Dict[str, Any]:
    return {k: serialize_property_value(v) for k, v in props.items() if k not in ("embedding", "__tmp_internal_id")}


def std_prefix() -> str:
    return (kg_settings().section("graph").get("standard_labels") or {}).get("prefix", "STD_")


def primary_label(labels: List[str]) -> str:
    """The ontology-class label of a node (standard labels and internal labels removed)."""
    prefix = std_prefix()
    domain = [lab for lab in labels if not lab.startswith("__") and not lab.startswith(prefix)]
    return domain[0] if domain else (labels[0] if labels else "Entity")


def node_display(labels: List[str], props: Dict[str, Any]) -> Tuple[str, str, str]:
    """(primary label, domain entity id, display name) for any node of the knowledge graph."""
    label = primary_label(labels)
    sem = semantic_model(optional=True)
    entity_id = ""
    if sem is not None:
        t = sem.by_label(label)
        if t is not None and t.primary_key and props.get(t.primary_key) is not None:
            entity_id = str(props[t.primary_key])
    if not entity_id:
        entity_id = str(props.get("api10") or props.get("document_id") or props.get("id") or props.get("name") or "")
    name = str(props.get("caption") or props.get("title") or props.get("name") or props.get("path") or entity_id or label)
    return label, entity_id, name


def semantic_model(optional: bool = False):
    """The extracted semantic model (``build/semantic_model.json``), cached; None when missing and optional."""
    from app.kg.ontology.extract import SemanticModel

    with _sem_lock:
        if "sem" not in _sem_cache:
            try:
                _sem_cache["sem"] = SemanticModel.load(kg_settings())
            except SystemExit as exc:
                if optional:
                    return None
                raise HTTPException(status_code=503, detail=f"Semantic model not built yet: {exc}") from exc
        return _sem_cache["sem"]


def reset_semantic_cache() -> None:
    with _sem_lock:
        _sem_cache.clear()


def ensure_neo4j() -> None:
    if not neo4j_client.verify_connectivity():
        raise HTTPException(status_code=503, detail="Knowledge graph database unavailable: start Neo4j and check NEO4J_* in backend/.env.")


def query(cypher: str, **params: Any) -> List[Dict[str, Any]]:
    """Read query with JSON-safe values."""
    ensure_neo4j()
    return [{k: serialize_property_value(v) for k, v in row.items()} for row in neo4j_client.execute_query(cypher, params)]
