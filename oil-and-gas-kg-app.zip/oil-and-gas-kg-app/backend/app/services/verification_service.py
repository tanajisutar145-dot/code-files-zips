"""
Verification service for human-in-the-loop review of GraphRAG answers.

Answers with low grounding (or flagged by the user) are queued; reviewers approve or reject them with a
comment. The queue is persisted as JSON under ``outputs/verification_queue.json`` so it survives restarts.
"""

from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.core.config import settings

_LOCK = threading.Lock()


class VerificationService:
    def __init__(self):
        self.path: Path = settings.path(settings.output_dir) / "verification_queue.json"

    def _read(self) -> List[Dict[str, Any]]:
        if not self.path.exists():
            return []
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            return []

    def _write(self, items: List[Dict[str, Any]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(items, indent=2, default=str), encoding="utf-8")

    def enqueue(self, question: str, answer: str, confidence: float, reason: str, job_id: Optional[str] = None,
                retriever: Optional[str] = None) -> Dict[str, Any]:
        item = {"id": f"verify-{uuid.uuid4().hex[:8]}", "content": answer, "question": question, "type": "graphrag_answer",
                "status": "pending", "confidence": round(float(confidence), 3), "reason": reason, "job_id": job_id, "retriever": retriever,
                "created_at": datetime.now(timezone.utc).isoformat(), "reviewed_at": None, "reviewer": None, "comment": None}
        with _LOCK:
            items = self._read()
            items.append(item)
            self._write(items)
        return item

    async def get_pending_items(self) -> List[Dict[str, Any]]:
        return [i for i in self._read() if i["status"] == "pending"]

    async def get_items(self) -> List[Dict[str, Any]]:
        return self._read()

    async def review_item(self, item_id: str, decision: str, comment: Optional[str] = None, reviewer: str = "reviewer") -> Dict[str, Any]:
        with _LOCK:
            items = self._read()
            for i in items:
                if i["id"] == item_id:
                    i.update(status=decision, reviewed_at=datetime.now(timezone.utc).isoformat(), reviewer=reviewer, comment=comment)
                    self._write(items)
                    return i
        raise KeyError(item_id)

    async def get_stats(self) -> Dict[str, Any]:
        items = self._read()
        approved = sum(i["status"] == "approved" for i in items)
        rejected = sum(i["status"] == "rejected" for i in items)
        reviewed = approved + rejected
        return {"pending": sum(i["status"] == "pending" for i in items), "approved": approved, "rejected": rejected, "total": len(items),
                "accuracy_rate": round(approved / reviewed, 3) if reviewed else None}


verification_service = VerificationService()
