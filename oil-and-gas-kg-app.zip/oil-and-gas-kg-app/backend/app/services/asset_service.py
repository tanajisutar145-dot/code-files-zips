"""
Service for equipment integrity: register with integrity counters, and full relational context of one item
(facility, ISO 14224 functional location, PM plans, integrity programmes, inspections, failures, work orders,
production downtime, HSE events and drilling NPT).
"""

import logging
from typing import Any, Dict, Optional

from app.core.config import kg_settings
from app.models.assets import AssetDetailResponse, AssetListItem, AssetListResponse, AssetOverviewResponse
from app.services.common import query
from app.services.usecase_service import graph_for

logger = logging.getLogger(__name__)


def _as_of() -> str:
    return str(kg_settings().section("api").get("as_of_date", "2026-09-30"))


class AssetService:
    def get_overview(self) -> AssetOverviewResponse:
        as_of = _as_of()
        row = query("""
            MATCH (e:Equipment)
            RETURN count(e) AS total, sum(CASE WHEN e.is_safety_critical THEN 1 ELSE 0 END) AS safety,
                   sum(CASE WHEN e.is_safety_critical AND e.next_inspection_due_date < date($as_of) THEN 1 ELSE 0 END) AS overdue""", as_of=as_of)[0]
        failures = query("MATCH (f:FailureReport) RETURN count(f) AS c")[0]["c"]
        open_wo = query("MATCH (w:WorkOrder) WHERE w.work_order_status <> 'closed' RETURN count(w) AS c")[0]["c"]
        crit = {r["k"]: r["c"] for r in query("MATCH (e:Equipment) RETURN e.criticality_ranking AS k, count(*) AS c") if r["k"]}
        cls = {r["k"]: r["c"] for r in query("MATCH (e:Equipment) RETURN e.equipment_type AS k, count(*) AS c ORDER BY c DESC") if r["k"]}
        fac = {r["k"]: r["c"] for r in query("MATCH (e:Equipment)-[:ASSET_FACILITY]->(f:AssetFacility) RETURN f.facility_name AS k, count(*) AS c ORDER BY c DESC")}
        return AssetOverviewResponse(total_equipment=row["total"], safety_critical=row["safety"], overdue_inspections=row["overdue"],
                                     failures=failures, open_work_orders=open_wo, criticality_counts=crit, class_counts=cls,
                                     facility_counts=fac, as_of=as_of)

    def list_assets(self, search: Optional[str] = None, equipment_type: Optional[str] = None, criticality: Optional[str] = None,
                    facility_code: Optional[str] = None, safety_critical: Optional[bool] = None, skip: int = 0, limit: int = 50) -> AssetListResponse:
        params: Dict[str, Any] = {"search": (search or "").lower() or None, "etype": equipment_type, "crit": criticality,
                                  "fac": facility_code, "safety": safety_critical, "skip": skip, "limit": limit, "as_of": _as_of()}
        where = """
            WHERE ($search IS NULL OR toLower(e.tag) CONTAINS $search OR toLower(e.equipment_name) CONTAINS $search)
              AND ($etype IS NULL OR e.equipment_type = $etype) AND ($crit IS NULL OR e.criticality_ranking = $crit)
              AND ($fac IS NULL OR f.facility_code = $fac) AND ($safety IS NULL OR e.is_safety_critical = $safety)"""
        total = query(f"MATCH (e:Equipment) OPTIONAL MATCH (e)-[:ASSET_FACILITY]->(f:AssetFacility) {where} RETURN count(e) AS c", **params)[0]["c"]
        rows = query(f"""
            MATCH (e:Equipment) OPTIONAL MATCH (e)-[:ASSET_FACILITY]->(f:AssetFacility) {where}
            WITH e, f ORDER BY e.tag SKIP $skip LIMIT $limit
            RETURN e.equipment_id AS equipment_id, e.tag AS tag, e.equipment_name AS name, e.equipment_type AS equipment_type,
                   f.facility_name AS facility, f.facility_code AS facility_code, e.criticality_ranking AS criticality,
                   coalesce(e.is_safety_critical, false) AS safety_critical, e.maintenance_strategy AS maintenance_strategy,
                   e.next_inspection_due_date AS next_inspection_due_date,
                   coalesce(e.next_inspection_due_date < date($as_of), false) AS inspection_overdue,
                   COUNT {{ (:FailureReport)-[:EQUIPMENT]->(e) }} AS failure_count,
                   COUNT {{ (:InspectionEvent)-[:EQUIPMENT]->(e) }} AS inspection_count,
                   COUNT {{ (:WorkOrder)-[:EQUIPMENT]->(e) }} AS work_order_count,
                   reduce(m = null, d IN [(fr:FailureReport)-[:EQUIPMENT]->(e) | fr.failure_date] |
                          CASE WHEN m IS NULL OR d > m THEN d ELSE m END) AS last_failure_date,
                   e.mtbf_hours AS mtbf_hours, e.std_class AS std_class""", **params)
        return AssetListResponse(assets=[AssetListItem(**r) for r in rows], total=total, skip=skip, limit=limit,
                                 filters_applied={k: v for k, v in params.items() if v is not None and k not in ("skip", "limit", "as_of")})

    def get_asset_detail(self, key: str) -> Optional[AssetDetailResponse]:
        """``key`` is an equipment tag (e.g. FD1-K-201) or a numeric equipment_id."""
        ident = int(key) if key.isdigit() else None
        found = query("MATCH (e:Equipment) WHERE e.tag = $tag OR e.equipment_id = $id RETURN properties(e) AS p", tag=key, id=ident)
        if not found:
            return None
        p = found[0]["p"]
        eid = p["equipment_id"]
        q = lambda c: query(c, id=eid)  # noqa: E731
        facility = q("MATCH (e:Equipment {equipment_id: $id})-[:ASSET_FACILITY]->(f:AssetFacility) RETURN f.facility_code AS code, f.facility_name AS name, "
                     "f.facility_type AS type, f.latitude AS latitude, f.longitude AS longitude, f.iso_55001_classification AS iso_55001")
        parent = q("MATCH (e:Equipment {equipment_id: $id})-[:PARENT_EQUIPMENT]->(x:Equipment) RETURN x.tag AS tag, x.equipment_name AS name")
        children = q("MATCH (x:Equipment)-[:PARENT_EQUIPMENT]->(e:Equipment {equipment_id: $id}) RETURN x.tag AS tag, x.equipment_name AS name, x.is_safety_critical AS safety_critical")
        floc = q("MATCH (e:Equipment {equipment_id: $id})<-[:LOCATES]-(h:Hierarchy) OPTIONAL MATCH path = (h)-[:CHILD_OF*0..6]->(top:Hierarchy) "
                 "WITH path ORDER BY length(path) DESC LIMIT 1 UNWIND reverse(nodes(path)) AS n "
                 "RETURN n.functional_location_code AS code, n.hierarchy_level AS iso14224_level, n.notes AS name")
        plans = q("MATCH (pm:PreventiveMaintenancePlan)-[:EQUIPMENT]->(e:Equipment {equipment_id: $id}) RETURN pm.plan_code AS plan, pm.plan_name AS name, "
                  "pm.maintenance_strategy_type AS strategy, pm.frequency_value + ' ' + pm.frequency_unit AS frequency, pm.next_scheduled_date AS next_due")
        programs = q("MATCH (ip:IntegrityProgram) WHERE (ip)-[:EQUIPMENT]->(:Equipment {equipment_id: $id}) OR "
                     "(ip)<-[:INTEGRITY_PROGRAM]-(:InspectionEvent)-[:EQUIPMENT]->(:Equipment {equipment_id: $id}) "
                     "RETURN DISTINCT ip.program_number AS program, ip.program_name AS name, ip.applicable_standard AS standard, ip.damage_mechanism AS damage_mechanism")
        inspections = q("MATCH (i:InspectionEvent)-[:EQUIPMENT]->(e:Equipment {equipment_id: $id}) RETURN i.inspection_number AS inspection, i.inspection_date AS date, "
                        "i.inspection_type AS type, i.defect_severity AS severity, i.fitness_for_service_result AS fitness_for_service, "
                        "i.inspection_findings AS findings, i.regulatory_reference AS reference ORDER BY date")
        failures = q("MATCH (f:FailureReport)-[:EQUIPMENT]->(e:Equipment {equipment_id: $id}) OPTIONAL MATCH (f)-[:INSPECTION_EVENT]->(i:InspectionEvent) "
                     "OPTIONAL MATCH (f)-[:PREVIOUS_FAILURE_REPORT]->(prev:FailureReport) OPTIONAL MATCH (f)-[:WORK_ORDER]->(w:WorkOrder) "
                     "RETURN f.failure_report_number AS failure, f.failure_date AS date, f.failure_mode AS failure_mode, f.failure_cause AS cause, "
                     "f.repair_cost AS repair_cost_usd, f.production_impact_boe AS deferred_boe, i.inspection_number AS preceded_by_inspection, "
                     "prev.failure_report_number AS previous_failure, w.work_order_number AS work_order ORDER BY date")
        work_orders = q("MATCH (w:WorkOrder)-[:EQUIPMENT]->(e:Equipment {equipment_id: $id}) RETURN w.work_order_number AS work_order, w.work_type AS type, "
                        "w.priority AS priority, w.work_order_status AS status, w.actual_start_timestamp AS started, w.work_order_description AS description ORDER BY started")
        downtime = q("MATCH (d:DowntimeEvent)-[:EQUIPMENT]->(e:Equipment {equipment_id: $id}) RETURN d.event_number AS event, d.downtime_category AS category, "
                     "d.start_timestamp AS start, d.duration_hours AS hours, d.deferred_boe AS deferred_boe ORDER BY start")
        hse = q("MATCH (x)-[:EQUIPMENT]->(e:Equipment {equipment_id: $id}) WHERE x:ProcessSafetyEvent OR x:SpillEvent OR x:Violation OR x:IncidentInvestigation "
                "OR x:PermitToWork OR x:HseCorrectiveAction RETURN [l IN labels(x) WHERE NOT l STARTS WITH 'STD_' AND NOT l STARTS WITH '__'][0] AS type, x.caption AS record")
        npt = q("MATCH (n:NptEvent)-[:EQUIPMENT]->(e:Equipment {equipment_id: $id}) OPTIONAL MATCH (n)-[:DRILLING_WELL]->(d:DrillingWell) "
                "RETURN n.event_number AS event, n.event_category AS category, n.duration_hours AS hours, d.well_name AS well, n.lessons_learned AS lesson ORDER BY event")
        graph = graph_for("MATCH (e:Equipment {equipment_id: $id}) OPTIONAL MATCH a = (e)-[r]-(m) WHERE (r.fk_column IS NOT NULL OR r.derived) "
                          "OPTIONAL MATCH b = (m)-[:INSPECTION_EVENT|WORK_ORDER|INCIDENT|PROCESS_SAFETY_EVENT|PREVIOUS_FAILURE_REPORT]->() WHERE m:FailureReport "
                          "RETURN collect(DISTINCT a) + collect(DISTINCT b) AS ps", id=eid)
        return AssetDetailResponse(asset=p, facility=facility[0] if facility else None, parent=parent[0] if parent else None, children=children,
                                   functional_location=floc, maintenance_plans=plans, integrity_programs=programs, inspections=inspections,
                                   failures=failures, work_orders=work_orders, downtime=downtime, hse_events=hse, drilling_npt=npt, graph=graph)


asset_service = AssetService()
