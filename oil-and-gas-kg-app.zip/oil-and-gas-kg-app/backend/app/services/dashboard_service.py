"""
Service for the executive dashboard: live oil & gas KPIs, graph / document statistics and use-case highlights.
Read-only, parameterised Cypher; no LLM calls.
"""

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List

from fastapi import HTTPException

from app.core.config import kg_settings
from app.llm.client import llm_client
from app.models.dashboard import DashboardDocumentStats, DashboardGraphStats, DashboardSummaryResponse, KpiGroup
from app.services.common import ensure_neo4j, query, semantic_model
from app.services.usecase_service import usecase_service

logger = logging.getLogger(__name__)

KPI_QUERIES: Dict[str, tuple[str, str]] = {
    "wells": ("Wells & identity", """
        MATCH (i:WellIdentity) WITH count(i) AS physical_wells
        MATCH (d:DrillingWell) WITH physical_wells, count(d) AS wellbores
        MATCH (p:ProductionWell) WITH physical_wells, wellbores, count(p) AS production_records,
             sum(CASE WHEN p.well_status = 'producing' THEN 1 ELSE 0 END) AS producing
        OPTIONAL MATCH (:ProductionWell)-[c:NAME_MATCH_API_CONFLICT]->()
        RETURN physical_wells, wellbores, production_records, producing, count(c) AS api_conflicts"""),
    "production": ("Production (latest allocation month)", """
        MATCH (a:ProductionAllocation) WITH max(a.production_month) AS m
        MATCH (a:ProductionAllocation {production_month: m})
        RETURN m AS month, round(sum(a.gross_oil_volume_bbl)) AS gross_oil_bbl, round(sum(a.gross_gas_volume_mcf)) AS gross_gas_mcf,
               round(sum(a.total_boe)) AS boe, count(a) AS wells_allocated"""),
    "drilling": ("Drilling", """
        MATCH (n:NptEvent) WITH count(n) AS npt_events, round(sum(n.duration_hours), 1) AS npt_hours, sum(n.estimated_cost_impact_usd) AS npt_cost_usd
        MATCH (w:WellControlEvent) RETURN npt_events, npt_hours, npt_cost_usd, count(w) AS well_control_events,
              sum(CASE WHEN w.event_type = 'kick' THEN 1 ELSE 0 END) AS kicks"""),
    "integrity": ("Asset integrity", """
        MATCH (f:FailureReport) WITH count(f) AS failures, sum(f.repair_cost) AS repair_cost_usd, sum(f.production_impact_boe) AS deferred_boe
        MATCH (e:Equipment) WITH failures, repair_cost_usd, deferred_boe,
             sum(CASE WHEN e.is_safety_critical AND e.next_inspection_due_date < date($as_of) THEN 1 ELSE 0 END) AS overdue_safety_critical
        MATCH (w:WorkOrder) RETURN failures, repair_cost_usd, deferred_boe, overdue_safety_critical,
              sum(CASE WHEN w.work_order_status <> 'closed' THEN 1 ELSE 0 END) AS open_work_orders"""),
    "hse": ("HSE & process safety", """
        MATCH (i:Incident) WITH count(i) AS incidents
        MATCH (p:ProcessSafetyEvent) WITH incidents, sum(CASE WHEN p.pse_tier_classification = 'Tier 1' THEN 1 ELSE 0 END) AS pse_tier_1,
             sum(CASE WHEN p.pse_tier_classification = 'Tier 2' THEN 1 ELSE 0 END) AS pse_tier_2
        MATCH (c:HseCorrectiveAction) WITH incidents, pse_tier_1, pse_tier_2,
             sum(CASE WHEN c.action_status IN ['open', 'in_progress', 'overdue', 'pending_verification'] THEN 1 ELSE 0 END) AS open_capas
        MATCH (v:Violation) RETURN incidents, pse_tier_1, pse_tier_2, open_capas, count(v) AS violations, sum(v.penalty_amount) AS penalties_usd"""),
    "emissions": ("Emissions", """
        MATCH (g:GhgEmission) WITH round(sum(g.co2e_tonnes), 1) AS co2e_t, round(sum(CASE WHEN g.ghg_gas_type = 'CH4' THEN g.ghg_quantity_tonnes ELSE 0 END), 2) AS ch4_t
        MATCH (f:FlareRecord) WITH co2e_t, ch4_t, round(sum(f.flare_volume_mcf)) AS flared_mcf
        MATCH (l:LdarSurvey) RETURN co2e_t, ch4_t, flared_mcf, sum(toInteger(l.leaks_detected_count)) AS ldar_leaks"""),
}

TREND_QUERIES = {
    "production_by_month": """MATCH (a:ProductionAllocation) RETURN a.production_month AS month, round(sum(a.gross_oil_volume_bbl)) AS gross_oil_bbl,
                              round(sum(a.gross_gas_volume_mcf)) AS gross_gas_mcf ORDER BY month""",
    "npt_by_category": """MATCH (n:NptEvent) RETURN n.event_category AS category, round(sum(n.duration_hours), 1) AS hours, count(*) AS events
                          ORDER BY hours DESC LIMIT 6""",
    "co2e_by_quarter": """MATCH (g:GhgEmission) RETURN toString(g.reporting_period_end_date) AS quarter_end, round(sum(g.co2e_tonnes), 1) AS co2e_t
                          ORDER BY quarter_end""",
    "pse_by_tier": """MATCH (p:ProcessSafetyEvent) RETURN p.pse_tier_classification AS tier, count(*) AS events ORDER BY tier""",
    "failures_by_class": """MATCH (f:FailureReport)-[:EQUIPMENT]->(e:Equipment) RETURN e.equipment_type AS equipment_class, count(f) AS failures
                            ORDER BY failures DESC LIMIT 8""",
}


class DashboardService:
    def get_dashboard_summary(self) -> DashboardSummaryResponse:
        ensure_neo4j()
        cfg = kg_settings()
        as_of = str(cfg.section("api").get("as_of_date", "2026-09-30"))
        try:
            kpis = {}
            for key, (title, cypher) in KPI_QUERIES.items():
                rows = query(cypher, as_of=as_of)
                kpis[key] = KpiGroup(title=title, values=rows[0] if rows else {})
            graph = self._graph_stats()
            documents = self._document_stats(cfg)
            trends = {k: query(v) for k, v in TREND_QUERIES.items()}
            return DashboardSummaryResponse(
                generated_at=datetime.now(timezone.utc).isoformat(), status="healthy" if graph.data_nodes else "empty",
                project=cfg.section("project"), as_of=as_of, kpis=kpis, graph=graph, documents=documents,
                use_cases=usecase_service.overview(), trends=trends, highlights=self._highlights(as_of))
        except HTTPException:
            raise
        except Exception as e:  # noqa: BLE001
            logger.error(f"Error computing dashboard summary: {e}", exc_info=True)
            raise HTTPException(status_code=500, detail=f"Internal error computing dashboard metrics: {e}")

    # ------------------------------------------------------------------ parts
    def _graph_stats(self) -> DashboardGraphStats:
        row = query("""
            MATCH (n) WITH n, [l IN labels(n) WHERE NOT l STARTS WITH 'STD_' AND NOT l STARTS WITH '__'] AS ls
            RETURN count(n) AS total,
                   sum(CASE WHEN any(l IN ls WHERE l IN ['Document', 'Chunk']) THEN 1 ELSE 0 END) AS docs,
                   sum(CASE WHEN any(l IN ls WHERE l IN ['OntologyClass', 'StandardClass', 'OntologyProperty', 'StandardAttribute', 'SubjectArea']) THEN 1 ELSE 0 END) AS sem,
                   sum(CASE WHEN 'WellIdentity' IN ls THEN 1 ELSE 0 END) AS ident""")[0]
        rels = query("MATCH ()-[r]->() RETURN count(r) AS c")[0]["c"]
        by_domain = {r["domain"]: r["c"] for r in query("MATCH (n) WHERE n.source_table IS NOT NULL RETURN n.subject_area AS domain, count(*) AS c ORDER BY c DESC")}
        sem = semantic_model(optional=True)
        aligned = sum(1 for t in sem.tables.values() if t.standard_class) if sem else 0
        data_nodes = sum(by_domain.values())
        return DashboardGraphStats(total_nodes=row["total"], total_relationships=rels, data_nodes=data_nodes, semantic_nodes=row["sem"],
                                   document_nodes=row["docs"], identity_nodes=row["ident"], nodes_by_domain=by_domain,
                                   aligned_classes=aligned, standard_classes=len(sem.standard_classes) if sem else 0)

    def _document_stats(self, cfg) -> DashboardDocumentStats:
        row = query("""
            OPTIONAL MATCH (d:Document) WITH count(d) AS docs, sum(CASE WHEN d.document_id IS NOT NULL THEN 1 ELSE 0 END) AS uploaded
            OPTIONAL MATCH (c:Chunk) RETURN docs, uploaded, count(c) AS chunks, sum(CASE WHEN c.embedding IS NOT NULL THEN 1 ELSE 0 END) AS embedded""")[0]
        idx_name = cfg.section("indexes").get("vector", {}).get("name", "chunk_embeddings")
        status, population = "ABSENT", 0.0
        try:
            idx = query("SHOW INDEXES YIELD name, state, populationPercent WHERE name = $name RETURN state, populationPercent", name=idx_name)
            if idx:
                status, population = idx[0]["state"], float(idx[0]["populationPercent"] or 0.0)
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Could not read vector index status: {e}")
        emb = cfg.embedding
        return DashboardDocumentStats(total_documents=row["docs"] or 0, uploaded_documents=row["uploaded"] or 0, total_chunks=row["chunks"] or 0,
                                      embedded_chunks=row["embedded"] or 0,
                                      embedding_model=f"{emb.provider} / {emb.model}" if emb else llm_client.describe()["embedder"],
                                      embedding_dimension=emb.dimensions if emb else None, vector_index_name=idx_name,
                                      vector_index_status=status, vector_index_population=population)

    def _highlights(self, as_of: str) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []

        def add(uc: str, cypher: str, fmt, **params: Any) -> None:
            try:
                rows = query(cypher, **params)
                if rows and any(v is not None for v in rows[0].values()):
                    out.append({"use_case": uc, "text": fmt(rows[0])})
            except Exception as e:  # noqa: BLE001
                logger.debug("highlight %s skipped: %s", uc, e)

        add("UC1", "MATCH (p:ProductionWell)-[c:NAME_MATCH_API_CONFLICT]->(d:DrillingWell) RETURN count(c) AS n, collect(p.well_name)[..3] AS wells",
            lambda r: f"{r['n']} production records carry an API number that conflicts with the drilling register ({', '.join(r['wells'])}).")
        add("UC2", "MATCH (n:NptEvent) RETURN n.event_category AS cat, round(sum(n.duration_hours), 1) AS h ORDER BY h DESC LIMIT 1",
            lambda r: f"'{r['cat']}' is the largest NPT category: {r['h']} rig hours.")
        add("UC3", "MATCH (f:FailureReport)-[:EQUIPMENT]->(e:Equipment) WITH e, count(f) AS n, sum(f.repair_cost) AS c ORDER BY n DESC, c DESC LIMIT 1 "
                   "RETURN e.tag AS tag, n, c",
            lambda r: f"Bad actor {r['tag']}: {r['n']} failures, USD {r['c']:,.0f} repair cost.")
        add("UC4", "MATCH (p:ProcessSafetyEvent {pse_tier_classification: 'Tier 1'}) OPTIONAL MATCH (p)-[:PRODUCTION_FACILITY]->(f) "
                   "RETURN p.pse_number AS pse, f.facility_name AS fac, p.release_quantity AS q, p.release_unit_of_measure AS u ORDER BY p.event_date DESC LIMIT 1",
            lambda r: f"Tier 1 process safety event {r['pse']} at {r['fac']}: {r['q']} {r['u']} released.")
        add("UC5", "MATCH (m:MeterStation) WHERE m.next_calibration_due_date < date($as_of) AND m.custody_transfer_flag "
                   "OPTIONAL MATCH (a:ProductionAllocation)-[:METER_STATION]->(m) WHERE abs(a.oil_allocation_variance_bbl) > 150 "
                   "RETURN m.station_code AS meter, count(a) AS n ORDER BY n DESC LIMIT 1",
            lambda r: f"Custody meter {r['meter']} is past its calibration date and carries {r['n']} allocations with variance > 150 bbl.", as_of=as_of)
        return out


dashboard_service = DashboardService()
