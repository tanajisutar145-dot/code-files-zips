"""
Search service: keyword search (Neo4j full-text indexes + record captions) and "find similar" by chunk embeddings.
"""

import re
import time
from typing import Dict, List, Optional

from app.core.config import kg_settings
from app.graph.neo4j_client import neo4j_client
from app.services.common import ensure_neo4j, primary_label

_LUCENE_SPECIAL = re.compile(r'([+\-&|!(){}\[\]^"~*?:\\/])')


class SearchService:
    def _indexes(self) -> Dict[str, str]:
        idx = kg_settings().section("indexes")
        return {"chunks": idx.get("fulltext", {}).get("name", "chunk_fulltext"),
                "rows": idx.get("narrative_fulltext", {}).get("name", "row_narratives"),
                "vector": idx.get("vector", {}).get("name", "chunk_embeddings")}

    async def keyword_search(self, query: str, filters: Optional[Dict] = None, limit: int = 50) -> Dict:
        ensure_neo4j()
        t0 = time.time()
        ix = self._indexes()
        q = _LUCENE_SPECIAL.sub(r"\\\1", query.strip())
        label = (filters or {}).get("label")
        results: List[Dict] = []
        # 1. records whose caption contains the query (identifiers, names)
        for r in neo4j_client.execute_query(
                "MATCH (n) WHERE n.caption IS NOT NULL AND n.source_table IS NOT NULL AND toLower(n.caption) CONTAINS toLower($q) "
                "AND ($label IS NULL OR $label IN labels(n)) "
                "RETURN elementId(n) AS id, n.caption AS title, labels(n) AS labels, n.subject_area AS area, n.std_class AS std LIMIT $limit",
                {"q": query.strip(), "label": label, "limit": limit}):
            results.append({"id": r["id"], "title": r["title"], "content": f"{primary_label(r['labels'])} record", "type": "record",
                            "score": 1.0, "metadata": {"label": primary_label(r["labels"]), "subject_area": r["area"], "std_class": r["std"]}})
        # 2. narrative text of records (full-text index over narrative columns)
        try:
            for r in neo4j_client.execute_query(
                    f"CALL db.index.fulltext.queryNodes($index, $q) YIELD node, score RETURN elementId(node) AS id, node.caption AS title, "
                    "labels(node) AS labels, score LIMIT $limit", {"index": ix["rows"], "q": q, "limit": limit}):
                results.append({"id": r["id"], "title": r["title"] or "", "content": "narrative match", "type": "record_narrative",
                                "score": float(r["score"]), "metadata": {"label": primary_label(r["labels"])}})
        except Exception:  # noqa: BLE001 - index not created (load without text)
            pass
        # 3. chunks (record narratives + uploaded documents)
        try:
            for r in neo4j_client.execute_query(
                    "CALL db.index.fulltext.queryNodes($index, $q) YIELD node, score MATCH (node)-[:FROM_DOCUMENT]->(d:Document) "
                    "RETURN node.id AS id, coalesce(d.title, d.path) AS title, left(node.text, 400) AS content, score, d.path AS path LIMIT $limit",
                    {"index": ix["chunks"], "q": q, "limit": limit}):
                results.append({"id": r["id"], "title": r["title"], "content": r["content"], "type": "chunk", "score": float(r["score"]),
                                "metadata": {"document": r["path"]}})
        except Exception:  # noqa: BLE001
            pass
        results.sort(key=lambda x: -x["score"])
        return {"results": results[:limit], "total": len(results), "query_time": time.time() - t0}

    async def find_similar(self, item_id: str, limit: int = 10) -> List[Dict]:
        """Chunks most similar to the first chunk of a record narrative / document / chunk id."""
        ensure_neo4j()
        ix = self._indexes()
        seed = neo4j_client.execute_query(
            "MATCH (c:Chunk) WHERE c.id = $id OR c.chunk_id = $id RETURN c.embedding AS e LIMIT 1 "
            "UNION MATCH (c:Chunk)-[:FROM_DOCUMENT]->(d:Document) WHERE d.document_id = $id OR d.path = $id "
            "RETURN c.embedding AS e ORDER BY c.index LIMIT 1 "
            "UNION MATCH (n)-[:HAS_NARRATIVE]->(:Document)<-[:FROM_DOCUMENT]-(c:Chunk) WHERE elementId(n) = $id OR n.caption = $id "
            "RETURN c.embedding AS e LIMIT 1", {"id": item_id})
        vec = next((r["e"] for r in seed if r["e"]), None)
        if vec is None:
            return []
        rows = neo4j_client.execute_query(
            "CALL db.index.vector.queryNodes($index, $k, $v) YIELD node, score MATCH (node)-[:FROM_DOCUMENT]->(d:Document) "
            "OPTIONAL MATCH (d)<-[:HAS_NARRATIVE]-(src) "
            "RETURN node.id AS id, coalesce(d.title, head(collect(src.caption)), d.path) AS title, left(node.text, 400) AS content, score, "
            "d.path AS path, head(collect(labels(src))) AS labels", {"index": ix["vector"], "k": limit + 1, "v": vec})
        return [{"id": r["id"], "title": r["title"], "content": r["content"], "type": "chunk", "score": float(r["score"]),
                 "metadata": {"document": r["path"], "label": primary_label(r["labels"] or [])}} for r in rows][1:limit + 1]
