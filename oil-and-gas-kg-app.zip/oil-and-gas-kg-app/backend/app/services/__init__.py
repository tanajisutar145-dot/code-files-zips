"""
Business logic services
"""