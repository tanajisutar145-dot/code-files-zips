"""
Use-case analytics for the five knowledge-graph use cases (docs/01_OilGas_KG_Research_and_Use_Cases.md).

Every method runs fixed, read-only, parameterised Cypher over the loaded graph (no LLM) and returns the rows
together with the Cypher text, so the UI can show exactly how each answer was obtained. Relationship types
come from the oil_gas ontology (FK object properties) and the derived rules in config.yaml.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List

from app.core.config import kg_settings
from app.graph.neo4j_client import neo4j_client
from app.services.common import ensure_neo4j, query, semantic_model

logger = logging.getLogger(__name__)


def _as_of() -> str:
    return str(kg_settings().section("api").get("as_of_date", "2026-09-30"))


def _result(rows: List[Dict[str, Any]], cypher: str, **extra: Any) -> Dict[str, Any]:
    return {"rows": rows, "count": len(rows), "cypher": " ".join(cypher.split()), **extra}


def graph_for(cypher: str, **params: Any) -> Dict[str, Any]:
    from app.kg.qa.graphjson import GraphJsonBuilder

    ensure_neo4j()
    builder = GraphJsonBuilder(kg_settings(), semantic_model())
    return builder.from_records(neo4j_client.execute_records(cypher, params))


USE_CASES = [
    {"id": "UC1", "title": "Well & subsurface 360 / well identity", "owner": "Subsurface data management",
     "summary": "One physical well, four registers: resolve exploration, drilling, production and asset records to one PPDM API-10 "
                "identity and walk basin - play - prospect - reservoir - zone - tests - reserves.",
     "standards": ["OSDU master-data Well / Wellbore", "PPDM US Well Number", "SPE-PRMS 2018", "RESQML"], "questions": ["Q1", "Q2", "Q3"]},
    {"id": "UC2", "title": "Drilling performance & lessons learned", "owner": "Drilling & completions",
     "summary": "NPT, kicks and cement issues linked to wells, rigs, formations and zones; offset-well briefs for planned programs.",
     "standards": ["WITSML 2.x", "IADC NPT categories", "API RP 59"], "questions": ["Q4", "Q5", "Q6"]},
    {"id": "UC3", "title": "Asset integrity & reliability", "owner": "Asset integrity / maintenance",
     "summary": "Inspection findings that preceded failures, bad-actor equipment, overdue safety-critical inspections, ISO 14224 hierarchy.",
     "standards": ["ISO 14224:2016", "API 510 / 570 / 653 / RP 576", "API RP 580/581", "CFIHOS tags"], "questions": ["Q7", "Q8", "Q9"]},
    {"id": "UC4", "title": "HSE & process-safety incident intelligence", "owner": "HSE / process safety",
     "summary": "Process safety events with investigations, CAPAs, permits to work, spills and violations; recurring root causes.",
     "standards": ["API RP 754 / IOGP 456", "ISO 45001 CAPA", "Permit-to-work practice"], "questions": ["Q10", "Q11", "Q12"]},
    {"id": "UC5", "title": "Production-to-market & emissions traceability", "owner": "Production accounting / ESG",
     "summary": "Custody transfer back to wells, meters and allocation; facility CO2e, flaring and LDAR leaks; allocation variances.",
     "standards": ["API MPMS", "PRODML", "EPA 40 CFR 98 Subpart W", "OGMP 2.0"], "questions": ["Q13", "Q14", "Q15"]},
]


class UseCaseService:
    # ================================================================== overview
    def overview(self) -> List[Dict[str, Any]]:
        headline = {
            "UC1": "MATCH (i:WellIdentity) WITH count(i) AS wells MATCH (p:ProductionWell)-[:NAME_MATCH_API_CONFLICT]->() "
                   "RETURN wells, count(p) AS conflicts",
            "UC2": "MATCH (n:NptEvent) RETURN count(n) AS npt_events, round(sum(n.duration_hours), 1) AS npt_hours, sum(n.estimated_cost_impact_usd) AS npt_cost_usd",
            "UC3": "MATCH (f:FailureReport) WITH count(f) AS failures MATCH (f2:FailureReport)-[:INSPECTION_EVENT]->() RETURN failures, count(f2) AS preceded_by_inspection",
            "UC4": "MATCH (p:ProcessSafetyEvent) RETURN sum(CASE WHEN p.pse_tier_classification = 'Tier 1' THEN 1 ELSE 0 END) AS tier1, "
                   "sum(CASE WHEN p.pse_tier_classification = 'Tier 2' THEN 1 ELSE 0 END) AS tier2, count(p) AS pse",
            "UC5": "MATCH (g:GhgEmission) WITH round(sum(g.co2e_tonnes)) AS co2e_t MATCH (c:CustodyTransfer) RETURN co2e_t, count(c) AS custody_transfers",
        }
        out = []
        for uc in USE_CASES:
            kpis: Dict[str, Any] = {}
            try:
                rows = query(headline[uc["id"]])
                kpis = rows[0] if rows else {}
            except Exception as exc:  # noqa: BLE001 - graph not loaded yet
                kpis = {"error": str(exc)[:160]}
            out.append({**uc, "kpis": kpis})
        return out

    # ================================================================== UC1 well identity
    WELLS = """
    MATCH (i:WellIdentity)
    OPTIONAL MATCH (i)<-[:IDENTIFIED_BY]-(r)
    WITH i, collect(r) AS recs
    WITH i, [x IN recs WHERE x:DrillingWell] AS dw, [x IN recs WHERE x:ExplorationWell] AS ew,
         [x IN recs WHERE x:ProductionWell] AS pw, [x IN recs WHERE x:WellAsset] AS wa
    RETURN i.api10 AS api10, i.caption AS api,
           coalesce(head([x IN dw WHERE x.api_wellbore_code = '00' | x.well_name]), head([x IN pw | x.well_name]),
                    head([x IN ew | x.well_name]), head([x IN wa | x.well_name])) AS well_name,
           size(dw) AS wellbores, size(ew) > 0 AS in_exploration, size(dw) > 0 AS in_drilling,
           size(pw) > 0 AS in_production, size(wa) > 0 AS in_asset,
           head([x IN wa | x.well_status]) AS asset_status, head([x IN pw | x.current_production_bopd]) AS current_bopd,
           head([(i)<-[:IDENTIFIED_BY]-(:ProductionWell)-[:FIELD]->(f:Field) | f.field_name]) AS field,
           head([(i)<-[:IDENTIFIED_BY]-(:DrillingWell)-[:FORMATION]->(fm:Formation) | fm.formation_name]) AS target_formation
    ORDER BY well_name
    """

    def wells(self) -> Dict[str, Any]:
        rows = query(self.WELLS)
        registers = {k: sum(1 for r in rows if r[k]) for k in ("in_exploration", "in_drilling", "in_production", "in_asset")}
        complete = sum(1 for r in rows if r["in_drilling"] and r["in_production"] and r["in_asset"])
        return _result(rows, self.WELLS, registers=registers, complete_identities=complete)

    def well_360(self, api10: str) -> Dict[str, Any]:
        records = query("MATCH (i:WellIdentity {api10: $api10})<-[:IDENTIFIED_BY]-(r) "
                        "RETURN [l IN labels(r) WHERE NOT l STARTS WITH 'STD_' AND NOT l STARTS WITH '__'][0] AS register, "
                        "r.caption AS name, coalesce(r.api_well_number, r.api_number) AS api, r.uwi AS uwi, r.api_wellbore_code AS wellbore_code, "
                        "r.well_status AS status, r.std_class AS std_class, r.std_match AS std_match ORDER BY register", api10=api10)
        if not records:
            return {"api10": api10, "found": False}
        context_q = """
        MATCH (i:WellIdentity {api10: $api10})<-[:IDENTIFIED_BY]-(d:DrillingWell)
        OPTIONAL MATCH (d)-[:RESERVOIR]->(res:Reservoir) OPTIONAL MATCH (d)-[:FORMATION]->(fm:Formation)
        OPTIONAL MATCH (d)-[:PROSPECT]->(pr:Prospect) OPTIONAL MATCH (pr)-[:PLAY]->(pl:Play) OPTIONAL MATCH (pl)-[:BASIN]->(b:Basin)
        OPTIONAL MATCH (d)-[:RIG]->(rig:Rig)
        RETURN d.well_name AS wellbore, d.api_well_number AS api, d.well_type AS well_type, d.well_status AS status, d.spud_date AS spud_date,
               d.measured_depth_ft AS md_ft, d.true_vertical_depth_ft AS tvd_ft, res.reservoir_name AS reservoir, fm.formation_name AS formation,
               pr.prospect_name AS prospect, pl.play_name AS play, b.basin_name AS basin, rig.rig_name AS rig ORDER BY wellbore"""
        tests_q = """
        MATCH (i:WellIdentity {api10: $api10})<-[:IDENTIFIED_BY]-(w)<-[:WELL_ASSET|EXPLORATION_WELL]-(t:WellTest)
        OPTIONAL MATCH (t)-[:ZONE]->(z:Zone)
        RETURN DISTINCT t.test_number AS test, t.test_type AS type, t.test_start_date AS start, t.oil_flow_rate_bopd AS oil_bopd,
               t.gas_flow_rate_mcfd AS gas_mcfd, z.zone_name AS zone, t.test_comments AS comments ORDER BY start"""
        reserves_q = """
        MATCH (i:WellIdentity {api10: $api10})<-[:IDENTIFIED_BY]-(:WellAsset)<-[:WELL_ASSET]-(re:ReservesEstimate)
        RETURN re.estimate_number AS estimate, re.reserves_category AS category, re.reserves_sub_category AS sub_category,
               re.proved_reserves_volume AS proved_boe, re.effective_date AS effective_date, re.estimation_method AS method"""
        events_q = """
        MATCH (i:WellIdentity {api10: $api10})<-[:IDENTIFIED_BY]-(d:DrillingWell)<-[:DRILLING_WELL]-(e)
        WHERE e:NptEvent OR e:WellControlEvent OR e:CementingJob OR e:WellStatusHistory
        RETURN [l IN labels(e) WHERE NOT l STARTS WITH 'STD_' AND NOT l STARTS WITH '__'][0] AS type, e.caption AS record,
               coalesce(e.event_category, e.event_type, e.job_quality_assessment, e.status_change_reason) AS detail,
               coalesce(e.duration_hours, e.pit_gain_volume_bbl) AS value, coalesce(e.event_start_timestamp, e.event_timestamp, e.job_start_timestamp, e.event_timestamp) AS at
        ORDER BY at"""
        production_q = """
        MATCH (i:WellIdentity {api10: $api10})<-[:IDENTIFIED_BY]-(p:ProductionWell)
        OPTIONAL MATCH (p)<-[:PRODUCTION_WELL]-(a:ProductionAllocation)
        OPTIONAL MATCH (p)<-[:PRODUCTION_WELL]-(al:ArtificialLift)
        RETURN p.well_name AS well, p.well_status AS status, p.current_production_bopd AS current_bopd, p.cumulative_oil_bbls AS cum_oil_bbl,
               collect(DISTINCT {month: a.production_month, gross_oil_bbl: a.gross_oil_volume_bbl, method: a.allocation_method}) AS allocations,
               collect(DISTINCT al.lift_type) AS lift"""
        hse_q = """
        MATCH (i:WellIdentity {api10: $api10})<-[:IDENTIFIED_BY]-(w)
        MATCH (x)-[:WELL_ASSET|DRILLING_WELL]->(w) WHERE x:Incident OR x:ProcessSafetyEvent OR x:Violation OR x:SpillEvent
        RETURN DISTINCT [l IN labels(x) WHERE NOT l STARTS WITH 'STD_' AND NOT l STARTS WITH '__'][0] AS type, x.caption AS record,
               coalesce(x.incident_type, x.pse_tier_classification, x.violation_type) AS detail"""
        graph_q = """
        MATCH p = (i:WellIdentity {api10: $api10})<-[:IDENTIFIED_BY]-(r)
        OPTIONAL MATCH q = (r)-[rel]-(m) WHERE (rel.fk_column IS NOT NULL OR rel.derived) AND NOT m:WellIdentity
        RETURN p, collect(q)[..90] AS qs"""
        return {"api10": api10, "found": True, "records": records, "wellbores": query(context_q, api10=api10),
                "tests": query(tests_q, api10=api10), "reserves": query(reserves_q, api10=api10),
                "drilling_events": query(events_q, api10=api10), "production": query(production_q, api10=api10),
                "hse": query(hse_q, api10=api10), "graph": graph_for(graph_q, api10=api10),
                "cypher": {"records": "MATCH (i:WellIdentity {api10: $api10})<-[:IDENTIFIED_BY]-(r) RETURN r",
                           "context": " ".join(context_q.split())}}

    def identity_issues(self) -> Dict[str, Any]:
        conflicts_q = """
        MATCH (p:ProductionWell)-[c:NAME_MATCH_API_CONFLICT]->(d:DrillingWell)
        RETURN p.well_name AS well_name, p.api_number AS production_api, d.api_well_number AS drilling_api,
               c.production_api10 AS production_api10, c.drilling_api10 AS drilling_api10 ORDER BY well_name"""
        orphan_q = """
        MATCH (p:ProductionWell)-[:IDENTIFIED_BY]->(i:WellIdentity)
        WHERE NOT (i)<-[:IDENTIFIED_BY]-(:WellAsset) AND NOT (p)-[:NAME_MATCH_API_CONFLICT]->()
        RETURN p.well_name AS well_name, p.api_number AS api_number, p.well_status AS status ORDER BY well_name"""
        alias_q = """
        MATCH (a:WellAsset)-[:IDENTIFIED_BY]->(i:WellIdentity)<-[:IDENTIFIED_BY]-(d:DrillingWell)
        WHERE d.api_wellbore_code = '00' AND a.well_name <> d.well_name
        RETURN i.caption AS api, a.well_name AS asset_register_name, d.well_name AS drilling_register_name"""
        single_q = """
        MATCH (i:WellIdentity) WHERE COUNT { (i)<-[:IDENTIFIED_BY]-() } = 1
        MATCH (i)<-[:IDENTIFIED_BY]-(r)
        RETURN i.caption AS api, r.caption AS name, [l IN labels(r) WHERE NOT l STARTS WITH 'STD_' AND NOT l STARTS WITH '__'][0] AS only_register"""
        return {"api_conflicts": _result(query(conflicts_q), conflicts_q), "production_without_asset": _result(query(orphan_q), orphan_q),
                "name_aliases": _result(query(alias_q), alias_q), "single_register": _result(query(single_q), single_q)}

    FORMATION_WELLS = """
    MATCH (d:DrillingWell)-[:FORMATION]->(f:Formation {formation_name: $formation}) WHERE d.api_wellbore_code = '00'
    OPTIONAL MATCH (d)-[:WELL_ASSET]->(wa:WellAsset)
    OPTIONAL MATCH (wa)<-[:WELL_ASSET]-(t:WellTest)
    OPTIONAL MATCH (wa)<-[:WELL_ASSET]-(re:ReservesEstimate)
    WITH d, max(t.oil_flow_rate_bopd) AS best_oil_bopd, collect(DISTINCT re.reserves_category + '/' + re.reserves_sub_category) AS reserves
    OPTIONAL MATCH (d)-[:RESERVOIR]->(res:Reservoir)
    RETURN d.well_name AS well, d.api_well_number AS api, res.reservoir_name AS reservoir, best_oil_bopd, reserves
    ORDER BY best_oil_bopd DESC
    """

    def formation_wells(self, formation: str) -> Dict[str, Any]:
        formations = [r["name"] for r in query("MATCH (f:Formation) RETURN f.formation_name AS name ORDER BY name")]
        return _result(query(self.FORMATION_WELLS, formation=formation), self.FORMATION_WELLS, formation=formation, formations=formations)

    # ================================================================== UC2 drilling
    NPT = """
    MATCH (n:NptEvent)
    RETURN n.event_category AS category, n.iadc_npt_code AS code, count(*) AS events, round(sum(n.duration_hours), 1) AS hours,
           sum(n.estimated_cost_impact_usd) AS cost_usd, sum(CASE WHEN n.preventability_flag THEN 1 ELSE 0 END) AS preventable,
           head(collect(n.lessons_learned)) AS lesson_learned
    ORDER BY hours DESC
    """
    NPT_RIG = """
    MATCH (n:NptEvent)-[:RIG]->(r:Rig)
    RETURN r.rig_name AS rig, count(n) AS events, round(sum(n.duration_hours), 1) AS hours, sum(n.estimated_cost_impact_usd) AS cost_usd
    ORDER BY hours DESC
    """

    def npt_summary(self) -> Dict[str, Any]:
        return {"by_category": _result(query(self.NPT), self.NPT), "by_rig": _result(query(self.NPT_RIG), self.NPT_RIG)}

    OFFSET = """
    MATCH (p:WellProgram {program_number: $program})-[:FORMATION]->(f:Formation)
    MATCH (d:DrillingWell)-[:FORMATION]->(f)
    OPTIONAL MATCH (w:WellControlEvent)-[:DRILLING_WELL]->(d)
    OPTIONAL MATCH (n:NptEvent)-[:DRILLING_WELL]->(d)
    OPTIONAL MATCH (c:CementingJob)-[:DRILLING_WELL]->(d) WHERE c.job_quality_assessment <> 'successful'
    WITH p, f, d, collect(DISTINCT w) AS wces, collect(DISTINCT n) AS npts, collect(DISTINCT c) AS cmts
    RETURN d.well_name AS offset_well, d.spud_date AS spud_date,
           [x IN wces | x.event_number + ' ' + x.event_type + ' (' + toString(x.pit_gain_volume_bbl) + ' bbl)'] AS well_control,
           [x IN npts | x.event_number + ' ' + x.event_category + ' ' + toString(x.duration_hours) + ' h'] AS npt,
           reduce(h = 0.0, x IN npts | h + x.duration_hours) AS npt_hours,
           [x IN cmts | x.job_number + ' ' + x.job_quality_assessment] AS cement_issues
    ORDER BY npt_hours DESC
    """

    def programs(self) -> List[Dict[str, Any]]:
        return query("MATCH (p:WellProgram) OPTIONAL MATCH (p)-[:FORMATION]->(f:Formation) OPTIONAL MATCH (p)-[:PROGRAM_FOR]->(w:DrillingWell) "
                     "RETURN p.program_number AS program, p.program_name AS name, p.program_status AS status, f.formation_name AS formation, "
                     "w.well_name AS well ORDER BY CASE p.program_status WHEN 'approved' THEN 0 WHEN 'draft' THEN 1 ELSE 2 END, program")

    def offset_brief(self, program: str) -> Dict[str, Any]:
        head = query("MATCH (p:WellProgram {program_number: $program}) OPTIONAL MATCH (p)-[:FORMATION]->(f:Formation) "
                     "OPTIONAL MATCH (p)-[:PROSPECT]->(pr:Prospect) RETURN p.program_number AS program, p.program_name AS name, "
                     "p.program_status AS status, p.mud_weight_max AS planned_max_mw_ppg, p.max_anticipated_pressure_psi AS max_pressure_psi, "
                     "f.formation_name AS formation, f.drilling_hazard_notes AS hazard_notes, pr.prospect_name AS prospect", program=program)
        lessons = query("MATCH (p:WellProgram {program_number: $program})-[:FORMATION]->(f:Formation)<-[:FORMATION]-(d:DrillingWell)<-[:DRILLING_WELL]-(n:NptEvent) "
                        "RETURN n.event_category AS category, count(*) AS events, round(sum(n.duration_hours), 1) AS hours, "
                        "head(collect(n.lessons_learned)) AS lesson ORDER BY hours DESC", program=program)
        rows = query(self.OFFSET, program=program)
        return _result(rows, self.OFFSET, program=head[0] if head else None, lessons=lessons)

    WC_CHAINS = """
    MATCH (w:WellControlEvent)-[:DRILLING_WELL]->(d:DrillingWell)
    OPTIONAL MATCH (w)-[:INCIDENT]->(i:Incident)
    OPTIONAL MATCH (w)-[:VIOLATION]->(v:Violation)
    OPTIONAL MATCH (w)-[:PROCESS_SAFETY_EVENT]->(ps:ProcessSafetyEvent)
    WITH w, d, i, v, ps WHERE i IS NOT NULL OR v IS NOT NULL OR ps IS NOT NULL
    OPTIONAL MATCH (n:NptEvent)-[:WELL_CONTROL_EVENT]->(w)
    OPTIONAL MATCH (f:FlareRecord)-[:WELL_CONTROL_EVENT]->(w)
    OPTIONAL MATCH (dt:DowntimeEvent)-[:WELL_CONTROL_EVENT]->(w)
    RETURN w.event_number AS well_control_event, d.well_name AS well, w.measured_depth_ft AS md_ft, w.pit_gain_volume_bbl AS pit_gain_bbl,
           i.incident_number AS incident, v.nov_number AS violation, v.penalty_amount AS penalty_usd, ps.pse_number AS pse,
           ps.pse_tier_classification AS pse_tier, collect(DISTINCT n.event_number) AS npt, sum(DISTINCT n.duration_hours) AS npt_hours,
           collect(DISTINCT f.flare_event_number) AS flaring, collect(DISTINCT dt.event_number) AS downtime
    """
    WC_GRAPH = """
    MATCH (w:WellControlEvent)-[:DRILLING_WELL]->(d:DrillingWell) WHERE (w)-[:INCIDENT|VIOLATION|PROCESS_SAFETY_EVENT]->()
    OPTIONAL MATCH a = (w)-[:INCIDENT|VIOLATION|PROCESS_SAFETY_EVENT|DRILLING_WELL|RIG|DAILY_DRILLING_REPORT]->()
    OPTIONAL MATCH b = ()-[:WELL_CONTROL_EVENT]->(w)
    OPTIONAL MATCH c = (w)-[:VIOLATION]->(:Violation)-[:REGULATORY_AUTHORITY]->()
    RETURN collect(a) + collect(b) + collect(c) AS paths
    """

    def well_control_chains(self) -> Dict[str, Any]:
        return _result(query(self.WC_CHAINS), self.WC_CHAINS, graph=graph_for(self.WC_GRAPH))

    # ================================================================== UC3 integrity
    PRECURSORS = """
    MATCH (f:FailureReport)-[:INSPECTION_EVENT]->(ins:InspectionEvent)
    OPTIONAL MATCH (f)-[:EQUIPMENT]->(e:Equipment)
    OPTIONAL MATCH (f)-[:PIPELINE_SEGMENT]->(pl:PipelineSegment)
    OPTIONAL MATCH (f)-[:WORK_ORDER]->(wo:WorkOrder)
    OPTIONAL MATCH (dt:DowntimeEvent)-[:WORK_ORDER]->(wo)
    OPTIONAL MATCH (f)-[:INCIDENT]->(inc:Incident)
    RETURN coalesce(e.tag, pl.segment_number) AS asset, coalesce(e.equipment_name, pl.pipeline_name) AS asset_name,
           ins.inspection_number AS inspection, ins.inspection_date AS inspection_date, ins.defect_severity AS severity,
           ins.fitness_for_service_result AS fitness_for_service, ins.inspection_findings AS finding,
           f.failure_report_number AS failure, f.failure_date AS failure_date, duration.inDays(ins.inspection_date, f.failure_date).days AS days_after_inspection,
           f.failure_mode AS failure_mode, wo.work_order_number AS work_order, sum(dt.deferred_boe) AS deferred_boe,
           f.repair_cost AS repair_cost_usd, inc.incident_number AS incident
    ORDER BY failure_date
    """
    PRECURSOR_GRAPH = """
    MATCH p = (f:FailureReport)-[:INSPECTION_EVENT]->(:InspectionEvent)
    OPTIONAL MATCH q = (f)-[:EQUIPMENT|PIPELINE_SEGMENT|WORK_ORDER|INCIDENT|PROCESS_SAFETY_EVENT|SPILL_EVENT|PREVIOUS_FAILURE_REPORT]->()
    OPTIONAL MATCH r = (:DowntimeEvent)-[:WORK_ORDER]->(:WorkOrder)<-[:WORK_ORDER]-(f)
    RETURN p, collect(q) AS qs, collect(r) AS rs
    """

    def precursors(self) -> Dict[str, Any]:
        return _result(query(self.PRECURSORS), self.PRECURSORS, graph=graph_for(self.PRECURSOR_GRAPH))

    BAD_ACTORS = """
    MATCH (f:FailureReport)-[:EQUIPMENT]->(e:Equipment)
    OPTIONAL MATCH (e)-[:ASSET_FACILITY]->(af:AssetFacility)
    WITH e, af, count(f) AS failures, sum(f.repair_cost) AS repair_cost_usd, sum(f.production_impact_boe) AS deferred_boe, max(f.failure_date) AS last_failure
    OPTIONAL MATCH (n:NptEvent)-[:EQUIPMENT]->(e)
    WITH e, af, failures, repair_cost_usd, deferred_boe, last_failure, count(n) AS npt_events, round(sum(n.duration_hours), 1) AS npt_hours
    WHERE failures >= 2 OR npt_events >= 2
    RETURN e.tag AS tag, e.equipment_name AS equipment, e.equipment_type AS iso14224_class, af.facility_name AS facility, failures,
           repair_cost_usd, deferred_boe, npt_events, npt_hours, e.mtbf_hours AS mtbf_hours, last_failure
    ORDER BY failures DESC, repair_cost_usd DESC
    """

    def bad_actors(self) -> Dict[str, Any]:
        chains = query("MATCH p = (f:FailureReport)-[:PREVIOUS_FAILURE_REPORT*1..5]->(first:FailureReport) WHERE NOT ()-[:PREVIOUS_FAILURE_REPORT]->(f) "
                       "MATCH (f)-[:EQUIPMENT]->(e:Equipment) RETURN e.tag AS tag, [x IN reverse(nodes(p)) | x.failure_report_number + ' ' + toString(x.failure_date)] AS failure_chain")
        return _result(query(self.BAD_ACTORS), self.BAD_ACTORS, recurrence_chains=chains)

    OVERDUE = """
    MATCH (e:Equipment) WHERE e.is_safety_critical = true AND e.next_inspection_due_date < date($as_of)
    OPTIONAL MATCH (e)-[:ASSET_FACILITY]->(af:AssetFacility)
    RETURN e.tag AS tag, e.equipment_name AS equipment, af.facility_name AS facility, e.next_inspection_due_date AS due_date,
           duration.inDays(e.next_inspection_due_date, date($as_of)).days AS days_overdue
    ORDER BY days_overdue DESC
    """
    NFFS = """
    MATCH (i:InspectionEvent)-[:EQUIPMENT]->(e:Equipment) WHERE i.fitness_for_service_result = 'not_fit_for_service'
    OPTIONAL MATCH (e)-[:ASSET_FACILITY]->(af:AssetFacility)
    RETURN e.tag AS tag, e.equipment_name AS equipment, e.is_safety_critical AS safety_critical, af.facility_name AS facility,
           i.inspection_number AS inspection, i.inspection_date AS inspection_date, i.inspection_findings AS finding
    """

    def overdue(self) -> Dict[str, Any]:
        return {"as_of": _as_of(), "overdue": _result(query(self.OVERDUE, as_of=_as_of()), self.OVERDUE),
                "not_fit_for_service": _result(query(self.NFFS), self.NFFS)}

    def hierarchy(self, facility_code: str | None = None) -> Dict[str, Any]:
        cypher = """
        MATCH (h:Hierarchy) WHERE $code IS NULL OR h.path CONTAINS ('/' + $code)
        OPTIONAL MATCH (h)-[:CHILD_OF]->(parent:Hierarchy)
        OPTIONAL MATCH (h)-[:LOCATES]->(target)
        OPTIONAL MATCH (fr:FailureReport)-[:EQUIPMENT]->(target)
        RETURN h.functional_location_code AS code, h.notes AS name, h.hierarchy_level AS iso14224_level, h.path AS path,
               parent.functional_location_code AS parent, h.criticality_rating AS criticality,
               [l IN labels(target) WHERE NOT l STARTS WITH 'STD_' AND NOT l STARTS WITH '__'][0] AS locates, count(fr) AS failures
        ORDER BY path"""
        return _result(query(cypher, code=facility_code), cypher)

    # ================================================================== UC4 HSE
    PSE_LIST = """
    MATCH (p:ProcessSafetyEvent)
    OPTIONAL MATCH (p)-[:PRODUCTION_FACILITY]->(pf:ProductionFacility)
    OPTIONAL MATCH (p)-[:EQUIPMENT]->(e:Equipment)
    OPTIONAL MATCH (p)-[:DRILLING_WELL]->(d:DrillingWell)
    RETURN p.pse_number AS pse, p.pse_tier_classification AS tier, p.event_type AS event_type, p.event_date AS event_date,
           p.release_quantity AS release_quantity, p.release_unit_of_measure AS unit, coalesce(pf.facility_name, d.well_name) AS location,
           e.tag AS equipment, p.safety_system_response AS safety_system_response
    ORDER BY tier, event_date DESC
    """

    def pse_list(self) -> Dict[str, Any]:
        return _result(query(self.PSE_LIST), self.PSE_LIST)

    def pse_story(self, pse: str) -> Dict[str, Any]:
        head = query("MATCH (p:ProcessSafetyEvent {pse_number: $pse}) OPTIONAL MATCH (p)-[:EQUIPMENT]->(e:Equipment) "
                     "OPTIONAL MATCH (p)-[:PRODUCTION_FACILITY]->(pf:ProductionFacility) OPTIONAL MATCH (p)-[:VIOLATION]->(v:Violation) "
                     "OPTIONAL MATCH (v)-[:REGULATORY_AUTHORITY]->(ra:RegulatoryAuthority) "
                     "RETURN p.pse_number AS pse, p.pse_tier_classification AS tier, p.event_type AS event_type, p.event_timestamp AS at, "
                     "p.release_quantity AS release_quantity, p.release_unit_of_measure AS unit, p.immediate_cause_description AS immediate_cause, "
                     "p.safety_system_involved AS safety_system, p.safety_system_response AS safety_system_response, e.tag AS equipment, "
                     "pf.facility_name AS facility, v.nov_number AS violation, v.regulation_cited AS regulation, v.penalty_amount AS penalty_usd, "
                     "ra.regulatory_authority_name AS regulator", pse=pse)
        incidents = query("MATCH (p:ProcessSafetyEvent {pse_number: $pse})<-[:PROCESS_SAFETY_EVENT]-(x)-[:INCIDENT]->(i:Incident) "
                          "OPTIONAL MATCH (i)-[:PERMIT_TO_WORK]->(ptw:PermitToWork) "
                          "RETURN DISTINCT i.incident_number AS incident, i.incident_type AS type, i.initial_description AS description, "
                          "ptw.permit_number AS permit_to_work, ptw.permit_type AS permit_type, ptw.isolation_requirements AS isolation", pse=pse)
        investigation = query("MATCH (p:ProcessSafetyEvent {pse_number: $pse})<-[:PROCESS_SAFETY_EVENT]-()-[:INCIDENT]->(i:Incident)<-[:INCIDENT]-(inv:IncidentInvestigation) "
                              "RETURN DISTINCT inv.investigation_number AS investigation, inv.rca_methodology AS method, inv.root_cause_description AS root_cause, "
                              "inv.systemic_causes AS systemic_causes, inv.lessons_learned AS lessons_learned", pse=pse)
        capas = query("MATCH (p:ProcessSafetyEvent {pse_number: $pse})<-[:PROCESS_SAFETY_EVENT]-(ca:HseCorrectiveAction) "
                      "OPTIONAL MATCH (ca)-[:PREVIOUS_ACTION_HSE_CORRECTIVE_ACTION]->(prev:HseCorrectiveAction) "
                      "RETURN ca.action_number AS action, ca.action_type AS type, ca.action_description AS description, ca.action_status AS status, "
                      "ca.effectiveness_review_status AS effectiveness, prev.action_number AS follows_up ORDER BY action", pse=pse)
        related = query("MATCH (p:ProcessSafetyEvent {pse_number: $pse})<-[:PROCESS_SAFETY_EVENT]-(x) "
                        "RETURN [l IN labels(x) WHERE NOT l STARTS WITH 'STD_' AND NOT l STARTS WITH '__'][0] AS type, x.caption AS record ORDER BY type", pse=pse)
        graph = graph_for("MATCH (p:ProcessSafetyEvent {pse_number: $pse}) OPTIONAL MATCH a = (p)-[]->() OPTIONAL MATCH b = (p)<-[:PROCESS_SAFETY_EVENT]-(x) "
                          "OPTIONAL MATCH c = (x)-[:INCIDENT|SPILL_EVENT|WORK_ORDER|INSPECTION_EVENT|INCIDENT_INVESTIGATION|PREVIOUS_ACTION_HSE_CORRECTIVE_ACTION]->() "
                                                    "RETURN collect(DISTINCT a) + collect(DISTINCT b) + collect(DISTINCT c) AS ps", pse=pse)
        return {"event": head[0] if head else None, "incidents": incidents, "investigations": investigation, "corrective_actions": capas,
                "related_records": related, "graph": graph}

    ROOT_CAUSES = """
    MATCH (inv:IncidentInvestigation)-[:INCIDENT]->(i:Incident)
    OPTIONAL MATCH (inv)-[:ASSET_FACILITY]->(af:AssetFacility)
    OPTIONAL MATCH (ca:HseCorrectiveAction)-[:INCIDENT_INVESTIGATION]->(inv)
    WITH trim(split(split(inv.root_cause_description, ':')[0], ';')[0]) AS root_cause, inv, af, ca
    RETURN root_cause, count(DISTINCT inv) AS investigations, count(DISTINCT af) AS facilities,
           collect(DISTINCT af.facility_name) AS facility_names,
           collect(DISTINCT CASE WHEN ca.effectiveness_review_status = 'ineffective' THEN ca.action_number END) AS ineffective_capas
    ORDER BY investigations DESC
    """

    def root_causes(self) -> Dict[str, Any]:
        return _result(query(self.ROOT_CAUSES), self.ROOT_CAUSES)

    PTW_INCIDENTS = """
    MATCH (i:Incident)-[:PERMIT_TO_WORK]->(p:PermitToWork)
    RETURN p.permit_type AS permit_type, count(i) AS incidents, collect(i.incident_number) AS incident_numbers,
           collect(DISTINCT i.incident_type) AS incident_types
    ORDER BY incidents DESC
    """

    def ptw_incidents(self) -> Dict[str, Any]:
        total = query("MATCH (i:Incident) RETURN count(i) AS incidents, sum(CASE WHEN (i)-[:PERMIT_TO_WORK]->() THEN 1 ELSE 0 END) AS under_ptw")
        return _result(query(self.PTW_INCIDENTS), self.PTW_INCIDENTS, totals=total[0] if total else {})

    # ================================================================== UC5 traceability
    CUSTODY = """
    MATCH (c:CustodyTransfer)
    OPTIONAL MATCH (c)-[:DELIVERY_POINT]->(dp:DeliveryPoint)
    OPTIONAL MATCH (c)-[:CRUDE_GRADE]->(g:CrudeGrade)
    OPTIONAL MATCH (a:ProductionAllocation)-[:CUSTODY_TRANSFER]->(c)
    RETURN c.transfer_reference_number AS transfer, c.transfer_date AS transfer_date, dp.delivery_point_name AS delivery_point,
           g.grade_name AS crude_grade, c.gross_observed_volume AS gov, c.net_standard_volume AS nsv, c.volume_unit_of_measure AS unit,
           count(a) AS allocations
    ORDER BY transfer_date DESC, transfer
    """

    def custody_transfers(self) -> Dict[str, Any]:
        return _result(query(self.CUSTODY), self.CUSTODY)

    LINEAGE = """
    MATCH (c:CustodyTransfer {transfer_reference_number: $ref})
    MATCH (a:ProductionAllocation)-[:CUSTODY_TRANSFER]->(c)
    OPTIONAL MATCH (a)-[:PRODUCTION_WELL]->(w:ProductionWell)
    OPTIONAL MATCH (w)-[:IDENTIFIED_BY]->(i:WellIdentity)
    OPTIONAL MATCH (a)-[:METER_STATION]->(m:MeterStation)
    OPTIONAL MATCH (m)-[:MEASUREMENT_POINT]->(mp:MeasurementPoint)
    OPTIONAL MATCH (a)-[:PRODUCTION_FACILITY]->(pf:ProductionFacility)
    RETURN w.well_name AS well, i.caption AS api, a.production_month AS month, a.gross_oil_volume_bbl AS gross_oil_bbl,
           a.net_oil_volume_bbl AS net_oil_bbl, a.allocation_method AS allocation_method, a.oil_allocation_variance_bbl AS variance_bbl,
           m.station_code AS meter, m.meter_factor AS meter_factor, m.next_calibration_due_date AS calibration_due,
           mp.measurement_point_code AS measurement_point, pf.facility_name AS facility
    ORDER BY well
    """
    LINEAGE_GRAPH = """
    MATCH (c:CustodyTransfer {transfer_reference_number: $ref})
    OPTIONAL MATCH a = (c)-[:DELIVERY_POINT|CRUDE_GRADE]->()
    OPTIONAL MATCH b = (:ProductionWell)<-[:PRODUCTION_WELL]-(:ProductionAllocation)-[:CUSTODY_TRANSFER]->(c)
    WITH c, collect(a) AS as_, collect(b) AS bs
    OPTIONAL MATCH d = (c)<-[:CUSTODY_TRANSFER]-(:ProductionAllocation)-[:METER_STATION]->(:MeterStation)-[:MEASUREMENT_POINT|DELIVERY_POINT]->()
    OPTIONAL MATCH e = (c)<-[:CUSTODY_TRANSFER]-(:ProductionAllocation)-[:PRODUCTION_FACILITY]->(:ProductionFacility)-[:SAME_FACILITY_AS]->(:AssetFacility)
    RETURN as_ + bs + collect(d) + collect(e) AS ps
    """

    def lineage(self, ref: str) -> Dict[str, Any]:
        head = query("MATCH (c:CustodyTransfer {transfer_reference_number: $ref}) OPTIONAL MATCH (c)-[:DELIVERY_POINT]->(dp:DeliveryPoint) "
                     "OPTIONAL MATCH (c)-[:CRUDE_GRADE]->(g:CrudeGrade) RETURN c.transfer_reference_number AS transfer, c.transfer_date AS transfer_date, "
                     "c.gross_observed_volume AS gov, c.gross_standard_volume AS gsv, c.net_standard_volume AS nsv, c.bsw_percentage AS bsw_pct, "
                     "c.volume_unit_of_measure AS unit, c.meter_ticket_number AS ticket, dp.delivery_point_name AS delivery_point, "
                     "g.grade_name AS crude_grade, g.api_gravity AS api_gravity", ref=ref)
        rows = query(self.LINEAGE, ref=ref)
        allocated = sum(float(r["gross_oil_bbl"] or 0) for r in rows)
        reconciliation = None
        if head and head[0].get("gov"):
            gov = float(head[0]["gov"])
            reconciliation = {"allocated_gross_oil_bbl": allocated, "ticket_gov": gov,
                              "difference_pct": round((gov - allocated) / gov * 100, 2) if gov else None}
        return _result(rows, self.LINEAGE, transfer=head[0] if head else None, reconciliation=reconciliation,
                       graph=graph_for(self.LINEAGE_GRAPH, ref=ref))

    EMISSIONS = """
    MATCH (af:AssetFacility)
    OPTIONAL MATCH (g:GhgEmission)-[:ASSET_FACILITY]->(af)
    WITH af, sum(g.co2e_tonnes) AS co2e, sum(CASE WHEN g.ghg_gas_type = 'CH4' THEN g.ghg_quantity_tonnes ELSE 0 END) AS ch4_t
    WHERE co2e > 0
    OPTIONAL MATCH (pf:ProductionFacility)-[:SAME_FACILITY_AS]->(af)
    OPTIONAL MATCH (f:FlareRecord)-[:PRODUCTION_FACILITY]->(pf)
    WITH af, co2e, ch4_t, pf, sum(f.flare_volume_mcf) AS flared_mcf
    OPTIONAL MATCH (l:LdarSurvey)-[:PRODUCTION_FACILITY]->(pf)
    RETURN af.facility_name AS facility, round(co2e, 1) AS co2e_t, round(ch4_t, 2) AS ch4_t, flared_mcf,
           sum(toInteger(l.leaks_detected_count)) AS ldar_leaks
    ORDER BY co2e_t DESC
    """

    def emissions(self) -> Dict[str, Any]:
        return _result(query(self.EMISSIONS), self.EMISSIONS)

    VARIANCE = """
    MATCH (a:ProductionAllocation)-[:METER_STATION]->(m:MeterStation)
    WHERE abs(a.oil_allocation_variance_bbl) > $threshold
    MATCH (a)-[:PRODUCTION_WELL]->(w:ProductionWell)
    RETURN a.production_month AS month, w.well_name AS well, a.oil_allocation_variance_bbl AS variance_bbl, m.station_code AS meter,
           m.meter_factor AS meter_factor, m.next_calibration_due_date AS calibration_due,
           m.next_calibration_due_date < date($as_of) AS calibration_overdue, a.reconciliation_status AS reconciliation
    ORDER BY abs(a.oil_allocation_variance_bbl) DESC
    """

    def allocation_variance(self, threshold: float = 150.0) -> Dict[str, Any]:
        return _result(query(self.VARIANCE, threshold=threshold, as_of=_as_of()), self.VARIANCE, threshold=threshold, as_of=_as_of())


usecase_service = UseCaseService()
