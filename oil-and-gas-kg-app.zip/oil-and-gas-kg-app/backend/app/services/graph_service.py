"""
Service for Knowledge Graph exploration and neighbour traversal (Graph Explorer page).

Labels and relationship types are validated against the live schema (no Cypher injection); node names come
from the ``caption`` written at load time and domain ids from the semantic model's primary keys.
"""

import logging
from typing import Any, Dict, List, Optional, Set, Tuple

from fastapi import HTTPException

from app.graph.neo4j_client import neo4j_client
from app.models.graph import (GraphExploreResponse, GraphNeighborsResponse, GraphNode, GraphNodeDetailResponse,
                              GraphOverviewResponse, GraphRelationship)
from app.services.common import clean_props, ensure_neo4j, node_display, std_prefix

logger = logging.getLogger(__name__)

_FIND = """
MATCH (n)
WHERE elementId(n) = $node_id OR n.caption = $node_id OR n.api10 = $node_id OR n.document_id = $node_id
RETURN elementId(n) AS eid, labels(n) AS lbls, properties(n) AS props
LIMIT 1
"""


class GraphService:
    """Knowledge graph exploration and traversal"""

    def __init__(self):
        self.client = neo4j_client

    def _ensure_connectivity(self):
        ensure_neo4j()

    def _get_whitelists(self) -> Tuple[Set[str], Set[str]]:
        prefix = std_prefix()
        labels = {r["label"] for r in self.client.execute_query("CALL db.labels() YIELD label RETURN label")}
        labels = {lab for lab in labels if not lab.startswith("__")}
        rel_types = {r["relationshipType"] for r in self.client.execute_query(
            "CALL db.relationshipTypes() YIELD relationshipType RETURN relationshipType")}
        return labels | {lab for lab in labels if lab.startswith(prefix)}, rel_types

    def _build_graph_node(self, eid: str, labels: List[str], raw_props: Dict[str, Any]) -> GraphNode:
        primary, entity_id, name = node_display(labels, raw_props)
        return GraphNode(id=eid, label=primary, labels=labels, name=name, entity_id=entity_id, properties=clean_props(raw_props))

    @staticmethod
    def _build_graph_rel(eid: str, rel_type: str, src: str, tgt: str, raw_props: Dict[str, Any]) -> GraphRelationship:
        return GraphRelationship(id=eid, source=src, target=tgt, type=rel_type, properties=clean_props(raw_props))

    def _find(self, node_id: str) -> Dict[str, Any]:
        recs = self.client.execute_query(_FIND, {"node_id": node_id})
        if not recs and ":" in node_id:   # "Label:pk" form, e.g. "DrillingWell:24010"
            label, pk = node_id.split(":", 1)
            from app.services.common import semantic_model

            t = semantic_model(optional=True)
            t = t.by_label(label) if t else None
            if t:
                recs = self.client.execute_query(
                    f"MATCH (n:`{label}`) WHERE toString(n.`{t.primary_key}`) = $pk RETURN elementId(n) AS eid, labels(n) AS lbls, properties(n) AS props LIMIT 1",
                    {"pk": pk})
        if not recs:
            raise HTTPException(status_code=404, detail=f"Node '{node_id}' not found in knowledge graph")
        return recs[0]

    # ------------------------------------------------------------------ overview
    def get_overview(self) -> GraphOverviewResponse:
        self._ensure_connectivity()
        prefix = std_prefix()
        valid_labels, valid_rels = self._get_whitelists()
        node_counts = {r["label"]: r["c"] for r in self.client.execute_query(
            "MATCH (n) WITH [l IN labels(n) WHERE NOT l STARTS WITH '__' AND NOT l STARTS WITH $p][0] AS label "
            "RETURN label, count(*) AS c ORDER BY c DESC", {"p": prefix}) if r["label"]}
        rel_counts = {r["t"]: r["c"] for r in self.client.execute_query("MATCH ()-[r]->() RETURN type(r) AS t, count(*) AS c ORDER BY c DESC")}
        return GraphOverviewResponse(total_nodes=sum(node_counts.values()), total_relationships=sum(rel_counts.values()),
                                     node_counts_by_label=node_counts, relationship_counts_by_type=rel_counts,
                                     available_labels=sorted(lab for lab in valid_labels if not lab.startswith(prefix)),
                                     available_relationship_types=sorted(valid_rels))

    # ------------------------------------------------------------------ explore
    def explore_graph(self, node_label: Optional[str] = None, rel_type: Optional[str] = None, query: Optional[str] = None,
                      limit: int = 100) -> GraphExploreResponse:
        self._ensure_connectivity()
        valid_labels, valid_rels = self._get_whitelists()
        bounded_limit = max(1, min(limit, 250))
        cleaned_label = node_label if node_label and node_label in valid_labels else None
        cleaned_rel = rel_type if rel_type and rel_type in valid_rels else None
        search_query = query.strip() if query and query.strip() else None
        params: Dict[str, Any] = {"limit": bounded_limit}
        node_pattern = f"(n:`{cleaned_label}`)" if cleaned_label else "(n)"
        where = ["NOT n:Chunk", "NOT n:OntologyProperty", "NOT n:StandardAttribute"]
        if not cleaned_label:
            where.append("NOT n:Document")
        if search_query:
            params["search_term"] = search_query.lower()
            where.append("(toLower(coalesce(n.caption, '')) CONTAINS $search_term OR toLower(coalesce(n.api10, '')) CONTAINS $search_term "
                         "OR toLower(coalesce(n.title, '')) CONTAINS $search_term)")
        if cleaned_rel:
            where.append(f"(n)-[:`{cleaned_rel}`]-()")
        node_records = self.client.execute_query(
            f"MATCH {node_pattern} WHERE {' AND '.join(where)} RETURN elementId(n) AS eid, labels(n) AS lbls, properties(n) AS props LIMIT $limit",
            params)
        nodes = [self._build_graph_node(r["eid"], r["lbls"], r["props"]) for r in node_records]
        ids = [n.id for n in nodes]
        relationships: List[GraphRelationship] = []
        if ids:
            rel_pattern = f"-[r:`{cleaned_rel}`]->" if cleaned_rel else "-[r]->"
            for r in self.client.execute_query(
                    f"MATCH (n){rel_pattern}(m) WHERE elementId(n) IN $ids AND elementId(m) IN $ids "
                    "RETURN elementId(r) AS eid, type(r) AS t, elementId(n) AS src, elementId(m) AS tgt, properties(r) AS props", {"ids": ids}):
                relationships.append(self._build_graph_rel(r["eid"], r["t"], r["src"], r["tgt"], r["props"]))
        return GraphExploreResponse(nodes=nodes, relationships=relationships, total_nodes=len(nodes), total_relationships=len(relationships),
                                    is_truncated=len(nodes) >= bounded_limit,
                                    filters_applied={"node_label": cleaned_label, "rel_type": cleaned_rel, "query": search_query, "limit": bounded_limit})

    # ------------------------------------------------------------------ detail
    def get_node_detail(self, node_id: str) -> GraphNodeDetailResponse:
        self._ensure_connectivity()
        rec = self._find(node_id)
        eid = rec["eid"]
        node = self._build_graph_node(eid, rec["lbls"], rec["props"])
        edge_records = self.client.execute_query("MATCH (n)-[r]-() WHERE elementId(n) = $e RETURN type(r) AS t, count(r) AS c", {"e": eid})
        connected_by_type = {r["t"]: r["c"] for r in edge_records}
        neighbors = self.client.execute_query(
            "MATCH (n)-[r]-(m) WHERE elementId(n) = $e AND NOT m:Chunk AND NOT m:OntologyProperty "
            "RETURN DISTINCT elementId(m) AS eid, labels(m) AS lbls, properties(m) AS props LIMIT 12", {"e": eid})
        docs = self.client.execute_query(
            "MATCH (n)-[:HAS_NARRATIVE]->(d:Document)<-[:FROM_DOCUMENT]-(c:Chunk) WHERE elementId(n) = $e "
            "RETURN coalesce(d.document_id, d.path) AS doc_id, coalesce(d.title, d.path) AS title, c.id AS chunk_id, left(c.text, 220) AS snippet "
            "ORDER BY c.index LIMIT 5", {"e": eid})
        return GraphNodeDetailResponse(node=node, connected_count=sum(connected_by_type.values()), connected_by_type=connected_by_type,
                                       neighbors_preview=[self._build_graph_node(r["eid"], r["lbls"], r["props"]) for r in neighbors],
                                       document_links=[{"document_id": r["doc_id"], "title": r["title"], "chunk_id": r["chunk_id"],
                                                        "snippet": r["snippet"]} for r in docs])

    def get_node_neighbors(self, node_id: str, limit: int = 50, rel_type: Optional[str] = None, direction: str = "both") -> GraphNeighborsResponse:
        self._ensure_connectivity()
        _, valid_rels = self._get_whitelists()
        bounded_limit = max(1, min(limit, 100))
        cleaned_rel = rel_type if rel_type and rel_type in valid_rels else None
        rec = self._find(node_id)
        center_eid = rec["eid"]
        center = self._build_graph_node(center_eid, rec["lbls"], rec["props"])
        tok = f":`{cleaned_rel}`" if cleaned_rel else ""
        pattern = {"out": f"-[r{tok}]->", "in": f"<-[r{tok}]-"}.get(direction, f"-[r{tok}]-")
        records = self.client.execute_query(
            f"MATCH (n){pattern}(m) WHERE elementId(n) = $e AND NOT m:Chunk AND NOT m:OntologyProperty "
            "RETURN elementId(m) AS eid, labels(m) AS lbls, properties(m) AS props, elementId(r) AS r_eid, type(r) AS r_type, "
            "elementId(startNode(r)) AS r_src, elementId(endNode(r)) AS r_tgt, properties(r) AS r_props LIMIT $limit",
            {"e": center_eid, "limit": bounded_limit})
        seen_nodes, seen_rels = set(), set()
        neighbor_nodes, relationships = [], []
        for r in records:
            if r["eid"] not in seen_nodes and r["eid"] != center_eid:
                seen_nodes.add(r["eid"])
                neighbor_nodes.append(self._build_graph_node(r["eid"], r["lbls"], r["props"]))
            if r["r_eid"] not in seen_rels:
                seen_rels.add(r["r_eid"])
                relationships.append(self._build_graph_rel(r["r_eid"], r["r_type"], r["r_src"], r["r_tgt"], r["r_props"]))
        return GraphNeighborsResponse(center_node=center, neighbor_nodes=neighbor_nodes, relationships=relationships,
                                      total_neighbors=len(neighbor_nodes))

    # ------------------------------------------------------------------ legacy / path
    async def get_nodes(self, node_type: Optional[str] = None, limit: int = 100) -> List[dict]:
        res = self.explore_graph(node_label=node_type, limit=limit)
        return [{"id": n.id, "label": n.name, "type": n.label, "properties": n.properties} for n in res.nodes]

    async def get_relationships(self, relationship_type: Optional[str] = None, limit: int = 100) -> List[dict]:
        res = self.explore_graph(rel_type=relationship_type, limit=limit)
        return [{"id": r.id, "source": r.source, "target": r.target, "type": r.type, "properties": r.properties} for r in res.relationships]

    async def get_subgraph(self, node_id: str, depth: int = 2) -> dict:
        res = self.get_node_neighbors(node_id, limit=50)
        all_nodes = [res.center_node] + res.neighbor_nodes
        return {"nodes": [{"id": n.id, "label": n.name, "type": n.label, "properties": n.properties} for n in all_nodes],
                "relationships": [{"id": r.id, "source": r.source, "target": r.target, "type": r.type, "properties": r.properties}
                                  for r in res.relationships]}

    async def find_path(self, start_node: str, end_node: str, max_depth: int = 5) -> dict:
        """Shortest path over data / derived relationships (semantic and lexical layers excluded)."""
        self._ensure_connectivity()
        a, b = self._find(start_node), self._find(end_node)
        depth = max(1, min(int(max_depth), 8))
        recs = self.client.execute_records(
            f"MATCH (a), (b) WHERE elementId(a) = $a AND elementId(b) = $b "
            f"MATCH p = shortestPath((a)-[*..{depth}]-(b)) "
            "WHERE all(r IN relationships(p) WHERE r.fk_column IS NOT NULL OR r.derived) RETURN p", {"a": a["eid"], "b": b["eid"]})
        if not recs:
            return {"path": [], "length": None, "relationships": [], "found": False}
        p = recs[0]["p"]
        return {"found": True, "length": len(p.relationships),
                "path": [self._build_graph_node(n.element_id, list(n.labels), dict(n)).model_dump() for n in p.nodes],
                "relationships": [self._build_graph_rel(r.element_id, r.type, r.start_node.element_id, r.end_node.element_id, dict(r)).model_dump()
                                  for r in p.relationships]}


# Global graph service instance
graph_service = GraphService()
