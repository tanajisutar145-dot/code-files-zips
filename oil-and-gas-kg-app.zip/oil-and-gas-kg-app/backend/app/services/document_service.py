"""
Document management: uploaded documents and the record narratives the pipeline turned into documents.

* ``kind = uploaded``  - files uploaded through the API or ``python -m app.documents load`` (parsed, chunked,
  embedded and linked to the records they mention);
* ``kind = record_narrative`` - one document per data row with narrative columns (lessons learned,
  investigation findings...), created by ``python -m app.kg run --step load``. Read-only here.
"""

import logging
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import HTTPException, UploadFile

from app.core.config import kg_settings, settings
from app.documents.loader import DocumentLoader
from app.documents.models import Document, DocumentType
from app.documents.parsers import get_parser_for_file
from app.graph.neo4j_client import neo4j_client
from app.llm.client import llm_client
from app.models.documents import (DocumentChunkDetail, DocumentDetailResponse, DocumentEntityLink, DocumentListResponse,
                                  DocumentOverviewResponse, DocumentSummaryItem, DocumentUploadResult)
from app.services.common import clean_props, ensure_neo4j, primary_label, serialize_property_value

logger = logging.getLogger(__name__)

_KIND = "CASE WHEN d.document_id IS NOT NULL THEN 'uploaded' ELSE 'record_narrative' END"


class DocumentService:
    def __init__(self):
        self.client = neo4j_client
        self.upload_dir = settings.path(settings.upload_dir)
        self.upload_dir.mkdir(parents=True, exist_ok=True)

    def _loader(self) -> DocumentLoader:
        embed = llm_client.embed if llm_client.embedder_configured() else None
        return DocumentLoader(neo4j_client=self.client, embed_fn=embed, embedding_model=llm_client.describe()["embedder"])

    # ------------------------------------------------------------------ overview
    def get_overview(self) -> DocumentOverviewResponse:
        ensure_neo4j()
        row = self.client.execute_query(f"""
            OPTIONAL MATCH (d:Document) WITH count(d) AS docs, sum(CASE WHEN d.document_id IS NOT NULL THEN 1 ELSE 0 END) AS uploaded
            OPTIONAL MATCH (c:Chunk) RETURN docs, uploaded, count(c) AS chunks, sum(CASE WHEN c.embedding IS NOT NULL THEN 1 ELSE 0 END) AS embedded""")[0]
        types = {r["t"]: r["c"] for r in self.client.execute_query(
            f"MATCH (d:Document) RETURN coalesce(d.document_type, d.source_label) AS t, count(*) AS c ORDER BY c DESC") if r["t"]}
        kinds = {r["k"]: r["c"] for r in self.client.execute_query(f"MATCH (d:Document) RETURN {_KIND} AS k, count(*) AS c")}
        idx_name = kg_settings().section("indexes").get("vector", {}).get("name", "chunk_embeddings")
        status, population = ("ONLINE" if row["embedded"] else "ABSENT"), (100.0 if row["embedded"] else 0.0)
        try:
            idx = self.client.execute_query("SHOW INDEXES YIELD name, state, populationPercent WHERE name = $n RETURN state, populationPercent", {"n": idx_name})
            if idx:
                status, population = idx[0]["state"], float(idx[0]["populationPercent"] or 0)
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Could not check vector index: {e}")
        emb = kg_settings().embedding
        return DocumentOverviewResponse(total_documents=row["docs"] or 0, total_chunks=row["chunks"] or 0, embedded_chunks=row["embedded"] or 0,
                                        document_types=types, processing_statuses=kinds, vector_index_name=idx_name,
                                        vector_index_status=status, vector_index_population=population,
                                        embedding_model=f"{emb.provider} / {emb.model}" if emb else "not configured",
                                        embedding_dimension=(emb.dimensions or 0) if emb else 0, uploaded_documents=row["uploaded"] or 0)

    # ------------------------------------------------------------------ list
    def list_documents(self, search: Optional[str] = None, document_type: Optional[str] = None, kind: Optional[str] = None,
                       skip: int = 0, limit: int = 50) -> DocumentListResponse:
        ensure_neo4j()
        params: Dict[str, Any] = {"s": (search or "").lower() or None, "t": document_type, "k": kind, "skip": skip, "limit": limit}
        where = (f"WHERE ($s IS NULL OR toLower(coalesce(d.title, d.path)) CONTAINS $s OR toLower(coalesce(d.document_id, '')) CONTAINS $s) "
                 f"AND ($t IS NULL OR coalesce(d.document_type, d.source_label) = $t) AND ($k IS NULL OR {_KIND} = $k)")
        total = self.client.execute_query(f"MATCH (d:Document) {where} RETURN count(d) AS c", params)[0]["c"]
        rows = self.client.execute_query(f"""
            MATCH (d:Document) {where}
            WITH d ORDER BY {_KIND} DESC, coalesce(d.created_date, '') DESC, d.path SKIP $skip LIMIT $limit
            OPTIONAL MATCH (c:Chunk)-[:FROM_DOCUMENT]->(d)
            WITH d, count(c) AS chunks, sum(CASE WHEN c.embedding IS NOT NULL THEN 1 ELSE 0 END) AS embedded,
                 sum(size(coalesce(c.text, ''))) AS length
            RETURN coalesce(d.document_id, d.path) AS document_id, coalesce(d.title, d.caption, d.path) AS title,
                   coalesce(d.document_type, d.source_label) AS document_type, coalesce(d.source, 'knowledge graph load') AS source,
                   coalesce(d.source_reference, d.source_id) AS source_reference, d.created_date AS created_date,
                   coalesce(d.processing_status, 'completed') AS processing_status, d.content_hash AS content_hash,
                   coalesce(size(d.content), length) AS content_length, chunks AS chunk_count, embedded AS embedded_chunks,
                   coalesce(d.format, 'record') AS format, d.source_filename AS source_filename, coalesce(d.warnings, []) AS warnings,
                   {_KIND} AS kind""", params)
        return DocumentListResponse(documents=[DocumentSummaryItem(**{k: serialize_property_value(v) for k, v in r.items()}) for r in rows],
                                    total=total, skip=skip, limit=limit)

    # ------------------------------------------------------------------ detail
    def get_document_detail(self, document_id: str) -> Optional[DocumentDetailResponse]:
        ensure_neo4j()
        found = self.client.execute_query("MATCH (d:Document) WHERE d.document_id = $id OR d.path = $id RETURN properties(d) AS p, "
                                          f"{_KIND} AS kind", {"id": document_id})
        if not found:
            return None
        p, kind = clean_props(found[0]["p"]), found[0]["kind"]
        chunks = self.client.execute_query("MATCH (c:Chunk)-[:FROM_DOCUMENT]->(d:Document) WHERE d.document_id = $id OR d.path = $id "
                                           "RETURN c.id AS id, coalesce(c.chunk_id, c.id) AS chunk_id, c.index AS idx, c.text AS text, "
                                           "c.embedding IS NOT NULL AS embedded, size(coalesce(c.embedding, [])) AS dims, c.embedding_model AS model, "
                                           "c.page_number AS page, c.sheet_name AS sheet, c.row_range AS rows, c.section_title AS section "
                                           "ORDER BY idx", {"id": document_id})
        links = self.client.execute_query("MATCH (d:Document) WHERE d.document_id = $id OR d.path = $id "
                                          "MATCH (n)-[:HAS_NARRATIVE]->(d) OPTIONAL MATCH (d)-[m:MENTIONS_RECORD]->(n) "
                                          "RETURN labels(n) AS labels, n.caption AS caption, elementId(n) AS eid, properties(n) AS props, "
                                          "CASE WHEN m IS NULL THEN 'HAS_NARRATIVE (source record)' ELSE 'MENTIONS_RECORD' END AS rel", {"id": document_id})
        content = p.get("content") or "\n\n".join(c["text"] or "" for c in chunks)
        return DocumentDetailResponse(
            document_id=p.get("document_id") or p.get("path"), title=p.get("title") or p.get("caption") or p.get("path"),
            document_type=p.get("document_type") or p.get("source_label") or "record_narrative", source=p.get("source") or "knowledge graph load",
            source_reference=p.get("source_reference") or p.get("source_id"), created_date=p.get("created_date"),
            processing_status=p.get("processing_status") or "completed", content_hash=p.get("content_hash"), content=content,
            format=p.get("format") or "record", source_filename=p.get("source_filename"), warnings=p.get("warnings") or [], kind=kind,
            chunks=[DocumentChunkDetail(chunk_id=c["chunk_id"], chunk_index=c["idx"] or 0, text=c["text"] or "", is_embedded=c["embedded"],
                                        embedding_model=c["model"], embedding_dimension=c["dims"] or None, page_number=c["page"],
                                        sheet_name=c["sheet"], row_range=c["rows"], section_title=c["section"], metadata={"node_id": c["id"]})
                    for c in chunks],
            linked_entities=[DocumentEntityLink(relationship=lk["rel"], labels=lk["labels"], entity_id=lk["eid"], entity_name=lk["caption"] or "",
                                                properties={"type": primary_label(lk["labels"]), **{k: v for k, v in clean_props(lk["props"]).items()
                                                                                                    if k in ("caption", "std_class", "subject_area")}})
                             for lk in links])

    # ------------------------------------------------------------------ upload / delete
    async def upload_document(self, file: UploadFile) -> DocumentUploadResult:
        ensure_neo4j()
        filename = file.filename or "uploaded_document"
        try:
            parser = get_parser_for_file(filename)
        except ValueError as val_err:
            raise HTTPException(status_code=400, detail=str(val_err))
        content_bytes = await file.read()
        if len(content_bytes) > settings.max_upload_size_bytes:
            raise HTTPException(status_code=400, detail=f"File exceeds maximum allowed size of {settings.max_upload_size_bytes // (1024 * 1024)}MB.")
        if not content_bytes:
            raise HTTPException(status_code=400, detail="Uploaded file is empty (0 bytes).")
        ext = Path(filename).suffix.lower()
        safe_stem = "".join(c for c in Path(filename).stem if c.isalnum() or c in ("-", "_"))
        try:
            (self.upload_dir / f"{uuid.uuid4().hex[:8]}_{safe_stem}{ext}").write_bytes(content_bytes)
        except Exception as e:  # noqa: BLE001
            logger.warning(f"Could not persist upload: {e}")
        try:
            extracted = parser.parse(content_bytes, filename)
        except ValueError as parse_err:
            raise HTTPException(status_code=400, detail=str(parse_err))
        except Exception as e:  # noqa: BLE001
            raise HTTPException(status_code=400, detail=f"Error parsing document content: {e}")
        if not extracted.content.strip():
            raise HTTPException(status_code=400, detail="Document produced no readable text or content.")
        meta = dict(extracted.metadata)
        doc_type = meta.get("document_type") if meta.get("document_type") in {t.value for t in DocumentType} else DocumentType.OPERATIONAL_NOTE.value
        doc = Document(document_id=meta.get("document_id") or f"DOC-{uuid.uuid4().hex[:6].upper()}", title=extracted.title, document_type=doc_type,
                       source=meta.get("source") or f"Upload ({extracted.format.upper()})", source_reference=meta.get("source_reference") or filename,
                       created_date=datetime.utcnow(), content=extracted.content,
                       linked_records=[str(x) for x in meta.get("linked_records", [])] if isinstance(meta.get("linked_records"), list) else [],
                       metadata={"format": extracted.format, "source_filename": filename, "sections": [s.model_dump() for s in extracted.sections],
                                 "warnings": extracted.warnings})
        result = self._loader().load_document(doc)
        if result["action"] == "failed":
            raise HTTPException(status_code=500, detail=f"Ingestion failed: {result.get('error')}")
        message = (f"Document {result['action']}: {result['chunks_created']} chunks, {result['entity_links']} linked records"
                   + ("" if result.get("embedded") else " (no embedder configured: chunks are not searchable by vector yet)") + ".")
        if result["action"] == "skipped":
            message = f"Document skipped ({result.get('reason')})."
        if extracted.warnings:
            message += " Notice: " + " | ".join(extracted.warnings)
        return DocumentUploadResult(document_id=result["document_id"], title=doc.title, action=result["action"], chunks_created=result["chunks_created"],
                                    relationships_created=result["relationships_created"], entity_links=result["entity_links"],
                                    embedded=bool(result.get("embedded")), format=extracted.format, warnings=extracted.warnings, message=message,
                                    linked_records=result.get("linked_records", []))

    def delete_document(self, document_id: str) -> bool:
        ensure_neo4j()
        exists = self.client.execute_query("MATCH (d:Document {document_id: $id}) RETURN count(d) AS c", {"id": document_id})[0]["c"]
        if not exists:
            return False
        return self._loader().delete(document_id)


document_service = DocumentService()
