# Knowledge Graphs in Oil & Gas — Research, Landscape and Top 5 Use Cases

**Document:** 01 · Research and use-case guidance
**Scope:** upstream and midstream operations of an integrated operator, as covered by the
*oil_gas* Databricks industry data model (v1, MVM flavour)
**Audience:** data and AI leadership, domain owners (subsurface, drilling, asset integrity, HSE,
production accounting), solution architects
**Status:** guidance for the reference application in this repository (`oil-and-gas-kg-app`)

> **How to read the evidence.** Every claim about a company, product or standard is linked to a
> public source in [section 12](#12-references). Tags in brackets show how strong each source is:
> **[peer-reviewed]** journal or conference paper, **[standard]** standards body, **[company]**
> the operator's own publication or press release, **[vendor]** vendor-published case study or
> press release (the vendor's account, not independently verified), **[press]** trade press,
> **[unverified]** a claim we could not confirm from a primary source. Where we could not verify
> something, we say so instead of filling the gap.

---

## Contents

1. [Executive summary](#1-executive-summary)
2. [Method](#2-method)
3. [Industry trends (2018–2026)](#3-industry-trends-20182026)
4. [Challenges operators are trying to solve](#4-challenges-operators-are-trying-to-solve)
5. [Landscape: who does what](#5-landscape-who-does-what)
6. [Domain standards a knowledge graph must respect](#6-domain-standards-a-knowledge-graph-must-respect)
7. [What qualifies a use case for a knowledge graph](#7-what-qualifies-a-use-case-for-a-knowledge-graph)
8. [Long list and scoring](#8-long-list-and-scoring)
9. [The top 5 use cases](#9-the-top-5-use-cases)
10. [Mapping to the oil_gas data model](#10-mapping-to-the-oil_gas-data-model)
11. [Reference architecture, roadmap and risks](#11-reference-architecture-roadmap-and-risks)
12. [References](#12-references)

---

## 1. Executive summary

Oil and gas data is unusually *connected*: one physical well appears as an exploration well, a
drilled wellbore, a producing well and a fixed asset, each in a different system with a
different identifier; one failed pump touches an inspection, a work order, a production
deferment, an HSE incident and a regulatory violation. Most of the industry's hardest analytical
questions follow these connections across domains, and that is where knowledge graphs earn
their keep.

Public evidence shows three converging movements:

* **Standard data foundations.** The OSDU Data Platform defines well-known master data (Well,
  Wellbore, Field, Basin…) and work-product components that link back to it; the Energistics
  standards (WITSML, PRODML, RESQML) sit inside that ecosystem since Energistics affiliated with
  The Open Group in January 2022 ([R10][R10], [R11][R11]).
* **Contextualisation and ontology-driven operations.** Operators publicly describe industrial
  knowledge graphs or ontology layers: Equinor's ontology-based data access for geologists
  ([R1][R1], [R2][R2]), Aker BP's contextualised data on Cognite Data Fusion ([R5][R5]),
  bp's Palantir-based production digital twin ([R7][R7]), TotalEnergies' ISO 15926-14-based
  semantic framework ([R8][R8]).
* **Generative AI grounded in graphs.** Research in 2025–2026 combines knowledge graphs with
  LLMs (GraphRAG, Text2Cypher) for reservoir engineering and pipeline-topology question answering
  ([R24][R24], [R25][R25]); operators stress that a robust data foundation must come first
  ([R26][R26]).

From a long list of ten candidates (section 8), the five use cases that best combine business
value, graph fit, public evidence and coverage in the *oil_gas* model are:

| # | Use case | Primary owner | Why a graph |
|---|---|---|---|
| **UC1** | **Well & subsurface 360 / well identity** | Subsurface data management | One well, many records and identifiers; basin → play → prospect → reservoir → zone → well chains |
| **UC2** | **Drilling performance & well-construction lessons learned** | Drilling & completions | NPT, kicks and cement jobs linked to formations, zones, rigs and offset wells |
| **UC3** | **Asset integrity & reliability (inspection → failure → work order)** | Asset integrity / maintenance | Causal chains and equipment hierarchies (ISO 14224) across CMMS, inspection and production |
| **UC4** | **HSE & process-safety incident intelligence** | HSE / process safety | Incident ↔ investigation ↔ CAPA ↔ permit-to-work ↔ equipment ↔ violation webs (API RP 754) |
| **UC5** | **Production-to-market & emissions traceability** | Production accounting / ESG | Well → meter → allocation → custody transfer lineage, joined to flaring, LDAR and GHG records |

All five run on **56 tables in 10 subject areas** of the *oil_gas* MVM model with **297 in-scope
foreign keys**, and are implemented end to end in this repository (synthetic data, Neo4j load,
GraphRAG, use-case APIs and UI).

---

## 2. Method

1. **Desk research** (October 2026) of public sources: operator publications and press
   releases, peer-reviewed papers (IEEE, ISWC, KEOD, PLoS ONE, Computers & Geosciences), SPE/JPT
   articles, standards bodies (ISO, API, IOGP, SPE, PPDM, The Open Group, POSC Caesar), and
   vendor case studies. Search terms covered knowledge graph, ontology, semantic data access,
   contextualisation, OSDU, ISO 15926, ISO 14224, drilling reports, HSE incidents, emissions
   traceability and GraphRAG.
2. **Evidence grading** with the tags above. Vendor case studies are used to show *what
   operators are attempting*, not as proof of value.
3. **Use-case qualification** with the criteria in section 7 and a weighted score (section 8).
4. **Model fit**: each shortlisted use case was mapped table by table to the *oil_gas* v1 MVM
   DDL and RDF ontology (`data_model/`), including in-scope foreign keys.

**Limitations.** Many operator programmes are not published in detail; some prominent names
(for example ExxonMobil, Chevron and Shell) returned no primary source describing a knowledge
graph programme in our searches, so this document does not attribute one to them. Figures from
vendor case studies are reported as the vendor's claims.

---

## 3. Industry trends (2018–2026)

### 3.1 From data lakes to semantic layers

* **Ontology-based data access (OBDA) reached production in subsurface work.** The EU FP7
  *Optique* project (2012–2016) tested OBDA with Statoil geologists, e.g. "find all wellbores that
  penetrate a rock layer of a given geological age", over Statoil's exploration and production
  data store and the Norwegian Petroleum Directorate fact pages ([R2][R2]) **[peer-reviewed]**.
  Equinor later described a deployed semantic data-access system for exploration geologists in
  *"Finding Data Should be Easier than Finding Oil"* (IEEE Big Data 2018) ([R1][R1])
  **[peer-reviewed]**. The research continued in the SIRIUS centre (University of Oslo,
  2015–2023) with Equinor, SLB, IBM, DNV and others as partners ([R3][R3]) **[company/academic]**.
* **Enterprise semantic frameworks.** TotalEnergies presents a semantic framework that builds
  domain ontologies following ISO 15926-14 principles and generates a semantic knowledge graph
  from siloed datasets ([R8][R8]) **[company, conference]**.
* **Industrial top-level ontology standardised.** The Industrial Data Ontology (IDO) is the
  ISO 15926-14 top-level ontology; POSC Caesar operates the public Reference Data Service, and
  the READI/NOAKA reference library is published as OWL 2 ontologies following ISO 15926-14
  ([R12][R12]) **[standard]**.

### 3.2 Standard data platforms with graph-shaped master data

* The **OSDU Data Platform** models wells and wellbores as master data that reference basin,
  field, play and prospect; logs and trajectories are work-product components that link back to
  master data ([R10][R10]) **[vendor/standard]**. A public OSDU ontology (Accenture Labs, Apache
  2.0) converts the OSDU schemas into OWL and argues that subsurface data integration can be
  achieved by building a domain knowledge graph on OSDU schemas ([R9][R9]) **[peer-reviewed]**.
* **Energistics** (WITSML, PRODML, RESQML, ETP) affiliated with The Open Group on 1 January
  2022; its standards are described as a critical component of the OSDU Data Platform, and
  WITSML 2.1 gained OSDU compliance work in 2023 ([R11][R11]) **[press]**.

### 3.3 Contextualisation platforms and ontology-driven digital twins

* **Aker BP / Cognite.** Cognite describes an "industrial knowledge graph" in Cognite Data
  Fusion that connects OT, engineering and business data; Aker BP case studies cover a
  maintenance overview combining four source systems (15 hours saved) and condition monitoring
  (USD 6.5 million estimated savings); a 2026 announcement couples the knowledge graph with
  NVIDIA time-series models for anomaly detection on wells and heat exchangers ([R5][R5])
  **[vendor]**. TotalEnergies runs an upstream drilling and wells surface data platform on the
  same product ([R6][R6]) **[vendor]**.
* **bp / Palantir.** bp's production digital twin merges models of physical assets with data
  from over 2 million sensors; a five-year agreement in 2024 added Palantir AIP (LLM) capabilities
  on top of a ten-year collaboration ([R7][R7]) **[company/vendor press release]**.

### 3.4 Unstructured operational text becomes graph data

* **Drilling reports.** bp mined daily drilling reports with NLP and a rig-vocabulary
  dictionary (SPE 173429) ([R13][R13]) **[peer-reviewed/SPE]**; Montanuniversität Leoben built an
  application to extract NPT from daily drilling reports for lessons learned ([R14][R14])
  **[academic]**; a well-engineering ontology aligned with ISO 15926 structures daily operational
  reports into knowledge graphs ([R15][R15]) **[academic]**.
* **Geoscience text.** PetroChina's *PetroKG* builds an upstream knowledge graph from structured
  and unstructured data ([R16][R16]) **[peer-reviewed]**; the Petrobras-supported *Petrolês*
  resources and the Petro KGraph thesis extract geoscience entities from Portuguese technical
  reports ([R17][R17]) **[academic]**.
* **Accident reports.** A gas-pipeline emergency-response knowledge graph was built in Neo4j
  from 343 pipeline accident investigation reports ([R20][R20]) **[academic]**.

### 3.5 LLMs need grounding — GraphRAG

* Research proposes dual-layer GraphRAG for reservoir engineering decision support ([R24][R24])
  and an LLM + knowledge-graph framework that generates Cypher for pipeline-topology questions,
  falling back to a bounded subgraph when direct queries fail ([R25][R25]) **[peer-reviewed]**.
* Operators' public AI statements emphasise a standardised data foundation before scaling AI
  ([R26][R26]) **[press]**. Grounding answers in a graph of record — with the query that produced
  them — is the main mitigation for hallucination in regulated operations.

### 3.6 Emissions transparency

* OGMP 2.0 (UNEP) is a measurement-based methane reporting framework; 118 companies reported in
  2023 ([R22][R22]) **[NGO/UN]**. Claims about low-methane cargoes need a traceable chain from
  product flows to emission sources and calculation methods ([R23][R23]) **[press]** — a lineage
  problem that a graph represents naturally.

---

## 4. Challenges operators are trying to solve

| # | Challenge | What it looks like in practice | Evidence |
|---|---|---|---|
| C1 | **"What is a well?" — identity across systems** | Operators, vendors and regulators define well, wellbore and completion differently; API numbers vary in length and use; logs must be tied to a unique wellbore before platform ingestion | PPDM "What is a Well" and US Well Number Standard ([R18][R18]); OSDU ingestion practice ([R10][R10]) |
| C2 | **Finding data takes longer than using it** | Geologists depend on IT to assemble data from many stores | Equinor/Optique OBDA work ([R1][R1], [R2][R2]) |
| C3 | **Knowledge locked in narrative text** | DDRs, investigations, failure write-ups and test comments are free text | SPE 173429 ([R13][R13]); Leoben NPT ([R14][R14]); pipeline accident KG ([R20][R20]) |
| C4 | **Inconsistent maintenance and failure records** | Free-text failure causes, non-standard taxonomies, poor MTBF data | ISO 14224 purpose ([R19][R19]); ontology schema for maintenance records ([R27][R27]) |
| C5 | **Partially integrated lifecycle systems** | Engineering, maintenance and operations systems only partly integrated; handover data lost | O&M knowledge graph on IDO and CFIHOS ([R21][R21]); CFIHOS ([R28][R28]) |
| C6 | **Standards fragmentation and uneven adoption** | Several overlapping standards; adoption of handover specs reported as limited by some contractors | CFIHOS adoption caveat ([R28][R28]); ISO 15926 / IDO ([R12][R12]) |
| C7 | **Lineage for allocation, custody transfer and emissions** | Need to prove which wells' volumes and which emission sources sit behind a cargo or report | OGMP 2.0 ([R22][R22]); traceability ([R23][R23]) |
| C8 | **Trustworthy GenAI** | LLM answers must be traceable to records and queries | GraphRAG research ([R24][R24], [R25][R25]); bp/Palantir auditable AI records ([R7][R7]) |

---

## 5. Landscape: who does what

| Category | Examples (public) | Relevance to knowledge graphs |
|---|---|---|
| **Operators with published semantic/KG work** | Equinor (OBDA, SIRIUS) [R1–R3]; Aker BP (contextualised data) [R5]; bp (ontology-based digital twin) [R7]; TotalEnergies (semantic framework, ISO 15926-14) [R8]; PetroChina (PetroKG) [R16]; Petrobras-supported NLP resources [R17] | Proven demand in subsurface, maintenance, operations |
| **Industrial data / contextualisation platforms** | Cognite Data Fusion [R5, R6]; Palantir Foundry/AIP [R7]; AVEVA PI System asset framework (TotalEnergies contextualisation platform) [R8] | Asset graphs, ontologies, time-series context |
| **Open data platforms & standards bodies** | The Open Group OSDU Forum + Energistics [R10, R11]; PPDM [R18]; POSC Caesar / ISO 15926 [R12]; IOGP (CFIHOS JIP36, Report 456) [R28, R30]; SPE (PRMS) [R31]; API (RP 754, MPMS) [R30] | Shared vocabularies, identifiers, reference data |
| **Graph & semantic technology** | Neo4j (property graph, vector + full-text indexes, GraphRAG library); RDF/OWL stores and reasoners; OTTR templates (SIRIUS) [R3] | Storage, query, reasoning, LLM retrieval |
| **Research** | Accenture Labs OSDU ontology [R9]; Gong et al. — Neo4j for oilfield ontology storage [R29]; GraphRAG for reservoir engineering [R24]; pipeline-topology LLM–KG [R25] | Patterns, ontologies, evaluation |

---

## 6. Domain standards a knowledge graph must respect

The reference application aligns every in-scope ontology class to one of these standards
(`data_model/ontology/og_standards_reference.ttl`, `og_standards_alignment.ttl`). The alignment is
**informative**: it names the standard concept a table corresponds to; it is not an official
ontology published by those bodies.

| Standard | Owner | Used for | In the app |
|---|---|---|---|
| **OSDU well-known schemas** (master data Well, Wellbore, Field, Basin; geo-context Play/Prospect) | The Open Group OSDU Forum [R9, R10] | Well/wellbore identity, geo-context hierarchy | `STD_Well`, `STD_Wellbore`, `STD_Field`, `STD_Basin`, `STD_Play`, `STD_Prospect` |
| **PPDM "What is a Well" & US Well Number Standard** (successor of the API well number) | PPDM [R18] | API-10/12/14 identifiers, well vs wellbore | `api_number` / `uwi` normalised to API-10 → `SAME_WELL_AS`; `well_identity_key` |
| **Energistics WITSML / PRODML / RESQML** | Energistics / The Open Group [R11] | Drilling reports, cement jobs, tubulars; production volumes, well tests; stratigraphy | Alignment of drilling, production and zone classes |
| **SPE-PRMS 2018** | SPE [R31] | Reserves categories 1P/2P/3P, PDP/PDNP/PUD | `reserves_estimate`, `well_test`, `zone` |
| **ISO 14224:2016** reliability & maintenance data (equipment, failure, maintenance data; taxonomy) | ISO [R19] | Equipment hierarchy, failure modes, MTBF/MTTR | UC3 classes and causal chains |
| **ISO 15926 / ISO 15926-14 IDO** | ISO / POSC Caesar [R12] | Lifecycle integration, top-level ontology | Design principle for the semantic layer |
| **CFIHOS** (JIP36) | IOGP [R28] | Handover tag/equipment classes | Equipment tagging conventions |
| **API RP 754 / IOGP Report 456** process safety KPIs (Tier 1–4) | API / IOGP [R30] | PSE tiers, LOPC | `process_safety_event`, `incident` |
| **API RP 510 / 570 / 580 (RBI)** inspection codes | API | Inspection and risk-based inspection | `inspection_event`, `integrity_program` |
| **IADC NPT codes / lexicon** | IADC | NPT classification | `npt_event.iadc_npt_code` |
| **API MPMS** measurement & allocation | API | Meters, proving, custody transfer | UC5 |
| **EPA 40 CFR 98 Subpart W, OGMP 2.0** | US EPA / UNEP [R22] | GHG emission sources, methane reporting | `emission_source`, `ghg_emission`, `ldar_survey`, `flare_record` |
| **WGS84 (EPSG:4326)** | — | Coordinates of wells, facilities, spills | `geo_point` on every located node |

Units follow the oilfield conventions encoded in the column names (ft, psi, bbl, Mcf, MMcf,
BOPD, ppg, °F, USD) and are surfaced as property units in the semantic layer.

---

## 7. What qualifies a use case for a knowledge graph

A use case is a good knowledge-graph candidate when most of these hold:

1. **Multi-hop questions** — the answer needs three or more joins across subject areas
   (e.g. inspection → failure → work order → downtime → incident).
2. **Identity and reconciliation** — the same real-world thing has several records or IDs.
3. **Variable-depth structure** — hierarchies, networks or chains of unknown depth (equipment
   trees, sidetracks, pipelines, causal chains).
4. **Mixed structured and narrative evidence** — numbers in tables, explanations in free text.
5. **Explainability** — users must see *why* (the path), not only the score.
6. **Standards alignment adds value** — the vocabulary must be shared across systems or partners.
7. **Data available** in the target data model (here: *oil_gas* MVM) with real foreign keys.
8. **Measurable value** — time saved, NPT/deferment reduced, risk avoided, compliance proven.

---

## 8. Long list and scoring

Weights: graph fit 30 %, business value 25 %, public evidence 20 %, model coverage 15 %,
feasibility 10 %. Scores 1–5.

| Candidate | Graph fit | Value | Evidence | Model coverage | Feasibility | **Weighted** | Decision |
|---|---|---|---|---|---|---|---|
| Well & subsurface 360 / well identity | 5 | 5 | 5 [R1, R2, R9, R10, R18] | 5 | 4 | **4.85** | **UC1** |
| Asset integrity & reliability | 5 | 5 | 4 [R5, R7, R19, R21, R27] | 5 | 5 | **4.80** | **UC3** |
| Drilling performance & lessons learned | 4 | 5 | 4 [R13–R15] | 5 | 5 | **4.50** | **UC2** |
| HSE & process-safety incident intelligence | 5 | 4 | 4 [R20, R30, R32] | 5 | 4 | **4.45** | **UC4** |
| Production-to-market & emissions traceability | 4 | 4 | 3 [R7, R22, R23] | 5 | 4 | **3.95** | **UC5** |
| JV / land ownership & royalty chains | 4 | 4 | 2 | 4 (land, venture) | 3 | 3.55 | Phase 2 |
| Supply chain & materials (spares, vendors, POs) | 3 | 3 | 2 | 4 (procurement) | 4 | 3.05 | Phase 2 |
| Regulatory obligation management | 3 | 3 | 2 | 4 (compliance) | 4 | 3.05 | Partly in UC4 |
| Refinery crude-to-product genealogy | 4 | 3 | 2 | 3 (refining not in MVM scope here) | 3 | 3.20 | Later |
| Seismic & interpretation catalogue | 3 | 3 | 4 [R2, R10] | 2 (seismic table only) | 3 | 3.05 | Later |

---

## 9. The top 5 use cases

Each use case lists: the business problem and owner, why a graph beats a relational or document
store, the entities and relationships (tables of the *oil_gas* model), data sources, value and
KPIs, the demo questions implemented in the app, and the sources.

### UC1 — Well & subsurface 360 / well identity

**Business problem and owner.** Subsurface teams (geoscience, reservoir engineering, subsurface
data management) need a complete, trustworthy view of every well and what it penetrates:
basin, play, prospect, discovery, reservoir, zones, tests and reserves. The same physical well is
recorded as an *exploration well*, a *drilled wellbore*, a *production well* and a *well asset*,
with API numbers, UWIs and names that do not always agree — so every study starts with manual
reconciliation (challenges C1, C2).

**Why a graph.** Identity resolution is a graph problem (cluster records that refer to the same
well; keep the evidence for each link); the geo-context chain basin → play → prospect → discovery
and reservoir → zone → test is variable depth; and the questions geologists ask ("wells
penetrating formation X with a successful test in zone Y") are multi-hop. OBDA work at Statoil/Equinor
shows that domain experts can phrase such questions directly over a semantic model
([R1][R1], [R2][R2]).

**Entities and relationships** (in-scope tables):
`exploration.basin`, `play`, `prospect`, `block`, `formation`, `discovery`, `exploration_well`;
`reservoir.reservoir`, `zone`, `well_test`, `reserves_estimate`, `development_plan`;
`drilling.drilling_well` (with `parent_wellbore` sidetracks); `production.field`, `production_well`;
`asset.well_asset`.
Key FKs: `prospect → play → basin`, `discovery → prospect`, `zone → reservoir → formation`,
`well_test → zone / exploration_well / well_asset`, `drilling_well → reservoir / prospect / development_plan`,
`production_well → field / reservoir / zone`.
**Derived:** `SAME_WELL_AS` between exploration, drilling, production and asset well records whose
API/UWI numbers normalise to the same API-10 (PPDM US Well Number) and `SIDETRACK_OF`
for wellbores of the same well ([R18][R18]).

**Data sources.** Exploration/G&G databases, well master (drilling data store), production
database, fixed-asset register, reserves system.

**Value and KPIs.** Time to assemble a well dossier (target: minutes instead of days); share of
wells with a reconciled identity; number of identity conflicts found and fixed; reserves booked
on wells with complete test evidence.

**Demo questions in the app.** *Q1* everything known about one well across the four registers;
*Q2* wells penetrating a formation with their best test and reserves category; *Q3* well-identity
conflicts (API numbers that disagree, records without a match).

**Standards.** OSDU master data Well/Wellbore/Field/Basin; PPDM US Well Number; SPE-PRMS 2018;
RESQML stratigraphy.

**Sources.** [R1], [R2], [R3], [R9], [R10], [R16], [R18], [R31].

---

### UC2 — Drilling performance & well-construction lessons learned

**Business problem and owner.** Drilling & completions managers want fewer non-productive-time
(NPT) hours and safer wells. NPT, kicks, losses and poor cement jobs are recorded in daily
drilling reports and event logs, but the *lessons* stay in free text and are rarely reused when
planning the next well into the same formation (C3).

**Why a graph.** "Offset-well" analysis is relational in the graph sense: wells drilled into the
same formation or zone, by the same rig, with similar casing designs, and the events, causes and
corrective actions recorded on them. Chains such as kick → well control event → HSE incident →
violation span four domains. Narrative fields (lessons learned, root cause summaries, operations
summaries) are embedded for semantic search and then expanded through the graph.

**Entities and relationships.** `drilling.drilling_well`, `rig`, `well_program`, `daily_drilling_report`,
`npt_event`, `casing_design`, `cementing_job`, `well_control_event`, `well_status_history`; context
from `exploration.formation`, `reservoir.zone`, `asset.equipment`, `hse.incident`, `compliance.violation`.
Key FKs: `npt_event → drilling_well / rig / zone / equipment / well_control_event / incident`;
`well_control_event → daily_drilling_report / incident / process_safety_event / violation`;
`cementing_job → casing_design → well_program → formation`.

**Data sources.** Daily drilling report (DDR) systems, rig contractor reports, cementing service
reports, well control logs, regulator notifications.

**Value and KPIs.** NPT hours and cost per well and per formation; NPT % of rig time; kicks per
10 000 ft drilled; first-time-right cement jobs; reuse of lessons learned in new well programs.

**Demo questions.** *Q4* NPT hours and cost by formation and IADC code, with the lessons learned;
*Q5* offset-well risk brief for a planned well (events in wells into the same formation);
*Q6* the chain from a kick to the incident and violation it caused.

**Standards.** WITSML 2.x (drill reports, cement jobs, tubulars), IADC NPT codes, API RP 53/59
well-control practices, BSEE/state reporting.

**Sources.** [R13], [R14], [R15], [R5] (offset-well context, vendor).

---

### UC3 — Asset integrity & reliability (inspection → failure → work order)

**Business problem and owner.** Asset integrity and maintenance managers must keep
safety-critical equipment and pipelines fit for service while cutting unplanned downtime.
Inspection findings, failure reports, work orders and production deferments live in different
systems, so precursors are missed and "bad actors" are not recognised (C4, C5).

**Why a graph.** Equipment trees (ISO 14224 taxonomy: installation → system → equipment unit →
maintainable item) are hierarchies of variable depth; reliability questions follow causal chains
(inspection finding → failure → corrective work order → downtime → deferred BOE → incident).
Recurring failures form chains via `previous_failure_report`. A graph returns the chain itself
as evidence, which a relational report cannot easily show.

**Entities and relationships.** `asset.asset_facility`, `equipment` (with `parent_equipment`),
`hierarchy`, `pipeline_segment`, `inspection_event`, `failure_report`, `work_order`,
`preventive_maintenance_plan`, `integrity_program`, `well_asset`; `production.downtime_event`,
`artificial_lift`.
Key FKs: `failure_report → inspection_event / equipment / work_order / previous_failure_report`;
`inspection_event → integrity_program / preventive_maintenance_plan / work_order`;
`downtime_event → equipment / work_order / pipeline_segment`; `artificial_lift → production_well / equipment`.

**Data sources.** CMMS (work orders, PM plans, equipment register), inspection management (API
510/570/653, RBI), historian/SCADA for deferment, production accounting.

**Value and KPIs.** MTBF / MTTR by equipment class; repeat failures; deferred BOE per failure;
inspection findings closed before failure; overdue inspections on safety-critical equipment.

**Demo questions.** *Q7* failures that were preceded by an inspection finding, with the work
orders and deferred production; *Q8* bad-actor equipment ranked by failures, repair cost and
deferment; *Q9* safety-critical equipment with overdue inspections or not-fit-for-service results.

**Standards.** ISO 14224:2016, ISO 55001, API RP 510/570/580/581, CFIHOS tag classes, ISO 15926.

**Sources.** [R5], [R7], [R19], [R21], [R27], [R28].

---

### UC4 — HSE & process-safety incident intelligence

**Business problem and owner.** HSE and process-safety leaders must learn from incidents across
sites: which permit-to-work activities, equipment and root causes recur, whether corrective
actions closed the gap, and which events are Tier 1/2 process safety events (API RP 754) with
regulatory consequences (C3, C6).

**Why a graph.** An incident is a hub: investigation, root causes, CAPAs (with follow-up actions
chained by `previous_action`), the permit to work under which work was done, the equipment and
facility involved, spills, process safety events and violations. Similar-incident search over
narratives (vector) plus graph expansion finds recurring patterns; the Norwegian industry's
learning-from-incidents practice and the pipeline accident knowledge graph show the demand
([R32][R32], [R20][R20]).

**Entities and relationships.** `hse.incident`, `incident_investigation`, `hse_corrective_action`,
`permit_to_work`, `process_safety_event`, `spill_event`; `compliance.regulatory_authority`, `permit`,
`violation`; context from `asset.equipment`, `asset_facility`, `pipeline_segment`, `drilling.rig`,
`production.production_facility`.
Key FKs: `incident_investigation → incident / equipment / violation`;
`hse_corrective_action → incident / investigation / process_safety_event / spill_event / previous_action`;
`spill_event → incident / pipeline_segment / violation`; `violation → permit → regulatory_authority`.

**Data sources.** HSE management system (incidents, investigations, CAPA), permit-to-work system,
environmental reporting, regulator correspondence.

**Value and KPIs.** Tier 1/2 PSE rate; repeat incidents with the same root cause; CAPA overdue
and effectiveness; time from incident to investigation closure; violations and penalties.

**Demo questions.** *Q10* full story of the most serious process safety event (equipment, root
cause, CAPAs, violation, penalty); *Q11* recurring root causes across facilities; *Q12* incidents
that occurred under an active permit to work, by permit type.

**Standards.** API RP 754 / IOGP Report 456 (PSE tiers), OSHA recordkeeping, ISO 45001 CAPA,
permit-to-work guidance, regulator notification rules.

**Sources.** [R20], [R30], [R32], [R12].

---

### UC5 — Production-to-market & emissions traceability

**Business problem and owner.** Production accounting, commercial and ESG teams must prove which
wells and facilities stand behind a sale, how volumes were allocated and measured, and how much
methane and CO₂e was flared, vented or leaked on the way (C7).

**Why a graph.** Lineage is a path: production well → allocation → meter station → measurement
point → custody transfer → delivery point, with crude grade quality on the way; emissions attach
to facilities and equipment (`emission_source → ghg_emission`, `ldar_survey`, `flare_record`).
A graph answers "trace this cargo back to its wells and emissions" in one traversal, and shows
the path as audit evidence.

**Entities and relationships.** `production.production_facility`, `daily_production`,
`production_allocation`, `meter_station` (with parent stations), `flare_record`;
`logistics.custody_transfer`, `measurement_point`; `customer.delivery_point`; `product.crude_grade`;
`hse.emission_source`, `ghg_emission`, `ldar_survey`.
Key FKs: `production_allocation → production_well / meter_station / custody_transfer`;
`meter_station → measurement_point / delivery_point / parent_meter_station`;
`custody_transfer → delivery_point / crude_grade`; `flare_record → production_facility / emission_source / ghg_emission`;
`ghg_emission → emission_source / ldar_survey`.

**Data sources.** Production accounting / allocation system, SCADA and historian, measurement
and proving records, terminal and pipeline custody tickets, emissions inventory and LDAR programme.

**Value and KPIs.** Allocation variance (bbl, Mcf) by meter; meters past calibration due date;
methane intensity (CH₄ / marketed gas) and CO₂e per BOE by facility; flared volume and economic
loss; share of sales volumes with complete lineage.

**Demo questions.** *Q13* trace a custody transfer back to its wells, meters and allocation
method; *Q14* facilities ranked by CO₂e per BOE with flaring and LDAR leaks; *Q15* allocations
with large variances and the meters behind them (calibration status).

**Standards.** API MPMS (measurement, proving, allocation), PRODML product volumes, EPA 40 CFR 98
Subpart W, OGMP 2.0, GHG Protocol scopes.

**Sources.** [R7], [R22], [R23], [R25].

---

## 10. Mapping to the oil_gas data model

**Model.** *oil_gas* v1 **MVM** (Minimum Viable Model): 17 domains, 246 tables, 2,664 FKs
(Databricks Industry Data Models). The MVM is the recommended starting point for focused
analytics and PoCs; the ECM adds breadth (568 tables). The DDL (`data_model/ddl`) and the RDF
ontology (`data_model/ontology/oil_gas_rdf_v1_mvm.ttl`) are copied unchanged; the app reads them.

**In scope: 56 tables, 10 subject areas, 297 in-scope FKs.**

| Subject area | Tables | UC1 | UC2 | UC3 | UC4 | UC5 |
|---|---|:-:|:-:|:-:|:-:|:-:|
| exploration | basin, play, prospect, block, formation, discovery, exploration_well | ● | ○ | | | |
| reservoir | reservoir, zone, well_test, reserves_estimate, development_plan | ● | ○ | | | ○ |
| drilling | drilling_well, rig, well_program, daily_drilling_report, npt_event, casing_design, cementing_job, well_control_event, well_status_history | ○ | ● | | ○ | |
| production | field, production_well, production_facility, daily_production, production_allocation, downtime_event, artificial_lift, meter_station, flare_record | ○ | | ○ | | ● |
| asset | asset_facility, equipment, hierarchy, pipeline_segment, inspection_event, failure_report, work_order, preventive_maintenance_plan, integrity_program, well_asset | ○ | ○ | ● | ○ | |
| hse | incident, incident_investigation, hse_corrective_action, permit_to_work, process_safety_event, spill_event, emission_source, ghg_emission, ldar_survey | | ○ | ○ | ● | ● |
| compliance | regulatory_authority, permit, violation | | ○ | | ● | |
| logistics | custody_transfer, measurement_point | | | | | ● |
| customer | delivery_point | | | | | ● |
| product | crude_grade | ○ | | | | ● |

● primary, ○ supporting. Foreign keys to tables outside this scope (finance, venture, land,
procurement…) are left empty in the synthetic data and are not loaded as relationships; adding a
subject area to `scope.domains` in `backend/kg_config.yaml` brings them in without code changes.

**Model observations that shape the design.**

* The four well registers (`exploration_well`, `drilling_well`, `production_well`, `well_asset`)
  have **no foreign keys between them** except `drilling_well.well_asset_id` and
  `exploration_well.well_asset_id`; `production_well` carries `api_number`/`uwi` only. Identity is
  therefore derived (UC1, `SAME_WELL_AS`).
* `daily_production` links to facility, meter station, artificial lift and well test but **not**
  to `production_well`; the well is reached through `artificial_lift` or `production_allocation`.
* `well_program` links to prospect/formation but not to a well; offset-well analysis uses
  formation and zone as the bridge.
* The ontology is RDFS with `ind:` classes per table (`ind:DrillingWell`) and global
  camelCase properties (`ind:apiWellNumber`); it carries no standards annotations, so the app
  adds a separate, clearly labelled standards alignment file.

---

## 11. Reference architecture, roadmap and risks

### 11.1 Architecture (as implemented in this repository)

```mermaid
flowchart LR
    subgraph IN[Inputs - read only]
        DDL[oil_gas MVM DDL]
        TTL[oil_gas RDF ontology<br/>+ standards alignment<br/>+ subject areas]
        CSV[input_data CSV<br/>synthetic, one-time]
    end
    subgraph MODEL[Model step - offline]
        P[DDL parser + typed reader + validation]
        O[ontology extractor<br/>table→class→standard,<br/>column→property→standard attribute + unit]
    end
    subgraph LOAD[Load step - Neo4j]
        S[structured MERGE load<br/>STD_* labels]
        D[derived: SAME_WELL_AS,<br/>SIDETRACK_OF, PRECURSOR_OF]
        G[GIS points]
        SEM[semantic layer<br/>OntologyClass → StandardClass]
        N[narratives → chunks + embeddings]
    end
    subgraph APP[Application]
        API[FastAPI: dashboard, use cases,<br/>graph explorer, search, GraphRAG,<br/>documents, model & standards]
        UI[React UI]
    end
    DDL --> P --> O
    CSV --> P
    TTL --> O
    O --> S --> D --> G --> SEM --> N --> NEO[(Neo4j)]
    NEO --> API --> UI
```

### 11.2 Roadmap

| Phase | Scope | Exit criteria |
|---|---|---|
| 0 — PoC (this repo) | 5 use cases, 56 tables, synthetic data, GraphRAG with ground-truth checks | Demo questions answered with traceable evidence |
| 1 — Pilot | One asset, real extracts for UC1 + UC3; identity rules agreed with data owners; SSO | Reconciled well identity for the asset; integrity bad-actor list accepted by engineers |
| 2 — Scale | UC2, UC4, UC5; streaming deltas; OSDU/WITSML connectors; land/JV ownership (phase 2 candidate) | Weekly refresh, data-quality SLAs, governance board |
| 3 — Agentic | Guarded agents for well dossiers, offset-well briefs, CAPA follow-up | Human-in-the-loop approvals, audit log of every AI answer |

### 11.3 Risks and mitigations

| Risk | Mitigation |
|---|---|
| Wrong identity links | Rule transparency (each `SAME_WELL_AS` carries `rule` and matched value), conflicts surfaced as data-quality findings (Q3) |
| LLM generates wrong Cypher | Read-only execution, curated few-shot examples, routing + fallback to hybrid retrieval, ground-truth Cypher for demo questions |
| Standards drift | Alignment kept in separate TTL files with source references; versioned with the model |
| Sensitive data in narratives | Data classification from the model, redaction before embedding, role-based access in phase 1 |
| Vendor lock-in | Open formats (DDL, OWL/TTL, CSV), configurable providers (OpenAI, Azure, Anthropic, Ollama, OpenAI-compatible) |

---

## 12. References

| Id | Source | Type |
|---|---|---|
| [R1] | Kharlamov E. et al., *Finding Data Should be Easier than Finding Oil*, IEEE Big Data 2018 (Equinor deployment). https://ntnuopen.ntnu.no/ntnu-xmlui/handle/11250/2595911 | peer-reviewed |
| [R2] | Optique project / *Ontology Based Data Access in Statoil*, Journal of Web Semantics; Optique summary. https://sage.cnpereading.com/doi/10.3233/SW-180293 · https://oilit.com/HTML_Articles/2016_3_5.php · https://results2021.ref.ac.uk/outputs/9a140a19-29e4-488d-9e87-c3ba969e0d20?page=1 | peer-reviewed / press |
| [R3] | SIRIUS centre for scalable data access in oil & gas, University of Oslo. https://mn.uio.no/sirius/english/about · https://www.cs.ox.ac.uk/isg/projects/SIRIUS/ | academic |
| [R4] | Equinor interview on Omnia data platform and text-based knowledge graphs. https://www.plantautomation-technology.com/index.php/interviews/ahmed-khamassi-equinor | press |
| [R5] | Cognite — Aker BP customer stories and 2026 NVIDIA announcement. https://cognite.com/en/customers/aker-bp · https://hub.cognite.com/oil-and-gas-86/how-cognite-data-fusion-enabled-quick-maintenance-overviews-of-critical-equipment-for-aker-bp-196 · https://www.cognite.com/en/customer-stories/dataops-oil-gas-siemens-condition-monitoring · https://www.businesswire.com/news/home/20260323390546/en · https://cognite.com/en/extend-your-osdu-data-platform-into-valuable-data-products | vendor |
| [R6] | Cognite — TotalEnergies upstream data platform. https://resources.cognite.com/en/resources/customer-stories/how-totalenergies-is-improving-ai-and-data-maturity-at-scale-across-36-upstream-assets | vendor |
| [R7] | bp and Palantir — 2021 extension and 2024 five-year AIP agreement; production digital twin. https://www.businesswire.com/news/home/20240909534283/en · https://www.businesswire.com/news/home/20210205005057/en · https://www.offshore-technology.com/news/bp-extends-partnership-with-palantir/ | company / vendor press release |
| [R8] | TotalEnergies Semantic Framework (CEUR 2023 poster) and PLM Roadmap 2025 presentation; AVEVA PI contextualisation story. https://ceur-ws.org/Vol-3240/poster1.pdf · https://cimdata.com/images/Downloads/LeClerc_Final_Distribution_Europe_2025.pdf · https://www.factorysoftware.com/resources/-total-energies-success-story | company / conference / vendor |
| [R9] | Abolhassani N., Tudor A., Paul A., *A Data Mesh Adaptable Oil and Gas Ontology Based on OSDU*, KEOD 2023; OSDU ontology (Apache 2.0). https://www.scitepress.org/Documents/2023/121600 · https://accenture.github.io/OSDU-Ontology/ | peer-reviewed |
| [R10] | OSDU data types and well/wellbore master data. https://aws.amazon.com/blogs/industries/osdu-data-platform-on-aws-ingestion-series-1-overview-of-data-types-for-osdutm-data-platform · https://community.opengroup.org/osdu/data/data-definitions/-/blame/cacf5864f65a53dd37618268c4908d763d1e3028/E-R/_SubDomains/Domain-Well.Well.md · https://www.ltimindtree.com/wp-content/uploads/2022/02/OSDU-The-New-Game-Changer-in-EP-Industry-PoV.pdf | vendor / standard |
| [R11] | Energistics affiliation with The Open Group (2022) and WITSML 2.1 OSDU compliance (2023). https://www.businesswire.com/news/home/20220106005072/en · https://oilit.com/HTML_Articles/2023_3_9.php | press |
| [R12] | POSC Caesar Association — ISO 15926, IDO (ISO 15926-14), Reference Data Service, READI. https://rds.posccaesar.org/ · https://rds.posccaesar.org/ontology/lis14/ · https://www.mimosa.org/wp-content/uploads/presentations/2021/04/posc-caesar-association-pca-status-and-plans/20210310_Nils_Sandsmark_MIMOSA_Open_Meeting.pdf | standard |
| [R13] | *Mining Daily Drillers' Reports: Looking for Telling Patterns* (bp, SPE 173429), JPT. https://jpt.spe.org/mining-daily-drillers-reports-looking-telling-patterns | SPE |
| [R14] | Montanuniversität Leoben — automatic capture of drilling lessons learnt / NPT extraction. https://pure.unileoben.ac.at/en/publications/investigating-possibilities-to-automatically-capture-drilling-les/ | academic |
| [R15] | Well-engineering ontology for daily operational reports (ISO 15926-aligned). https://educapes.capes.gov.br/handle/11449/305003?mode=full | academic |
| [R16] | *PetroKG: Construction and Application of Knowledge Graph in Upstream Area of PetroChina* (2020). https://www.springerprofessional.de/en/petrokg-construction-and-application-of-knowledge-graph-in-upstr/18004430 | peer-reviewed |
| [R17] | Petrolês (PUC-Rio, Petrobras R&D) and Petro KGraph thesis (FGV). https://www.petroles.ica.ele.puc-rio.br/index_en.html · https://repositorio.fgv.br/items/fd2e467a-4d06-4e6f-91af-edc4c8843ef6 | academic |
| [R18] | PPDM US Well Number Standard; Curtis T., *What is a Well?* (CSEG/CSPG). https://ppdm.org/ppdm/PPDM/IEDS/Well_Identification/US_Well_Number_Standard/PPDM/US_Well_Number_Standard.aspx · https://www.searchanddiscovery.com/abstracts/pdf/2013/90171cspg/abstracts/ndx_curt.pdf · https://en.wikipedia.org/wiki/API_well_number | standard |
| [R19] | ISO 14224:2016 — collection and exchange of reliability and maintenance data for equipment. https://www.iso.org/standard/64076.html | standard |
| [R20] | Gas pipeline emergency-response knowledge graph from 343 accident reports (Neo4j). https://www.aidic.it/cisap12fex26/programma/shuo.docx | academic (abstract) |
| [R21] | Knowledge graph for O&G plant operations and maintenance based on IDO and CFIHOS (SBSI 2024). https://sol.sbc.org.br/index.php/sbsi/article/view/30889 | peer-reviewed |
| [R22] | OGMP 2.0 (UNEP) and EDF membership figures. https://www.ogmpartnership.org/solution-methane-challenge · https://business.edf.org/?p=11353 · https://methanedata.unep.org/dict-ogmp20-company-factsheets | NGO / UN |
| [R23] | *Oil and Gas Carbon, Methane, and Product Traceability: A Supply Chain Imperative*. https://logisticsviewpoints.com/2026/07/20/oil-and-gas-carbon-methane-and-product-traceability-a-supply-chain-imperative/ | press |
| [R24] | *Process-Oriented Dual-Layer Knowledge GraphRAG for Reservoir Engineering Decision Support* (2025). https://www.researchgate.net/publication/396429313_Process-Oriented_Dual-Layer_Knowledge_GraphRAG_for_Reservoir_Engineering_Decision_Support | peer-reviewed (preprint record) |
| [R25] | *A dual-stage LLM–KG framework for question answering on oil and gas pipeline topologies* (2026). https://www.sciencedirect.com/science/article/pii/S2667143326001320 | peer-reviewed |
| [R26] | *AI at the Helm: Quantifying the Next Value Revolution in Upstream Oil and Gas*, JPT; Aramco AI value reporting. https://jpt.spe.org/twa/ai-at-the-helm-quantifying-the-next-value-revolution-in-upstream-oil-and-gas · https://ognnews.com/Article/47684/Aramco_leveraging_AI_and_big_data_to_drive_operational_efficiency | press |
| [R27] | Ebrahimipour V., Yacout S., *Ontology-Based Schema to Support Maintenance Knowledge Representation With a Case Study of a Pneumatic Valve*, IEEE Trans. SMC: Systems 45(4), 2015, doi:10.1109/TSMC.2014.2383361. https://publications.polymtl.ca/11207/ | peer-reviewed |
| [R28] | IOGP — CFIHOS (JIP36) and its history; adoption caveat. https://www.iogp.org/blog/standards/new-initiative-will-ease-information-handover/ · https://oilit.com/HTML_Articles/2019_3_10.php · https://oilit.com/HTML_Articles/2023_5_4.php | standard / press |
| [R29] | Gong F. et al., *Neo4j graph database realizes efficient storage performance of oilfield ontology*, PLoS ONE 2018. https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6239324/ | peer-reviewed |
| [R30] | API RP 754 and IOGP Report 456 process safety KPIs. https://www.iogp.org/bookstore/product/process-safety-recommended-practice-on-key-performance-indicators/ · https://jpt.spe.org/revised-report-iogp-focuses-process-safety-kpis | standard |
| [R31] | SPE-PRMS 2018 key changes and FAQ. https://spe.org:443/media/filer_public/63/13/6313c8f3-d065-4b07-9f57-7f2507430780/prms2018keychanges.pdf · https://spe.org/industry/reserves/prms-faqs/ | standard |
| [R32] | Norwegian Oil and Gas Recommendation 043E — Learning from Incidents. https://samarbeidforsikkerhet.no/wp-content/uploads/2021/04/Recommendation-043E-Learning-from-Incidents.pdf | industry guideline |

**Not verified.** (a) A blog claim that Shell, Equinor, ExxonMobil and Chevron run named
knowledge-graph programmes ([LinkedIn article](https://www.linkedin.com/pulse/how-using-knowledge-graphs-can-optimize-oil-gas-industry-jon-brewton))
could not be confirmed from primary sources and is not used. (b) Edition details of IOGP
Report 456 differ between sources (2nd vs 3rd edition); the tier structure is consistent.
(c) The current status of ISO 14224:2016 differs between ISO (confirmed 2022) and one national
store (listed as cancelled). (d) The Cognite/Aker BP and Siemens figures are vendor-reported.

[R1]: #12-references
[R2]: #12-references
[R3]: #12-references
[R5]: #12-references
[R6]: #12-references
[R7]: #12-references
[R8]: #12-references
[R9]: #12-references
[R10]: #12-references
[R11]: #12-references
[R12]: #12-references
[R13]: #12-references
[R14]: #12-references
[R15]: #12-references
[R16]: #12-references
[R18]: #12-references
[R19]: #12-references
[R20]: #12-references
[R21]: #12-references
[R22]: #12-references
[R23]: #12-references
[R24]: #12-references
[R25]: #12-references
[R26]: #12-references
[R27]: #12-references
[R28]: #12-references
[R30]: #12-references
[R31]: #12-references
[R32]: #12-references
