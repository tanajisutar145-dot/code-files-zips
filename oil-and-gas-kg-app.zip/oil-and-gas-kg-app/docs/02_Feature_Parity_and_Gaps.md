# Feature parity and gaps

This document checks the acceptance criterion *"every reference-project feature (except the UI) has a counterpart,
gaps listed"*. It maps each feature of the two reference projects to its counterpart in this application, lists
what was added for the five oil & gas use cases, and states what is a gap or has not been verified yet.

* **Reference 1**: `utility-knowledge-graph-v3` (ukg3), the generic DDL + TTL + CSV → Neo4j → GraphRAG pipeline. Its
  functionality was ported in full, except its static web UI.
* **Reference 2**: `utility-knowledge-intelligence` (UKI), the FastAPI backend and React UI. It is the base structure,
  UI and backend of this application.

Status legend: **Ported** = same capability, adapted to oil_gas · **Replaced** = the capability exists, implemented by a
better-fitting component · **Not applicable** = utility-specific, with no oil_gas equivalent · **Gap** = missing or
not verified.

## 1. ukg3 pipeline and engine → `backend/app/kg/`

| ukg3 feature | Counterpart here | Status |
|---|---|---|
| `python -m ukg run --step all\|model\|load\|rag\|viz`, `--reset`, `--skip-text`, `--question`, `--config`, `-v` | `python -m app.kg run ...` (same flags; config also via `OGKG_CONFIG`) | Ported |
| Generic DDL parser (`model/ddl.py`): tables, PKs, FKs, enums, patterns | `app/kg/model/ddl.py`, reading the 19 oil_gas MVM SQL files incl. the cross-domain FK file | Ported |
| Typed CSV/JSONL reader + read-only validation (PK, FK orphans, NOT NULL, enums, WGS84) → `output/data_validation.json` | `app/kg/model/data.py`, `validate.py`. Result: 56 tables, 1,875 rows, 297 FKs, 0 issues | Ported |
| Ontology extractor: table → class, column → property → standard attribute, FK → object property → association; ontology subset | `app/kg/ontology/extract.py`. The oil_gas TTL has no standards annotations, so the alignment comes from the new `og_standards_alignment.ttl` (+ `og_standards_reference.ttl`, `og_subject_areas.skos.ttl`); units are inferred from column-name suffixes (`ontology.unit_suffixes`) | Ported (generalised from CIM to a configurable standard) |
| `build/semantic_model.json`, `ontology_subset.ttl`, `graph_schema.json` | Same files in `backend/build/` | Ported |
| Standard-annotated Text2Cypher schema + few-shot examples | `app/kg/ontology/schema.py` (`std_*` wording, `schema_notes`); examples in `questions.yaml` | Ported |
| MERGE writer; labels `class` + `CIM_*` superclasses; props `cim_class`, `cim_match`, `cim_package`, `cim_standard`, `subject_area`, `source_table` | `app/kg/graph/writer.py`, `structured.py`: labels `class` + `STD_*`; props `std_class`, `std_match`, `std_package`, `std_standard`, `subject_area`, `source_table`, `caption` | Ported (CIM → oil & gas standards) |
| FK relationships carrying the association role (`cim_association`) | `std_association` from `og_standards_alignment.ttl` (about 28 association roles) | Ported |
| Polymorphic links (Terminal → equipment, GIS feature → record) | Same mechanism (`graph.polymorphic_links`). The oil_gas scope has no polymorphic columns, so the list is empty | Ported (unused) |
| GIS: `geo_point` on located nodes, point index, `SF_WITHIN` / `SF_INTERSECTS` to polygons | `app/kg/graph/gis.py`, `geometry.py`: `geo_point` from `latitude/longitude`, `surface_latitude/longitude` and `spill_latitude/longitude`; point index; Text2Cypher distance example | Ported. Spatial relations are a gap: no polygon tables (leases, units, HCAs) are in scope |
| Derived relationships: CIM topology `FEEDS`, identity `REGISTERED_AS` | Config-driven rules for the oil & gas identity and coding standards: `IDENTIFIED_BY` (PPDM US Well Number → `WellIdentity` hub), `NAME_MATCH_API_CONFLICT`, `SAME_FACILITY_AS`, `LOCATES` / `CHILD_OF` (ISO 14224 hierarchy), `PROGRAM_FOR` | Replaced (`FEEDS` is utility network topology and has no oil_gas equivalent) |
| Semantic layer in the graph: `OntologyClass -SPECIALIZES-> CimClass -SUBCLASS_OF*->`, `OntologyProperty -MAPS_TO-> CimAttribute`, `INSTANCE_OF` | `app/kg/graph/semantic.py`: `StandardClass`, `StandardAttribute`, `SubjectArea` (+ UC1–UC5 concepts), `OntologyClass.subject_area` | Ported |
| Narratives → `Document`/`Chunk` + embeddings; vector, full-text and point indexes | `app/kg/graph/unstructured.py`, `indexes.py`: narrative columns of 25 tables (`extraction.narrative_columns`); `chunk_embeddings`, `chunk_fulltext` and row-narrative indexes | Ported |
| Optional LLM entity extraction (`extraction.mode: extract`) | Same switch. The oil & gas entity types are FailureMode, RootCause, CorrectiveAction, Hazard and LessonLearned | Ported; **Gap**: never run (mode `embed` by default) |
| Providers: OpenAI, Azure OpenAI, Anthropic, Ollama, OpenAI-compatible; LLM and embedder configured separately | `app/kg/rag/providers.py`, `backend/.env` | Ported |
| Retrievers: Text2Cypher (EXPLAIN-checked, read-only), Vector + graph, Hybrid + graph; config-driven retrieval templates | `app/kg/rag/retrievers.py`. Templates `neighbourhood`, `event_context`, `causal_chain`, `well_identity`, `lineage`, `equipment_peers` | Ported (templates re-designed for the use cases) |
| Question runner: every retriever per demo question, deterministic ground truth, fact score, `output/report.md`, `run_results.json` | `app/kg/rag/runner.py`, `report.py`. Q1–Q15 (3 per use case) and S1–S5 in `backend/user_questions/questions.yaml` | Ported; **Gap**: not run (needs Neo4j and an LLM) |
| QA engine: routing (regex), fallback, small talk, history, live trace, evidence graph (curated subgraph or quoted records), verification | `app/kg/qa/engine.py` behind `app/intelligence/graphrag_service.py` (`/api/intelligence/jobs`, `/ask`) | Ported |
| Viz: overview, CIM alignment, schema, GIS map, per-question subgraphs | `app/kg/viz/render.py`: `graph_overview.html`, `std_alignment.html/.svg`, `schema_overview.html/.svg`, `gis_map.html` (points), `Q*_subgraph.html` | Ported; **Gap**: not run |
| Brand / vendor-name sanitiser (`sanitize.py`, `BrandGuard`) | `app/kg/sanitize.py` | Ported (disabled: synthetic data has no vendor names) |
| `python -m ukg ui`: FastAPI server + static UI (chat, evidence graph with CIM overlay and geo layout, trace, Model & CIM explorer) | UI excluded by the brief. The server functions moved into the UKI-style API (`/api/intelligence/info`, `/jobs`, `/jobs/{id}`, `/api/model/*`); the React UI provides the same views (Intelligence page: trace, evidence graph with standards overlay and map layout; Model & Standards page) | Replaced |

## 2. UKI backend → `backend/app/`

| UKI feature | Counterpart here | Status |
|---|---|---|
| FastAPI app, CORS, request-logging middleware, `/health`, `/api/health` | `app/main.py`, `app/api/middleware.py`, `app/api/routes.py`. Health covers backend, Neo4j, graph, semantic model, LLM and embedder; Neo4j failures return fast | Ported |
| Settings from `.env` (pydantic) | `app/core/config.py` (+ `kg_settings()` for `config.yaml`) | Ported |
| Neo4j client | `app/graph/neo4j_client.py` (database-aware, read routing, write counters) | Ported |
| Groq LLM client | `app/llm/client.py` over the five configurable providers | Replaced |
| Sentence-Transformers embedding service | Configured embedder (Ollama `nomic-embed-text` by default, or OpenAI / Azure / compatible) | Replaced |
| Utility ingestion: data generator, validator, loader, ontology loader | ukg3 pipeline (model + load steps). The one-time generator was used to create `input_data/` and is not part of the app package | Replaced |
| `/api/dashboard/summary` | Oil & gas KPI groups (wells, production, drilling, integrity, HSE, emissions), use-case headlines, trends, findings, graph and document statistics | Ported (content rewritten) |
| `/api/graph/*` explorer (overview, explore, node, neighbours, nodes, relationships, subgraph, path) | `app/services/graph_service.py`, same routes | Ported |
| `/api/assets/*` (overview, list, detail) | Equipment integrity: ISO 14224 class, criticality, safety-critical, overdue inspection, failures, work orders, PM plans, integrity programmes, downtime, HSE, drilling NPT, evidence graph | Ported (content rewritten) |
| `/api/documents/*` (overview, list, detail, upload, delete) + parsers (PDF, DOCX, XLSX, CSV, TXT, JSON) + chunker + entity linker | Same routes plus `kind` (uploaded / record narrative). Entity linking uses graph captions and API numbers (`MENTIONS_RECORD`, `WellIdentity`). CLI: `python -m app.documents load\|list\|delete` | Ported |
| `/api/search/semantic`, `/retrieve`, `/keyword`, `/similar/{id}` | Same routes over the shared chunk vector / full-text indexes | Ported |
| `/api/intelligence/ask`, `/ask/simple`, `/query`, `/fact-check`, `/summarize` | Same routes, answered by the QA engine; plus `/info`, `/jobs`, `/jobs/{id}`, `/jobs/latest`, `/jobs/{id}/response` | Ported + extended |
| Answer verifier (grounding score, supported / unsupported claims) | `app/verification/answer_verifier.py`: record identifiers, API numbers and figures checked against the retrieved context; blended with the ground truth for demo questions | Ported |
| `/api/verification/pending`, `/review/{id}`, `/stats` | Same routes, plus `/items` and `/flag`. Answers with low grounding are queued automatically. The queue is a JSON file in `outputs/` | Ported |
| Backend tests (`backend/tests`) | 42 offline tests (`pytest`): semantic model, dataset integrity and planted facts, demo questions, static Cypher lint of all queries, verifier, entity linker, parsers, API | Replaced (rewritten for oil_gas) |

## 3. UKI frontend → `frontend/` (base structure and look kept)

| UKI page / component | Counterpart here | Status |
|---|---|---|
| Layout, routing, MUI theme, health chip | Rebranded. Menu: Dashboard, Use Cases, Intelligence, Knowledge Graph, Model & Standards, Search, Documents, Equipment, Answer Review, System Health, Settings | Ported |
| Dashboard (fleet KPIs, operations, heat rate, knowledge, AI summary) | KPI groups, the five use-case cards with live figures and findings, trends, knowledge statistics, GraphRAG entry with demo questions | Ported (utility panels replaced) |
| Knowledge Graph explorer + node popup | Same components. Colours come from the oil_gas subject areas; vocabulary, units, parent rules and status colours are oil & gas | Ported |
| Intelligence (chat, composer, evidence inspector) | Jobs API with a live trace, retriever picker (auto / Text2Cypher / vector / hybrid / compare), demo and sample questions from the engine, an evidence graph tab, a retriever comparison, a ground-truth fact check, and flag-for-review | Ported + extended |
| Search, Documents, Assets, Health, Settings | Search and Documents adapted; Assets rewritten as Equipment Integrity; Health shows six services; Settings rebranded | Ported |
| Frontend tests (Jest, static markup) | Rewritten with oil & gas fixtures; `react-markdown` is mapped to a Jest stub (`src/__mocks__`) | Ported; **Gap**: not run (see §5) |

## 4. Added for the five use cases (no reference counterpart)

* **Use Cases page and `/api/usecases/*`**: deterministic Cypher analyses, each returned with its query. **UC1**:
  well register by API-10, well 360, identity conflicts (API conflicts, missing asset record, name aliases,
  single-register wells), wells by formation with best test and reserves. **UC2**: NPT by category and rig,
  offset-well risk brief for a planned program, well-control consequence chains. **UC3**: failures preceded by an
  inspection finding, bad actors and repeat-failure chains, overdue safety-critical inspections, not-fit-for-service
  results, ISO 14224 hierarchy. **UC4**: process safety events and the full story of each, recurring root causes,
  incidents under a permit to work. **UC5**: custody-transfer lineage with volume reconciliation, facility
  emissions with flaring and LDAR, allocation variances vs meter calibration.
* **Model & Standards page and `/api/model/*`**: classes, columns, units, standard classes and attributes, FK and
  derived relationships, sample instances, pipeline status. Works before the graph is loaded.
* **Answer Review page.**
* **Reusable evidence graph** (Cytoscape) with a standards overlay and a map layout, used on the Intelligence, Use
  Cases, Equipment and Model pages.
* **Four synthetic sample documents** (`backend/data/documents/`) whose facts match the dataset.
* **Static Cypher lint** (`backend/tests/cypher_lint.py`). It checks 196 queries (services, demo questions, derived
  rules, generated retrieval templates) against the model without a database.

## 5. Gaps and items not verified

| # | Item | Why / what settles it |
|---|---|---|
| 1 | **Live Neo4j load** (`--step load`) and every endpoint that reads the graph | Neo4j was not running during the build. To settle it: start the DBMS in Neo4j Desktop, run `python -m app.kg run --step load --reset`, then open `/api/usecases/*` and the UI. The Cypher was checked statically, the data was validated offline, and the expected answers were recomputed from the CSVs |
| 2 | **GraphRAG answers** and the retriever comparison (`--step rag`), demo-question fact scores | Needs Neo4j and the LLM / embedder. With a small local LLM, Text2Cypher can produce wrong Cypher; Auto mode then falls back to hybrid retrieval |
| 3 | **Frontend build and Jest tests** | Node.js is not installed on the build machine. The sources were type-checked with the bundled TypeScript 6 compiler against minimal library stubs: 0 errors after filtering stub artefacts. `npm install`, `npm test` and `npm run build` have not been run |
| 4 | **Spatial relationships** (`SF_WITHIN` / `SF_INTERSECTS`) | No polygon tables (leases, units, high-consequence areas) are in the 56-table scope; only point locations exist |
| 5 | **LLM entity extraction** (`extraction.mode: extract`) | Supported but not run; the default mode is `embed` |
| 6 | **Polymorphic links** | The mechanism is ported, but no oil_gas in-scope column needs it |
| 7 | **Scale** | 1,875 synthetic rows (about 50 per transactional table): enough for the planted stories, not for performance testing |
| 8 | **Data-generation script** | Not part of the app package (one-time generation). It is kept beside the app in `../_synthetic_data_generator/` and reproduces `input_data/` and the standards TTLs byte for byte; the method and planted facts are in `input_data/README.md` |
| 9 | **Out-of-scope foreign keys** | Columns that reference tables outside the 56 in scope (finance, contracts, land...) are left empty, so those links do not exist in the graph |
