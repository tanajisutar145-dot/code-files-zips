# Oil & Gas Knowledge Intelligence

A knowledge graph and GraphRAG application over the `oil_gas` data model (56 tables, 10 subject areas) for five
use cases: well & subsurface 360, drilling lessons learned, asset integrity, HSE / process safety, and
production-to-market & emissions traceability. **All records are synthetic** (fictitious operator "OGX Energy").

| Folder | Contents |
|---|---|
| `docs/` | `01_OilGas_KG_Research_and_Use_Cases.md` (research, top 5 use cases, cited sources), `02_Feature_Parity_and_Gaps.md` |
| `input_data/` | Synthetic dataset: one CSV per table (`<schema>/<table>.csv`), `manifest.json`, `README.md` (schema, generation, planted facts) |
| `data_model/` | oil_gas DDL (unchanged), OWL ontology (unchanged) + standards-alignment and subject-area TTLs |
| `backend/` | FastAPI API (`app/`), knowledge-graph pipeline (`app/kg/`), `config.yaml`, demo questions, sample documents, tests |
| `frontend/` | React + TypeScript + MUI user interface |

## 1. Prerequisites

* **Python 3.11+** (developed with 3.12).
* **Neo4j 5.13+ with the APOC plugin.** Neo4j Desktop works: create a DBMS, add APOC under *Plugins*, then press **Start**.
  The database `oil-gas-kg` is created automatically on Enterprise / Desktop. On Neo4j Community set `NEO4J_DATABASE=neo4j`.
* **An LLM and an embedder.** The default is local [Ollama](https://ollama.com) (`ollama pull qwen2.5:7b`,
  `ollama pull nomic-embed-text`). OpenAI, Azure OpenAI, Anthropic (LLM only) and OpenAI-compatible servers are configured
  in `backend/.env`.
* **Node.js 18+** for the frontend.

## 2. Backend setup (Windows PowerShell; on macOS / Linux use `python3` and `.venv/bin/`)

```powershell
cd backend
py -3.12 -m venv .venv
.venv\Scripts\pip install -r requirements.txt
copy .env.example .env      # then set NEO4J_PASSWORD and, if needed, the LLM_* / EMBEDDING_* values
```

## 3. Build the knowledge graph (load the synthetic data)

Run these from `backend/` with the virtual environment's Python (`.venv\Scripts\python`):

```powershell
.venv\Scripts\python -m app.kg run --step model          # offline: parse DDL + ontology + CSVs, validate, build the semantic model
.venv\Scripts\python -m app.kg run --step load --reset   # Neo4j: records, foreign keys, standard labels, derived rules, narrative chunks
.venv\Scripts\python -m app.documents load               # optional: the four sample documents in data/documents
.venv\Scripts\python -m app.kg run --step rag            # optional: answer Q1-Q15 with every retriever -> output/report.md
.venv\Scripts\python -m app.kg run --step viz            # optional: HTML graph renderings -> output/
```

* `--step all` runs model, load, rag and viz in order.
* `--skip-text` loads only the structured graph, with no embeddings and no LLM.
* `--question Q7` limits the rag and viz steps to one question.

The model step checks the data against the model (`output/data_validation.json`): every CSV column is in the DDL,
primary keys are unique and every foreign key resolves.

## 4. Run the application

```powershell
.venv\Scripts\python -m app.main                      # API on http://127.0.0.1:8000 (OpenAPI docs: /docs)
```

```powershell
cd frontend
npm install
npm start                                             # UI on http://localhost:3000 (proxies /api to port 8000)
```

| Page | What it shows |
|---|---|
| Dashboard | KPIs, the five use cases with live figures and findings, trends, graph and document statistics |
| Use Cases | Deterministic analyses for UC1 to UC5, each shown with its Cypher. Includes the well 360 view, identity conflicts, offset-well brief, failure precursors, bad actors, the process-safety-event story, custody-transfer lineage and emissions |
| Intelligence | GraphRAG chat with a retriever choice (auto, Text2Cypher, vector + graph, hybrid + graph, compare). Each answer shows a live trace of the backend steps, the evidence graph (with standards overlay and map layout), a ground-truth fact check for the demo questions, and can be flagged for review |
| Knowledge Graph | Explorer: labels, relationship types, node details and neighbours |
| Model & Standards | Classes, columns, units, standards alignment, relationships and pipeline status. Works before the graph is loaded |
| Search / Documents / Equipment / Answer Review / System Health | Semantic search; document upload with record linking; equipment integrity; human review queue; service status |

## 5. Tests

```powershell
cd backend
.venv\Scripts\python -m pytest -q      # offline: model, dataset, demo questions, static Cypher checks, verifier, documents, API
```

The backend tests need neither Neo4j nor an LLM. `tests/test_cypher_static.py` checks every Cypher query against the
semantic model: the service queries, the demo questions, the derived rules and the generated retrieval templates.
It reports unknown labels, unknown properties, unknown relationship types and relationships drawn in the wrong
direction. To run the frontend tests: `cd frontend; npm test`.

## 6. Configuration

* `backend/config.yaml` holds the pipeline and API settings: input files, scope, ontology and standard alignment,
  derived relationships, narrative columns, indexes, retrieval templates and routing, visualisation, and the
  `api.as_of_date` used for "overdue" checks (2026-09-30).
* `backend/.env` holds secrets and model providers (see `.env.example`). `OGKG_CONFIG` points to another config file.
* `backend/user_questions/questions.yaml` holds the demo questions, their ground-truth Cypher, the expected facts
  and the Text2Cypher few-shot examples.

## 7. Verification status

The run guide above is complete, but not everything in it has been exercised yet:

* **Verified:** the model step and data validation (56 tables, 1,875 rows, 297 foreign keys, 0 issues), the backend
  tests (42 passed), the offline API smoke tests, and a type check of the frontend sources with stubbed library typings.
* **Not yet verified:** the live Neo4j load, the GraphRAG answers, and `npm install` / `npm test` / `npm run build` of
  the frontend (Node.js was not installed on the build machine).

The open points are listed in `docs/02_Feature_Parity_and_Gaps.md`.
