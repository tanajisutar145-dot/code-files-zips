/**
 * Evidence graph: renders the vis JSON returned by the backend (answer subgraphs, use-case lineage,
 * equipment context) with Cytoscape. Nodes keep the backend colour (subject area); records that were
 * quoted in the answer are drawn with a heavy border. Options: standards overlay (adds the aligned
 * standard class to each caption) and map layout (positions nodes by their WGS84 point).
 */

import React, { useEffect, useMemo, useRef, useState } from 'react';
import cytoscape, { Core, EventObject } from 'cytoscape';
import {
  Box,
  Chip,
  FormControlLabel,
  IconButton,
  Switch,
  Table,
  TableBody,
  TableCell,
  TableRow,
  Tooltip,
  Typography,
} from '@mui/material';
import { CenterFocusStrong as FitIcon, Close as CloseIcon } from '@mui/icons-material';
import { VisGraph, VisNode } from '../../types/api';
import { CYTOSCAPE_STYLESHEET, DERIVED_RELATIONSHIPS, darken, getNodeColor } from '../../pages/graph/utils/graphStyles';
import { formatPropertyLabel, formatPropertyValue } from '../../pages/graph/utils/relationshipUtils';

interface EvidenceGraphProps {
  graph?: VisGraph | null;
  height?: number;
  emptyText?: string;
  showLegend?: boolean;
}

const HIDDEN_PROPS = new Set(['embedding', 'geo_point', 'caption', 'source_table', 'subject_area']);

const shorten = (s: string, n: number = 26) => (s && s.length > n ? `${s.slice(0, n - 2)}…` : s || '');

export const EvidenceGraph: React.FC<EvidenceGraphProps> = ({
  graph,
  height = 420,
  emptyText = 'No graph evidence for this result.',
  showLegend = true,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const cyRef = useRef<Core | null>(null);
  const [standards, setStandards] = useState(false);
  const [mapLayout, setMapLayout] = useState(false);
  const [selected, setSelected] = useState<VisNode | null>(null);

  const nodes = useMemo(() => graph?.nodes || [], [graph]);
  const edges = useMemo(() => graph?.edges || [], [graph]);
  const byId = useMemo(() => new Map(nodes.map((n) => [n.id, n])), [nodes]);
  const located = useMemo(() => nodes.filter((n) => typeof n.lat === 'number' && typeof n.lon === 'number'), [nodes]);
  const canMap = located.length >= 2;
  const isEmpty = !graph || nodes.length === 0;

  // Latest id -> node map for the tap handler registered once below
  const byIdRef = useRef(byId);
  useEffect(() => {
    byIdRef.current = byId;
  }, [byId]);

  const legend = useMemo(() => {
    const counts = new Map<string, { color: string; count: number }>();
    nodes.forEach((n) => {
      const entry = counts.get(n.group) || { color: n.color || getNodeColor(n.group).bg, count: 0 };
      entry.count += 1;
      counts.set(n.group, entry);
    });
    return Array.from(counts.entries()).sort((a, b) => b[1].count - a[1].count);
  }, [nodes]);

  // Create / destroy the Cytoscape instance
  useEffect(() => {
    if (!containerRef.current) return;
    const cy = cytoscape({
      container: containerRef.current,
      elements: [],
      style: CYTOSCAPE_STYLESHEET,
      boxSelectionEnabled: false,
      wheelSensitivity: 0.25,
    });
    cy.on('tap', 'node', (evt: EventObject) => setSelected(byIdRef.current.get(evt.target.id()) || null));
    cy.on('tap', (evt: EventObject) => {
      if (evt.target === cy) setSelected(null);
    });
    cyRef.current = cy;
    const observer = new ResizeObserver(() => !cy.destroyed() && cy.resize());
    observer.observe(containerRef.current);
    return () => {
      observer.disconnect();
      if (!cy.destroyed()) cy.destroy();
      cyRef.current = null;
    };
  }, []);

  // (Re)build elements and run the layout
  useEffect(() => {
    const cy = cyRef.current;
    if (!cy || cy.destroyed()) return;
    const ids = new Set(nodes.map((n) => n.id));
    cy.batch(() => {
      cy.elements().remove();
      cy.add(
        nodes.map((n) => {
          const bg = n.color || getNodeColor(n.group).bg;
          const std = n.std?.std_class;
          const caption = standards && std ? `${shorten(n.label)}\n«${std}»` : shorten(n.label);
          return {
            group: 'nodes' as const,
            data: { id: n.id, shortLabel: caption, color: bg, borderColor: darken(bg) },
            classes: n.evidence ? 'evidence' : '',
          };
        })
      );
      cy.add(
        edges
          .filter((e) => ids.has(e.from) && ids.has(e.to))
          .map((e) => ({
            group: 'edges' as const,
            data: { id: `e-${e.id}`, source: e.from, target: e.to, type: standards && e.std ? `${e.label} «${e.std}»` : e.label },
            classes: DERIVED_RELATIONSHIPS.has(e.label) ? 'derived' : '',
          }))
      );
    });
    if (nodes.length === 0) return;
    cy.resize();
    if (mapLayout && canMap) {
      const lats = located.map((n) => n.lat as number);
      const lons = located.map((n) => n.lon as number);
      const [minLat, maxLat, minLon, maxLon] = [Math.min(...lats), Math.max(...lats), Math.min(...lons), Math.max(...lons)];
      const w = 900;
      const h = 600;
      const sx = (lon: number) => ((lon - minLon) / (maxLon - minLon || 1)) * w;
      const sy = (lat: number) => h - ((lat - minLat) / (maxLat - minLat || 1)) * h;
      let k = 0;
      cy.layout({
        name: 'preset',
        positions: (node: any) => {
          const n = byId.get(node.id());
          if (n && typeof n.lat === 'number' && typeof n.lon === 'number') return { x: sx(n.lon), y: sy(n.lat) };
          k += 1;
          return { x: -120, y: (k * 40) % (h + 80) };
        },
        fit: true,
        padding: 30,
      } as any).run();
    } else {
      cy.layout({
        name: 'cose',
        animate: false,
        padding: 30,
        nodeRepulsion: 400000,
        idealEdgeLength: 80,
        gravity: 80,
        numIter: 800,
      } as any).run();
      cy.fit(undefined, 30);
    }
  }, [nodes, edges, standards, mapLayout, canMap, located, byId]);

  const selectedProps = selected
    ? Object.entries(selected.props || {}).filter(([k, v]) => !HIDDEN_PROPS.has(k) && v !== null && v !== '' && !k.startsWith('std_'))
    : [];

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
      {isEmpty && (
        <Box
          sx={{
            height: Math.min(height, 160),
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            border: '1px dashed #cbd5e1',
            borderRadius: 2,
            color: '#94a3b8',
            fontSize: '0.875rem',
            textAlign: 'center',
            px: 2,
          }}
        >
          {emptyText}
        </Box>
      )}
      <Box sx={{ display: isEmpty ? 'none' : 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 1 }}>
        <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 600 }}>
          {nodes.length} nodes · {edges.length} relationships
          {nodes.some((n) => n.evidence) ? ' · heavy border = record quoted in the answer' : ''}
        </Typography>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <FormControlLabel
            control={<Switch size="small" checked={standards} onChange={(e) => setStandards(e.target.checked)} />}
            label={<Typography variant="caption">Standards overlay</Typography>}
          />
          <Tooltip title={canMap ? 'Position records by latitude / longitude' : 'Fewer than two records carry coordinates'}>
            <span>
              <FormControlLabel
                disabled={!canMap}
                control={<Switch size="small" checked={mapLayout && canMap} onChange={(e) => setMapLayout(e.target.checked)} />}
                label={<Typography variant="caption">Map layout</Typography>}
              />
            </span>
          </Tooltip>
          <Tooltip title="Fit to view">
            <IconButton size="small" onClick={() => cyRef.current?.fit(undefined, 30)}>
              <FitIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        </Box>
      </Box>

      {/* The container stays mounted so the Cytoscape instance survives empty -> filled transitions */}
      <Box
        ref={containerRef}
        sx={{
          width: '100%',
          height,
          display: isEmpty ? 'none' : 'block',
          bgcolor: '#fafafa',
          border: '1px solid #e2e8f0',
          borderRadius: 2,
          overflow: 'hidden',
        }}
      />

      {!isEmpty && showLegend && legend.length > 0 && (
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.75 }}>
          {legend.map(([group, info]) => (
            <Chip
              key={group}
              size="small"
              label={`${group} (${info.count})`}
              sx={{ height: 20, fontSize: '0.6875rem', bgcolor: info.color, color: '#ffffff', fontWeight: 600 }}
            />
          ))}
        </Box>
      )}

      {!isEmpty && selected && (
        <Box sx={{ border: '1px solid #e2e8f0', borderRadius: 2, p: 1.5, bgcolor: '#ffffff' }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 1 }}>
            <Box>
              <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#0f172a' }}>
                {selected.label}
              </Typography>
              <Box sx={{ display: 'flex', gap: 0.75, flexWrap: 'wrap', mt: 0.5 }}>
                <Chip size="small" label={selected.group} sx={{ height: 20, fontSize: '0.6875rem', bgcolor: selected.color, color: '#fff' }} />
                {selected.std?.std_class && (
                  <Chip
                    size="small"
                    variant="outlined"
                    label={`${selected.std.std_class} (${selected.std.std_match || 'aligned'})`}
                    title={[selected.std.std_package, selected.std.std_standard].filter(Boolean).join(' · ')}
                    sx={{ height: 20, fontSize: '0.6875rem' }}
                  />
                )}
                {selected.evidence && <Chip size="small" color="success" label="Quoted in answer" sx={{ height: 20, fontSize: '0.6875rem' }} />}
              </Box>
            </Box>
            <IconButton size="small" onClick={() => setSelected(null)}>
              <CloseIcon fontSize="small" />
            </IconButton>
          </Box>
          <Table size="small" sx={{ mt: 1 }}>
            <TableBody>
              {selectedProps.slice(0, 18).map(([k, v]) => (
                <TableRow key={k}>
                  <TableCell sx={{ color: '#64748b', fontSize: '0.75rem', width: '40%', py: 0.5 }}>{formatPropertyLabel(k)}</TableCell>
                  <TableCell sx={{ fontSize: '0.75rem', py: 0.5, wordBreak: 'break-word' }}>{formatPropertyValue(k, v)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Box>
      )}
    </Box>
  );
};

export default EvidenceGraph;
