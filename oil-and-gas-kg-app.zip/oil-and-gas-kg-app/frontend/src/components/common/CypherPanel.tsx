/**
 * Collapsible "how this was computed" panel showing the read-only Cypher behind a result.
 */

import React, { useState } from 'react';
import { Box, Button, Collapse, IconButton, Tooltip, Typography } from '@mui/material';
import { Code as CodeIcon, ContentCopy as CopyIcon } from '@mui/icons-material';

interface CypherPanelProps {
  cypher?: string | null;
  title?: string;
  defaultOpen?: boolean;
}

/** Re-indent a single-line Cypher string at its clauses so it reads well. */
export const prettyCypher = (cypher: string): string =>
  cypher
    .replace(/\s+/g, ' ')
    .replace(/ (OPTIONAL MATCH|MATCH|WHERE|WITH|RETURN|ORDER BY|UNION|UNWIND|CALL|LIMIT|SKIP) /g, '\n$1 ')
    .trim();

export const CypherPanel: React.FC<CypherPanelProps> = ({ cypher, title = 'Cypher', defaultOpen = false }) => {
  const [open, setOpen] = useState(defaultOpen);
  if (!cypher) return null;
  const text = cypher.includes('\n') ? cypher.trim() : prettyCypher(cypher);

  return (
    <Box sx={{ mt: 1 }}>
      <Button
        size="small"
        startIcon={<CodeIcon sx={{ fontSize: 16 }} />}
        onClick={() => setOpen((v) => !v)}
        sx={{ textTransform: 'none', color: '#64748b', fontWeight: 600, fontSize: '0.75rem', px: 1 }}
      >
        {open ? `Hide ${title}` : `Show ${title}`}
      </Button>
      <Collapse in={open}>
        <Box sx={{ position: 'relative', mt: 0.5 }}>
          <Tooltip title="Copy">
            <IconButton
              size="small"
              onClick={() => navigator.clipboard?.writeText(text)}
              sx={{ position: 'absolute', top: 4, right: 4, color: '#94a3b8' }}
            >
              <CopyIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </Tooltip>
          <Typography
            component="pre"
            sx={{
              m: 0,
              p: 1.5,
              pr: 5,
              bgcolor: '#0f172a',
              color: '#e2e8f0',
              borderRadius: 1.5,
              fontFamily: 'Consolas, Menlo, monospace',
              fontSize: '0.75rem',
              lineHeight: 1.5,
              whiteSpace: 'pre-wrap',
              wordBreak: 'break-word',
              maxHeight: 360,
              overflow: 'auto',
            }}
          >
            {text}
          </Typography>
        </Box>
      </Collapse>
    </Box>
  );
};

export default CypherPanel;
