/**
 * Titled card used by the use-case, model and dashboard pages.
 */

import React from 'react';
import { Box, Card, CardContent, Typography } from '@mui/material';

interface SectionCardProps {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  action?: React.ReactNode;
  children: React.ReactNode;
  sx?: Record<string, any>;
}

export const SectionCard: React.FC<SectionCardProps> = ({ title, subtitle, action, children, sx }) => (
  <Card
    elevation={0}
    sx={{ border: '1px solid #e2e8f0', borderRadius: 2, boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)', mb: 2.5, ...sx }}
  >
    <CardContent sx={{ p: 2.5, '&:last-child': { pb: 2.5 } }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 2, mb: 1.5 }}>
        <Box>
          <Typography variant="subtitle1" sx={{ fontWeight: 700, color: '#0f172a', lineHeight: 1.3 }}>
            {title}
          </Typography>
          {subtitle && (
            <Typography variant="body2" sx={{ color: '#64748b', mt: 0.25 }}>
              {subtitle}
            </Typography>
          )}
        </Box>
        {action}
      </Box>
      {children}
    </CardContent>
  </Card>
);

export default SectionCard;
