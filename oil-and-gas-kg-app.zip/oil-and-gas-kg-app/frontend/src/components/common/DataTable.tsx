/**
 * Compact table for Cypher result rows. Columns are inferred from the rows unless given; values are
 * formatted by column name (USD, bbl, Mcf, ft, dates, lists, booleans).
 */

import React from 'react';
import { Box, Chip, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from '@mui/material';
import { formatPropertyLabel, formatPropertyValue } from '../../pages/graph/utils/relationshipUtils';

export interface DataColumn {
  key: string;
  label?: string;
  render?: (value: any, row: Record<string, any>) => React.ReactNode;
  align?: 'left' | 'right' | 'center';
  width?: number | string;
}

interface DataTableProps {
  rows: Record<string, any>[];
  columns?: (DataColumn | string)[];
  maxHeight?: number;
  emptyText?: string;
  onRowClick?: (row: Record<string, any>) => void;
  dense?: boolean;
}

const isNumeric = (v: any) => typeof v === 'number';

export const renderValue = (key: string, value: any): React.ReactNode => {
  if (value === null || value === undefined || value === '') return <span style={{ color: '#cbd5e1' }}>—</span>;
  if (typeof value === 'boolean') {
    return (
      <Chip
        size="small"
        label={value ? 'Yes' : 'No'}
        sx={{ height: 18, fontSize: '0.6875rem', bgcolor: value ? '#ecfdf5' : '#f1f5f9', color: value ? '#047857' : '#64748b' }}
      />
    );
  }
  if (Array.isArray(value)) {
    const items = value.filter((v) => v !== null && v !== undefined && v !== '');
    if (items.length === 0) return <span style={{ color: '#cbd5e1' }}>—</span>;
    if (items.every((v) => typeof v !== 'object')) {
      return (
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
          {items.slice(0, 12).map((v, i) => (
            <Chip key={i} size="small" label={String(v)} sx={{ height: 18, fontSize: '0.6875rem', bgcolor: '#f1f5f9' }} />
          ))}
          {items.length > 12 && <Typography variant="caption">+{items.length - 12}</Typography>}
        </Box>
      );
    }
    return <span>{items.length} item(s)</span>;
  }
  if (typeof value === 'object') return <code style={{ fontSize: '0.7rem' }}>{JSON.stringify(value)}</code>;
  return formatPropertyValue(key, value);
};

export const DataTable: React.FC<DataTableProps> = ({
  rows,
  columns,
  maxHeight = 420,
  emptyText = 'No rows.',
  onRowClick,
  dense = true,
}) => {
  if (!rows || rows.length === 0) {
    return (
      <Typography variant="body2" sx={{ color: '#94a3b8', py: 2, textAlign: 'center' }}>
        {emptyText}
      </Typography>
    );
  }
  const cols: DataColumn[] = (columns || Object.keys(rows[0])).map((c) => (typeof c === 'string' ? { key: c } : c));

  return (
    <TableContainer sx={{ maxHeight, border: '1px solid #e2e8f0', borderRadius: 1.5 }}>
      <Table stickyHeader size={dense ? 'small' : 'medium'}>
        <TableHead>
          <TableRow>
            {cols.map((c) => (
              <TableCell
                key={c.key}
                align={c.align || (isNumeric(rows[0][c.key]) ? 'right' : 'left')}
                sx={{ bgcolor: '#f8fafc', color: '#475569', fontWeight: 700, fontSize: '0.72rem', whiteSpace: 'nowrap', width: c.width }}
              >
                {c.label || formatPropertyLabel(c.key)}
              </TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row, i) => (
            <TableRow
              key={i}
              hover
              onClick={onRowClick ? () => onRowClick(row) : undefined}
              sx={{ cursor: onRowClick ? 'pointer' : 'default' }}
            >
              {cols.map((c) => (
                <TableCell
                  key={c.key}
                  align={c.align || (isNumeric(row[c.key]) ? 'right' : 'left')}
                  sx={{ fontSize: '0.78rem', color: '#1e293b', verticalAlign: 'top' }}
                >
                  {c.render ? c.render(row[c.key], row) : renderValue(c.key, row[c.key])}
                </TableCell>
              ))}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default DataTable;
