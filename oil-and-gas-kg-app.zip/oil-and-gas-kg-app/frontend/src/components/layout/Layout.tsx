import React, { useState } from 'react';
import {
  AppBar,
  Box,
  CssBaseline,
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Typography,
  Chip,
  Tooltip,
} from '@mui/material';
import {
  Menu as MenuIcon,
  Dashboard as DashboardIcon,
  AccountTree as GraphIcon,
  Description as DocumentsIcon,
  Search as SearchIcon,
  Psychology as IntelligenceIcon,
  PrecisionManufacturing as AssetsIcon,
  MonitorHeart as HealthIcon,
  Insights as UseCasesIcon,
  Schema as ModelIcon,
  FactCheck as ReviewIcon,
  Tune as SettingsIcon,
} from '@mui/icons-material';
import { useNavigate, useLocation } from 'react-router-dom';
import { useHealth } from '../../hooks/useHealth';

const drawerWidth = 248;

interface LayoutProps {
  children: React.ReactNode;
}

const APP_TITLE = 'Oil & Gas Knowledge Intelligence';

const menuItems = [
  { text: 'Dashboard', icon: <DashboardIcon />, path: '/' },
  { text: 'Use Cases', icon: <UseCasesIcon />, path: '/usecases' },
  { text: 'Intelligence', icon: <IntelligenceIcon />, path: '/intelligence' },
  { text: 'Knowledge Graph', icon: <GraphIcon />, path: '/graph' },
  { text: 'Model & Standards', icon: <ModelIcon />, path: '/model' },
  { text: 'Search', icon: <SearchIcon />, path: '/search' },
  { text: 'Documents', icon: <DocumentsIcon />, path: '/documents' },
  { text: 'Equipment', icon: <AssetsIcon />, path: '/assets' },
  { text: 'Answer Review', icon: <ReviewIcon />, path: '/verification' },
  { text: 'System Health', icon: <HealthIcon />, path: '/health' },
  { text: 'Settings', icon: <SettingsIcon />, path: '/settings' },
];

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { health, loading } = useHealth();

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const getOverallStatus = () => {
    if (loading || !health) return 'loading';
    if (health.backend === 'offline' || health.backend === 'disconnected') return 'offline';
    if (health.neo4j !== 'connected' || health.graph !== 'loaded' || health.llm !== 'configured') return 'warning';
    return 'connected';
  };

  const getStatusText = () => {
    const status = getOverallStatus();
    if (status === 'loading') return 'Backend Checking...';
    if (status === 'offline') return 'Backend Offline';
    if (status === 'warning') return health?.neo4j !== 'connected' ? 'Neo4j Offline' : health?.graph !== 'loaded' ? 'Graph Not Loaded' : 'LLM Not Configured';
    return 'Backend Online';
  };

  const getStatusColor = (): 'success' | 'warning' | 'error' | 'default' => {
    const status = getOverallStatus();
    if (status === 'connected') return 'success';
    if (status === 'warning') return 'warning';
    if (status === 'offline') return 'error';
    return 'default';
  };

  const drawer = (
    <div>
      <Toolbar>
        <Typography variant="h6" component="div" sx={{ fontWeight: 700, fontSize: '1rem', lineHeight: 1.25, color: '#0f766e' }}>
          {APP_TITLE}
        </Typography>
      </Toolbar>
      <List>
        {menuItems.map((item) => (
          <ListItem key={item.text} disablePadding>
            <ListItemButton
              selected={item.path === '/' ? location.pathname === '/' || location.pathname === '/dashboard' : location.pathname.startsWith(item.path)}
              onClick={() => navigate(item.path)}
            >
              <ListItemIcon>{item.icon}</ListItemIcon>
              <ListItemText primary={item.text} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </div>
  );

  return (
    <Box sx={{ display: 'flex' }}>
      <CssBaseline />
      <AppBar
        position="fixed"
        sx={{
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          ml: { sm: `${drawerWidth}px` },
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: 'none' } }}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" noWrap component="div" sx={{ flexGrow: 1 }}>
            {APP_TITLE}
            <Typography component="span" variant="caption" sx={{ ml: 1.5, opacity: 0.8 }}>
              synthetic demo data
            </Typography>
          </Typography>
          <Box display="flex" alignItems="center" gap={2}>
            <Tooltip title={getOverallStatus() === 'connected' ? 'All systems operational' : 'Some services may have issues'}>
              <Chip
                label={getStatusText()}
                color={getStatusColor()}
                size="small"
                variant="outlined"
              />
            </Tooltip>
          </Box>
        </Toolbar>
      </AppBar>
      <Box
        component="nav"
        sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
        aria-label="navigation"
      >
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true,
          }}
          sx={{
            display: { xs: 'block', sm: 'none' },
            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
          }}
        >
          {drawer}
        </Drawer>
        <Drawer
          variant="permanent"
          sx={{
            display: { xs: 'none', sm: 'block' },
            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
          }}
          open
        >
          {drawer}
        </Drawer>
      </Box>
      <Box
        component="main"
        sx={{ flexGrow: 1, p: 3, width: { sm: `calc(100% - ${drawerWidth}px)` } }}
      >
        <Toolbar />
        {children}
      </Box>
    </Box>
  );
};

export default Layout;