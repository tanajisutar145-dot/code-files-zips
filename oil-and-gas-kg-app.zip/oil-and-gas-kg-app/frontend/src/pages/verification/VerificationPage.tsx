/**
 * Answer Review: the human verification queue. Answers with a low grounding score are queued
 * automatically by /api/intelligence/ask; users can flag any answer from the Intelligence page.
 */

import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
  Typography,
} from '@mui/material';
import { FactCheck as ReviewIcon } from '@mui/icons-material';
import { useApi } from '../../hooks/useApi';
import { errorMessage, verificationApi } from '../../services/api';
import { VerificationItem } from '../../types/api';
import { getStatusColorInfo } from '../graph/utils/relationshipUtils';

const VerificationPage: React.FC = () => {
  const [status, setStatus] = useState<'pending' | 'all'>('pending');
  const [comments, setComments] = useState<Record<string, string>>({});
  const [actionError, setActionError] = useState<string | null>(null);
  const items = useApi(() => verificationApi.items(), []);
  const stats = useApi(() => verificationApi.stats(), []);

  const review = async (item: VerificationItem, decision: 'approved' | 'rejected') => {
    setActionError(null);
    try {
      await verificationApi.review(item.id, decision, comments[item.id]);
      items.refresh();
      stats.refresh();
    } catch (err) {
      setActionError(errorMessage(err, 'Review failed'));
    }
  };

  const shown = (items.data || []).filter((i) => status === 'all' || i.status === 'pending').slice().reverse();

  return (
    <Box sx={{ width: '100%', maxWidth: 1200, mx: 'auto', pb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 2, mb: 2, flexWrap: 'wrap' }}>
        <Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.25 }}>
            <ReviewIcon sx={{ color: '#0f766e', fontSize: 28 }} />
            <Typography variant="h5" component="h1" sx={{ fontWeight: 700, color: '#0f172a' }}>
              Answer Review
            </Typography>
          </Box>
          <Typography variant="body2" sx={{ color: '#64748b', mt: 0.5 }}>
            Human review queue for GraphRAG answers: low grounding scores are queued automatically, users can flag any answer.
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
          {stats.data && (
            <>
              <Chip size="small" label={`pending ${stats.data.pending ?? 0}`} />
              <Chip size="small" label={`approved ${stats.data.approved ?? 0}`} sx={{ bgcolor: '#ecfdf5', color: '#047857' }} />
              <Chip size="small" label={`rejected ${stats.data.rejected ?? 0}`} sx={{ bgcolor: '#fef2f2', color: '#b91c1c' }} />
            </>
          )}
          <ToggleButtonGroup size="small" exclusive value={status} onChange={(_, v) => v && setStatus(v)}>
            <ToggleButton value="pending" sx={{ textTransform: 'none' }}>
              Pending
            </ToggleButton>
            <ToggleButton value="all" sx={{ textTransform: 'none' }}>
              All
            </ToggleButton>
          </ToggleButtonGroup>
        </Box>
      </Box>

      {items.error && <Alert severity="error" sx={{ mb: 2 }}>{items.error}</Alert>}
      {actionError && <Alert severity="error" sx={{ mb: 2 }}>{actionError}</Alert>}
      {!items.loading && shown.length === 0 && (
        <Alert severity="info">No {status === 'pending' ? 'pending ' : ''}answers to review.</Alert>
      )}

      {shown.map((item) => {
        const colors = getStatusColorInfo(item.status);
        return (
          <Card key={item.id} elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: 2, mb: 2 }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: 1, flexWrap: 'wrap', mb: 1 }}>
                <Box sx={{ display: 'flex', gap: 0.75, flexWrap: 'wrap', alignItems: 'center' }}>
                  <Chip size="small" label={item.status} sx={{ bgcolor: colors.bg, color: colors.text, fontWeight: 700 }} />
                  <Chip size="small" variant="outlined" label={`grounding ${Math.round((item.confidence || 0) * 100)}%`} />
                  {item.retriever && <Chip size="small" variant="outlined" label={item.retriever} />}
                  {item.reason && <Chip size="small" variant="outlined" label={item.reason} />}
                </Box>
                <Typography variant="caption" sx={{ color: '#94a3b8' }}>
                  {new Date(item.created_at).toLocaleString()}
                  {item.job_id ? ` · job ${item.job_id}` : ''}
                </Typography>
              </Box>
              {item.question && (
                <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#0f172a', mb: 0.5 }}>
                  {item.question}
                </Typography>
              )}
              <Box sx={{ fontSize: '0.875rem', color: '#1e293b', '& p': { my: 0.75 } }}>
                <ReactMarkdown>{item.content}</ReactMarkdown>
              </Box>
              {item.status === 'pending' ? (
                <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', mt: 1.5, flexWrap: 'wrap' }}>
                  <TextField
                    size="small"
                    placeholder="Reviewer comment (optional)"
                    value={comments[item.id] || ''}
                    onChange={(e) => setComments((c) => ({ ...c, [item.id]: e.target.value }))}
                    sx={{ flex: 1, minWidth: 240 }}
                  />
                  <Button variant="contained" color="success" size="small" onClick={() => review(item, 'approved')} sx={{ textTransform: 'none' }}>
                    Approve
                  </Button>
                  <Button variant="outlined" color="error" size="small" onClick={() => review(item, 'rejected')} sx={{ textTransform: 'none' }}>
                    Reject
                  </Button>
                </Box>
              ) : (
                <Typography variant="caption" sx={{ color: '#64748b', display: 'block', mt: 1 }}>
                  Reviewed by {item.reviewer || 'reviewer'} {item.reviewed_at ? `on ${new Date(item.reviewed_at).toLocaleString()}` : ''}
                  {item.comment ? ` · "${item.comment}"` : ''}
                </Typography>
              )}
            </CardContent>
          </Card>
        );
      })}
    </Box>
  );
};

export default VerificationPage;
