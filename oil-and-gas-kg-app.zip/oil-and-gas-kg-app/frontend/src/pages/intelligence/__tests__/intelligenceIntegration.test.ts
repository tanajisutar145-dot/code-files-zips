import { askGraphRAG, submitQuestionJob, getQuestionJob, getQuestionJobResponse, api } from '../../../services/api';
import { GraphRAGRequest, GraphRAGResponse, JobState } from '../../../types/api';

describe('GraphRAG API and job integration', () => {
  beforeEach(() => {
    jest.restoreAllMocks();
  });

  // Facts of demo question Q13 (synthetic data)
  const mockResponse: GraphRAGResponse = {
    question: 'Trace custody transfer CT-2026-0815 back to the wells, allocations, meters and measurement points behind it, and check the allocated volume against the ticket.',
    answer: 'CT-2026-0815 is fed by eight Falcon Draw wells through FD-LACT-01 and FD-LACT-02; 115,108 bbl allocated vs 115,568 bbl GOV.',
    confidence: 'high',
    verification: {
      verified: true,
      grounding_score: 0.92,
      supported_claims: ['CT-2026-0815', 'FD-LACT-01'],
      unsupported_claims: [],
      warnings: [],
      evidence_gaps: [],
    },
    evidence: {
      semantic_results: [],
      graph_evidence: { entities: [], relationships: [] },
      evidence_graph: { nodes: [], edges: [] },
    },
    sources: { documents: [], entities: ['CT-2026-0815'] },
    metadata: { execution_time: 18.4, retrieval_method: 'text2cypher', llm_model: 'ollama/qwen2.5:7b', question_id: 'Q13' },
    retriever: 'text2cypher',
    runs: [],
    trace: [],
    job_id: 'job42',
  };

  it('sends the GraphRAG request to POST /api/intelligence/ask', async () => {
    const postSpy = jest.spyOn(api, 'post').mockResolvedValueOnce({ data: mockResponse });
    const request: GraphRAGRequest = { question: mockResponse.question, mode: 'text2cypher', include_verification: true };
    const response = await askGraphRAG(request);
    expect(postSpy).toHaveBeenCalledWith('/api/intelligence/ask', request);
    expect(response.retriever).toBe('text2cypher');
    expect(response.answer).toContain('FD-LACT-01');
    expect(response.verification.grounding_score).toBe(0.92);
  });

  it('submits a job with mode and conversation history', async () => {
    const postSpy = jest.spyOn(api, 'post').mockResolvedValueOnce({ data: { job_id: 'job42' } });
    const started = await submitQuestionJob({
      question: 'And which meters were past their calibration date?',
      mode: 'auto',
      history: [
        { role: 'user', content: mockResponse.question },
        { role: 'assistant', content: mockResponse.answer },
      ],
    });
    expect(started.job_id).toBe('job42');
    expect(postSpy).toHaveBeenCalledWith('/api/intelligence/jobs', expect.objectContaining({ mode: 'auto' }));
    const payload = postSpy.mock.calls[0][1] as GraphRAGRequest;
    expect(payload.history).toHaveLength(2);
  });

  it('returns an immediate reply for small talk', async () => {
    jest.spyOn(api, 'post').mockResolvedValueOnce({ data: { reply: 'Hi! I answer questions from the knowledge graph.' } });
    const started = await submitQuestionJob({ question: 'hello' });
    expect(started.reply).toContain('knowledge graph');
    expect(started.job_id).toBeUndefined();
  });

  it('polls the job state and fetches the verified response', async () => {
    const job: JobState = {
      id: 'job42',
      question: mockResponse.question,
      mode: 'auto',
      status: 'done',
      steps: [],
      answer: mockResponse.answer,
      retriever: 'text2cypher',
      runs: [],
      graph: { nodes: [], edges: [] },
      started: 0,
      finished: 18.4,
      elapsed: 18.4,
    };
    const getSpy = jest
      .spyOn(api, 'get')
      .mockResolvedValueOnce({ data: job })
      .mockResolvedValueOnce({ data: mockResponse });
    const state = await getQuestionJob('job42');
    expect(state.status).toBe('done');
    const response = await getQuestionJobResponse('job42');
    expect(response.metadata.question_id).toBe('Q13');
    expect(getSpy).toHaveBeenNthCalledWith(1, '/api/intelligence/jobs/job42', { params: undefined });
    expect(getSpy).toHaveBeenNthCalledWith(2, '/api/intelligence/jobs/job42/response', { params: undefined });
  });

  it('propagates backend errors without fabricating answers', async () => {
    jest.spyOn(api, 'post').mockRejectedValueOnce(new Error('LLM service unavailable'));
    await expect(submitQuestionJob({ question: 'What caused the failure?' })).rejects.toThrow('LLM service unavailable');
  });
});
