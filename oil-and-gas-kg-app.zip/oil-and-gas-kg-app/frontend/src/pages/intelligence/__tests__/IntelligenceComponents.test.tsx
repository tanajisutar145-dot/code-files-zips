import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { MemoryRouter } from 'react-router-dom';
import { IntelligenceHeader } from '../components/IntelligenceHeader';
import { SuggestedQuestions, FALLBACK_QUESTIONS } from '../components/SuggestedQuestions';
import { QuestionComposer, DEFAULT_CONFIG } from '../components/QuestionComposer';
import { AnswerMessageCard } from '../components/AnswerMessageCard';
import { EvidenceInspector } from '../components/EvidenceInspector';
import { DocumentEvidenceCard } from '../components/DocumentEvidenceCard';
import { GraphEntityCard } from '../components/GraphEntityCard';
import { TraceView } from '../components/TraceView';
import { GraphRAGResponse, ChatMessage, JobState, TraceStep } from '../../../types/api';

// Facts of demo question Q7 (backend/user_questions/questions.yaml), synthetic data
const steps: TraceStep[] = [
  { key: 'route', title: '1. Routing', status: 'done', seconds: 0.01, summary: 'Text2Cypher', detail: { retriever: 'text2cypher', question_id: 'Q7' } },
  { key: 'retrieve', title: '2. Retrieval', status: 'done', seconds: 2.1, summary: 'Text2Cypher · 4 item(s) · 2.1s', detail: {} },
  { key: 'context', title: '3. Context sent to the LLM', status: 'done', summary: '4 item(s)', detail: {} },
  { key: 'generate', title: '4. Answer generation', status: 'done', seconds: 12.4, summary: 'ollama/qwen2.5:7b · 12.4s', detail: {} },
  { key: 'graph', title: '5. Evidence graph', status: 'done', summary: '9 nodes, 8 relationships', detail: {} },
  { key: 'verify', title: '6. Verification', status: 'done', summary: '5/5 expected facts found', detail: { matched: ['FD1-K-201'] } },
];

const mockResponse: GraphRAGResponse = {
  question: 'Which equipment failures were preceded by an inspection finding?',
  answer: 'Compressor **FD1-K-201** failed 29 days after inspection INS-2025-0001 found 38% wall loss (FR-2025-0001, USD 27,500).',
  confidence: 'medium',
  verification: {
    verified: true,
    grounding_score: 0.85,
    supported_claims: ['FD1-K-201', 'INS-2025-0001'],
    unsupported_claims: [],
    warnings: [],
    evidence_gaps: [],
  },
  evidence: {
    semantic_results: [
      {
        chunk_id: 'job#0',
        document_id: 'InspectionEvent INS-2025-0001',
        document_title: 'Inspection report INS-2025-0001: compressor FD1-K-201',
        text: 'SOURCE ROW: InspectionEvent INS-2025-0001 ... 38% wall loss at the discharge elbow.',
        score: 0.885,
        source: 'OGX Energy (synthetic) - Asset Integrity',
        metadata: { document_type: 'inspection_report' },
      },
    ],
    graph_evidence: {
      entities: [
        {
          entity_id: '4:abc:1',
          entity_type: 'Equipment',
          properties: { caption: 'FD1-K-201', equipment_type: 'compressor', criticality_ranking: 'critical', evidence: true },
        },
      ],
      relationships: [],
    },
    evidence_graph: { nodes: [], edges: [] },
  },
  sources: { documents: [], entities: ['FD1-K-201'] },
  metadata: {
    execution_time: 15.2,
    retrieval_method: 'text2cypher',
    llm_model: 'ollama/qwen2.5:7b',
    question_id: 'Q7',
    ground_truth: { score: 0.8, matched: ['FD1-K-201', 'INS-2025-0001'], missing: ['FD-07'], expected_answer: 'Four failures ...' },
  },
  retriever: 'text2cypher',
  runs: [],
  trace: steps,
  job_id: 'abc123',
};

const mockMessage: ChatMessage = {
  id: 'msg-1',
  timestamp: '2026-10-12T08:00:00Z',
  question: 'Which equipment failures were preceded by an inspection finding?',
  response: mockResponse,
};

const runningJob: JobState = {
  id: 'abc123',
  question: mockMessage.question,
  mode: 'auto',
  status: 'running',
  steps: steps.map((s, i) => (i < 2 ? s : { ...s, status: i === 2 ? 'running' : 'pending' })),
  answer: '',
  retriever: '',
  runs: [],
  graph: { nodes: [], edges: [] },
  started: 0,
  elapsed: 3.2,
};

describe('Intelligence Subcomponents Rendering', () => {
  it('renders IntelligenceHeader with title and status badge', () => {
    const html = renderToStaticMarkup(<IntelligenceHeader isBackendHealthy={true} messageCount={2} onClearConversation={jest.fn()} />);
    expect(html).toContain('GraphRAG Intelligence');
    expect(html).toContain('GraphRAG Active');
    expect(html).toContain('New Conversation');
  });

  it('renders SuggestedQuestions with the demo questions', () => {
    const html = renderToStaticMarkup(<SuggestedQuestions onSelectQuestion={jest.fn()} isLoading={false} />);
    expect(html).toContain('Trace custody transfer CT-2026-0815');
    expect(html).toContain('fact check');
    expect(FALLBACK_QUESTIONS.length).toBeGreaterThan(3);
  });

  it('renders QuestionComposer with input, retriever options and submit button', () => {
    const html = renderToStaticMarkup(
      <QuestionComposer
        question="Which kicks were taken at the Wolfcamp B transition?"
        onQuestionChange={jest.fn()}
        config={DEFAULT_CONFIG}
        onConfigChange={jest.fn()}
        onSubmit={jest.fn()}
        isLoading={false}
      />
    );
    expect(html).toContain('Question');
    expect(html).toContain('Ask');
    expect(html).toContain('Retriever Options');
    expect(html).toContain('Auto (route + fallback)');
  });

  it('renders AnswerMessageCard with answer, retriever, fact check and confidence badges', () => {
    const html = renderToStaticMarkup(
      <AnswerMessageCard message={mockMessage} isSelected={true} onSelectMessage={jest.fn()} onRetry={jest.fn()} onFlag={jest.fn()} />
    );
    expect(html).toContain('Which equipment failures were preceded by an inspection finding?');
    expect(html).toContain('FD1-K-201');
    expect(html).toContain('Medium Confidence');
    expect(html).toContain('Text2Cypher');
    expect(html).toContain('Fact check 80%');
    expect(html).toContain('85%');
    expect(html).toContain('ollama/qwen2.5:7b');
  });

  it('renders the live trace while a job is running', () => {
    const html = renderToStaticMarkup(
      <AnswerMessageCard
        message={{ ...mockMessage, response: undefined, isLoading: true, job: runningJob }}
        isSelected={true}
        onSelectMessage={jest.fn()}
        onRetry={jest.fn()}
      />
    );
    expect(html).toContain('Answering...');
    expect(html).toContain('1. Routing');
    expect(html).toContain('3. Context sent to the LLM');
  });

  it('renders a conversational reply without graph lookup', () => {
    const html = renderToStaticMarkup(
      <AnswerMessageCard
        message={{ id: 'm2', timestamp: '2026-10-12T08:00:00Z', question: 'hello', reply: 'Hi! I answer questions from the knowledge graph.' }}
        isSelected={false}
        onSelectMessage={jest.fn()}
        onRetry={jest.fn()}
      />
    );
    expect(html).toContain('Hi! I answer questions from the knowledge graph.');
  });

  it('renders EvidenceInspector with grounding and fact-check chips', () => {
    const html = renderToStaticMarkup(
      <MemoryRouter>
        <EvidenceInspector response={mockResponse} questionText={mockResponse.question} />
      </MemoryRouter>
    );
    expect(html).toContain('Evidence Inspector');
    expect(html).toContain('85% grounded');
    expect(html).toContain('Fact check 80%');
    expect(html).toContain('How it was checked');
  });

  it('renders TraceView steps', () => {
    const html = renderToStaticMarkup(<TraceView steps={steps} />);
    expect(html).toContain('6. Verification');
    expect(html).toContain('5/5 expected facts found');
  });

  it('renders DocumentEvidenceCard with metadata and match percentage', () => {
    const html = renderToStaticMarkup(<DocumentEvidenceCard chunk={mockResponse.evidence.semantic_results[0]} index={0} />);
    expect(html).toContain('InspectionEvent INS-2025-0001');
    expect(html).toContain('89% Match');
  });

  it('renders GraphEntityCard with entity type and caption', () => {
    const html = renderToStaticMarkup(
      <MemoryRouter>
        <GraphEntityCard entity={mockResponse.evidence.graph_evidence.entities[0]} />
      </MemoryRouter>
    );
    expect(html).toContain('Equipment');
    expect(html).toContain('FD1-K-201');
    expect(html).toContain('View in Graph');
  });
});
