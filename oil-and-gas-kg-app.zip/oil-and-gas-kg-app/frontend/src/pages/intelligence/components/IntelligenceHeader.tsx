import React from 'react';
import {
  Box,
  Typography,
  Chip,
  Button,
  Tooltip,
} from '@mui/material';
import {
  Psychology as IntelligenceIcon,
  CheckCircleOutline as ReadyIcon,
  CloudOff as OfflineIcon,
  DeleteSweep as ClearIcon,
} from '@mui/icons-material';

interface IntelligenceHeaderProps {
  isBackendHealthy: boolean | null;
  messageCount: number;
  onClearConversation: () => void;
}

export const IntelligenceHeader: React.FC<IntelligenceHeaderProps> = ({
  isBackendHealthy,
  messageCount,
  onClearConversation,
}) => {
  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: { xs: 'column', sm: 'row' },
        justifyContent: 'space-between',
        alignItems: { xs: 'flex-start', sm: 'center' },
        mb: 2.5,
        gap: 1.5,
      }}
    >
      <Box>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: 38,
              height: 38,
              borderRadius: 1.5,
              bgcolor: 'rgba(15, 118, 110, 0.1)',
              color: '#0f766e',
            }}
          >
            <IntelligenceIcon sx={{ fontSize: 24 }} />
          </Box>
          <Typography
            variant="h4"
            sx={{
              fontSize: { xs: '1.5rem', sm: '1.75rem' },
              fontWeight: 700,
              color: '#0f172a',
              letterSpacing: '-0.02em',
            }}
          >
            GraphRAG Intelligence
          </Typography>
        </Box>
        <Typography
          variant="body2"
          sx={{
            color: '#64748b',
            mt: 0.5,
            maxWidth: 720,
            fontSize: '0.875rem',
            lineHeight: 1.5,
          }}
        >
          Ask questions answered from the oil &amp; gas knowledge graph: Text2Cypher, vector and hybrid retrieval with graph
          expansion, an evidence graph for every answer, the backend trace and a fact check for the demo questions.
        </Typography>
      </Box>

      {/* Action and Readiness Indicators */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
        {/* Service Readiness */}
        {isBackendHealthy === null ? (
          <Chip
            size="small"
            label="Checking GraphRAG..."
            variant="outlined"
            sx={{ borderColor: '#cbd5e1', color: '#64748b' }}
          />
        ) : isBackendHealthy ? (
          <Tooltip title="GraphRAG engine, Neo4j knowledge graph and LLM are reachable">
            <Chip
              size="small"
              icon={<ReadyIcon sx={{ fontSize: '15px !important', color: '#0f766e !important' }} />}
              label="GraphRAG Active"
              sx={{
                bgcolor: 'rgba(15, 118, 110, 0.08)',
                color: '#0f766e',
                fontWeight: 600,
                fontSize: '0.75rem',
                border: '1px solid rgba(15, 118, 110, 0.25)',
              }}
            />
          </Tooltip>
        ) : (
          <Tooltip title="Backend API or LLM service unreachable. Verify local services.">
            <Chip
              size="small"
              icon={<OfflineIcon sx={{ fontSize: '15px !important', color: '#dc2626 !important' }} />}
              label="Service Offline"
              sx={{
                bgcolor: 'rgba(239, 68, 68, 0.08)',
                color: '#dc2626',
                fontWeight: 600,
                fontSize: '0.75rem',
                border: '1px solid rgba(239, 68, 68, 0.25)',
              }}
            />
          </Tooltip>
        )}

        {/* Clear / New Conversation Button */}
        {messageCount > 0 && (
          <Button
            size="small"
            variant="outlined"
            color="inherit"
            startIcon={<ClearIcon sx={{ fontSize: 16 }} />}
            onClick={onClearConversation}
            sx={{
              borderColor: '#cbd5e1',
              color: '#475569',
              textTransform: 'none',
              fontWeight: 600,
              fontSize: '0.8125rem',
              '&:hover': {
                borderColor: '#94a3b8',
                bgcolor: '#f8fafc',
              },
            }}
          >
            New Conversation
          </Button>
        )}
      </Box>
    </Box>
  );
};
