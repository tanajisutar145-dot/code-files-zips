/**
 * "How it was checked": the six backend steps of an answer (routing, retrieval, context, generation,
 * evidence graph, verification) with timings, generated Cypher, retrieval query, context and ground truth.
 */

import React from 'react';
import { Accordion, AccordionDetails, AccordionSummary, Box, Chip, CircularProgress, Typography } from '@mui/material';
import {
  ExpandMore as ExpandMoreIcon,
  CheckCircle as DoneIcon,
  Error as ErrorIcon,
  RadioButtonUnchecked as PendingIcon,
  SkipNext as SkippedIcon,
} from '@mui/icons-material';
import { TraceStep } from '../../../types/api';
import { CypherPanel } from '../../../components/common/CypherPanel';
import { DataTable } from '../../../components/common/DataTable';
import { formatDuration } from '../utils/intelligenceUtils';

interface TraceViewProps {
  steps: TraceStep[];
  compact?: boolean;
}

const StatusIcon: React.FC<{ status: TraceStep['status'] }> = ({ status }) => {
  switch (status) {
    case 'done':
      return <DoneIcon sx={{ fontSize: 18, color: '#059669' }} />;
    case 'error':
      return <ErrorIcon sx={{ fontSize: 18, color: '#dc2626' }} />;
    case 'running':
      return <CircularProgress size={16} sx={{ color: '#0f766e' }} />;
    case 'skipped':
      return <SkippedIcon sx={{ fontSize: 18, color: '#94a3b8' }} />;
    default:
      return <PendingIcon sx={{ fontSize: 18, color: '#cbd5e1' }} />;
  }
};

const Pre: React.FC<{ text: string; maxHeight?: number }> = ({ text, maxHeight = 220 }) => (
  <Typography
    component="pre"
    sx={{
      m: 0,
      p: 1.25,
      bgcolor: '#f8fafc',
      border: '1px solid #e2e8f0',
      borderRadius: 1.5,
      fontFamily: 'Consolas, Menlo, monospace',
      fontSize: '0.7rem',
      whiteSpace: 'pre-wrap',
      wordBreak: 'break-word',
      maxHeight,
      overflow: 'auto',
    }}
  >
    {text}
  </Typography>
);

const StepDetail: React.FC<{ step: TraceStep }> = ({ step }) => {
  const d = step.detail || {};
  switch (step.key) {
    case 'route':
      return (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75 }}>
          {d.reason && <Typography variant="caption" sx={{ color: '#334155' }}>{d.reason}</Typography>}
          {d.fallback && <Typography variant="caption" sx={{ color: '#b45309' }}>{d.fallback}</Typography>}
          <Box sx={{ display: 'flex', gap: 0.75, flexWrap: 'wrap' }}>
            {d.retriever && <Chip size="small" label={`retriever: ${d.retriever}`} sx={{ height: 20, fontSize: '0.68rem' }} />}
            {d.template && <Chip size="small" label={`template: ${d.template}`} sx={{ height: 20, fontSize: '0.68rem' }} />}
            {d.question_id && <Chip size="small" color="success" label={`curated ${d.question_id}`} sx={{ height: 20, fontSize: '0.68rem' }} />}
          </Box>
        </Box>
      );
    case 'retrieve':
      return (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          {(d.runs || []).map((r: any, i: number) => (
            <Box key={i} sx={{ borderLeft: '3px solid #e2e8f0', pl: 1 }}>
              <Typography variant="caption" sx={{ fontWeight: 700 }}>
                {r.label || r.retriever} · {r.items} item(s) · {formatDuration(r.seconds)}
                {r.error ? ` · error: ${r.error}` : ''}
              </Typography>
              <CypherPanel cypher={r.cypher} title="generated Cypher" defaultOpen={i === 0 && !!r.cypher} />
              <CypherPanel cypher={r.retrieval_query} title="retrieval query (graph expansion)" />
              {r.paths && r.paths.length > 0 && <Pre text={r.paths.join('\n')} maxHeight={140} />}
            </Box>
          ))}
        </Box>
      );
    case 'context':
      return (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          {(d.runs || []).map((r: any, i: number) => (
            <Box key={i}>
              <Typography variant="caption" sx={{ fontWeight: 700 }}>
                {r.retriever}: {(r.items || []).length} item(s)
              </Typography>
              <Pre text={(r.items || []).join('\n---\n') || '(empty)'} maxHeight={260} />
            </Box>
          ))}
        </Box>
      );
    case 'generate':
      return (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75 }}>
          <Typography variant="caption">
            Model: <strong>{d.model || '—'}</strong> · history turns sent: {d.history_turns ?? 0}
          </Typography>
          {d.error && <Typography variant="caption" sx={{ color: '#dc2626' }}>{d.error}</Typography>}
          {d.system_prompt && <Pre text={d.system_prompt} maxHeight={160} />}
        </Box>
      );
    case 'graph':
      return (
        <Box>
          <Typography variant="caption">Source: {d.source || '—'}</Typography>
          <CypherPanel cypher={d.cypher} title="subgraph Cypher" />
        </Box>
      );
    case 'verify':
      return (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          {(d.checks || []).map((c: string, i: number) => (
            <Typography key={i} variant="caption" sx={{ color: '#334155' }}>
              • {c}
            </Typography>
          ))}
          {d.expected_answer && (
            <Box>
              <Typography variant="caption" sx={{ fontWeight: 700 }}>Expected answer</Typography>
              <Typography variant="caption" sx={{ display: 'block', color: '#334155' }}>{d.expected_answer}</Typography>
            </Box>
          )}
          {(d.matched || d.missing) && (
            <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
              {(d.matched || []).map((m: string) => (
                <Chip key={`m-${m}`} size="small" label={`✓ ${m}`} sx={{ height: 20, fontSize: '0.68rem', bgcolor: '#ecfdf5', color: '#047857' }} />
              ))}
              {(d.missing || []).map((m: string) => (
                <Chip key={`x-${m}`} size="small" label={`✗ ${m}`} sx={{ height: 20, fontSize: '0.68rem', bgcolor: '#fef2f2', color: '#b91c1c' }} />
              ))}
            </Box>
          )}
          <CypherPanel cypher={d.ground_truth_cypher} title="ground-truth Cypher" />
          {d.ground_truth && d.ground_truth.length > 0 && <DataTable rows={d.ground_truth} maxHeight={240} />}
        </Box>
      );
    default:
      return <Pre text={JSON.stringify(d, null, 2)} />;
  }
};

export const TraceView: React.FC<TraceViewProps> = ({ steps, compact = false }) => {
  if (!steps || steps.length === 0) {
    return (
      <Typography variant="body2" sx={{ color: '#94a3b8', textAlign: 'center', py: 3 }}>
        No trace recorded for this answer.
      </Typography>
    );
  }

  if (compact) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75 }}>
        {steps.map((s) => (
          <Box key={s.key} sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <StatusIcon status={s.status} />
            <Typography variant="caption" sx={{ fontWeight: 600, color: '#334155', minWidth: 170 }}>
              {s.title}
            </Typography>
            <Typography variant="caption" sx={{ color: '#64748b' }} noWrap>
              {s.summary}
            </Typography>
          </Box>
        ))}
      </Box>
    );
  }

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75 }}>
      {steps.map((s) => (
        <Accordion
          key={s.key}
          disableGutters
          elevation={0}
          sx={{ border: '1px solid #e2e8f0', borderRadius: '8px !important', '&:before': { display: 'none' } }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon sx={{ fontSize: 18 }} />} sx={{ minHeight: 40, '& .MuiAccordionSummary-content': { my: 0.75 } }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%', pr: 1 }}>
              <StatusIcon status={s.status} />
              <Typography variant="caption" sx={{ fontWeight: 700, color: '#0f172a', minWidth: 160 }}>
                {s.title}
              </Typography>
              <Typography variant="caption" sx={{ color: '#64748b', flex: 1 }} noWrap title={s.summary}>
                {s.summary}
              </Typography>
              {typeof s.seconds === 'number' && (
                <Typography variant="caption" sx={{ color: '#94a3b8', whiteSpace: 'nowrap' }}>
                  {formatDuration(s.seconds)}
                </Typography>
              )}
            </Box>
          </AccordionSummary>
          <AccordionDetails sx={{ pt: 0 }}>
            <StepDetail step={s} />
          </AccordionDetails>
        </Accordion>
      ))}
    </Box>
  );
};

export default TraceView;
