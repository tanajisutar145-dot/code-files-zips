import React, { useState } from 'react';
import {
  Box,
  Card,
  TextField,
  Button,
  IconButton,
  Collapse,
  Typography,
  Grid,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  FormControlLabel,
  Switch,
  Chip,
  CircularProgress,
} from '@mui/material';
import { Send as SendIcon, Tune as TuneIcon, Clear as ClearIcon, RestartAlt as ResetIcon } from '@mui/icons-material';
import { RetrieverMode } from '../../../types/api';

export interface IntelligenceConfig {
  mode: RetrieverMode;
  include_verification: boolean;
}

export const DEFAULT_CONFIG: IntelligenceConfig = { mode: 'auto', include_verification: true };

const DEFAULT_RETRIEVERS: { id: RetrieverMode; label: string }[] = [
  { id: 'auto', label: 'Auto (route + fallback)' },
  { id: 'text2cypher', label: 'Text2Cypher' },
  { id: 'vector_cypher', label: 'Vector + graph' },
  { id: 'hybrid_cypher', label: 'Hybrid + graph' },
  { id: 'compare', label: 'Compare all three' },
];

const MODE_HELP: Record<string, string> = {
  auto: 'Routes the question: exact sets, counts, traces and rankings go to Text2Cypher; narratives to vector or hybrid search with a graph expansion. Falls back when a retriever returns nothing.',
  text2cypher: 'The LLM writes one read-only Cypher query from the graph schema and examples; it is checked with EXPLAIN before running.',
  vector_cypher: 'Vector similarity over narrative chunks, then a fixed graph expansion (causal chain, well identity, lineage...).',
  hybrid_cypher: 'Vector + full-text search over narrative chunks, then the same graph expansion. Best when exact identifiers appear in the question.',
  compare: 'Runs all three retrievers and shows their answers, timings and fact-check scores side by side.',
};

interface QuestionComposerProps {
  question: string;
  onQuestionChange: (q: string) => void;
  config: IntelligenceConfig;
  onConfigChange: (newConfig: IntelligenceConfig) => void;
  onSubmit: (questionOverride?: string) => void;
  isLoading: boolean;
  retrievers?: { id: RetrieverMode; label: string }[];
  hasChunks?: boolean;
}

export const QuestionComposer: React.FC<QuestionComposerProps> = ({
  question,
  onQuestionChange,
  config,
  onConfigChange,
  onSubmit,
  isLoading,
  retrievers,
  hasChunks = true,
}) => {
  const [showConfig, setShowConfig] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);
  const options = retrievers && retrievers.length > 0 ? retrievers : DEFAULT_RETRIEVERS;

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      handleTriggerSubmit();
    }
  };

  const handleTriggerSubmit = () => {
    const trimmed = question.trim();
    if (!trimmed) {
      setValidationError('Please enter a question before submitting.');
      return;
    }
    setValidationError(null);
    onSubmit();
  };

  const isConfigModified = config.mode !== DEFAULT_CONFIG.mode || config.include_verification !== DEFAULT_CONFIG.include_verification;

  return (
    <Card
      elevation={0}
      sx={{ p: 2, bgcolor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: 2, boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)' }}
    >
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
        <TextField
          id="intelligence-question-input"
          label="Question"
          placeholder="Ask about wells, drilling events, equipment integrity, HSE incidents, custody transfers or emissions..."
          multiline
          minRows={2}
          maxRows={5}
          value={question}
          onChange={(e) => {
            onQuestionChange(e.target.value);
            if (validationError && e.target.value.trim()) {
              setValidationError(null);
            }
          }}
          onKeyDown={handleKeyDown}
          error={!!validationError}
          helperText={validationError || 'Press Ctrl+Enter to submit. The last turns are sent as conversation history.'}
          fullWidth
          disabled={isLoading}
          InputProps={{
            endAdornment: question ? (
              <IconButton
                size="small"
                onClick={() => {
                  onQuestionChange('');
                  setValidationError(null);
                }}
                disabled={isLoading}
                sx={{ alignSelf: 'flex-start', mt: 0.5, color: '#94a3b8' }}
              >
                <ClearIcon fontSize="small" />
              </IconButton>
            ) : undefined,
            sx: {
              fontSize: '0.9375rem',
              lineHeight: 1.5,
              '& .MuiOutlinedInput-notchedOutline': { borderColor: '#cbd5e1' },
              '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#0f766e' },
              '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#0f766e' },
            },
          }}
        />

        <Box
          sx={{
            display: 'flex',
            flexDirection: { xs: 'column', sm: 'row' },
            justifyContent: 'space-between',
            alignItems: { xs: 'stretch', sm: 'center' },
            gap: 1.5,
          }}
        >
          <Button
            size="small"
            startIcon={<TuneIcon sx={{ fontSize: 18 }} />}
            onClick={() => setShowConfig((prev) => !prev)}
            sx={{
              color: isConfigModified ? '#0f766e' : '#64748b',
              fontWeight: 600,
              textTransform: 'none',
              bgcolor: isConfigModified ? 'rgba(15, 118, 110, 0.08)' : 'transparent',
              alignSelf: { xs: 'flex-start', sm: 'center' },
            }}
          >
            {showConfig ? 'Hide Retriever Options' : 'Retriever Options'}
            <Chip
              label={options.find((o) => o.id === config.mode)?.label || config.mode}
              size="small"
              sx={{ ml: 1, height: 18, fontSize: '0.6875rem', bgcolor: isConfigModified ? '#0f766e' : '#e2e8f0', color: isConfigModified ? '#fff' : '#334155' }}
            />
          </Button>

          <Button
            id="intelligence-submit-btn"
            variant="contained"
            disabled={isLoading || !question.trim()}
            onClick={handleTriggerSubmit}
            startIcon={isLoading ? <CircularProgress size={18} color="inherit" /> : <SendIcon sx={{ fontSize: 18 }} />}
            sx={{
              bgcolor: '#0f766e',
              color: '#ffffff',
              fontWeight: 600,
              textTransform: 'none',
              px: 3,
              py: 1,
              borderRadius: 1.5,
              '&:hover': { bgcolor: '#115e59' },
              '&.Mui-disabled': { bgcolor: '#e2e8f0', color: '#94a3b8' },
            }}
          >
            {isLoading ? 'Answering...' : 'Ask'}
          </Button>
        </Box>

        <Collapse in={showConfig}>
          <Box sx={{ mt: 1, p: 2, bgcolor: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 1.5 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 600, color: '#334155' }}>
                GraphRAG retriever and verification
              </Typography>
              {isConfigModified && (
                <Button
                  size="small"
                  startIcon={<ResetIcon sx={{ fontSize: 16 }} />}
                  onClick={() => onConfigChange(DEFAULT_CONFIG)}
                  sx={{ color: '#64748b', textTransform: 'none', fontSize: '0.75rem' }}
                >
                  Reset Defaults
                </Button>
              )}
            </Box>

            <Grid container spacing={3}>
              <Grid item xs={12} md={7}>
                <FormControl fullWidth size="small">
                  <InputLabel id="intelligence-mode-label" sx={{ fontSize: '0.8125rem' }}>
                    Retriever
                  </InputLabel>
                  <Select
                    labelId="intelligence-mode-label"
                    value={config.mode}
                    label="Retriever"
                    onChange={(e) => onConfigChange({ ...config, mode: e.target.value as RetrieverMode })}
                    sx={{ fontSize: '0.875rem' }}
                  >
                    {options.map((o) => (
                      <MenuItem key={o.id} value={o.id} disabled={!hasChunks && (o.id === 'vector_cypher' || o.id === 'hybrid_cypher')}>
                        {o.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
                <Typography variant="caption" sx={{ color: '#64748b', display: 'block', mt: 1, lineHeight: 1.45 }}>
                  {MODE_HELP[config.mode]}
                  {!hasChunks && ' Vector and hybrid retrieval need embedded narrative chunks (load step with an embedder).'}
                </Typography>
              </Grid>

              <Grid item xs={12} md={5}>
                <FormControlLabel
                  control={
                    <Switch
                      checked={config.include_verification}
                      onChange={(e) => onConfigChange({ ...config, include_verification: e.target.checked })}
                      color="primary"
                    />
                  }
                  label={
                    <Typography variant="caption" sx={{ fontWeight: 600, color: '#334155' }}>
                      Answer verification
                    </Typography>
                  }
                />
                <Typography variant="caption" sx={{ color: '#94a3b8', fontSize: '0.7rem', display: 'block' }}>
                  Checks identifiers and figures of the answer against the retrieved context (and the ground truth of demo questions).
                </Typography>
              </Grid>
            </Grid>
          </Box>
        </Collapse>
      </Box>
    </Card>
  );
};
