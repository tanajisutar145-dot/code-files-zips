import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { Box, Card, Typography, Chip, Tabs, Tab, Alert, AlertTitle, LinearProgress } from '@mui/material';
import {
  Description as DocumentIcon,
  Hub as GraphIcon,
  Timeline as TraceIcon,
  CompareArrows as CompareIcon,
  FactCheck as VerificationIcon,
  Verified as VerifiedIcon,
  WarningAmber as WarningIcon,
} from '@mui/icons-material';
import { GraphRAGResponse, JobState } from '../../../types/api';
import { DocumentEvidenceCard } from './DocumentEvidenceCard';
import { GraphEntityCard } from './GraphEntityCard';
import { TraceView } from './TraceView';
import { EvidenceGraph } from '../../../components/common/EvidenceGraph';
import { CypherPanel } from '../../../components/common/CypherPanel';
import { DataTable } from '../../../components/common/DataTable';
import { formatDuration, formatGroundingScore, getGroundingColor } from '../utils/intelligenceUtils';

interface EvidenceInspectorProps {
  response: GraphRAGResponse | null;
  job?: JobState | null;
  questionText?: string;
}

const Empty: React.FC<{ text: string }> = ({ text }) => (
  <Typography variant="body2" sx={{ color: '#94a3b8', textAlign: 'center', py: 4 }}>
    {text}
  </Typography>
);

export const EvidenceInspector: React.FC<EvidenceInspectorProps> = ({ response, job, questionText }) => {
  const [tabIndex, setTabIndex] = useState(0);

  if (!response && !job) {
    return (
      <Card
        elevation={0}
        sx={{
          p: 4,
          bgcolor: '#ffffff',
          border: '1px dashed #cbd5e1',
          borderRadius: 2,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          minHeight: 360,
          textAlign: 'center',
          gap: 1.5,
        }}
      >
        <VerificationIcon sx={{ fontSize: 44, color: '#94a3b8' }} />
        <Typography variant="subtitle1" sx={{ fontWeight: 600, color: '#475569' }}>
          No Evidence Active
        </Typography>
        <Typography variant="body2" sx={{ color: '#64748b', maxWidth: 340 }}>
          Ask a question or select an answer to inspect its evidence graph, each backend step (with the generated Cypher),
          the retriever comparison and the verification report.
        </Typography>
      </Card>
    );
  }

  const graph = response?.evidence?.evidence_graph || job?.graph;
  const steps = response?.trace || job?.steps || [];
  const runs = response?.runs || job?.runs || [];
  const chunks = response?.evidence?.semantic_results || [];
  const entities = (response?.evidence?.graph_evidence?.entities || []).filter((e) => e.properties?.evidence);
  const verification = response?.verification;
  const groundTruth = response?.metadata?.ground_truth || job?.verification || null;
  const groundingColor = getGroundingColor(verification?.grounding_score);
  const running = !response && job && job.status !== 'done' && job.status !== 'error';

  return (
    <Card
      elevation={0}
      sx={{
        bgcolor: '#ffffff',
        border: '1px solid #e2e8f0',
        borderRadius: 2,
        display: 'flex',
        flexDirection: 'column',
        position: 'sticky',
        top: 80,
        maxHeight: 'calc(100vh - 110px)',
        overflow: 'hidden',
      }}
    >
      <Box sx={{ p: 2, pb: 1.5, borderBottom: '1px solid #f1f5f9' }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 0.5, gap: 1 }}>
          <Typography variant="subtitle1" sx={{ fontWeight: 700, color: '#0f172a' }}>
            Evidence Inspector
          </Typography>
          <Box sx={{ display: 'flex', gap: 0.75 }}>
            {groundTruth && typeof groundTruth.score === 'number' && (
              <Chip
                size="small"
                label={`Fact check ${Math.round(groundTruth.score * 100)}%`}
                sx={{
                  bgcolor: groundTruth.score >= 0.8 ? '#ecfdf5' : groundTruth.score >= 0.5 ? '#fffbeb' : '#fef2f2',
                  color: groundTruth.score >= 0.8 ? '#047857' : groundTruth.score >= 0.5 ? '#b45309' : '#b91c1c',
                  fontWeight: 700,
                  fontSize: '0.6875rem',
                  height: 22,
                }}
              />
            )}
            {verification && (
              <Chip
                size="small"
                icon={
                  verification.verified ? (
                    <VerifiedIcon sx={{ fontSize: '14px !important', color: '#059669 !important' }} />
                  ) : (
                    <WarningIcon sx={{ fontSize: '14px !important', color: '#d97706 !important' }} />
                  )
                }
                label={`${formatGroundingScore(verification.grounding_score)} grounded`}
                sx={{
                  bgcolor: groundingColor.bg,
                  color: groundingColor.text,
                  fontWeight: 700,
                  fontSize: '0.6875rem',
                  height: 22,
                  border: `1px solid ${groundingColor.bar}40`,
                }}
              />
            )}
          </Box>
        </Box>
        {questionText && (
          <Typography
            variant="caption"
            sx={{ color: '#64748b', display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}
            title={questionText}
          >
            For question: "{questionText}"
          </Typography>
        )}
        {running && <LinearProgress sx={{ mt: 1, height: 3, borderRadius: 2, '& .MuiLinearProgress-bar': { bgcolor: '#0f766e' } }} />}
      </Box>

      <Tabs
        value={tabIndex}
        onChange={(_, val) => setTabIndex(val)}
        variant="scrollable"
        scrollButtons="auto"
        sx={{
          borderBottom: '1px solid #e2e8f0',
          minHeight: 40,
          '& .MuiTab-root': {
            minHeight: 40,
            fontSize: '0.75rem',
            fontWeight: 600,
            textTransform: 'none',
            color: '#64748b',
            '&.Mui-selected': { color: '#0f766e' },
          },
          '& .MuiTabs-indicator': { bgcolor: '#0f766e' },
        }}
      >
        <Tab icon={<GraphIcon sx={{ fontSize: 16 }} />} iconPosition="start" label={`Graph (${graph?.nodes?.length || 0})`} />
        <Tab icon={<TraceIcon sx={{ fontSize: 16 }} />} iconPosition="start" label="How it was checked" />
        <Tab icon={<CompareIcon sx={{ fontSize: 16 }} />} iconPosition="start" label={`Retrievers (${runs.length})`} />
        <Tab icon={<DocumentIcon sx={{ fontSize: 16 }} />} iconPosition="start" label={`Context (${chunks.length + entities.length})`} />
        <Tab icon={<VerificationIcon sx={{ fontSize: 16 }} />} iconPosition="start" label="Audit" />
      </Tabs>

      <Box sx={{ p: 2, overflowY: 'auto', flex: 1, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
        {/* Tab 0: evidence graph */}
        {tabIndex === 0 && (
          <EvidenceGraph
            graph={graph}
            height={380}
            emptyText={running ? 'The evidence graph is built after the answer is generated.' : 'No records of the answer could be located in the graph.'}
          />
        )}

        {/* Tab 1: trace */}
        {tabIndex === 1 && <TraceView steps={steps} />}

        {/* Tab 2: retriever runs */}
        {tabIndex === 2 && (
          <>
            {runs.length === 0 ? (
              <Empty text="No retriever run finished yet." />
            ) : (
              runs.map((r, i) => (
                <Box key={`${r.retriever}-${i}`} sx={{ border: '1px solid #e2e8f0', borderRadius: 2, p: 1.5 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 1, mb: 1, flexWrap: 'wrap' }}>
                    <Box sx={{ display: 'flex', gap: 0.75, alignItems: 'center' }}>
                      <Chip
                        size="small"
                        label={r.label || r.retriever}
                        sx={{ height: 22, fontWeight: 700, bgcolor: i === 0 ? '#0f766e' : '#e2e8f0', color: i === 0 ? '#fff' : '#334155' }}
                      />
                      {i === 0 && <Typography variant="caption" sx={{ color: '#0f766e', fontWeight: 600 }}>answer shown</Typography>}
                    </Box>
                    <Typography variant="caption" sx={{ color: '#64748b' }}>
                      retrieval {formatDuration(r.retrieval_s)} · generation {formatDuration(r.generation_s)} · {r.context?.length || 0} item(s)
                      {typeof r.score === 'number' ? ` · facts ${Math.round(r.score * 100)}%` : ''}
                    </Typography>
                  </Box>
                  {r.error ? (
                    <Alert severity="error" sx={{ py: 0 }}>
                      {r.error}
                    </Alert>
                  ) : (
                    <Box sx={{ fontSize: '0.8rem', color: '#1e293b', '& p': { my: 0.5 } }}>
                      <ReactMarkdown>{r.answer || '(no answer)'}</ReactMarkdown>
                    </Box>
                  )}
                  {r.missing && r.missing.length > 0 && (
                    <Typography variant="caption" sx={{ color: '#b91c1c', display: 'block' }}>
                      Missing expected facts: {r.missing.join(', ')}
                    </Typography>
                  )}
                  <CypherPanel cypher={r.cypher} title="generated Cypher" />
                  <CypherPanel cypher={r.retrieval_query} title="retrieval query" />
                </Box>
              ))
            )}
          </>
        )}

        {/* Tab 3: context items */}
        {tabIndex === 3 && (
          <>
            {chunks.length === 0 && entities.length === 0 && <Empty text="No context items for this answer." />}
            {chunks.map((chunk, i) => (
              <DocumentEvidenceCard key={chunk.chunk_id || i} chunk={chunk} index={i} />
            ))}
            {entities.length > 0 && (
              <Typography variant="caption" sx={{ fontWeight: 700, color: '#475569', mt: 1 }}>
                Records quoted in the answer ({entities.length})
              </Typography>
            )}
            {entities.map((entity) => (
              <GraphEntityCard key={entity.entity_id} entity={entity} />
            ))}
          </>
        )}

        {/* Tab 4: verification audit */}
        {tabIndex === 4 && (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {groundTruth && (groundTruth.expected_answer || groundTruth.ground_truth) && (
              <Box sx={{ border: '1px solid #e2e8f0', borderRadius: 2, p: 1.5 }}>
                <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#0f172a', mb: 0.5 }}>
                  Ground truth (deterministic Cypher, no LLM)
                </Typography>
                {groundTruth.expected_answer && (
                  <Typography variant="caption" sx={{ color: '#334155', display: 'block', mb: 1 }}>
                    {groundTruth.expected_answer}
                  </Typography>
                )}
                <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mb: 1 }}>
                  {(groundTruth.matched || []).map((m) => (
                    <Chip key={`m-${m}`} size="small" label={`✓ ${m}`} sx={{ height: 20, fontSize: '0.68rem', bgcolor: '#ecfdf5', color: '#047857' }} />
                  ))}
                  {(groundTruth.missing || []).map((m) => (
                    <Chip key={`x-${m}`} size="small" label={`✗ ${m}`} sx={{ height: 20, fontSize: '0.68rem', bgcolor: '#fef2f2', color: '#b91c1c' }} />
                  ))}
                </Box>
                {groundTruth.ground_truth && <DataTable rows={groundTruth.ground_truth} maxHeight={240} />}
                <CypherPanel cypher={groundTruth.ground_truth_cypher} title="ground-truth Cypher" />
              </Box>
            )}

            {verification ? (
              <>
                <Alert severity={verification.verified ? 'success' : 'warning'} sx={{ borderRadius: 1.5 }}>
                  <AlertTitle sx={{ fontWeight: 700, fontSize: '0.875rem' }}>
                    {verification.verified ? 'Answer grounded in the retrieved evidence' : 'Answer contains claims not found in the evidence'}
                  </AlertTitle>
                  Grounding score: {formatGroundingScore(verification.grounding_score)}. Record identifiers, API numbers and figures of the
                  answer were looked up in the retrieved context.
                </Alert>
                {[
                  { title: 'Supported claims', items: verification.supported_claims, color: '#059669' },
                  { title: 'Unsupported claims', items: verification.unsupported_claims, color: '#dc2626' },
                  { title: 'Warnings', items: verification.warnings, color: '#d97706' },
                  { title: 'Evidence gaps', items: verification.evidence_gaps, color: '#64748b' },
                ]
                  .filter((g) => g.items && g.items.length > 0)
                  .map((g) => (
                    <Box key={g.title}>
                      <Typography variant="subtitle2" sx={{ fontWeight: 700, color: g.color, mb: 0.75, fontSize: '0.8125rem' }}>
                        {g.title} ({g.items.length})
                      </Typography>
                      <Box sx={{ pl: 2 }}>
                        {g.items.map((claim, idx) => (
                          <Typography key={idx} variant="caption" sx={{ display: 'block', color: '#334155', mb: 0.5 }}>
                            • {claim}
                          </Typography>
                        ))}
                      </Box>
                    </Box>
                  ))}
              </>
            ) : (
              <Empty text={running ? 'Verification runs when the answer is ready.' : 'Verification was not enabled for this question.'} />
            )}
          </Box>
        )}
      </Box>
    </Card>
  );
};
