import React, { useMemo, useState } from 'react';
import { Box, Card, Typography, Grid, Chip, ToggleButton, ToggleButtonGroup } from '@mui/material';
import { HelpOutline as HelpIcon, ArrowForward as ArrowIcon } from '@mui/icons-material';
import { QuestionBrief } from '../../../types/api';

interface SuggestedQuestionsProps {
  onSelectQuestion: (question: string) => void;
  isLoading: boolean;
  questions?: QuestionBrief[];
}

const UC_COLORS: Record<string, string> = {
  UC1: '#1F77B4',
  UC2: '#E45756',
  UC3: '#B279A2',
  UC4: '#F58518',
  UC5: '#54A24B',
};

const RETRIEVER_LABELS: Record<string, string> = {
  text2cypher: 'Text2Cypher',
  vector_cypher: 'Vector + graph',
  hybrid_cypher: 'Hybrid + graph',
};

// Used until /api/intelligence/info answers (and when the QA engine is unavailable)
export const FALLBACK_QUESTIONS: QuestionBrief[] = [
  {
    id: 'Q3',
    kind: 'demo',
    title: 'Well identity conflicts',
    use_case: 'UC1 Well & subsurface 360 / well identity',
    retriever: 'text2cypher',
    pattern: '',
    question:
      'Which production well records have an API number that does not match the drilling register for the same well name, and which production wells have no record in the asset register?',
  },
  {
    id: 'Q6',
    kind: 'demo',
    title: 'Consequences of a kick',
    use_case: 'UC2 Drilling performance & lessons learned',
    retriever: 'hybrid_cypher',
    pattern: '',
    question:
      'What happened after the kick on Red Mesa 12-2H? Trace the well control event to the HSE incident, regulatory violation, process safety event, NPT, flaring and production downtime it caused.',
  },
  {
    id: 'Q7',
    kind: 'demo',
    title: 'Failures preceded by an inspection finding',
    use_case: 'UC3 Asset integrity & reliability',
    retriever: 'text2cypher',
    pattern: '',
    question:
      'Which equipment failures were preceded by an inspection finding, how many days after the inspection did they fail, and what did they cost in repairs and deferred production?',
  },
  {
    id: 'Q10',
    kind: 'demo',
    title: 'Story of the Tier 1 process safety event',
    use_case: 'UC4 HSE & process-safety incident intelligence',
    retriever: 'hybrid_cypher',
    pattern: '',
    question:
      'Give the full story of the Tier 1 process safety event: equipment and facility, the permit to work, the investigation root cause, the corrective actions and their effectiveness, the spill and the regulatory violation.',
  },
  {
    id: 'Q13',
    kind: 'demo',
    title: 'Custody transfer lineage',
    use_case: 'UC5 Production-to-market & emissions traceability',
    retriever: 'text2cypher',
    pattern: '',
    question:
      'Trace custody transfer CT-2026-0815 back to the wells, allocations, meters and measurement points behind it, and check the allocated volume against the ticket.',
  },
  {
    id: 'Q15',
    kind: 'demo',
    title: 'Allocation variances and meter calibration',
    use_case: 'UC5 Production-to-market & emissions traceability',
    retriever: 'text2cypher',
    pattern: '',
    question:
      'Which production allocations have an oil variance above 150 bbl, at which meters, and are those meters past their calibration due date?',
  },
];

const ucOf = (useCase: string) => (useCase || '').split(' ')[0];

export const SuggestedQuestions: React.FC<SuggestedQuestionsProps> = ({ onSelectQuestion, isLoading, questions }) => {
  const all = questions && questions.length > 0 ? questions : FALLBACK_QUESTIONS;
  const useCases = useMemo(() => Array.from(new Set(all.map((q) => ucOf(q.use_case)).filter(Boolean))).sort(), [all]);
  const [filter, setFilter] = useState<string>('all');
  const shown = filter === 'all' ? all : all.filter((q) => ucOf(q.use_case) === filter);

  return (
    <Box sx={{ mb: 3 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 1, mb: 1.5, flexWrap: 'wrap' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <HelpIcon sx={{ fontSize: 18, color: '#0f766e' }} />
          <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#334155' }}>
            Demo questions with a ground-truth fact check, and sample questions
          </Typography>
        </Box>
        <ToggleButtonGroup size="small" value={filter} exclusive onChange={(_, v) => v && setFilter(v)}>
          <ToggleButton value="all" sx={{ textTransform: 'none', py: 0.25, px: 1, fontSize: '0.72rem' }}>
            All
          </ToggleButton>
          {useCases.map((uc) => (
            <ToggleButton key={uc} value={uc} sx={{ textTransform: 'none', py: 0.25, px: 1, fontSize: '0.72rem' }}>
              {uc}
            </ToggleButton>
          ))}
        </ToggleButtonGroup>
      </Box>

      <Grid container spacing={2}>
        {shown.map((item) => {
          const uc = ucOf(item.use_case);
          const color = UC_COLORS[uc] || '#0f766e';
          return (
            <Grid item xs={12} sm={6} md={4} key={`${item.kind}-${item.id}`}>
              <Card
                elevation={0}
                onClick={() => !isLoading && onSelectQuestion(item.question)}
                sx={{
                  p: 2,
                  height: '100%',
                  bgcolor: '#ffffff',
                  border: '1px solid #e2e8f0',
                  borderLeft: `4px solid ${color}`,
                  borderRadius: 2,
                  cursor: isLoading ? 'default' : 'pointer',
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'space-between',
                  transition: 'all 0.2s ease-in-out',
                  '&:hover': {
                    borderColor: isLoading ? '#e2e8f0' : color,
                    boxShadow: isLoading ? 'none' : '0 4px 12px rgba(15, 118, 110, 0.08)',
                    transform: isLoading ? 'none' : 'translateY(-2px)',
                  },
                }}
              >
                <Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, mb: 1, flexWrap: 'wrap' }}>
                    <Chip size="small" label={`${item.id} · ${uc}`} sx={{ height: 20, fontSize: '0.6875rem', fontWeight: 700, bgcolor: color, color: '#fff' }} />
                    {item.retriever && (
                      <Chip
                        size="small"
                        variant="outlined"
                        label={RETRIEVER_LABELS[item.retriever] || item.retriever}
                        sx={{ height: 20, fontSize: '0.6875rem' }}
                      />
                    )}
                    {item.kind === 'demo' && (
                      <Chip size="small" label="fact check" sx={{ height: 20, fontSize: '0.6875rem', bgcolor: '#ecfdf5', color: '#047857' }} />
                    )}
                  </Box>
                  <Typography variant="caption" sx={{ fontWeight: 700, color: '#475569', display: 'block', mb: 0.5 }}>
                    {item.title}
                  </Typography>
                  <Typography variant="body2" sx={{ fontWeight: 500, color: '#0f172a', fontSize: '0.84rem', lineHeight: 1.45 }}>
                    "{item.question}"
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, color, fontWeight: 600, fontSize: '0.75rem', mt: 1.5 }}>
                  Ask GraphRAG <ArrowIcon sx={{ fontSize: 14 }} />
                </Box>
              </Card>
            </Grid>
          );
        })}
      </Grid>
    </Box>
  );
};
