import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  Chip,
  Button,
} from '@mui/material';
import {
  OpenInNew as OpenInNewIcon,
} from '@mui/icons-material';
import { GraphEntity } from '../../../types/api';
import { getNodeColor } from '../../graph/utils/graphStyles';

interface GraphEntityCardProps {
  entity: GraphEntity;
}

export const GraphEntityCard: React.FC<GraphEntityCardProps> = ({ entity }) => {
  const navigate = useNavigate();
  const color = getNodeColor(entity.entity_type);
  const name = entity.properties?.caption || entity.properties?.name || entity.properties?.tag || entity.entity_id;

  return (
    <Box
      sx={{
        p: 1.75,
        bgcolor: '#ffffff',
        border: '1px solid #e2e8f0',
        borderRadius: 2,
        borderLeft: `4px solid ${color.bg}`,
        display: 'flex',
        flexDirection: 'column',
        gap: 1,
      }}
    >
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Chip
            size="small"
            label={entity.entity_type}
            sx={{
              bgcolor: color.bg,
              color: color.text,
              fontWeight: 700,
              fontSize: '0.6875rem',
              height: 20,
            }}
          />
          <Typography variant="caption" sx={{ fontWeight: 700, color: '#0f172a' }}>
            {entity.entity_id}
          </Typography>
        </Box>

        <Button
          size="small"
          endIcon={<OpenInNewIcon sx={{ fontSize: 13 }} />}
          onClick={() => navigate(`/graph?node_label=${encodeURIComponent(entity.entity_type)}&query=${encodeURIComponent(String(name))}`)}
          sx={{
            p: 0,
            minWidth: 'auto',
            color: '#0f766e',
            fontSize: '0.6875rem',
            fontWeight: 600,
            textTransform: 'none',
          }}
        >
          View in Graph
        </Button>
      </Box>

      <Typography variant="body2" sx={{ fontWeight: 600, color: '#1e293b', fontSize: '0.875rem' }}>
        {name}
      </Typography>

      {/* Properties badges */}
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.75 }}>
        {Object.entries(entity.properties || {})
          .filter(
            ([k]) =>
              ![
                'caption',
                'name',
                'std',
                'evidence',
                'embedding',
                'source_table',
                'subject_area',
              ].includes(k) && !k.startsWith('std_') && !k.endsWith('_id')
          )
          .slice(0, 5)
          .map(([k, v]) => (
            <Chip
              key={k}
              size="small"
              label={`${k}: ${typeof v === 'object' ? JSON.stringify(v) : String(v)}`}
              variant="outlined"
              sx={{
                height: 20,
                fontSize: '0.6875rem',
                color: '#475569',
                borderColor: '#e2e8f0',
                maxWidth: 240,
                overflow: 'hidden',
              }}
            />
          ))}
      </Box>
    </Box>
  );
};
