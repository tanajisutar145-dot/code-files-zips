import React, { useRef, useEffect } from 'react';
import { Box } from '@mui/material';
import { ChatMessage, QuestionBrief } from '../../../types/api';
import { AnswerMessageCard } from './AnswerMessageCard';
import { SuggestedQuestions } from './SuggestedQuestions';

interface ConversationThreadProps {
  messages: ChatMessage[];
  selectedMessageId: string | null;
  onSelectMessage: (id: string) => void;
  onSelectQuestionSuggestion: (question: string) => void;
  onRetry: (question: string) => void;
  onFlag?: (message: ChatMessage) => void;
  isLoading: boolean;
  questions?: QuestionBrief[];
}

export const ConversationThread: React.FC<ConversationThreadProps> = ({
  messages,
  selectedMessageId,
  onSelectMessage,
  onSelectQuestionSuggestion,
  onRetry,
  onFlag,
  isLoading,
  questions,
}) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to latest response on new messages
  useEffect(() => {
    bottomRef.current?.scrollIntoView?.({ behavior: 'smooth' });
  }, [messages.length, isLoading]);

  if (messages.length === 0) {
    return <SuggestedQuestions onSelectQuestion={onSelectQuestionSuggestion} isLoading={isLoading} questions={questions} />;
  }

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
      {messages.map((msg) => (
        <AnswerMessageCard
          key={msg.id}
          message={msg}
          isSelected={msg.id === selectedMessageId}
          onSelectMessage={onSelectMessage}
          onRetry={onRetry}
          onFlag={onFlag}
        />
      ))}
      <div ref={bottomRef} />
    </Box>
  );
};
