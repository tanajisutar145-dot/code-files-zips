import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Box,
  Grid,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Button,
  Alert,
  Snackbar,
} from '@mui/material';

import { useLocation } from 'react-router-dom';

import { ChatMessage, ChatTurn, IntelligenceInfo, QuestionBrief } from '../../types/api';
import {
  errorMessage,
  getIntelligenceInfo,
  getQuestionJob,
  getQuestionJobResponse,
  isBackendReachable,
  submitQuestionJob,
  verificationApi,
} from '../../services/api';
import { IntelligenceHeader } from './components/IntelligenceHeader';
import { QuestionComposer, IntelligenceConfig, DEFAULT_CONFIG } from './components/QuestionComposer';
import { ConversationThread } from './components/ConversationThread';
import { EvidenceInspector } from './components/EvidenceInspector';

const POLL_MS = 1500;
const HISTORY_TURNS = 6;

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

const IntelligencePage: React.FC = () => {
  const location = useLocation();

  // Conversation and active selection state
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [selectedMessageId, setSelectedMessageId] = useState<string | null>(null);
  const [questionInput, setQuestionInput] = useState<string>('');
  const [config, setConfig] = useState<IntelligenceConfig>(DEFAULT_CONFIG);

  // Engine info (demo questions, retrievers) and service status
  const [info, setInfo] = useState<IntelligenceInfo | null>(null);
  const [infoError, setInfoError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isBackendHealthy, setIsBackendHealthy] = useState<boolean | null>(null);
  const [clearDialogOpen, setClearDialogOpen] = useState<boolean>(false);
  const [toast, setToast] = useState<string | null>(null);

  // Incremented on clear / unmount so a running poll loop stops updating state
  const sessionRef = useRef<number>(0);
  const messagesRef = useRef<ChatMessage[]>([]);
  useEffect(() => {
    messagesRef.current = messages;
  }, [messages]);

  useEffect(() => {
    let isMounted = true;
    isBackendReachable()
      .then((ok) => isMounted && setIsBackendHealthy(ok))
      .catch(() => isMounted && setIsBackendHealthy(false));
    getIntelligenceInfo()
      .then((data) => isMounted && setInfo(data))
      .catch((err) => isMounted && setInfoError(errorMessage(err, 'GraphRAG engine unavailable')));
    const session = sessionRef;
    return () => {
      isMounted = false;
      session.current += 1;
    };
  }, []);

  // Populate question input from URL query parameters (e.g. from Dashboard, Use Cases or Graph pages)
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const qParam = params.get('q') || params.get('question');
    if (qParam && qParam.trim()) {
      setQuestionInput(qParam.trim());
    }
  }, [location.search]);

  const updateMessage = (id: string, patch: Partial<ChatMessage>) =>
    setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, ...patch } : m)));

  const historyFor = (upTo: ChatMessage[]): ChatTurn[] => {
    const turns: ChatTurn[] = [];
    upTo.forEach((m) => {
      const answer = m.response?.answer || m.reply;
      if (m.question && answer) {
        turns.push({ role: 'user', content: m.question });
        turns.push({ role: 'assistant', content: answer });
      }
    });
    return turns.slice(-HISTORY_TURNS);
  };

  // Submit question as a job, poll its trace, then fetch the verified response
  const handleAskQuestion = useCallback(
    async (overrideQuestion?: string) => {
      const targetQuestion = (overrideQuestion !== undefined ? overrideQuestion : questionInput).trim();
      if (!targetQuestion || isLoading) return;

      const session = sessionRef.current;
      const messageId = `msg-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      const history = historyFor(messagesRef.current);
      const newMessage: ChatMessage = {
        id: messageId,
        timestamp: new Date().toISOString(),
        question: targetQuestion,
        mode: config.mode,
        isLoading: true,
      };

      setMessages((prev) => [...prev, newMessage]);
      setSelectedMessageId(messageId);
      setQuestionInput('');
      setIsLoading(true);

      try {
        const started = await submitQuestionJob({
          question: targetQuestion,
          mode: config.mode,
          history,
          include_verification: config.include_verification,
        });
        if (session !== sessionRef.current) return;
        if (started.reply !== undefined) {
          updateMessage(messageId, { reply: started.reply, isLoading: false });
          return;
        }
        const jobId = started.job_id as string;
        // Poll the live trace until the job finishes
        for (;;) {
          const job = await getQuestionJob(jobId);
          if (session !== sessionRef.current) return;
          updateMessage(messageId, { job });
          if (job.status === 'done' || job.status === 'error') break;
          await sleep(POLL_MS);
        }
        const response = await getQuestionJobResponse(jobId);
        if (session !== sessionRef.current) return;
        if (!config.include_verification) {
          response.verification = { ...response.verification, warnings: ['Answer verification switched off'] };
        }
        updateMessage(messageId, { response, isLoading: false, error: undefined });
      } catch (err: any) {
        if (session !== sessionRef.current) return;
        console.error('GraphRAG query error:', err);
        updateMessage(messageId, {
          isLoading: false,
          error: errorMessage(err, 'Question answering failed. Check that Neo4j is running, the graph is loaded and the LLM is reachable.'),
        });
      } finally {
        if (session === sessionRef.current) setIsLoading(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [questionInput, config, isLoading]
  );

  const handleFlag = useCallback(async (message: ChatMessage) => {
    if (!message.response) return;
    try {
      await verificationApi.flag({
        question: message.question,
        answer: message.response.answer,
        confidence: message.response.verification?.grounding_score ?? 0,
        reason: 'flagged from the Intelligence page',
        job_id: message.response.job_id,
        retriever: message.response.retriever,
      });
      setToast('Answer sent to the review queue (Answer Review page).');
    } catch (err) {
      setToast(errorMessage(err, 'Could not flag the answer'));
    }
  }, []);

  // Clear conversation with confirmation
  const handleConfirmClear = () => {
    sessionRef.current += 1;
    setMessages([]);
    setSelectedMessageId(null);
    setIsLoading(false);
    setClearDialogOpen(false);
  };

  const selectedMessage = messages.find((m) => m.id === selectedMessageId);
  const questions: QuestionBrief[] = info ? [...info.demo_questions, ...info.sample_questions] : [];

  return (
    <Box sx={{ width: '100%', maxWidth: 1700, mx: 'auto', p: { xs: 0, sm: 1 } }}>
      <IntelligenceHeader
        isBackendHealthy={isBackendHealthy === null ? null : isBackendHealthy && !infoError}
        messageCount={messages.length}
        onClearConversation={() => setClearDialogOpen(true)}
      />

      {infoError && (
        <Alert severity="warning" sx={{ mb: 2, borderRadius: 1.5 }}>
          {infoError} — start the Neo4j database, load the graph (<code>python -m app.kg run --step load</code>) and check the LLM settings
          in backend/.env. The questions below can be asked once the engine is up.
        </Alert>
      )}
      {info && !info.has_chunks && (
        <Alert severity="info" sx={{ mb: 2, borderRadius: 1.5 }}>
          No embedded narrative chunks are loaded: only Text2Cypher is available. Configure an embedder and re-run the load step to enable
          vector and hybrid retrieval.
        </Alert>
      )}

      <Grid container spacing={3}>
        <Grid item xs={12} md={7}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
            <ConversationThread
              messages={messages}
              selectedMessageId={selectedMessageId}
              onSelectMessage={setSelectedMessageId}
              onSelectQuestionSuggestion={(q) => handleAskQuestion(q)}
              onRetry={(q) => handleAskQuestion(q)}
              onFlag={handleFlag}
              isLoading={isLoading}
              questions={questions}
            />
            <QuestionComposer
              question={questionInput}
              onQuestionChange={setQuestionInput}
              config={config}
              onConfigChange={setConfig}
              onSubmit={handleAskQuestion}
              isLoading={isLoading}
              retrievers={info?.retrievers}
              hasChunks={info ? info.has_chunks : true}
            />
          </Box>
        </Grid>

        <Grid item xs={12} md={5}>
          <EvidenceInspector
            response={selectedMessage?.response || null}
            job={selectedMessage?.job || null}
            questionText={selectedMessage?.question}
          />
        </Grid>
      </Grid>

      <Dialog open={clearDialogOpen} onClose={() => setClearDialogOpen(false)} aria-labelledby="clear-conversation-dialog-title">
        <DialogTitle id="clear-conversation-dialog-title" sx={{ fontWeight: 700, color: '#0f172a' }}>
          Start New Conversation?
        </DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ color: '#475569' }}>
            Clearing this conversation removes the questions, answers and evidence views shown here. Answers already flagged stay in the review
            queue.
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ p: 2, pt: 0 }}>
          <Button onClick={() => setClearDialogOpen(false)} sx={{ color: '#64748b', textTransform: 'none' }}>
            Cancel
          </Button>
          <Button onClick={handleConfirmClear} variant="contained" color="error" sx={{ textTransform: 'none', fontWeight: 600 }}>
            Clear Conversation
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar open={!!toast} autoHideDuration={4000} onClose={() => setToast(null)} message={toast || ''} />
    </Box>
  );
};

export default IntelligencePage;
