import { ConfidenceLevel } from '../../../types/api';

/**
 * Visual styling tokens for answer confidence levels
 */
export const getConfidenceBadge = (confidence?: ConfidenceLevel) => {
  switch (confidence) {
    case 'high':
      return {
        label: 'High Confidence',
        bg: '#ecfdf5',
        text: '#059669',
        border: '#a7f3d0',
      };
    case 'medium':
      return {
        label: 'Medium Confidence',
        bg: '#f0f9ff',
        text: '#0284c7',
        border: '#bae6fd',
      };
    case 'low':
      return {
        label: 'Low Confidence',
        bg: '#fffbeb',
        text: '#d97706',
        border: '#fde68a',
      };
    case 'very_low':
      return {
        label: 'Very Low Confidence',
        bg: '#fef2f2',
        text: '#dc2626',
        border: '#fecaca',
      };
    default:
      return {
        label: 'Unknown Confidence',
        bg: '#f8fafc',
        text: '#64748b',
        border: '#cbd5e1',
      };
  }
};

/**
 * Format grounding/verification score as percentage
 */
export const formatGroundingScore = (score?: number | null): string => {
  if (score === undefined || score === null || isNaN(score)) return '0%';
  const clamped = Math.max(0, Math.min(1, score));
  return `${Math.round(clamped * 100)}%`;
};

/**
 * Grounding score visual colors
 */
export const getGroundingColor = (score?: number | null) => {
  if (score === undefined || score === null || isNaN(score)) {
    return { bg: '#f8fafc', text: '#64748b', bar: '#cbd5e1' };
  }
  if (score >= 0.8) return { bg: '#ecfdf5', text: '#059669', bar: '#10b981' };
  if (score >= 0.5) return { bg: '#fffbeb', text: '#d97706', bar: '#f59e0b' };
  return { bg: '#fef2f2', text: '#dc2626', bar: '#ef4444' };
};

/**
 * Format execution time duration in ms or seconds
 */
export const formatDuration = (seconds?: number | null): string => {
  if (seconds === undefined || seconds === null || isNaN(seconds)) return '0 ms';
  if (seconds < 1) return `${Math.round(seconds * 1000)} ms`;
  return `${seconds.toFixed(2)} s`;
};

/**
 * Format local time for message bubble
 */
export const formatMessageTime = (isoString?: string): string => {
  if (!isoString) return '';
  try {
    const d = new Date(isoString);
    if (isNaN(d.getTime())) return '';
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  } catch {
    return '';
  }
};
