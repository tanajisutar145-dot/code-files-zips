import {
  getConfidenceBadge,
  formatGroundingScore,
  getGroundingColor,
  formatDuration,
  formatMessageTime,
} from '../intelligenceUtils';

describe('intelligenceUtils', () => {
  describe('getConfidenceBadge', () => {
    it('returns appropriate visual styling for all confidence levels', () => {
      expect(getConfidenceBadge('high').label).toBe('High Confidence');
      expect(getConfidenceBadge('high').text).toBe('#059669');

      expect(getConfidenceBadge('medium').label).toBe('Medium Confidence');
      expect(getConfidenceBadge('medium').text).toBe('#0284c7');

      expect(getConfidenceBadge('low').label).toBe('Low Confidence');
      expect(getConfidenceBadge('low').text).toBe('#d97706');

      expect(getConfidenceBadge('very_low').label).toBe('Very Low Confidence');
      expect(getConfidenceBadge('very_low').text).toBe('#dc2626');
    });

    it('handles undefined or unknown confidence gracefully', () => {
      const badge = getConfidenceBadge(undefined);
      expect(badge.label).toBe('Unknown Confidence');
    });
  });

  describe('formatGroundingScore', () => {
    it('formats valid float scores into integer percentages', () => {
      expect(formatGroundingScore(0.85)).toBe('85%');
      expect(formatGroundingScore(0.8)).toBe('80%');
      expect(formatGroundingScore(1.0)).toBe('100%');
      expect(formatGroundingScore(0.0)).toBe('0%');
    });

    it('handles null, undefined, or NaN safely', () => {
      expect(formatGroundingScore(null)).toBe('0%');
      expect(formatGroundingScore(undefined)).toBe('0%');
      expect(formatGroundingScore(NaN)).toBe('0%');
    });
  });

  describe('getGroundingColor', () => {
    it('assigns green for score >= 0.8, amber for >= 0.5, red for < 0.5', () => {
      expect(getGroundingColor(0.85).text).toBe('#059669');
      expect(getGroundingColor(0.6).text).toBe('#d97706');
      expect(getGroundingColor(0.3).text).toBe('#dc2626');
    });
  });

  describe('formatDuration', () => {
    it('formats millisecond and second durations accurately', () => {
      expect(formatDuration(0.08)).toBe('80 ms');
      expect(formatDuration(0.75)).toBe('750 ms');
      expect(formatDuration(1.357)).toBe('1.36 s');
      expect(formatDuration(null)).toBe('0 ms');
    });
  });

  describe('formatMessageTime', () => {
    it('formats valid ISO timestamps', () => {
      const formatted = formatMessageTime('2026-10-12T08:15:00.000Z');
      expect(formatted).not.toBe('');
      expect(formatMessageTime(undefined)).toBe('');
    });
  });
});
