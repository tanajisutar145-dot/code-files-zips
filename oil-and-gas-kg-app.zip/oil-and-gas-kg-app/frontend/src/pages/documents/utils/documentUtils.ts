/**
 * Helpers for Document Management styling and formatting
 */

export const getDocumentTypeColor = (
  docType: string
): { bg: string; text: string; border: string; label: string } => {
  switch (docType?.toLowerCase()) {
    case 'inspection_report':
      return { bg: '#e0f2fe', text: '#0284c7', border: '#bae6fd', label: 'Inspection Report' };
    case 'failure_analysis':
      return { bg: '#fee2e2', text: '#dc2626', border: '#fecaca', label: 'Failure Analysis' };
    case 'drilling_report':
      return { bg: '#fef2f2', text: '#b91c1c', border: '#fecaca', label: 'Drilling Report' };
    case 'well_test_report':
      return { bg: '#ecfdf5', text: '#047857', border: '#a7f3d0', label: 'Well Test Report' };
    case 'lessons_learned':
      return { bg: '#fef3c7', text: '#d97706', border: '#fde68a', label: 'Lessons Learned' };
    case 'incident_investigation':
      return { bg: '#ffedd5', text: '#ea580c', border: '#fed7aa', label: 'Incident Investigation' };
    case 'hse_bulletin':
      return { bg: '#fff7ed', text: '#c2410c', border: '#fed7aa', label: 'HSE Bulletin' };
    case 'emissions_report':
      return { bg: '#f0fdf4', text: '#15803d', border: '#bbf7d0', label: 'Emissions Report' };
    case 'regulatory_correspondence':
      return { bg: '#f5f5f4', text: '#78716c', border: '#e7e5e4', label: 'Regulatory Correspondence' };
    case 'engineering_note':
      return { bg: '#e0f2f1', text: '#00897b', border: '#b2dfdb', label: 'Engineering Note' };
    case 'operational_note':
      return { bg: '#f3e8ff', text: '#9333ea', border: '#e9d5ff', label: 'Operational Note' };
    default:
      // record narratives carry the source class (e.g. FailureReport, NptEvent) as their type
      return { bg: '#f1f5f9', text: '#475569', border: '#cbd5e1', label: docType ? docType.replace(/([a-z])([A-Z])/g, '$1 $2') : 'Document' };
  }
};

export const formatDate = (dateStr?: string | null): string => {
  if (!dateStr) return 'N/A';
  try {
    const d = new Date(dateStr);
    return isNaN(d.getTime()) ? dateStr : d.toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return dateStr;
  }
};

export const formatDateTime = (dateStr?: string | null): string => {
  if (!dateStr) return 'N/A';
  try {
    const d = new Date(dateStr);
    return isNaN(d.getTime()) ? dateStr : d.toLocaleString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dateStr;
  }
};

export const formatFileSize = (bytes: number): string => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
};
