import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { MemoryRouter } from 'react-router-dom';
import { DocumentsHeader } from '../components/DocumentsHeader';
import { DocumentStatistics } from '../components/DocumentStatistics';
import { DocumentFiltersBar } from '../components/DocumentFiltersBar';
import { DocumentTable } from '../components/DocumentTable';
import { DocumentDetailModal } from '../components/DocumentDetailModal';
import { DocumentUploadModal } from '../components/DocumentUploadModal';
import { DocumentSummaryItem, DocumentDetailResponse, DocumentOverviewResponse } from '../../../types/documents';

const mockOverview: DocumentOverviewResponse = {
  total_documents: 8,
  total_chunks: 13,
  embedded_chunks: 13,
  document_types: { inspection_report: 1, failure_analysis: 2 },
  processing_statuses: { completed: 8 },
  vector_index_name: 'chunk_embedding_index',
  vector_index_status: 'ONLINE',
  vector_index_population: 100.0,
  embedding_model: 'ollama / nomic-embed-text',
  embedding_dimension: 768,
};

const mockDocuments: DocumentSummaryItem[] = [
  {
    document_id: 'DOC-001',
    title: 'Inspection report INS-2025-0001: compressor FD1-K-201',
    document_type: 'inspection_report',
    source: 'OGX Energy (synthetic) - Asset Integrity',
    source_reference: 'INS-001',
    created_date: '2026-08-08T08:12:57',
    processing_status: 'completed',
    content_length: 500,
    chunk_count: 1,
    embedded_chunks: 1,
  },
];

const mockDetail: DocumentDetailResponse = {
  document_id: 'DOC-001',
  title: 'Inspection report INS-2025-0001: compressor FD1-K-201',
  document_type: 'inspection_report',
  source: 'OGX Energy (synthetic) - Asset Integrity',
  source_reference: 'INS-001',
  created_date: '2026-08-08T08:12:57',
  processing_status: 'completed',
  content: 'UT grid showed 38% wall loss at the discharge elbow.',
  chunks: [
    {
      chunk_id: 'DOC-001_chk_0',
      chunk_index: 0,
      text: 'UT grid showed 38% wall loss at the discharge elbow.',
      is_embedded: true,
      embedding_model: 'ollama / nomic-embed-text',
      embedding_dimension: 768,
      metadata: { meta_tag: 'FD1-K-201' },
    },
  ],
  linked_entities: [
    {
      relationship: 'MENTIONS_RECORD',
      labels: ['Equipment'],
      entity_id: 'FD1-K-201',
      entity_name: 'FD1-K-201 Compressor',
      properties: {},
    },
  ],
};

describe('Document Management Components', () => {
  test('DocumentsHeader renders title, chip counts, and action buttons', () => {
    const html = renderToStaticMarkup(
      <DocumentsHeader
        totalDocuments={8}
        totalChunks={13}
        isLoading={false}
        onRefresh={jest.fn()}
        onOpenUpload={jest.fn()}
      />
    );

    expect(html).toContain('Document Intelligence');
    expect(html).toContain('8 Documents • 13 Chunks');
    expect(html).toContain('Refresh');
    expect(html).toContain('Upload Document');
  });

  test('DocumentStatistics renders overview cards with vector index state', () => {
    const html = renderToStaticMarkup(
      <DocumentStatistics overview={mockOverview} isLoading={false} />
    );

    expect(html).toContain('Total Documents');
    expect(html).toContain('8');
    expect(html).toContain('13 / 13');
    expect(html).toContain('ONLINE');
    expect(html).toContain('chunk_embedding_index');
  });

  test('DocumentFiltersBar renders search and document type options', () => {
    const html = renderToStaticMarkup(
      <DocumentFiltersBar
        search="wall loss"
        documentType="inspection_report"
        onSearchChange={jest.fn()}
        onDocumentTypeChange={jest.fn()}
        onClearFilters={jest.fn()}
      />
    );

    expect(html).toContain('wall loss');
    expect(html).toContain('Clear Filters');
  });

  test('DocumentTable renders document rows and metadata chips', () => {
    const html = renderToStaticMarkup(
      <DocumentTable
        documents={mockDocuments}
        total={1}
        page={0}
        rowsPerPage={10}
        isLoading={false}
        onPageChange={jest.fn()}
        onRowsPerPageChange={jest.fn()}
        onSelectDocument={jest.fn()}
      />
    );

    expect(html).toContain('DOC-001');
    expect(html).toContain('Inspection report INS-2025-0001: compressor FD1-K-201');
    expect(html).toContain('Inspection Report');
    expect(html).toContain('Indexed');
  });

  test('DocumentTable displays empty state when no documents match', () => {
    const html = renderToStaticMarkup(
      <DocumentTable
        documents={[]}
        total={0}
        page={0}
        rowsPerPage={10}
        isLoading={false}
        onPageChange={jest.fn()}
        onRowsPerPageChange={jest.fn()}
        onSelectDocument={jest.fn()}
      />
    );

    expect(html).toContain('No Documents Found');
  });

  test('DocumentDetailModal renders document text, chunks, and entity tabs', () => {
    const html = renderToStaticMarkup(
      <MemoryRouter>
        <DocumentDetailModal
          open={true}
          document={mockDetail}
          isLoading={false}
          onClose={jest.fn()}
        />
      </MemoryRouter>
    );

    expect(html).toContain('Inspection report INS-2025-0001: compressor FD1-K-201');
    expect(html).toContain('UT grid showed 38% wall loss at the discharge elbow');
    expect(html).toContain('Text Chunks (1)');
    expect(html).toContain('Linked Entities (1)');
  });

  test('DocumentUploadModal renders upload dialog and instructions', () => {
    const html = renderToStaticMarkup(
      <DocumentUploadModal
        open={true}
        onClose={jest.fn()}
        onUploadSuccess={jest.fn()}
      />
    );

    expect(html).toContain('Upload &amp; Ingest Document');
    expect(html).toContain('PDF (.pdf)');
    expect(html).toContain('Excel (.xlsx)');
    expect(html).toContain('CSV (.csv)');
    expect(html).toContain('Word (.docx)');
  });

  test('DocumentDetailModal renders format badge and chunk provenance chips', () => {
    const detailWithProvenance: DocumentDetailResponse = {
      ...mockDetail,
      format: 'pdf',
      source_filename: 'k201_inspection.pdf',
      warnings: ['Scanned or image-only PDF detected. OCR is required to extract full text.'],
      chunks: [
        {
          chunk_id: 'DOC-001_chk_0',
          chunk_index: 0,
          text: 'Discharge elbow wall-loss analysis.',
          is_embedded: true,
          page_number: 1,
          section_title: 'Introduction',
          metadata: {},
        },
      ],
    };

    const html = renderToStaticMarkup(
      <MemoryRouter>
        <DocumentDetailModal
          open={true}
          document={detailWithProvenance}
          isLoading={false}
          onClose={jest.fn()}
          initialTab={1}
        />
      </MemoryRouter>
    );

    expect(html).toContain('PDF');
    expect(html).toContain('File: k201_inspection.pdf');
    expect(html).toContain('Extraction Notice:');
    expect(html).toContain('OCR is required');
    expect(html).toContain('Page 1');
    expect(html).toContain('Section: Introduction');
  });
});
