import React, { useState, useEffect, useCallback } from 'react';
import { useLocation } from 'react-router-dom';
import {
  Box,
  Alert,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Typography,
  CircularProgress,
  Snackbar,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  WarningAmber as WarningIcon,
  DeleteOutline as DeleteIcon,
} from '@mui/icons-material';

import {
  DocumentOverviewResponse,
  DocumentSummaryItem,
  DocumentDetailResponse,
} from '../../types/documents';
import {
  getDocumentsOverview,
  listDocuments,
  getDocumentDetail,
  deleteDocument,
} from '../../services/api';

import { DocumentsHeader } from './components/DocumentsHeader';
import { DocumentStatistics } from './components/DocumentStatistics';
import { DocumentFiltersBar } from './components/DocumentFiltersBar';
import { DocumentTable } from './components/DocumentTable';
import { DocumentDetailModal } from './components/DocumentDetailModal';
import { DocumentUploadModal } from './components/DocumentUploadModal';

const DocumentsPage: React.FC = () => {
  const location = useLocation();

  // Overview metrics
  const [overview, setOverview] = useState<DocumentOverviewResponse | null>(null);
  const [isLoadingOverview, setIsLoadingOverview] = useState<boolean>(true);

  // Documents listing
  const [documents, setDocuments] = useState<DocumentSummaryItem[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [isLoadingList, setIsLoadingList] = useState<boolean>(true);
  const [listError, setListError] = useState<string | null>(null);

  // Filters & Pagination
  const [search, setSearch] = useState<string>('');
  const [documentType, setDocumentType] = useState<string>('');
  const [page, setPage] = useState<number>(0);
  const [rowsPerPage, setRowsPerPage] = useState<number>(10);

  // uploaded documents first; record narratives are the text of table rows (pipeline load step)
  const [kind, setKind] = useState<string>('uploaded');

  // Detail Modal
  const [detailDoc, setDetailDoc] = useState<DocumentDetailResponse | null>(null);
  const [isLoadingDetail, setIsLoadingDetail] = useState<boolean>(false);
  const [detailModalOpen, setDetailModalOpen] = useState<boolean>(false);

  // Upload Modal
  const [uploadModalOpen, setUploadModalOpen] = useState<boolean>(false);

  // Deletion State
  const [documentToDelete, setDocumentToDelete] = useState<{ document_id: string; title: string } | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Initialize search from URL params if present
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const queryParam = params.get('search') || params.get('q');
    const typeParam = params.get('type') || params.get('document_type');
    const kindParam = params.get('kind');
    if (kindParam !== null) {
      setKind(kindParam);
    }
    if (queryParam) {
      setSearch(queryParam);
    }
    if (typeParam) {
      setDocumentType(typeParam);
    }
  }, [location.search]);

  // Fetch overview statistics
  const fetchOverview = useCallback(async () => {
    try {
      setIsLoadingOverview(true);
      const data = await getDocumentsOverview();
      setOverview(data);
    } catch (err: any) {
      console.error('Failed to fetch document overview:', err);
    } finally {
      setIsLoadingOverview(false);
    }
  }, []);

  // Fetch documents list
  const fetchDocuments = useCallback(async () => {
    try {
      setIsLoadingList(true);
      setListError(null);
      const data = await listDocuments({
        search: search.trim() || undefined,
        document_type: documentType || undefined,
        kind: kind || undefined,
        skip: page * rowsPerPage,
        limit: rowsPerPage,
      });
      setDocuments(data.documents);
      setTotal(data.total);
    } catch (err: any) {
      console.error('Failed to list documents:', err);
      const msg = err?.response?.data?.detail || err?.message || 'Failed to retrieve documents from Neo4j.';
      setListError(msg);
    } finally {
      setIsLoadingList(false);
    }
  }, [search, documentType, kind, page, rowsPerPage]);

  useEffect(() => {
    fetchOverview();
  }, [fetchOverview]);

  useEffect(() => {
    fetchDocuments();
  }, [fetchDocuments]);

  // Open detail modal and fetch data
  const handleSelectDocument = async (docId: string) => {
    setDetailModalOpen(true);
    setIsLoadingDetail(true);
    try {
      const data = await getDocumentDetail(docId);
      setDetailDoc(data);
    } catch (err: any) {
      console.error('Failed to fetch document details:', err);
    } finally {
      setIsLoadingDetail(false);
    }
  };

  const handleCloseDetailModal = () => {
    setDetailModalOpen(false);
    setDetailDoc(null);
  };

  const handleClearFilters = () => {
    setSearch('');
    setDocumentType('');
    setPage(0);
  };

  const handleRefreshAll = () => {
    fetchOverview();
    fetchDocuments();
  };

  const handleRequestDelete = (doc: { document_id: string; title: string }) => {
    setDocumentToDelete(doc);
  };

  const handleCancelDelete = () => {
    if (!isDeleting) {
      setDocumentToDelete(null);
    }
  };

  const handleConfirmDelete = async () => {
    if (!documentToDelete) return;
    setIsDeleting(true);
    try {
      await deleteDocument(documentToDelete.document_id);
      setNotification({
        type: 'success',
        message: `Document "${documentToDelete.title}" (${documentToDelete.document_id}) and its associated chunks were deleted successfully.`,
      });
      setDocumentToDelete(null);
      fetchOverview();
      fetchDocuments();
    } catch (err: any) {
      console.error('Failed to delete document:', err);
      const errMsg = err?.response?.data?.detail || err?.message || 'Failed to delete document.';
      setNotification({
        type: 'error',
        message: errMsg,
      });
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <Box sx={{ maxWidth: 1400, mx: 'auto', p: { xs: 2, md: 3 } }}>
      <DocumentsHeader
        totalDocuments={overview?.total_documents ?? 0}
        totalChunks={overview?.total_chunks ?? 0}
        isLoading={isLoadingOverview || isLoadingList}
        onRefresh={handleRefreshAll}
        onOpenUpload={() => setUploadModalOpen(true)}
      />

      <DocumentStatistics
        overview={overview}
        isLoading={isLoadingOverview}
      />

      <DocumentFiltersBar
        search={search}
        documentType={documentType}
        kind={kind}
        onKindChange={(val) => {
          setKind(val);
          setPage(0);
        }}
        onSearchChange={(val) => {
          setSearch(val);
          setPage(0);
        }}
        onDocumentTypeChange={(val) => {
          setDocumentType(val);
          setPage(0);
        }}
        onClearFilters={handleClearFilters}
      />

      {listError && (
        <Alert
          severity="error"
          sx={{ mb: 2 }}
          action={
            <Button color="inherit" size="small" onClick={fetchDocuments} startIcon={<RefreshIcon />}>
              Retry
            </Button>
          }
        >
          {listError}
        </Alert>
      )}

      <DocumentTable
        documents={documents}
        total={total}
        page={page}
        rowsPerPage={rowsPerPage}
        isLoading={isLoadingList}
        onPageChange={(newPage) => setPage(newPage)}
        onRowsPerPageChange={(newRows) => {
          setRowsPerPage(newRows);
          setPage(0);
        }}
        onSelectDocument={handleSelectDocument}
        onDeleteDocument={handleRequestDelete}
      />

      <DocumentDetailModal
        open={detailModalOpen}
        document={detailDoc}
        isLoading={isLoadingDetail}
        onClose={handleCloseDetailModal}
        onDeleteDocument={handleRequestDelete}
      />

      <DocumentUploadModal
        open={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
        onUploadSuccess={() => {
          fetchOverview();
          fetchDocuments();
        }}
      />

      {/* Delete Confirmation Dialog */}
      <Dialog
        disablePortal
        open={Boolean(documentToDelete)}
        onClose={handleCancelDelete}
        maxWidth="xs"
        fullWidth
        PaperProps={{
          sx: { borderRadius: 2.5, p: 1 },
        }}
      >
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1, color: '#b91c1c', pb: 1 }}>
          <WarningIcon color="error" />
          <Typography variant="h6" fontWeight={700}>
            Delete Document?
          </Typography>
        </DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ color: '#334155', fontSize: '0.9rem', mb: 1 }}>
            Are you sure you want to permanently delete{' '}
            <strong>{documentToDelete?.title}</strong> (
            <code>{documentToDelete?.document_id}</code>)?
          </DialogContentText>
          <DialogContentText sx={{ color: '#64748b', fontSize: '0.82rem' }}>
            This will permanently remove the document node and all associated text chunks and vector embeddings from the Neo4j knowledge graph. This action cannot be undone.
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ p: 2, pt: 1 }}>
          <Button
            onClick={handleCancelDelete}
            disabled={isDeleting}
            variant="outlined"
            sx={{ textTransform: 'none', borderColor: '#cbd5e1', color: '#475569' }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleConfirmDelete}
            disabled={isDeleting}
            variant="contained"
            color="error"
            startIcon={isDeleting ? <CircularProgress size={16} color="inherit" /> : <DeleteIcon />}
            sx={{ textTransform: 'none' }}
          >
            {isDeleting ? 'Deleting...' : 'Confirm Delete'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Action Notification Snackbar */}
      <Snackbar
        open={Boolean(notification)}
        autoHideDuration={5000}
        onClose={() => setNotification(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        {notification ? (
          <Alert
            onClose={() => setNotification(null)}
            severity={notification.type}
            variant="filled"
            sx={{ width: '100%', borderRadius: 2, fontWeight: 500 }}
          >
            {notification.message}
          </Alert>
        ) : undefined}
      </Snackbar>
    </Box>
  );
};

export default DocumentsPage;