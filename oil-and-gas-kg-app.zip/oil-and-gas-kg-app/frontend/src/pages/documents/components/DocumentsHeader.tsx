import React from 'react';
import { Box, Typography, Button, Chip } from '@mui/material';
import {
  Description as DocumentIcon,
  Refresh as RefreshIcon,
  CloudUpload as UploadIcon,
} from '@mui/icons-material';

interface DocumentsHeaderProps {
  totalDocuments: number;
  totalChunks: number;
  isLoading: boolean;
  onRefresh: () => void;
  onOpenUpload: () => void;
}

export const DocumentsHeader: React.FC<DocumentsHeaderProps> = ({
  totalDocuments,
  totalChunks,
  isLoading,
  onRefresh,
  onOpenUpload,
}) => {
  return (
    <Box
      display="flex"
      justifyContent="space-between"
      alignItems={{ xs: 'flex-start', sm: 'center' }}
      flexDirection={{ xs: 'column', sm: 'row' }}
      gap={2}
      mb={3}
    >
      <Box>
        <Box display="flex" alignItems="center" gap={1.5} flexWrap="wrap">
          <DocumentIcon sx={{ color: '#00897b', fontSize: 32 }} />
          <Typography variant="h4" fontWeight={700} color="#0f172a">
            Document Intelligence
          </Typography>
          <Chip
            label={`${totalDocuments} Documents • ${totalChunks} Chunks`}
            size="small"
            sx={{
              backgroundColor: '#e0f2f1',
              color: '#00796b',
              fontWeight: 600,
              border: '1px solid #b2dfdb',
            }}
          />
        </Box>
        <Typography variant="body2" color="text.secondary" mt={0.5}>
          Manage technical reports, inspection records, work orders, and vector embeddings in the Neo4j knowledge graph.
        </Typography>
      </Box>

      <Box display="flex" alignItems="center" gap={1.5}>
        <Button
          variant="outlined"
          startIcon={<RefreshIcon />}
          onClick={onRefresh}
          disabled={isLoading}
          size="small"
          sx={{
            borderColor: '#cbd5e1',
            color: '#475569',
            textTransform: 'none',
            fontWeight: 600,
            '&:hover': { borderColor: '#94a3b8', backgroundColor: '#f8fafc' },
          }}
        >
          Refresh
        </Button>
        <Button
          variant="contained"
          startIcon={<UploadIcon />}
          onClick={onOpenUpload}
          size="small"
          sx={{
            backgroundColor: '#00897b',
            color: '#ffffff',
            textTransform: 'none',
            fontWeight: 600,
            boxShadow: 'none',
            '&:hover': { backgroundColor: '#00796b', boxShadow: 'none' },
          }}
        >
          Upload Document
        </Button>
      </Box>
    </Box>
  );
};
