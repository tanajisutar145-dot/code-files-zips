import React from 'react';
import {
  Box,
  TextField,
  MenuItem,
  Button,
  InputAdornment,
} from '@mui/material';
import {
  Search as SearchIcon,
  Clear as ClearIcon,
} from '@mui/icons-material';

interface DocumentFiltersBarProps {
  search: string;
  documentType: string;
  kind?: string;
  onSearchChange: (value: string) => void;
  onDocumentTypeChange: (value: string) => void;
  onKindChange?: (value: string) => void;
  onClearFilters: () => void;
}

const KINDS = [
  { value: 'uploaded', label: 'Uploaded documents' },
  { value: 'record_narrative', label: 'Record narratives' },
  { value: '', label: 'All' },
];

const DOCUMENT_TYPES = [
  { value: '', label: 'All Document Types' },
  { value: 'lessons_learned', label: 'Lessons Learned' },
  { value: 'incident_investigation', label: 'Incident Investigation' },
  { value: 'inspection_report', label: 'Inspection Report' },
  { value: 'failure_analysis', label: 'Failure Analysis' },
  { value: 'drilling_report', label: 'Drilling Report' },
  { value: 'well_test_report', label: 'Well Test Report' },
  { value: 'hse_bulletin', label: 'HSE Bulletin' },
  { value: 'emissions_report', label: 'Emissions Report' },
  { value: 'regulatory_correspondence', label: 'Regulatory Correspondence' },
  { value: 'engineering_note', label: 'Engineering Note' },
  { value: 'operational_note', label: 'Operational Note' },
];

export const DocumentFiltersBar: React.FC<DocumentFiltersBarProps> = ({
  search,
  documentType,
  kind,
  onSearchChange,
  onDocumentTypeChange,
  onKindChange,
  onClearFilters,
}) => {
  const hasActiveFilters = Boolean(search || documentType);

  return (
    <Box
      display="flex"
      gap={2}
      mb={2.5}
      flexWrap="wrap"
      alignItems="center"
      bgcolor="#ffffff"
      p={2}
      borderRadius={2}
      border="1px solid #e2e8f0"
    >
      <TextField
        placeholder="Search documents by title, ID, content, or source..."
        value={search}
        onChange={(e) => onSearchChange(e.target.value)}
        size="small"
        sx={{ flex: { xs: '1 1 100%', sm: '1 1 300px' } }}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchIcon sx={{ color: '#94a3b8' }} />
            </InputAdornment>
          ),
        }}
      />

      {onKindChange && (
        <TextField
          select
          label="Show"
          value={kind ?? ''}
          onChange={(e) => onKindChange(e.target.value)}
          size="small"
          sx={{ minWidth: 190, flex: { xs: '1 1 100%', sm: '0 0 200px' } }}
        >
          {KINDS.map((k) => (
            <MenuItem key={k.value || 'all'} value={k.value}>
              {k.label}
            </MenuItem>
          ))}
        </TextField>
      )}

      <TextField
        select
        label="Document Type"
        value={documentType}
        onChange={(e) => onDocumentTypeChange(e.target.value)}
        size="small"
        sx={{ minWidth: 200, flex: { xs: '1 1 100%', sm: '0 0 220px' } }}
      >
        {DOCUMENT_TYPES.map((option) => (
          <MenuItem key={option.value} value={option.value}>
            {option.label}
          </MenuItem>
        ))}
      </TextField>

      {hasActiveFilters && (
        <Button
          variant="text"
          startIcon={<ClearIcon />}
          onClick={onClearFilters}
          size="small"
          sx={{
            color: '#64748b',
            textTransform: 'none',
            fontWeight: 600,
            '&:hover': { color: '#0f172a' },
          }}
        >
          Clear Filters
        </Button>
      )}
    </Box>
  );
};
