/**
 * The five knowledge-graph use cases (docs/01_OilGas_KG_Research_and_Use_Cases.md). Every table is the
 * result of a fixed, read-only Cypher query over the loaded graph (no LLM); the Cypher is shown with it.
 */

import React from 'react';
import { Alert, Box, Chip, Tab, Tabs, Typography } from '@mui/material';
import { Insights as UseCaseIcon } from '@mui/icons-material';
import { useNavigate, useParams } from 'react-router-dom';
import { useApi } from '../../hooks/useApi';
import { useCaseApi } from '../../services/api';
import { UseCase } from '../../types/usecases';
import { AskLinks } from './components/AskLinks';
import { Uc1WellIdentity } from './components/Uc1WellIdentity';
import { Uc2Drilling } from './components/Uc2Drilling';
import { Uc3Integrity } from './components/Uc3Integrity';
import { Uc4Hse } from './components/Uc4Hse';
import { Uc5Traceability } from './components/Uc5Traceability';
import { UC_COLORS } from '../dashboard/components/UseCaseOverview';

type UseCaseHead = Pick<UseCase, 'id' | 'title' | 'owner' | 'summary' | 'standards'>;

const FALLBACK: UseCaseHead[] = [
  { id: 'UC1', title: 'Well & subsurface 360 / well identity', owner: 'Subsurface data management', summary: '', standards: [] },
  { id: 'UC2', title: 'Drilling performance & lessons learned', owner: 'Drilling & completions', summary: '', standards: [] },
  { id: 'UC3', title: 'Asset integrity & reliability', owner: 'Asset integrity / maintenance', summary: '', standards: [] },
  { id: 'UC4', title: 'HSE & process-safety incident intelligence', owner: 'HSE / process safety', summary: '', standards: [] },
  { id: 'UC5', title: 'Production-to-market & emissions traceability', owner: 'Production accounting / ESG', summary: '', standards: [] },
];

const VIEWS: Record<string, React.FC> = {
  UC1: Uc1WellIdentity,
  UC2: Uc2Drilling,
  UC3: Uc3Integrity,
  UC4: Uc4Hse,
  UC5: Uc5Traceability,
};

const UseCasesPage: React.FC = () => {
  const navigate = useNavigate();
  const { ucId } = useParams<{ ucId: string }>();
  const active = ucId && VIEWS[ucId.toUpperCase()] ? ucId.toUpperCase() : 'UC1';
  const list = useApi(() => useCaseApi.list(), []);
  const useCases: UseCaseHead[] = list.data && list.data.length > 0 ? list.data : FALLBACK;
  const current = useCases.find((u) => u.id === active);
  const View = VIEWS[active];
  const color = UC_COLORS[active];

  return (
    <Box sx={{ width: '100%', maxWidth: 1700, mx: 'auto', pb: 4 }}>
      <Box sx={{ mb: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.25 }}>
          <UseCaseIcon sx={{ color: '#0f766e', fontSize: 28 }} />
          <Typography variant="h5" component="h1" sx={{ fontWeight: 700, color: '#0f172a', letterSpacing: '-0.02em' }}>
            Knowledge-Graph Use Cases
          </Typography>
        </Box>
        <Typography variant="body2" sx={{ color: '#64748b', mt: 0.5 }}>
          Deterministic analyses for the five prioritised use cases. Each result shows the Cypher that produced it; the GraphRAG buttons ask
          the matching demo question with its ground-truth fact check.
        </Typography>
      </Box>

      <Tabs
        value={active}
        onChange={(_, v) => navigate(`/usecases/${v}`)}
        variant="scrollable"
        scrollButtons="auto"
        sx={{
          mb: 2,
          borderBottom: '1px solid #e2e8f0',
          '& .MuiTab-root': { textTransform: 'none', fontWeight: 600, minHeight: 44 },
          '& .MuiTabs-indicator': { bgcolor: color, height: 3 },
        }}
      >
        {useCases.map((u) => (
          <Tab key={u.id} value={u.id} label={`${u.id} · ${u.title}`} sx={{ '&.Mui-selected': { color: UC_COLORS[u.id] } }} />
        ))}
      </Tabs>

      {list.error && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          {list.error} — the analyses need a running Neo4j database with the loaded graph (python -m app.kg run --step load).
        </Alert>
      )}

      {current && (
        <Box sx={{ mb: 2, p: 2, bgcolor: '#ffffff', border: '1px solid #e2e8f0', borderLeft: `4px solid ${color}`, borderRadius: 2 }}>
          <Typography variant="subtitle1" sx={{ fontWeight: 700, color: '#0f172a' }}>
            {current.title}
          </Typography>
          <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 600 }}>
            Business owner: {current.owner}
          </Typography>
          {current.summary && (
            <Typography variant="body2" sx={{ color: '#334155', mt: 0.5 }}>
              {current.summary}
            </Typography>
          )}
          {current.standards.length > 0 && (
            <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mt: 1 }}>
              {current.standards.map((s) => (
                <Chip key={s} size="small" variant="outlined" label={s} sx={{ height: 20, fontSize: '0.68rem' }} />
              ))}
            </Box>
          )}
        </Box>
      )}

      <AskLinks uc={active} />
      <View />
    </Box>
  );
};

export default UseCasesPage;
