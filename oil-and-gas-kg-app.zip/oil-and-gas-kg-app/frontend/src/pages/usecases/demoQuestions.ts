/**
 * Demo (Q1-Q15) and sample (S1-S5) questions of backend/user_questions/questions.yaml.
 * Asked verbatim on the Intelligence page they use the configured retriever, the answer subgraph and the
 * ground-truth fact check. Keep in sync with the YAML file.
 */

export interface DemoQuestion {
  id: string;
  uc: string;
  title: string;
  question: string;
  retriever: string;
}

export const DEMO_QUESTIONS: DemoQuestion[] = [
  {
    id: 'Q1',
    uc: 'UC1',
    title: 'One well across four registers',
    question: 'Show everything known about well Falcon Draw 10-1H across the exploration, drilling, production and asset registers: its API number in each register, the reservoir and formation it targets, its best well test and its reserves booking.',
    retriever: 'text2cypher',
  },
  {
    id: 'Q2',
    uc: 'UC1',
    title: 'Wells into a formation with tests and reserves',
    question: 'Which wellbores target the Wolfcamp A formation, what was the best oil rate of each well\'s tests, and what reserves category is booked?',
    retriever: 'text2cypher',
  },
  {
    id: 'Q3',
    uc: 'UC1',
    title: 'Well identity conflicts',
    question: 'Which production well records have an API number that does not match the drilling register for the same well name, and which production wells have no record in the asset register?',
    retriever: 'text2cypher',
  },
  {
    id: 'Q4',
    uc: 'UC2',
    title: 'NPT by category with lessons learned',
    question: 'Which non-productive time (NPT) categories cost the most rig hours and money, and what lesson was recorded for each?',
    retriever: 'text2cypher',
  },
  {
    id: 'Q5',
    uc: 'UC2',
    title: 'Offset-well risk brief for a planned well',
    question: 'Prepare an offset-well risk brief for the approved program WP-2026-022 (Red Mesa 13-4H into Wolfcamp B): which wells drilled into Wolfcamp B had kicks or NPT, and what lessons apply?',
    retriever: 'text2cypher',
  },
  {
    id: 'Q6',
    uc: 'UC2',
    title: 'Consequences of a kick',
    question: 'What happened after the kick on Red Mesa 12-2H? Trace the well control event to the HSE incident, regulatory violation, process safety event, NPT, flaring and production downtime it caused.',
    retriever: 'hybrid_cypher',
  },
  {
    id: 'Q7',
    uc: 'UC3',
    title: 'Failures preceded by an inspection finding',
    question: 'Which equipment failures were preceded by an inspection finding, how many days after the inspection did they fail, and what did they cost in repairs and deferred production?',
    retriever: 'text2cypher',
  },
  {
    id: 'Q8',
    uc: 'UC3',
    title: 'Bad-actor equipment',
    question: 'Rank the bad-actor equipment by number of failures, repair cost and deferred production, including drilling NPT caused by equipment.',
    retriever: 'text2cypher',
  },
  {
    id: 'Q9',
    uc: 'UC3',
    title: 'Overdue safety-critical inspections',
    question: 'Which safety-critical equipment is overdue for inspection as of 30 September 2026, and which inspections found equipment not fit for service?',
    retriever: 'text2cypher',
  },
  {
    id: 'Q10',
    uc: 'UC4',
    title: 'Story of the Tier 1 process safety event',
    question: 'Give the full story of the Tier 1 process safety event: equipment and facility, the permit to work, the investigation root cause, the corrective actions and their effectiveness, the spill and the regulatory violation.',
    retriever: 'hybrid_cypher',
  },
  {
    id: 'Q11',
    uc: 'UC4',
    title: 'Recurring root causes',
    question: 'Which root causes recur across incident investigations, at how many facilities, and were the corrective actions effective?',
    retriever: 'hybrid_cypher',
  },
  {
    id: 'Q12',
    uc: 'UC4',
    title: 'Incidents under an active permit to work',
    question: 'How many incidents happened while a permit to work was active, broken down by permit type?',
    retriever: 'text2cypher',
  },
  {
    id: 'Q13',
    uc: 'UC5',
    title: 'Custody transfer lineage',
    question: 'Trace custody transfer CT-2026-0815 back to the wells, allocations, meters and measurement points behind it, and check the allocated volume against the ticket.',
    retriever: 'text2cypher',
  },
  {
    id: 'Q14',
    uc: 'UC5',
    title: 'Facility emissions ranking',
    question: 'Rank facilities by CO2-equivalent emissions and show their flared gas volume and LDAR leaks found.',
    retriever: 'text2cypher',
  },
  {
    id: 'Q15',
    uc: 'UC5',
    title: 'Allocation variances and meter calibration',
    question: 'Which production allocations have an oil variance above 150 bbl, at which meters, and are those meters past their calibration due date?',
    retriever: 'text2cypher',
  },
  {
    id: 'S1',
    uc: 'UC1',
    title: 'Sidetracks',
    question: 'Which wellbores are sidetracks, why were they drilled and what is their parent wellbore?',
    retriever: 'hybrid_cypher',
  },
  {
    id: 'S2',
    uc: 'UC2',
    title: 'Salado stuck pipe',
    question: 'What went wrong in the Salado salt and what lessons were recorded?',
    retriever: 'vector_cypher',
  },
  {
    id: 'S3',
    uc: 'UC3',
    title: 'Similar failures',
    question: 'Which other equipment shows failures similar to the ESP-09 motor burnout?',
    retriever: 'hybrid_cypher',
  },
  {
    id: 'S4',
    uc: 'UC4',
    title: 'H2S exposure',
    question: 'Where did H2S alarms or exposures occur and what actions followed?',
    retriever: 'hybrid_cypher',
  },
  {
    id: 'S5',
    uc: 'UC5',
    title: 'Flaring reasons',
    question: 'Why was gas flared at Coyote Flats CTB-2 and Red Mesa CTB-1?',
    retriever: 'hybrid_cypher',
  },
];

export const questionsFor = (uc: string): DemoQuestion[] => DEMO_QUESTIONS.filter((q) => q.uc === uc);
