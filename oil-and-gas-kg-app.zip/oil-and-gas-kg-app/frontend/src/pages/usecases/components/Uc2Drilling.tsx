/**
 * UC2 Drilling performance & lessons learned: NPT by category and rig, offset-well risk briefs for planned
 * programs (wells into the same formation), and the consequence chains of well-control events.
 */

import React, { useState } from 'react';
import { Alert, Box, Chip, FormControl, Grid, InputLabel, MenuItem, Select, Typography } from '@mui/material';
import { useApi } from '../../../hooks/useApi';
import { useCaseApi } from '../../../services/api';
import { ResultSection } from './ResultSection';
import { DataTable } from '../../../components/common/DataTable';
import { getStatusColorInfo } from '../../graph/utils/relationshipUtils';
import { ProgramRow } from '../../../types/usecases';

export const Uc2Drilling: React.FC = () => {
  const [program, setProgram] = useState('WP-2026-022');
  const npt = useApi(() => useCaseApi.npt(), []);
  const programs = useApi(() => useCaseApi.programs(), []);
  const brief = useApi(() => useCaseApi.offsetBrief(program), [program], !!program);
  const chains = useApi(() => useCaseApi.wellControlChains(), []);
  const head = brief.data?.program;
  const programRows: ProgramRow[] = programs.data || [{ program, name: program, status: '' }];

  return (
    <Box>
      <Grid container spacing={2.5}>
        <Grid item xs={12} md={7}>
          <ResultSection
            title="Non-productive time by category (IADC NPT codes)"
            subtitle="Hours, cost, preventable share and a recorded lesson for each category."
            loading={npt.loading}
            error={npt.error}
            onRefresh={npt.refresh}
            rows={npt.data?.by_category.rows}
            cypher={npt.data?.by_category.cypher}
          />
        </Grid>
        <Grid item xs={12} md={5}>
          <ResultSection
            title="NPT by rig"
            loading={npt.loading}
            error={npt.error}
            rows={npt.data?.by_rig.rows}
            cypher={npt.data?.by_rig.cypher}
          />
        </Grid>
      </Grid>

      <ResultSection
        title="Offset-well risk brief for a planned well program"
        subtitle="Programs have no well yet: offsets are the wellbores drilled into the same target formation; their kicks, NPT and cement issues follow DRILLING_WELL links."
        loading={brief.loading}
        error={brief.error}
        rows={brief.data?.rows}
        cypher={brief.data?.cypher}
        columns={['offset_well', 'spud_date', 'well_control', 'npt', 'npt_hours', 'cement_issues']}
        action={
          <FormControl size="small" sx={{ minWidth: 300 }}>
            <InputLabel id="uc2-program">Well program</InputLabel>
            <Select labelId="uc2-program" label="Well program" value={program} onChange={(e) => setProgram(e.target.value)}>
              {programRows.map((p) => (
                <MenuItem key={p.program} value={p.program}>
                  {p.program} · {p.name?.replace('Drilling and completion program - ', '')} {p.formation ? `· ${p.formation}` : ''}{' '}
                  {p.status ? `(${p.status})` : ''}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        }
      >
        {head && (
          <Box sx={{ mb: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>
            <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', alignItems: 'center' }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
                {head.name}
              </Typography>
              {head.status && (
                <Chip
                  size="small"
                  label={head.status}
                  sx={{ height: 20, bgcolor: getStatusColorInfo(head.status).bg, color: getStatusColorInfo(head.status).text }}
                />
              )}
              {head.formation && <Chip size="small" label={`Target: ${head.formation}`} sx={{ height: 20 }} />}
              {head.prospect && <Chip size="small" label={`Prospect: ${head.prospect}`} sx={{ height: 20 }} />}
              {head.planned_max_mw_ppg && <Chip size="small" label={`Max MW ${head.planned_max_mw_ppg} ppg`} sx={{ height: 20 }} />}
            </Box>
            {head.hazard_notes && (
              <Alert severity="warning" sx={{ py: 0.5 }}>
                Formation hazard notes: {head.hazard_notes}
              </Alert>
            )}
            {brief.data && brief.data.lessons.length > 0 && (
              <>
                <Typography variant="caption" sx={{ fontWeight: 700, color: '#475569' }}>
                  Lessons recorded in offset wells (by NPT category)
                </Typography>
                <DataTable rows={brief.data.lessons} maxHeight={220} />
              </>
            )}
          </Box>
        )}
      </ResultSection>

      <ResultSection
        title="Consequences of well-control events"
        subtitle="Kick → HSE incident, regulatory violation, process safety event, NPT, flaring and SIMOPS downtime."
        loading={chains.loading}
        error={chains.error}
        onRefresh={chains.refresh}
        rows={chains.data?.rows}
        cypher={chains.data?.cypher}
        graph={chains.data?.graph}
      />
    </Box>
  );
};

export default Uc2Drilling;
