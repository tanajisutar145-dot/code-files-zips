/**
 * UC5 Production-to-market & emissions traceability: custody transfer lineage back to wells, allocations,
 * meters and measurement points; facility emissions with flaring and LDAR; allocation variances vs meter calibration.
 */

import React, { useState } from 'react';
import { Alert, Box, Chip, Grid, Slider, Typography } from '@mui/material';
import { useApi } from '../../../hooks/useApi';
import { useCaseApi } from '../../../services/api';
import { ResultSection } from './ResultSection';
import { formatPropertyLabel, formatPropertyValue } from '../../graph/utils/relationshipUtils';

export const Uc5Traceability: React.FC = () => {
  const [ref, setRef] = useState('CT-2026-0815');
  const [threshold, setThreshold] = useState(150);
  const transfers = useApi(() => useCaseApi.custodyTransfers(), []);
  const lineage = useApi(() => useCaseApi.lineage(ref), [ref], !!ref);
  const emissions = useApi(() => useCaseApi.emissions(), []);
  const variance = useApi(() => useCaseApi.allocationVariance(threshold), [threshold]);
  const t = lineage.data?.transfer;
  const rec = lineage.data?.reconciliation;

  return (
    <Box>
      <Grid container spacing={2.5}>
        <Grid item xs={12} lg={5}>
          <ResultSection
            title="Custody transfers (API MPMS)"
            subtitle="Click a ticket to trace it back to the wells."
            loading={transfers.loading}
            error={transfers.error}
            onRefresh={transfers.refresh}
            rows={transfers.data?.rows}
            cypher={transfers.data?.cypher}
            onRowClick={(r) => setRef(r.transfer)}
            maxHeight={560}
          />
        </Grid>
        <Grid item xs={12} lg={7}>
          <ResultSection
            title={`Lineage of ${ref}`}
            subtitle="Custody transfer ← production allocations ← wells (API identity), meters and measurement points; allocated volume reconciled with the ticket."
            loading={lineage.loading}
            error={lineage.error}
            rows={lineage.data?.rows}
            cypher={lineage.data?.cypher}
            graph={lineage.data?.graph}
            graphHeight={420}
          >
            {t && (
              <Box sx={{ display: 'flex', gap: 0.75, flexWrap: 'wrap', mb: 1.5 }}>
                {['transfer_date', 'delivery_point', 'crude_grade', 'api_gravity', 'gov', 'gsv', 'nsv', 'bsw_pct', 'ticket']
                  .filter((k) => t[k] !== null && t[k] !== undefined)
                  .map((k) => (
                    <Chip key={k} size="small" label={`${formatPropertyLabel(k)}: ${formatPropertyValue(k, t[k])}`} sx={{ height: 22, fontSize: '0.72rem' }} />
                  ))}
              </Box>
            )}
            {rec && (
              <Alert severity={rec.difference_pct !== null && Math.abs(rec.difference_pct) <= 1 ? 'success' : 'warning'} sx={{ mb: 1.5 }}>
                Allocated gross oil {rec.allocated_gross_oil_bbl.toLocaleString('en-US', { maximumFractionDigits: 1 })} bbl vs ticket gross
                observed volume {rec.ticket_gov.toLocaleString('en-US')} bbl
                {rec.difference_pct !== null ? ` · difference ${rec.difference_pct}%` : ''}
                {t?.bsw_pct ? ` (BS&W ${t.bsw_pct}%)` : ''}.
              </Alert>
            )}
          </ResultSection>
        </Grid>
      </Grid>

      <Grid container spacing={2.5}>
        <Grid item xs={12} md={6}>
          <ResultSection
            title="Facility emissions, flaring and LDAR (EPA Subpart W / OGMP 2.0)"
            subtitle="GHG emissions are reported on the asset-register facility; flaring and LDAR on the production facility, joined by the derived SAME_FACILITY_AS identity."
            loading={emissions.loading}
            error={emissions.error}
            rows={emissions.data?.rows}
            cypher={emissions.data?.cypher}
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <ResultSection
            title="Allocation variances and meter calibration"
            loading={variance.loading}
            error={variance.error}
            rows={variance.data?.rows}
            cypher={variance.data?.cypher}
            emptyText="No allocation above the threshold."
          >
            <Box sx={{ px: 1, mb: 1 }}>
              <Typography variant="caption" sx={{ color: '#475569' }}>
                Oil variance threshold: <strong>{threshold} bbl</strong>
                {variance.data ? ` · calibration checked as of ${variance.data.as_of}` : ''}
              </Typography>
              <Slider
                size="small"
                value={threshold}
                min={0}
                max={500}
                step={25}
                onChangeCommitted={(_, v) => setThreshold(v as number)}
                sx={{ color: '#54A24B', maxWidth: 360 }}
              />
            </Box>
          </ResultSection>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Uc5Traceability;
