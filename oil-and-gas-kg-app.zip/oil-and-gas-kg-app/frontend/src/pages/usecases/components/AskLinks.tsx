/**
 * Buttons that open a demo question of the use case on the Intelligence page.
 */

import React from 'react';
import { Box, Button, Tooltip, Typography } from '@mui/material';
import { Psychology as AskIcon } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { questionsFor } from '../demoQuestions';

export const AskLinks: React.FC<{ uc: string }> = ({ uc }) => {
  const navigate = useNavigate();
  const questions = questionsFor(uc);
  if (questions.length === 0) return null;
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap', mb: 2 }}>
      <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 700 }}>
        Ask with GraphRAG:
      </Typography>
      {questions.map((q) => (
        <Tooltip key={q.id} title={q.question}>
          <Button
            size="small"
            variant="outlined"
            startIcon={<AskIcon sx={{ fontSize: 16 }} />}
            onClick={() => navigate(`/intelligence?q=${encodeURIComponent(q.question)}`)}
            sx={{ textTransform: 'none', fontSize: '0.75rem', borderColor: '#cbd5e1', color: '#334155' }}
          >
            {q.id} · {q.title}
          </Button>
        </Tooltip>
      ))}
    </Box>
  );
};

export default AskLinks;
