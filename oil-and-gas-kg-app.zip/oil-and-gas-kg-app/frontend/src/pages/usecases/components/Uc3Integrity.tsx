/**
 * UC3 Asset integrity & reliability: failures preceded by an inspection finding, bad actors and repeat
 * failures, overdue safety-critical inspections, and the ISO 14224 functional-location hierarchy.
 */

import React, { useState } from 'react';
import { Box, Chip, FormControl, Grid, InputLabel, MenuItem, Select, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useApi } from '../../../hooks/useApi';
import { useCaseApi } from '../../../services/api';
import { ResultSection } from './ResultSection';

// Asset-register facility codes (asset.asset_facility.facility_code); '' = whole hierarchy
const FACILITIES = ['', 'FD-CTB1', 'FD-CTB2', 'RM-CTB1', 'RM-CTB2', 'CF-CTB1', 'CF-CTB2', 'SR-CTB1', 'MB-CTB1', 'LB-GB1', 'MJ-CS1', 'PT-TRM1'];

export const Uc3Integrity: React.FC = () => {
  const navigate = useNavigate();
  const [facility, setFacility] = useState('');
  const precursors = useApi(() => useCaseApi.precursors(), []);
  const badActors = useApi(() => useCaseApi.badActors(), []);
  const overdue = useApi(() => useCaseApi.overdue(), []);
  const hierarchy = useApi(() => useCaseApi.hierarchy(facility || undefined), [facility]);
  const openEquipment = (row: Record<string, any>) => row.tag && navigate(`/assets?search=${encodeURIComponent(row.tag)}`);

  return (
    <Box>
      <ResultSection
        title="Failures preceded by an inspection finding"
        subtitle="Inspection → failure → work order → production downtime; days between the finding and the failure."
        loading={precursors.loading}
        error={precursors.error}
        onRefresh={precursors.refresh}
        rows={precursors.data?.rows}
        cypher={precursors.data?.cypher}
        graph={precursors.data?.graph}
      />

      <Grid container spacing={2.5}>
        <Grid item xs={12} md={7}>
          <ResultSection
            title="Bad-actor equipment"
            subtitle="Two or more failures, or two or more drilling NPT events caused by the equipment. Click a row to open the equipment record."
            loading={badActors.loading}
            error={badActors.error}
            rows={badActors.data?.rows}
            cypher={badActors.data?.cypher}
            onRowClick={openEquipment}
          >
            {badActors.data && badActors.data.recurrence_chains.length > 0 && (
              <Box sx={{ mb: 1.5, display: 'flex', flexDirection: 'column', gap: 0.75 }}>
                <Typography variant="caption" sx={{ fontWeight: 700, color: '#475569' }}>
                  Repeat-failure chains (PREVIOUS_FAILURE_REPORT)
                </Typography>
                {badActors.data.recurrence_chains.map((c, i) => (
                  <Box key={i} sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', alignItems: 'center' }}>
                    <Chip size="small" label={c.tag} sx={{ height: 20, fontWeight: 700, bgcolor: '#B279A2', color: '#fff' }} />
                    {c.failure_chain.map((f, j) => (
                      <React.Fragment key={j}>
                        {j > 0 && <Typography variant="caption">→</Typography>}
                        <Chip size="small" variant="outlined" label={f} sx={{ height: 20, fontSize: '0.68rem' }} />
                      </React.Fragment>
                    ))}
                  </Box>
                ))}
              </Box>
            )}
          </ResultSection>
        </Grid>
        <Grid item xs={12} md={5}>
          <ResultSection
            title={`Safety-critical equipment overdue for inspection${overdue.data ? ` (as of ${overdue.data.as_of})` : ''}`}
            loading={overdue.loading}
            error={overdue.error}
            rows={overdue.data?.overdue.rows}
            cypher={overdue.data?.overdue.cypher}
            onRowClick={openEquipment}
          />
          <ResultSection
            title="Inspections with a not-fit-for-service result"
            loading={overdue.loading}
            error={overdue.error}
            rows={overdue.data?.not_fit_for_service.rows}
            cypher={overdue.data?.not_fit_for_service.cypher}
            onRowClick={openEquipment}
          />
        </Grid>
      </Grid>

      <ResultSection
        title="ISO 14224 functional-location hierarchy"
        subtitle="Derived CHILD_OF / LOCATES links: installation → plant/unit → section/system → equipment unit, with failures per located item."
        loading={hierarchy.loading}
        error={hierarchy.error}
        rows={hierarchy.data?.rows}
        cypher={hierarchy.data?.cypher}
        maxHeight={480}
        action={
          <FormControl size="small" sx={{ minWidth: 170 }}>
            <InputLabel id="uc3-fac">Facility</InputLabel>
            <Select labelId="uc3-fac" label="Facility" value={facility} onChange={(e) => setFacility(e.target.value)}>
              {FACILITIES.map((f) => (
                <MenuItem key={f || 'all'} value={f}>
                  {f || 'All facilities'}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        }
      />
    </Box>
  );
};

export default Uc3Integrity;
