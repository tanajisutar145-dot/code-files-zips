/**
 * A use-case analysis card: loading / error states, the result table, the Cypher that produced it
 * and (optionally) its evidence graph.
 */

import React from 'react';
import { Alert, Box, CircularProgress, IconButton, Tooltip } from '@mui/material';
import { Refresh as RefreshIcon } from '@mui/icons-material';
import { SectionCard } from '../../../components/common/SectionCard';
import { DataTable, DataColumn } from '../../../components/common/DataTable';
import { CypherPanel } from '../../../components/common/CypherPanel';
import { EvidenceGraph } from '../../../components/common/EvidenceGraph';
import { VisGraph } from '../../../types/api';

interface ResultSectionProps {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  loading: boolean;
  error: string | null;
  rows?: Record<string, any>[];
  columns?: (DataColumn | string)[];
  cypher?: string | null;
  graph?: VisGraph | null;
  graphHeight?: number;
  onRefresh?: () => void;
  onRowClick?: (row: Record<string, any>) => void;
  maxHeight?: number;
  emptyText?: string;
  children?: React.ReactNode;
  action?: React.ReactNode;
}

export const ResultSection: React.FC<ResultSectionProps> = ({
  title,
  subtitle,
  loading,
  error,
  rows,
  columns,
  cypher,
  graph,
  graphHeight = 360,
  onRefresh,
  onRowClick,
  maxHeight,
  emptyText,
  children,
  action,
}) => (
  <SectionCard
    title={title}
    subtitle={subtitle}
    action={
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        {action}
        {onRefresh && (
          <Tooltip title="Re-run">
            <span>
              <IconButton size="small" onClick={onRefresh} disabled={loading}>
                {loading ? <CircularProgress size={16} /> : <RefreshIcon fontSize="small" />}
              </IconButton>
            </span>
          </Tooltip>
        )}
      </Box>
    }
  >
    {error && (
      <Alert severity="error" sx={{ mb: 1.5 }}>
        {error}
      </Alert>
    )}
    {loading && !rows && (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 3 }}>
        <CircularProgress size={26} />
      </Box>
    )}
    {children}
    {rows && <DataTable rows={rows} columns={columns} onRowClick={onRowClick} maxHeight={maxHeight} emptyText={emptyText} />}
    {graph && graph.nodes && graph.nodes.length > 0 && (
      <Box sx={{ mt: 2 }}>
        <EvidenceGraph graph={graph} height={graphHeight} />
      </Box>
    )}
    <CypherPanel cypher={cypher} />
  </SectionCard>
);

export default ResultSection;
