/**
 * UC1 Well & subsurface 360 / well identity: one physical well (PPDM API-10) across the exploration,
 * drilling, production and asset registers, identity data-quality findings, and wells by formation.
 */

import React, { useState } from 'react';
import { Box, Chip, FormControl, Grid, InputLabel, MenuItem, Select, TextField, Typography } from '@mui/material';
import { useApi } from '../../../hooks/useApi';
import { useCaseApi } from '../../../services/api';
import { ResultSection } from './ResultSection';
import { DataTable } from '../../../components/common/DataTable';
import { SectionCard } from '../../../components/common/SectionCard';
import { EvidenceGraph } from '../../../components/common/EvidenceGraph';
import { CypherPanel } from '../../../components/common/CypherPanel';
import { WellRow } from '../../../types/usecases';

const RegisterChips: React.FC<{ row: WellRow }> = ({ row }) => (
  <Box sx={{ display: 'flex', gap: 0.5 }}>
    {[
      ['E', row.in_exploration, 'Exploration register'],
      ['D', row.in_drilling, 'Drilling register'],
      ['P', row.in_production, 'Production register'],
      ['A', row.in_asset, 'Asset register'],
    ].map(([k, on, title]) => (
      <Chip
        key={String(k)}
        size="small"
        label={String(k)}
        title={String(title)}
        sx={{ height: 18, width: 22, fontSize: '0.65rem', fontWeight: 700, bgcolor: on ? '#1F77B4' : '#f1f5f9', color: on ? '#fff' : '#cbd5e1' }}
      />
    ))}
  </Box>
);

export const Uc1WellIdentity: React.FC = () => {
  const [selected, setSelected] = useState<string | null>('4238940000');
  const [filter, setFilter] = useState('');
  const [formation, setFormation] = useState('Wolfcamp A');

  const wells = useApi(() => useCaseApi.wells(), []);
  const well = useApi(() => useCaseApi.well360(selected as string), [selected], !!selected);
  const issues = useApi(() => useCaseApi.identityIssues(), []);
  const byFormation = useApi(() => useCaseApi.formationWells(formation), [formation]);

  const rows = (wells.data?.rows || []).filter(
    (r) => !filter || `${r.well_name} ${r.api} ${r.field || ''} ${r.target_formation || ''}`.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <Box>
      <Grid container spacing={2.5}>
        <Grid item xs={12} lg={5}>
          <ResultSection
            title="Physical wells (PPDM API-10 identity hub)"
            subtitle={
              wells.data
                ? `${wells.data.count} wells · ${wells.data.complete_identities} present in drilling, production and asset registers · click a row for the 360 view`
                : 'Every register record is linked to one WellIdentity per API-10 core.'
            }
            loading={wells.loading}
            error={wells.error}
            onRefresh={wells.refresh}
            cypher={wells.data?.cypher}
            maxHeight={560}
            action={
              <TextField size="small" placeholder="Filter" value={filter} onChange={(e) => setFilter(e.target.value)} sx={{ width: 140 }} />
            }
          >
            {wells.data && (
              <DataTable
                rows={rows}
                maxHeight={560}
                onRowClick={(r) => setSelected(r.api10)}
                columns={[
                  { key: 'well_name', label: 'Well' },
                  { key: 'api', label: 'API' },
                  { key: 'registers', label: 'Registers', render: (_, r) => <RegisterChips row={r as WellRow} /> },
                  { key: 'wellbores' },
                  { key: 'target_formation', label: 'Formation' },
                  { key: 'asset_status', label: 'Status' },
                ]}
              />
            )}
          </ResultSection>
        </Grid>

        <Grid item xs={12} lg={7}>
          <SectionCard
            title={well.data?.found ? `Well 360 · ${well.data.records[0]?.name || selected}` : 'Well 360'}
            subtitle="Records of the same physical well in each register, subsurface context, tests, reserves, drilling events, production and HSE."
          >
            {well.error && <Typography color="error">{well.error}</Typography>}
            {!selected && <Typography variant="body2">Select a well.</Typography>}
            {well.data?.found && (
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <DataTable rows={well.data.records} />
                <Typography variant="caption" sx={{ fontWeight: 700, color: '#475569' }}>
                  Wellbores and subsurface context (basin, play, prospect, reservoir, formation, rig)
                </Typography>
                <DataTable rows={well.data.wellbores} />
                <Grid container spacing={2}>
                  <Grid item xs={12} md={7}>
                    <Typography variant="caption" sx={{ fontWeight: 700, color: '#475569' }}>Well tests</Typography>
                    <DataTable rows={well.data.tests} emptyText="No well tests." maxHeight={220} />
                  </Grid>
                  <Grid item xs={12} md={5}>
                    <Typography variant="caption" sx={{ fontWeight: 700, color: '#475569' }}>Reserves (SPE-PRMS)</Typography>
                    <DataTable rows={well.data.reserves} emptyText="No reserves booking." maxHeight={220} />
                  </Grid>
                </Grid>
                <Typography variant="caption" sx={{ fontWeight: 700, color: '#475569' }}>Drilling events</Typography>
                <DataTable rows={well.data.drilling_events} emptyText="No drilling events." maxHeight={220} />
                <Grid container spacing={2}>
                  <Grid item xs={12} md={7}>
                    <Typography variant="caption" sx={{ fontWeight: 700, color: '#475569' }}>Production</Typography>
                    <DataTable
                      rows={well.data.production.map((p) => ({ ...p, allocations: (p.allocations || []).filter((a: any) => a.month).length }))}
                      emptyText="Not in the production register."
                    />
                  </Grid>
                  <Grid item xs={12} md={5}>
                    <Typography variant="caption" sx={{ fontWeight: 700, color: '#475569' }}>HSE records</Typography>
                    <DataTable rows={well.data.hse} emptyText="No HSE records." />
                  </Grid>
                </Grid>
                <EvidenceGraph graph={well.data.graph} height={380} />
                <CypherPanel cypher={well.data.cypher?.context} title="context Cypher" />
              </Box>
            )}
          </SectionCard>
        </Grid>
      </Grid>

      <Grid container spacing={2.5}>
        <Grid item xs={12} md={6}>
          <ResultSection
            title="API conflicts between registers"
            subtitle="Same well name, different API-10 (derived NAME_MATCH_API_CONFLICT): likely a mistyped API number."
            loading={issues.loading}
            error={issues.error}
            rows={issues.data?.api_conflicts.rows}
            cypher={issues.data?.api_conflicts.cypher}
            emptyText="No conflicts."
          />
          <ResultSection
            title="Production wells without an asset-register record"
            loading={issues.loading}
            error={issues.error}
            rows={issues.data?.production_without_asset.rows}
            cypher={issues.data?.production_without_asset.cypher}
            emptyText="Every production well has an asset record."
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <ResultSection
            title="Name aliases (same API, different well name)"
            loading={issues.loading}
            error={issues.error}
            rows={issues.data?.name_aliases.rows}
            cypher={issues.data?.name_aliases.cypher}
            emptyText="No aliases."
          />
          <ResultSection
            title="Wells known to a single register"
            loading={issues.loading}
            error={issues.error}
            rows={issues.data?.single_register.rows}
            cypher={issues.data?.single_register.cypher}
            maxHeight={260}
            emptyText="None."
          />
        </Grid>
      </Grid>

      <ResultSection
        title="Wellbores by target formation"
        subtitle="Best well-test oil rate and SPE-PRMS reserves category of each wellbore drilled into the formation."
        loading={byFormation.loading}
        error={byFormation.error}
        rows={byFormation.data?.rows}
        cypher={byFormation.data?.cypher}
        action={
          <FormControl size="small" sx={{ minWidth: 180 }}>
            <InputLabel id="uc1-formation">Formation</InputLabel>
            <Select labelId="uc1-formation" label="Formation" value={formation} onChange={(e) => setFormation(e.target.value)}>
              {(byFormation.data?.formations || [formation]).map((f) => (
                <MenuItem key={f} value={f}>
                  {f}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        }
      />
    </Box>
  );
};

export default Uc1WellIdentity;
