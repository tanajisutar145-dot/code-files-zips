/**
 * UC4 HSE & process-safety incident intelligence: process safety events (API RP 754 tiers) with the full
 * story of each event, recurring root causes across investigations, and incidents under a permit to work.
 */

import React, { useState } from 'react';
import { Alert, Box, Chip, Grid, Typography } from '@mui/material';
import { useApi } from '../../../hooks/useApi';
import { useCaseApi } from '../../../services/api';
import { ResultSection } from './ResultSection';
import { SectionCard } from '../../../components/common/SectionCard';
import { DataTable } from '../../../components/common/DataTable';
import { EvidenceGraph } from '../../../components/common/EvidenceGraph';
import { formatPropertyLabel, formatPropertyValue, getStatusColorInfo } from '../../graph/utils/relationshipUtils';

export const Uc4Hse: React.FC = () => {
  const [pse, setPse] = useState('PSE-2026-001');
  const list = useApi(() => useCaseApi.pseList(), []);
  const story = useApi(() => useCaseApi.pseStory(pse), [pse], !!pse);
  const rootCauses = useApi(() => useCaseApi.rootCauses(), []);
  const ptw = useApi(() => useCaseApi.ptwIncidents(), []);
  const ev = story.data?.event;

  return (
    <Box>
      <Grid container spacing={2.5}>
        <Grid item xs={12} lg={5}>
          <ResultSection
            title="Process safety events (API RP 754 / IOGP 456)"
            subtitle="Click an event for its full story."
            loading={list.loading}
            error={list.error}
            onRefresh={list.refresh}
            rows={list.data?.rows}
            cypher={list.data?.cypher}
            columns={['pse', 'tier', 'event_type', 'event_date', 'location', 'equipment', 'release_quantity', 'unit']}
            onRowClick={(r) => setPse(r.pse)}
            maxHeight={620}
          />
        </Grid>
        <Grid item xs={12} lg={7}>
          <SectionCard
            title={ev ? `${ev.pse} · ${ev.tier} · ${ev.facility || ev.equipment || ''}` : `Process safety event ${pse}`}
            subtitle="Equipment and facility, incident and permit to work, investigation root cause, corrective actions (CAPA) and their effectiveness, spill and violation."
          >
            {story.error && <Alert severity="error">{story.error}</Alert>}
            {ev && (
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                <Box sx={{ display: 'flex', gap: 0.75, flexWrap: 'wrap' }}>
                  {['event_type', 'release_quantity', 'equipment', 'safety_system', 'violation', 'regulation', 'penalty_usd', 'regulator']
                    .filter((k) => ev[k] !== null && ev[k] !== undefined && ev[k] !== '')
                    .map((k) => (
                      <Chip
                        key={k}
                        size="small"
                        label={`${formatPropertyLabel(k)}: ${k === 'release_quantity' ? `${ev[k]} ${ev.unit || ''}` : formatPropertyValue(k, ev[k])}`}
                        sx={{ height: 22, fontSize: '0.72rem' }}
                      />
                    ))}
                </Box>
                {ev.immediate_cause && (
                  <Typography variant="body2" sx={{ color: '#334155' }}>
                    <strong>Immediate cause:</strong> {ev.immediate_cause}
                  </Typography>
                )}
                {ev.safety_system_response && (
                  <Typography variant="body2" sx={{ color: '#334155' }}>
                    <strong>Safety system response:</strong> {ev.safety_system_response}
                  </Typography>
                )}
                <Typography variant="caption" sx={{ fontWeight: 700, color: '#475569' }}>Incidents and permits to work</Typography>
                <DataTable rows={story.data?.incidents || []} emptyText="No linked incident." />
                <Typography variant="caption" sx={{ fontWeight: 700, color: '#475569' }}>Investigations</Typography>
                <DataTable rows={story.data?.investigations || []} emptyText="No investigation." />
                <Typography variant="caption" sx={{ fontWeight: 700, color: '#475569' }}>Corrective actions</Typography>
                <DataTable
                  rows={story.data?.corrective_actions || []}
                  emptyText="No corrective action."
                  columns={[
                    'action',
                    'type',
                    'description',
                    'status',
                    {
                      key: 'effectiveness',
                      render: (v) =>
                        v ? (
                          <Chip
                            size="small"
                            label={formatPropertyValue('effectiveness', v)}
                            sx={{ height: 20, fontSize: '0.68rem', bgcolor: getStatusColorInfo(v).bg, color: getStatusColorInfo(v).text }}
                          />
                        ) : (
                          '—'
                        ),
                    },
                    'follows_up',
                  ]}
                />
                <Typography variant="caption" sx={{ fontWeight: 700, color: '#475569' }}>All records pointing at the event</Typography>
                <DataTable rows={story.data?.related_records || []} maxHeight={200} />
                <EvidenceGraph graph={story.data?.graph} height={400} />
              </Box>
            )}
          </SectionCard>
        </Grid>
      </Grid>

      <Grid container spacing={2.5}>
        <Grid item xs={12} md={7}>
          <ResultSection
            title="Recurring root causes across investigations"
            subtitle="Grouped by the first clause of the root-cause statement; facilities affected and corrective actions reviewed as ineffective."
            loading={rootCauses.loading}
            error={rootCauses.error}
            rows={rootCauses.data?.rows}
            cypher={rootCauses.data?.cypher}
          />
        </Grid>
        <Grid item xs={12} md={5}>
          <ResultSection
            title="Incidents under an active permit to work"
            subtitle={
              ptw.data?.totals?.incidents
                ? `${ptw.data.totals.under_ptw} of ${ptw.data.totals.incidents} incidents happened under a permit to work.`
                : undefined
            }
            loading={ptw.loading}
            error={ptw.error}
            rows={ptw.data?.rows}
            cypher={ptw.data?.cypher}
          />
        </Grid>
      </Grid>
    </Box>
  );
};

export default Uc4Hse;
