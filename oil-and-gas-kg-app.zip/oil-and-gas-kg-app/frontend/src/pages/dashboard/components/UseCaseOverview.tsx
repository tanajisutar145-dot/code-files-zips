import React from 'react';
import { Box, Card, CardContent, Chip, Typography, Button } from '@mui/material';
import { Insights as UseCaseIcon, ArrowForward as ArrowForwardIcon, Lightbulb as HighlightIcon } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { DashboardHighlight, UseCaseSummary } from '../../../types/dashboard';
import { formatPropertyLabel, formatPropertyValue } from '../../graph/utils/relationshipUtils';

interface UseCaseOverviewProps {
  useCases: UseCaseSummary[];
  highlights: DashboardHighlight[];
}

export const UC_COLORS: Record<string, string> = {
  UC1: '#1F77B4',
  UC2: '#E45756',
  UC3: '#B279A2',
  UC4: '#F58518',
  UC5: '#54A24B',
};

export const UseCaseOverview: React.FC<UseCaseOverviewProps> = ({ useCases, highlights }) => {
  const navigate = useNavigate();

  return (
    <Box sx={{ mb: 3 }}>
      <Typography
        variant="h6"
        sx={{ fontWeight: 700, color: '#0f172a', mb: 1.5, display: 'flex', alignItems: 'center', gap: 1, fontSize: '1.125rem' }}
      >
        <UseCaseIcon sx={{ color: '#0f766e', fontSize: 22 }} />
        Knowledge-Graph Use Cases
      </Typography>

      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(2, 1fr)', xl: 'repeat(5, 1fr)' }, gap: 2 }}>
        {useCases.map((uc) => {
          const color = UC_COLORS[uc.id] || '#0f766e';
          const highlight = highlights.find((h) => h.use_case === uc.id);
          const kpis = Object.entries(uc.kpis || {}).filter(([k]) => k !== 'error');
          return (
            <Card
              key={uc.id}
              sx={{
                bgcolor: '#ffffff',
                borderRadius: 2,
                border: '1px solid #e2e8f0',
                borderTop: `4px solid ${color}`,
                boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)',
                display: 'flex',
                flexDirection: 'column',
              }}
            >
              <CardContent sx={{ p: 2, flexGrow: 1, display: 'flex', flexDirection: 'column', gap: 1 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Chip label={uc.id} size="small" sx={{ bgcolor: color, color: '#fff', fontWeight: 700, height: 20, fontSize: '0.7rem' }} />
                  <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 600 }}>
                    {uc.owner}
                  </Typography>
                </Box>
                <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#0f172a', lineHeight: 1.3 }}>
                  {uc.title}
                </Typography>
                <Typography variant="caption" sx={{ color: '#475569', lineHeight: 1.45 }}>
                  {uc.summary}
                </Typography>

                {kpis.length > 0 ? (
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.75, mt: 0.5 }}>
                    {kpis.map(([k, v]) => (
                      <Box key={k} sx={{ px: 1, py: 0.5, bgcolor: '#f8fafc', border: '1px solid #f1f5f9', borderRadius: 1 }}>
                        <Typography variant="caption" sx={{ display: 'block', color: '#94a3b8', fontSize: '0.65rem' }}>
                          {formatPropertyLabel(k)}
                        </Typography>
                        <Typography variant="caption" sx={{ fontWeight: 700, color: '#0f172a' }}>
                          {typeof v === 'number' && !k.endsWith('_usd') ? v.toLocaleString('en-US') : formatPropertyValue(k, v)}
                        </Typography>
                      </Box>
                    ))}
                  </Box>
                ) : (
                  <Typography variant="caption" sx={{ color: '#b45309' }}>
                    Load the graph to see live figures.
                  </Typography>
                )}

                {highlight && (
                  <Box sx={{ display: 'flex', gap: 0.75, p: 1, bgcolor: '#fffbeb', border: '1px solid #fde68a', borderRadius: 1.5, mt: 0.5 }}>
                    <HighlightIcon sx={{ fontSize: 16, color: '#d97706', mt: 0.1 }} />
                    <Typography variant="caption" sx={{ color: '#92400e', lineHeight: 1.4 }}>
                      {highlight.text}
                    </Typography>
                  </Box>
                )}

                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mt: 'auto', pt: 1 }}>
                  {uc.standards.slice(0, 3).map((s) => (
                    <Chip key={s} label={s} size="small" variant="outlined" sx={{ height: 18, fontSize: '0.62rem' }} />
                  ))}
                </Box>
                <Button
                  size="small"
                  endIcon={<ArrowForwardIcon sx={{ fontSize: 14 }} />}
                  onClick={() => navigate(`/usecases/${uc.id}`)}
                  sx={{ alignSelf: 'flex-start', textTransform: 'none', fontWeight: 600, color, px: 0 }}
                >
                  Open use case
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </Box>
    </Box>
  );
};
