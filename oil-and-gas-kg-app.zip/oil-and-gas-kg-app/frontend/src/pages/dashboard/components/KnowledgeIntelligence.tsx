import React from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Chip,
} from '@mui/material';
import {
  AccountTree as GraphIcon,
  Description as DocumentIcon,
  ArrowForward as ArrowForwardIcon,
  CheckCircle as CheckIcon,
  Hub as HubIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { DashboardGraphStats, DashboardDocumentStats } from '../../../types/dashboard';
import { getDomainColor } from '../../graph/utils/graphStyles';

interface KnowledgeIntelligenceProps {
  graph: DashboardGraphStats;
  documents: DashboardDocumentStats;
}

export const KnowledgeIntelligence: React.FC<KnowledgeIntelligenceProps> = ({
  graph,
  documents,
}) => {
  const navigate = useNavigate();

  return (
    <Box sx={{ mb: 3 }}>
      <Typography
        variant="h6"
        sx={{
          fontWeight: 700,
          color: '#0f172a',
          mb: 1.5,
          display: 'flex',
          alignItems: 'center',
          gap: 1,
          fontSize: '1.125rem',
        }}
      >
        <GraphIcon sx={{ color: '#0f766e', fontSize: 22 }} />
        Knowledge Intelligence
      </Typography>

      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', md: 'repeat(2, 1fr)' },
          gap: 2,
        }}
      >
        {/* Card 1: Knowledge Graph Structure */}
        <Card
          sx={{
            bgcolor: '#ffffff',
            borderRadius: 2,
            border: '1px solid #e2e8f0',
            boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          <CardContent sx={{ p: 2.5, flexGrow: 1 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <Box
                  sx={{
                    width: 32,
                    height: 32,
                    borderRadius: '8px',
                    bgcolor: '#f0fdfa',
                    color: '#0f766e',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <HubIcon sx={{ fontSize: 18 }} />
                </Box>
                <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#1e293b', fontSize: '0.9rem' }}>
                  Neo4j Graph Topology
                </Typography>
              </Box>

              <Chip
                label="Property Graph"
                size="small"
                sx={{ bgcolor: '#f1f5f9', color: '#475569', fontSize: '0.7rem', fontWeight: 600, height: 22 }}
              />
            </Box>

            {/* Metrics Grid */}
            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: 'repeat(2, 1fr)',
                gap: 1.5,
                mb: 2.5,
              }}
            >
              <Box sx={{ p: 1.5, bgcolor: '#f8fafc', borderRadius: 1.5, border: '1px solid #f1f5f9' }}>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.72rem', display: 'block' }}>
                  Total Graph Nodes
                </Typography>
                <Typography variant="h5" sx={{ fontWeight: 700, color: '#0f172a', mt: 0.25 }}>
                  {graph.total_nodes}
                </Typography>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.7rem' }}>
                  {graph.data_nodes} records · {graph.identity_nodes} well identities · {graph.semantic_nodes} semantic · {graph.document_nodes} docs/chunks
                </Typography>
              </Box>

              <Box sx={{ p: 1.5, bgcolor: '#f8fafc', borderRadius: 1.5, border: '1px solid #f1f5f9' }}>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.72rem', display: 'block' }}>
                  Total Relationships
                </Typography>
                <Typography variant="h5" sx={{ fontWeight: 700, color: '#0f172a', mt: 0.25 }}>
                  {graph.total_relationships}
                </Typography>
                <Typography variant="caption" sx={{ color: '#0f766e', fontSize: '0.7rem', fontWeight: 600 }}>
                  {graph.aligned_classes} classes aligned to {graph.standard_classes} standard classes
                </Typography>
              </Box>
            </Box>

            {/* Semantic Link Distribution */}
            <Typography variant="caption" sx={{ color: '#475569', fontWeight: 600, mb: 1, display: 'block' }}>
              Records by Subject Area
            </Typography>
            <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 2.5 }}>
              {Object.entries(graph.nodes_by_domain || {}).map(([domain, count]) => (
                <Chip
                  key={domain}
                  label={`${domain}: ${count}`}
                  size="small"
                  sx={{ fontSize: '0.7rem', height: 22, bgcolor: getDomainColor(domain), color: '#ffffff', fontWeight: 600 }}
                />
              ))}
            </Box>

            {/* Action Link */}
            <Button
              variant="outlined"
              size="small"
              onClick={() => navigate('/graph')}
              endIcon={<ArrowForwardIcon sx={{ fontSize: 16 }} />}
              sx={{
                textTransform: 'none',
                fontWeight: 600,
                color: '#0f766e',
                borderColor: '#ccfbf1',
                bgcolor: '#f0fdfa',
                '&:hover': {
                  borderColor: '#0f766e',
                  bgcolor: '#ccfbf1',
                },
              }}
            >
              Open Knowledge Graph Explorer
            </Button>
          </CardContent>
        </Card>

        {/* Card 2: Document Ingestion & Vector Index */}
        <Card
          sx={{
            bgcolor: '#ffffff',
            borderRadius: 2,
            border: '1px solid #e2e8f0',
            boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          <CardContent sx={{ p: 2.5, flexGrow: 1 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <Box
                  sx={{
                    width: 32,
                    height: 32,
                    borderRadius: '8px',
                    bgcolor: '#eff6ff',
                    color: '#2563eb',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <DocumentIcon sx={{ fontSize: 18 }} />
                </Box>
                <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#1e293b', fontSize: '0.9rem' }}>
                  Document Corpus & Vector Index
                </Typography>
              </Box>

              <Chip
                icon={<CheckIcon sx={{ fontSize: '14px !important' }} />}
                label={`Index: ${documents.vector_index_status}`}
                size="small"
                sx={{
                  bgcolor: '#ecfdf5',
                  color: '#047857',
                  fontSize: '0.7rem',
                  fontWeight: 700,
                  height: 22,
                  border: '1px solid #a7f3d0',
                }}
              />
            </Box>

            {/* Metrics Grid */}
            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: 'repeat(3, 1fr)',
                gap: 1.5,
                mb: 2.5,
              }}
            >
              <Box sx={{ p: 1.5, bgcolor: '#f8fafc', borderRadius: 1.5, border: '1px solid #f1f5f9' }}>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.72rem', display: 'block' }}>
                  Ingested Docs
                </Typography>
                <Typography variant="h5" sx={{ fontWeight: 700, color: '#0f172a', mt: 0.25 }}>
                  {documents.total_documents}
                </Typography>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.7rem' }}>
                  Manuals & reports
                </Typography>
              </Box>

              <Box sx={{ p: 1.5, bgcolor: '#f8fafc', borderRadius: 1.5, border: '1px solid #f1f5f9' }}>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.72rem', display: 'block' }}>
                  Total Chunks
                </Typography>
                <Typography variant="h5" sx={{ fontWeight: 700, color: '#0f172a', mt: 0.25 }}>
                  {documents.total_chunks}
                </Typography>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.7rem' }}>
                  Semantic units
                </Typography>
              </Box>

              <Box sx={{ p: 1.5, bgcolor: '#f8fafc', borderRadius: 1.5, border: '1px solid #f1f5f9' }}>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.72rem', display: 'block' }}>
                  Embedded Chunks
                </Typography>
                <Typography variant="h5" sx={{ fontWeight: 700, color: '#10b981', mt: 0.25 }}>
                  {documents.embedded_chunks}
                </Typography>
                <Typography variant="caption" sx={{ color: '#10b981', fontSize: '0.7rem', fontWeight: 600 }}>
                  100% Vectorized
                </Typography>
              </Box>
            </Box>

            {/* Vector Index Details */}
            <Box sx={{ p: 1.25, bgcolor: '#f8fafc', borderRadius: 1.5, mb: 2.5, border: '1px solid #e2e8f0' }}>
              <Typography variant="caption" sx={{ color: '#334155', fontWeight: 600, display: 'block', mb: 0.5 }}>
                Vector Index: <code>{documents.vector_index_name}</code>
              </Typography>
              <Typography variant="caption" sx={{ color: '#64748b', display: 'block', fontSize: '0.75rem' }}>
                Model: <strong>{documents.embedding_model}</strong>
                {documents.embedding_dimension ? ` • ${documents.embedding_dimension} dimensions` : ''} • Cosine Similarity •{' '}
                {documents.uploaded_documents} uploaded document(s)
              </Typography>
            </Box>

            {/* Action Link */}
            <Button
              variant="outlined"
              size="small"
              onClick={() => navigate('/documents')}
              endIcon={<ArrowForwardIcon sx={{ fontSize: 16 }} />}
              sx={{
                textTransform: 'none',
                fontWeight: 600,
                color: '#2563eb',
                borderColor: '#dbeafe',
                bgcolor: '#eff6ff',
                '&:hover': {
                  borderColor: '#2563eb',
                  bgcolor: '#dbeafe',
                },
              }}
            >
              Browse Documents & Chunks
            </Button>
          </CardContent>
        </Card>
      </Box>
    </Box>
  );
};
