import React from 'react';
import { Box, Card, Typography } from '@mui/material';
import {
  Opacity as WellIcon,
  LocalGasStation as ProductionIcon,
  Construction as DrillingIcon,
  PrecisionManufacturing as IntegrityIcon,
  HealthAndSafety as HseIcon,
  Cloud as EmissionsIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { DashboardKPIs } from '../../../types/dashboard';
import { formatPropertyValue } from '../../graph/utils/relationshipUtils';

interface ExecutiveKPICardsProps {
  kpis: DashboardKPIs;
}

interface Metric {
  key: string;
  label: string;
  alert?: boolean;
}

interface KPIGroupConfig {
  id: keyof DashboardKPIs & string;
  icon: React.ReactNode;
  accentColor: string;
  bgColor: string;
  route: string;
  headline: Metric;
  metrics: Metric[];
}

const GROUPS: KPIGroupConfig[] = [
  {
    id: 'wells',
    icon: <WellIcon sx={{ fontSize: 20 }} />,
    accentColor: '#1F77B4',
    bgColor: '#eff6ff',
    route: '/usecases/UC1',
    headline: { key: 'physical_wells', label: 'Physical wells (API-10)' },
    metrics: [
      { key: 'wellbores', label: 'Wellbores' },
      { key: 'producing', label: 'Producing' },
      { key: 'api_conflicts', label: 'API conflicts', alert: true },
    ],
  },
  {
    id: 'production',
    icon: <ProductionIcon sx={{ fontSize: 20 }} />,
    accentColor: '#4C78A8',
    bgColor: '#eff6ff',
    route: '/usecases/UC5',
    headline: { key: 'gross_oil_bbl', label: 'Gross oil (bbl)' },
    metrics: [
      { key: 'month', label: 'Month' },
      { key: 'gross_gas_mcf', label: 'Gross gas (Mcf)' },
      { key: 'wells_allocated', label: 'Wells allocated' },
    ],
  },
  {
    id: 'drilling',
    icon: <DrillingIcon sx={{ fontSize: 20 }} />,
    accentColor: '#E45756',
    bgColor: '#fef2f2',
    route: '/usecases/UC2',
    headline: { key: 'npt_hours', label: 'NPT hours' },
    metrics: [
      { key: 'npt_events', label: 'NPT events' },
      { key: 'npt_cost_usd', label: 'NPT cost' },
      { key: 'kicks', label: 'Kicks', alert: true },
    ],
  },
  {
    id: 'integrity',
    icon: <IntegrityIcon sx={{ fontSize: 20 }} />,
    accentColor: '#B279A2',
    bgColor: '#faf5ff',
    route: '/usecases/UC3',
    headline: { key: 'failures', label: 'Equipment failures' },
    metrics: [
      { key: 'repair_cost_usd', label: 'Repair cost' },
      { key: 'deferred_boe', label: 'Deferred (BOE)' },
      { key: 'overdue_safety_critical', label: 'Overdue SCE', alert: true },
    ],
  },
  {
    id: 'hse',
    icon: <HseIcon sx={{ fontSize: 20 }} />,
    accentColor: '#F58518',
    bgColor: '#fff7ed',
    route: '/usecases/UC4',
    headline: { key: 'incidents', label: 'HSE incidents' },
    metrics: [
      { key: 'pse_tier_1', label: 'Tier 1 PSE', alert: true },
      { key: 'pse_tier_2', label: 'Tier 2 PSE' },
      { key: 'open_capas', label: 'Open CAPAs' },
      { key: 'penalties_usd', label: 'Penalties' },
    ],
  },
  {
    id: 'emissions',
    icon: <EmissionsIcon sx={{ fontSize: 20 }} />,
    accentColor: '#54A24B',
    bgColor: '#f0fdf4',
    route: '/usecases/UC5',
    headline: { key: 'co2e_t', label: 't CO2e reported' },
    metrics: [
      { key: 'ch4_t', label: 'CH4 (t)' },
      { key: 'flared_mcf', label: 'Flared (Mcf)' },
      { key: 'ldar_leaks', label: 'LDAR leaks' },
    ],
  },
];

const show = (key: string, value: any): string => {
  if (value === null || value === undefined) return '—';
  if (typeof value === 'number' && !key.endsWith('_usd')) return value.toLocaleString('en-US', { maximumFractionDigits: 1 });
  return formatPropertyValue(key, value);
};

export const ExecutiveKPICards: React.FC<ExecutiveKPICardsProps> = ({ kpis }) => {
  const navigate = useNavigate();

  return (
    <Box
      sx={{
        display: 'grid',
        gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)', md: 'repeat(3, 1fr)', xl: 'repeat(6, 1fr)' },
        gap: 1.5,
        mb: 3,
      }}
    >
      {GROUPS.map((g) => {
        const group = kpis[g.id];
        const values = group?.values || {};
        return (
          <Card
            key={g.id}
            onClick={() => navigate(g.route)}
            sx={{
              p: 1.75,
              bgcolor: '#ffffff',
              borderRadius: 2,
              border: '1px solid #e2e8f0',
              boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)',
              cursor: 'pointer',
              transition: 'all 0.18s ease-in-out',
              display: 'flex',
              flexDirection: 'column',
              gap: 1,
              '&:hover': { transform: 'translateY(-2px)', boxShadow: '0 4px 12px 0 rgba(0, 0, 0, 0.08)', borderColor: g.accentColor },
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <Typography
                variant="caption"
                sx={{ fontWeight: 600, color: '#64748b', fontSize: '0.72rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}
              >
                {group?.title || g.id}
              </Typography>
              <Box
                sx={{
                  width: 30,
                  height: 30,
                  borderRadius: '8px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  bgcolor: g.bgColor,
                  color: g.accentColor,
                  flexShrink: 0,
                }}
              >
                {g.icon}
              </Box>
            </Box>
            <Box>
              <Typography variant="h5" sx={{ fontWeight: 700, color: '#0f172a', fontSize: '1.5rem', lineHeight: 1.1 }}>
                {show(g.headline.key, values[g.headline.key])}
              </Typography>
              <Typography variant="caption" sx={{ color: '#94a3b8', fontSize: '0.7rem' }}>
                {g.headline.label}
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.25, borderTop: '1px solid #f1f5f9', pt: 0.75 }}>
              {g.metrics.map((m) => {
                const v = values[m.key];
                const alert = m.alert && typeof v === 'number' && v > 0;
                return (
                  <Box key={m.key} sx={{ display: 'flex', justifyContent: 'space-between', gap: 1 }}>
                    <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.72rem' }}>
                      {m.label}
                    </Typography>
                    <Typography variant="caption" sx={{ fontWeight: 700, color: alert ? '#be123c' : '#334155', fontSize: '0.72rem' }}>
                      {show(m.key, v)}
                    </Typography>
                  </Box>
                );
              })}
            </Box>
          </Card>
        );
      })}
    </Box>
  );
};
