import React from 'react';
import { Box, Card, CardContent, Typography } from '@mui/material';
import { ShowChart as TrendIcon } from '@mui/icons-material';
import { DashboardTrends } from '../../../types/dashboard';

interface TrendsPanelProps {
  trends: DashboardTrends;
}

interface BarItem {
  label: string;
  value: number;
  caption?: string;
}

const BarList: React.FC<{ title: string; unit: string; items: BarItem[]; color: string }> = ({ title, unit, items, color }) => {
  const max = Math.max(1, ...items.map((i) => i.value || 0));
  return (
    <Card sx={{ bgcolor: '#ffffff', borderRadius: 2, border: '1px solid #e2e8f0', boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)' }}>
      <CardContent sx={{ p: 2 }}>
        <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#1e293b', mb: 1.25, fontSize: '0.85rem' }}>
          {title}
        </Typography>
        {items.length === 0 ? (
          <Typography variant="caption" sx={{ color: '#94a3b8' }}>
            No data loaded.
          </Typography>
        ) : (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75 }}>
            {items.map((i) => (
              <Box key={i.label} sx={{ display: 'grid', gridTemplateColumns: '38% 1fr auto', alignItems: 'center', gap: 1 }}>
                <Typography
                  variant="caption"
                  title={i.label}
                  sx={{ color: '#475569', fontSize: '0.72rem', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}
                >
                  {i.label}
                </Typography>
                <Box sx={{ height: 10, bgcolor: '#f1f5f9', borderRadius: 1, overflow: 'hidden' }}>
                  <Box sx={{ width: `${Math.max(2, (100 * (i.value || 0)) / max)}%`, height: '100%', bgcolor: color, borderRadius: 1 }} />
                </Box>
                <Typography variant="caption" sx={{ fontWeight: 700, color: '#0f172a', fontSize: '0.72rem', whiteSpace: 'nowrap' }}>
                  {(i.value || 0).toLocaleString('en-US', { maximumFractionDigits: 1 })} {unit}
                  {i.caption ? <span style={{ color: '#94a3b8', fontWeight: 500 }}> · {i.caption}</span> : null}
                </Typography>
              </Box>
            ))}
          </Box>
        )}
      </CardContent>
    </Card>
  );
};

export const TrendsPanel: React.FC<TrendsPanelProps> = ({ trends }) => {
  const production = (trends.production_by_month || []).slice(-8).map((r) => ({ label: r.month, value: r.gross_oil_bbl }));
  const npt = (trends.npt_by_category || []).map((r) => ({ label: r.category, value: r.hours, caption: `${r.events} ev` }));
  const co2e = (trends.co2e_by_quarter || []).map((r) => ({ label: `Q ending ${r.quarter_end}`, value: r.co2e_t }));
  const pse = (trends.pse_by_tier || []).map((r) => ({ label: r.tier, value: r.events }));
  const failures = (trends.failures_by_class || []).map((r) => ({ label: r.equipment_class, value: r.failures }));

  return (
    <Box sx={{ mb: 3 }}>
      <Typography
        variant="h6"
        sx={{ fontWeight: 700, color: '#0f172a', mb: 1.5, display: 'flex', alignItems: 'center', gap: 1, fontSize: '1.125rem' }}
      >
        <TrendIcon sx={{ color: '#0f766e', fontSize: 22 }} />
        Operational Trends
      </Typography>
      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(2, 1fr)', xl: 'repeat(3, 1fr)' }, gap: 2 }}>
        <BarList title="Allocated gross oil by month" unit="bbl" items={production} color="#4C78A8" />
        <BarList title="Drilling NPT by category" unit="h" items={npt} color="#E45756" />
        <BarList title="Reported CO2e by quarter" unit="t" items={co2e} color="#54A24B" />
        <BarList title="Process safety events by tier (API RP 754)" unit="" items={pse} color="#F58518" />
        <BarList title="Equipment failures by ISO 14224 class" unit="" items={failures} color="#B279A2" />
      </Box>
    </Box>
  );
};
