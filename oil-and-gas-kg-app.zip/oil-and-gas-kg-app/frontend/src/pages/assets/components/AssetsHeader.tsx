import React from 'react';
import { Box, Typography, Button, Chip } from '@mui/material';
import { PrecisionManufacturing as AssetIcon, Refresh as RefreshIcon } from '@mui/icons-material';

interface AssetsHeaderProps {
  totalEquipment: number;
  safetyCritical: number;
  asOf?: string;
  isLoading: boolean;
  onRefresh: () => void;
}

export const AssetsHeader: React.FC<AssetsHeaderProps> = ({ totalEquipment, safetyCritical, asOf, isLoading, onRefresh }) => {
  return (
    <Box
      display="flex"
      justifyContent="space-between"
      alignItems={{ xs: 'flex-start', sm: 'center' }}
      flexDirection={{ xs: 'column', sm: 'row' }}
      gap={2}
      mb={3}
    >
      <Box>
        <Box display="flex" alignItems="center" gap={1.25}>
          <AssetIcon sx={{ color: '#B279A2', fontSize: 28 }} />
          <Typography variant="h5" component="h1" sx={{ fontWeight: 700, color: '#0f172a' }}>
            Equipment Integrity
          </Typography>
        </Box>
        <Typography variant="body2" sx={{ color: '#64748b', mt: 0.5 }}>
          ISO 14224 equipment register with inspections (API 510 / 570 / 653 / RP 576), failures, work orders, downtime, HSE events and
          drilling NPT linked through the knowledge graph.
        </Typography>
      </Box>
      <Box display="flex" alignItems="center" gap={1}>
        <Chip size="small" label={`${totalEquipment} items`} sx={{ fontWeight: 600 }} />
        <Chip size="small" label={`${safetyCritical} safety-critical`} sx={{ fontWeight: 600, bgcolor: '#fef2f2', color: '#b91c1c' }} />
        {asOf && <Chip size="small" variant="outlined" label={`as of ${asOf}`} />}
        <Button
          variant="outlined"
          size="small"
          startIcon={<RefreshIcon />}
          onClick={onRefresh}
          disabled={isLoading}
          sx={{ textTransform: 'none', fontWeight: 600 }}
        >
          Refresh
        </Button>
      </Box>
    </Box>
  );
};
