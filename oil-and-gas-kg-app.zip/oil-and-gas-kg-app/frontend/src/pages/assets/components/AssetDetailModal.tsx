import React, { useState } from 'react';
import {
  Box,
  Button,
  Chip,
  CircularProgress,
  Dialog,
  DialogContent,
  DialogTitle,
  IconButton,
  Tab,
  Tabs,
  Typography,
} from '@mui/material';
import { Close as CloseIcon, Psychology as AskIcon, AccountTree as GraphIcon } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { AssetDetailResponse } from '../../../types/assets';
import { DataTable } from '../../../components/common/DataTable';
import { EvidenceGraph } from '../../../components/common/EvidenceGraph';
import { formatPropertyLabel, formatPropertyValue } from '../../graph/utils/relationshipUtils';
import { getAssetClassLabel, getCriticalityColor } from '../utils/assetUtils';

interface AssetDetailModalProps {
  open: boolean;
  assetDetail: AssetDetailResponse | null;
  isLoading: boolean;
  onClose: () => void;
}

const KEY_PROPS = [
  'equipment_name',
  'equipment_type',
  'std_class',
  'criticality_ranking',
  'is_safety_critical',
  'maintenance_strategy',
  'manufacturer',
  'model_number',
  'installation_date',
  'last_inspection_date',
  'next_inspection_due_date',
  'mtbf_hours',
  'design_pressure_psi',
  'operating_pressure_psi',
];

export const AssetDetailModal: React.FC<AssetDetailModalProps> = ({ open, assetDetail, isLoading, onClose }) => {
  const navigate = useNavigate();
  const [tab, setTab] = useState(0);
  const a = assetDetail?.asset;
  const crit = getCriticalityColor(a?.criticality_ranking);

  const tabs: { label: string; rows: Record<string, any>[]; empty: string }[] = assetDetail
    ? [
        { label: `Inspections (${assetDetail.inspections.length})`, rows: assetDetail.inspections, empty: 'No inspections.' },
        { label: `Failures (${assetDetail.failures.length})`, rows: assetDetail.failures, empty: 'No failure reports.' },
        { label: `Work orders (${assetDetail.work_orders.length})`, rows: assetDetail.work_orders, empty: 'No work orders.' },
        { label: `PM plans (${assetDetail.maintenance_plans.length})`, rows: assetDetail.maintenance_plans, empty: 'No PM plan.' },
        { label: `Integrity programs (${assetDetail.integrity_programs.length})`, rows: assetDetail.integrity_programs, empty: 'No integrity program.' },
        { label: `Downtime (${assetDetail.downtime.length})`, rows: assetDetail.downtime, empty: 'No production downtime.' },
        { label: `HSE (${assetDetail.hse_events.length})`, rows: assetDetail.hse_events, empty: 'No HSE records.' },
        { label: `Drilling NPT (${assetDetail.drilling_npt.length})`, rows: assetDetail.drilling_npt, empty: 'No drilling NPT.' },
      ]
    : [];
  const graphTab = tabs.length;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="lg" fullWidth>
      <DialogTitle sx={{ pr: 6 }}>
        {a ? (
          <Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
              <Typography variant="h6" sx={{ fontWeight: 700, fontFamily: 'monospace' }}>
                {a.tag}
              </Typography>
              <Typography variant="h6" sx={{ fontWeight: 500 }}>
                {a.equipment_name}
              </Typography>
              <Chip size="small" label={crit.label} sx={{ bgcolor: crit.bg, color: crit.text, fontWeight: 700 }} />
              {a.is_safety_critical && <Chip size="small" label="Safety-critical" sx={{ bgcolor: '#fef2f2', color: '#b91c1c' }} />}
            </Box>
            <Typography variant="caption" sx={{ color: '#64748b' }}>
              {getAssetClassLabel(a.equipment_type)}
              {assetDetail?.facility ? ` · ${assetDetail.facility.name} (${assetDetail.facility.code})` : ''}
              {assetDetail?.parent ? ` · part of ${assetDetail.parent.tag}` : ''}
            </Typography>
          </Box>
        ) : (
          'Equipment'
        )}
        <IconButton onClick={onClose} sx={{ position: 'absolute', right: 12, top: 12 }}>
          <CloseIcon />
        </IconButton>
      </DialogTitle>
      <DialogContent dividers>
        {isLoading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
            <CircularProgress />
          </Box>
        )}
        {!isLoading && assetDetail && a && (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Box sx={{ display: 'flex', gap: 0.75, flexWrap: 'wrap' }}>
              {KEY_PROPS.filter((k) => a[k] !== null && a[k] !== undefined && a[k] !== '').map((k) => (
                <Chip key={k} size="small" variant="outlined" label={`${formatPropertyLabel(k)}: ${formatPropertyValue(k, a[k])}`} />
              ))}
            </Box>

            {assetDetail.functional_location.length > 0 && (
              <Box>
                <Typography variant="caption" sx={{ fontWeight: 700, color: '#475569' }}>
                  ISO 14224 functional location
                </Typography>
                <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', alignItems: 'center', mt: 0.5 }}>
                  {assetDetail.functional_location.map((f, i) => (
                    <React.Fragment key={`${f.code}-${i}`}>
                      {i > 0 && <Typography variant="caption">›</Typography>}
                      <Chip size="small" label={`${f.code}${f.iso14224_level ? ` (${f.iso14224_level})` : ''}`} title={f.name} sx={{ height: 22 }} />
                    </React.Fragment>
                  ))}
                </Box>
              </Box>
            )}

            {assetDetail.children.length > 0 && (
              <Typography variant="caption" sx={{ color: '#475569' }}>
                Sub-equipment: {assetDetail.children.map((c) => c.tag).join(', ')}
              </Typography>
            )}

            <Tabs value={tab} onChange={(_, v) => setTab(v)} variant="scrollable" scrollButtons="auto" sx={{ '& .MuiTab-root': { textTransform: 'none' } }}>
              {tabs.map((t) => (
                <Tab key={t.label} label={t.label} />
              ))}
              <Tab label="Graph" />
            </Tabs>
            {tab < graphTab && tabs[tab] && <DataTable rows={tabs[tab].rows} emptyText={tabs[tab].empty} maxHeight={360} />}
            {tab === graphTab && <EvidenceGraph graph={assetDetail.graph} height={420} />}

            <Box sx={{ display: 'flex', gap: 1, justifyContent: 'flex-end' }}>
              <Button
                size="small"
                startIcon={<GraphIcon />}
                onClick={() => navigate(`/graph?node_label=Equipment&query=${encodeURIComponent(a.tag)}`)}
                sx={{ textTransform: 'none' }}
              >
                Open in graph explorer
              </Button>
              <Button
                size="small"
                variant="contained"
                startIcon={<AskIcon />}
                onClick={() =>
                  navigate(
                    `/intelligence?q=${encodeURIComponent(
                      `What is the inspection, failure and maintenance history of ${a.tag} and what did the failures cost?`
                    )}`
                  )
                }
                sx={{ textTransform: 'none' }}
              >
                Ask GraphRAG
              </Button>
            </Box>
          </Box>
        )}
      </DialogContent>
    </Dialog>
  );
};
