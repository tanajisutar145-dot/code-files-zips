import React from 'react';
import {
  Box,
  Chip,
  LinearProgress,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  Typography,
} from '@mui/material';
import { Shield as SafetyIcon } from '@mui/icons-material';
import { AssetSummaryItem } from '../../../types/assets';
import { formatDate, getAssetClassLabel, getCriticalityColor, getInspectionColor } from '../utils/assetUtils';

interface AssetTableProps {
  assets: AssetSummaryItem[];
  total: number;
  page: number;
  rowsPerPage: number;
  isLoading: boolean;
  onPageChange: (page: number) => void;
  onRowsPerPageChange: (rows: number) => void;
  onSelectAsset: (tag: string) => void;
}

const head = { fontWeight: 700, color: '#475569', fontSize: '0.75rem', bgcolor: '#f8fafc', whiteSpace: 'nowrap' as const };

export const AssetTable: React.FC<AssetTableProps> = ({
  assets,
  total,
  page,
  rowsPerPage,
  isLoading,
  onPageChange,
  onRowsPerPageChange,
  onSelectAsset,
}) => (
  <Paper elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: 2, overflow: 'hidden' }}>
    {isLoading && <LinearProgress />}
    <TableContainer>
      <Table size="small">
        <TableHead>
          <TableRow>
            <TableCell sx={head}>Tag</TableCell>
            <TableCell sx={head}>Equipment</TableCell>
            <TableCell sx={head}>ISO 14224 class</TableCell>
            <TableCell sx={head}>Facility</TableCell>
            <TableCell sx={head}>Criticality</TableCell>
            <TableCell sx={head}>Next inspection</TableCell>
            <TableCell sx={head} align="right">Failures</TableCell>
            <TableCell sx={head} align="right">Inspections</TableCell>
            <TableCell sx={head} align="right">Work orders</TableCell>
            <TableCell sx={head}>Last failure</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {assets.length === 0 && !isLoading && (
            <TableRow>
              <TableCell colSpan={10}>
                <Typography variant="body2" sx={{ color: '#94a3b8', textAlign: 'center', py: 3 }}>
                  No equipment matches the filters.
                </Typography>
              </TableCell>
            </TableRow>
          )}
          {assets.map((a) => {
            const crit = getCriticalityColor(a.criticality);
            const insp = getInspectionColor(a.inspection_overdue, a.next_inspection_due_date);
            return (
              <TableRow key={a.equipment_id} hover onClick={() => onSelectAsset(a.tag)} sx={{ cursor: 'pointer' }}>
                <TableCell sx={{ fontWeight: 700, fontFamily: 'monospace', fontSize: '0.78rem' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    {a.safety_critical && <SafetyIcon titleAccess="Safety-critical element" sx={{ fontSize: 15, color: '#dc2626' }} />}
                    {a.tag}
                  </Box>
                </TableCell>
                <TableCell sx={{ fontSize: '0.8rem' }}>{a.name}</TableCell>
                <TableCell sx={{ fontSize: '0.78rem' }}>
                  {getAssetClassLabel(a.equipment_type)}
                  {a.std_class && (
                    <Typography variant="caption" sx={{ display: 'block', color: '#94a3b8' }}>
                      {a.std_class}
                    </Typography>
                  )}
                </TableCell>
                <TableCell sx={{ fontSize: '0.78rem' }}>{a.facility || '—'}</TableCell>
                <TableCell>
                  <Chip size="small" label={crit.label} sx={{ height: 20, bgcolor: crit.bg, color: crit.text, fontWeight: 600, fontSize: '0.7rem' }} />
                </TableCell>
                <TableCell>
                  <Chip
                    size="small"
                    label={`${insp.label}${a.next_inspection_due_date ? ` · ${formatDate(a.next_inspection_due_date)}` : ''}`}
                    sx={{ height: 20, bgcolor: insp.bg, color: insp.text, fontSize: '0.7rem' }}
                  />
                </TableCell>
                <TableCell align="right" sx={{ fontWeight: a.failure_count >= 2 ? 700 : 400, color: a.failure_count >= 2 ? '#be123c' : 'inherit' }}>
                  {a.failure_count}
                </TableCell>
                <TableCell align="right">{a.inspection_count}</TableCell>
                <TableCell align="right">{a.work_order_count}</TableCell>
                <TableCell sx={{ fontSize: '0.78rem' }}>{a.last_failure_date ? formatDate(a.last_failure_date) : '—'}</TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </TableContainer>
    <TablePagination
      component="div"
      count={total}
      page={page}
      rowsPerPage={rowsPerPage}
      rowsPerPageOptions={[10, 25, 50, 100]}
      onPageChange={(_, p) => onPageChange(p)}
      onRowsPerPageChange={(e) => onRowsPerPageChange(parseInt(e.target.value, 10))}
    />
  </Paper>
);
