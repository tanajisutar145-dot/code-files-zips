import React from 'react';
import { Box, Card, CardContent, Chip, Skeleton, Typography } from '@mui/material';
import { AssetOverviewResponse } from '../../../types/assets';
import { getAssetClassLabel, getCriticalityColor } from '../utils/assetUtils';

interface AssetStatisticsProps {
  overview: AssetOverviewResponse | null;
  isLoading: boolean;
}

const Stat: React.FC<{ label: string; value: number | string; alert?: boolean }> = ({ label, value, alert }) => (
  <Card elevation={0} sx={{ border: '1px solid #e2e8f0', borderRadius: 2 }}>
    <CardContent sx={{ p: 1.75, '&:last-child': { pb: 1.75 } }}>
      <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 600, textTransform: 'uppercase', fontSize: '0.7rem' }}>
        {label}
      </Typography>
      <Typography variant="h5" sx={{ fontWeight: 700, color: alert ? '#be123c' : '#0f172a' }}>
        {value}
      </Typography>
    </CardContent>
  </Card>
);

export const AssetStatistics: React.FC<AssetStatisticsProps> = ({ overview, isLoading }) => {
  if (isLoading && !overview) {
    return <Skeleton variant="rectangular" height={110} sx={{ mb: 3, borderRadius: 2 }} />;
  }
  if (!overview) return null;

  return (
    <Box sx={{ mb: 3 }}>
      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: 'repeat(2, 1fr)', md: 'repeat(5, 1fr)' }, gap: 1.5, mb: 1.5 }}>
        <Stat label="Equipment" value={overview.total_equipment} />
        <Stat label="Safety-critical" value={overview.safety_critical} />
        <Stat label="Overdue SCE inspections" value={overview.overdue_inspections} alert={overview.overdue_inspections > 0} />
        <Stat label="Failure reports" value={overview.failures} />
        <Stat label="Open work orders" value={overview.open_work_orders} />
      </Box>
      <Box sx={{ display: 'flex', gap: 0.75, flexWrap: 'wrap' }}>
        {Object.entries(overview.criticality_counts).map(([k, v]) => {
          const c = getCriticalityColor(k);
          return <Chip key={k} size="small" label={`${c.label}: ${v}`} sx={{ bgcolor: c.bg, color: c.text, fontWeight: 600 }} />;
        })}
        {Object.entries(overview.class_counts).map(([k, v]) => (
          <Chip key={k} size="small" variant="outlined" label={`${getAssetClassLabel(k)}: ${v}`} />
        ))}
      </Box>
    </Box>
  );
};
