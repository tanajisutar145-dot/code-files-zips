import React from 'react';
import { Box, Button, FormControl, FormControlLabel, InputLabel, MenuItem, Select, Switch, TextField } from '@mui/material';
import { Clear as ClearIcon } from '@mui/icons-material';
import { getAssetClassLabel } from '../utils/assetUtils';

interface AssetFiltersBarProps {
  search: string;
  equipmentType: string;
  criticality: string;
  facilityCode: string;
  safetyCriticalOnly: boolean;
  equipmentTypes: string[];
  facilities: { code: string; name: string }[];
  onSearchChange: (val: string) => void;
  onEquipmentTypeChange: (val: string) => void;
  onCriticalityChange: (val: string) => void;
  onFacilityChange: (val: string) => void;
  onSafetyCriticalChange: (val: boolean) => void;
  onClearFilters: () => void;
}

export const AssetFiltersBar: React.FC<AssetFiltersBarProps> = ({
  search,
  equipmentType,
  criticality,
  facilityCode,
  safetyCriticalOnly,
  equipmentTypes,
  facilities,
  onSearchChange,
  onEquipmentTypeChange,
  onCriticalityChange,
  onFacilityChange,
  onSafetyCriticalChange,
  onClearFilters,
}) => {
  const hasFilters = !!(search || equipmentType || criticality || facilityCode || safetyCriticalOnly);
  return (
    <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', alignItems: 'center', mb: 2 }}>
      <TextField
        size="small"
        label="Search tag or name"
        value={search}
        onChange={(e) => onSearchChange(e.target.value)}
        sx={{ minWidth: 220 }}
      />
      <FormControl size="small" sx={{ minWidth: 190 }}>
        <InputLabel id="eq-type">ISO 14224 class</InputLabel>
        <Select labelId="eq-type" label="ISO 14224 class" value={equipmentType} onChange={(e) => onEquipmentTypeChange(e.target.value)}>
          <MenuItem value="">All classes</MenuItem>
          {equipmentTypes.map((t) => (
            <MenuItem key={t} value={t}>
              {getAssetClassLabel(t)}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <FormControl size="small" sx={{ minWidth: 150 }}>
        <InputLabel id="eq-crit">Criticality</InputLabel>
        <Select labelId="eq-crit" label="Criticality" value={criticality} onChange={(e) => onCriticalityChange(e.target.value)}>
          <MenuItem value="">All</MenuItem>
          {['critical', 'high', 'medium', 'low'].map((c) => (
            <MenuItem key={c} value={c}>
              {c}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <FormControl size="small" sx={{ minWidth: 220 }}>
        <InputLabel id="eq-fac">Facility</InputLabel>
        <Select labelId="eq-fac" label="Facility" value={facilityCode} onChange={(e) => onFacilityChange(e.target.value)}>
          <MenuItem value="">All facilities</MenuItem>
          {facilities.map((f) => (
            <MenuItem key={f.code} value={f.code}>
              {f.name} ({f.code})
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <FormControlLabel
        control={<Switch size="small" checked={safetyCriticalOnly} onChange={(e) => onSafetyCriticalChange(e.target.checked)} />}
        label="Safety-critical only"
      />
      {hasFilters && (
        <Button size="small" startIcon={<ClearIcon />} onClick={onClearFilters} sx={{ textTransform: 'none' }}>
          Clear
        </Button>
      )}
    </Box>
  );
};
