import React, { useState, useEffect, useCallback } from 'react';
import { useLocation } from 'react-router-dom';
import { Box, Alert, Button } from '@mui/material';
import { Refresh as RefreshIcon } from '@mui/icons-material';

import { AssetOverviewResponse, AssetSummaryItem, AssetDetailResponse } from '../../types/assets';
import { errorMessage, getAssetsOverview, listAssets, getAssetDetail } from '../../services/api';

import { AssetsHeader } from './components/AssetsHeader';
import { AssetStatistics } from './components/AssetStatistics';
import { AssetFiltersBar } from './components/AssetFiltersBar';
import { AssetTable } from './components/AssetTable';
import { AssetDetailModal } from './components/AssetDetailModal';

const AssetsPage: React.FC = () => {
  const location = useLocation();

  // Overview metrics
  const [overview, setOverview] = useState<AssetOverviewResponse | null>(null);
  const [isLoadingOverview, setIsLoadingOverview] = useState<boolean>(true);
  const [facilities, setFacilities] = useState<{ code: string; name: string }[]>([]);

  // Equipment listing
  const [assets, setAssets] = useState<AssetSummaryItem[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [isLoadingList, setIsLoadingList] = useState<boolean>(true);
  const [listError, setListError] = useState<string | null>(null);

  // Filters & Pagination
  const [search, setSearch] = useState<string>('');
  const [equipmentType, setEquipmentType] = useState<string>('');
  const [criticality, setCriticality] = useState<string>('');
  const [facilityCode, setFacilityCode] = useState<string>('');
  const [safetyCriticalOnly, setSafetyCriticalOnly] = useState<boolean>(false);
  const [page, setPage] = useState<number>(0);
  const [rowsPerPage, setRowsPerPage] = useState<number>(25);

  // Detail Modal
  const [assetDetail, setAssetDetail] = useState<AssetDetailResponse | null>(null);
  const [isLoadingDetail, setIsLoadingDetail] = useState<boolean>(false);
  const [detailModalOpen, setDetailModalOpen] = useState<boolean>(false);

  // Initialize filters from query parameters (e.g. /assets?search=FD1-K-201 from the use-case pages)
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const searchParam = params.get('search') || params.get('q') || params.get('tag');
    const typeParam = params.get('equipment_type') || params.get('class');
    const critParam = params.get('criticality');
    const facParam = params.get('facility_code');
    if (searchParam) setSearch(searchParam);
    if (typeParam) setEquipmentType(typeParam);
    if (critParam) setCriticality(critParam);
    if (facParam) setFacilityCode(facParam);
  }, [location.search]);

  const fetchOverview = useCallback(async () => {
    try {
      setIsLoadingOverview(true);
      setOverview(await getAssetsOverview());
      // facility list for the filter (codes come with the equipment rows)
      const all = await listAssets({ limit: 100 });
      const seen: Record<string, string> = {};
      all.assets.forEach((a) => {
        if (a.facility_code) seen[a.facility_code] = a.facility || a.facility_code;
      });
      setFacilities(Object.keys(seen).sort().map((code) => ({ code, name: seen[code] })));
    } catch (err: any) {
      console.error('Failed to fetch equipment overview:', err);
    } finally {
      setIsLoadingOverview(false);
    }
  }, []);

  const fetchAssets = useCallback(async () => {
    try {
      setIsLoadingList(true);
      setListError(null);
      const data = await listAssets({
        search: search.trim() || undefined,
        equipment_type: equipmentType || undefined,
        criticality: criticality || undefined,
        facility_code: facilityCode || undefined,
        safety_critical: safetyCriticalOnly ? true : undefined,
        skip: page * rowsPerPage,
        limit: rowsPerPage,
      });
      setAssets(data.assets);
      setTotal(data.total);
    } catch (err: any) {
      console.error('Failed to list equipment:', err);
      setListError(errorMessage(err, 'Failed to retrieve equipment from Neo4j.'));
    } finally {
      setIsLoadingList(false);
    }
  }, [search, equipmentType, criticality, facilityCode, safetyCriticalOnly, page, rowsPerPage]);

  useEffect(() => {
    fetchOverview();
  }, [fetchOverview]);

  useEffect(() => {
    fetchAssets();
  }, [fetchAssets]);

  // Open detail modal directly when the search is an exact tag from another page
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const tag = params.get('search') || params.get('tag');
    if (tag && assets.length === 1 && assets[0].tag === tag && !detailModalOpen && !assetDetail) {
      handleSelectAsset(tag);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [assets]);

  const handleSelectAsset = async (tag: string) => {
    setDetailModalOpen(true);
    setIsLoadingDetail(true);
    try {
      setAssetDetail(await getAssetDetail(tag));
    } catch (err: any) {
      console.error('Failed to fetch equipment details:', err);
    } finally {
      setIsLoadingDetail(false);
    }
  };

  const handleCloseDetailModal = () => {
    setDetailModalOpen(false);
    setAssetDetail(null);
  };

  const handleClearFilters = () => {
    setSearch('');
    setEquipmentType('');
    setCriticality('');
    setFacilityCode('');
    setSafetyCriticalOnly(false);
    setPage(0);
  };

  const resetPage = <T,>(setter: (v: T) => void) => (v: T) => {
    setter(v);
    setPage(0);
  };

  return (
    <Box sx={{ maxWidth: 1500, mx: 'auto', p: { xs: 1, md: 2 } }}>
      <AssetsHeader
        totalEquipment={overview?.total_equipment ?? 0}
        safetyCritical={overview?.safety_critical ?? 0}
        asOf={overview?.as_of}
        isLoading={isLoadingOverview || isLoadingList}
        onRefresh={() => {
          fetchOverview();
          fetchAssets();
        }}
      />

      <AssetStatistics overview={overview} isLoading={isLoadingOverview} />

      <AssetFiltersBar
        search={search}
        equipmentType={equipmentType}
        criticality={criticality}
        facilityCode={facilityCode}
        safetyCriticalOnly={safetyCriticalOnly}
        equipmentTypes={Object.keys(overview?.class_counts || {})}
        facilities={facilities}
        onSearchChange={resetPage(setSearch)}
        onEquipmentTypeChange={resetPage(setEquipmentType)}
        onCriticalityChange={resetPage(setCriticality)}
        onFacilityChange={resetPage(setFacilityCode)}
        onSafetyCriticalChange={resetPage(setSafetyCriticalOnly)}
        onClearFilters={handleClearFilters}
      />

      {listError && (
        <Alert
          severity="error"
          sx={{ mb: 2 }}
          action={
            <Button color="inherit" size="small" onClick={fetchAssets} startIcon={<RefreshIcon />}>
              Retry
            </Button>
          }
        >
          {listError}
        </Alert>
      )}

      <AssetTable
        assets={assets}
        total={total}
        page={page}
        rowsPerPage={rowsPerPage}
        isLoading={isLoadingList}
        onPageChange={(newPage) => setPage(newPage)}
        onRowsPerPageChange={(newRows) => {
          setRowsPerPage(newRows);
          setPage(0);
        }}
        onSelectAsset={handleSelectAsset}
      />

      <AssetDetailModal open={detailModalOpen} assetDetail={assetDetail} isLoading={isLoadingDetail} onClose={handleCloseDetailModal} />
    </Box>
  );
};

export default AssetsPage;
