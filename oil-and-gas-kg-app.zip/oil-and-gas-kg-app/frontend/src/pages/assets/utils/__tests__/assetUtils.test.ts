import {
  getCriticalityColor,
  getInspectionColor,
  getFitnessColor,
  getAssetClassLabel,
  formatDate,
  formatCurrency,
} from '../assetUtils';

describe('Equipment Utilities', () => {
  test('returns styling for criticality rankings', () => {
    expect(getCriticalityColor('critical').label).toBe('Critical');
    expect(getCriticalityColor('critical').text).toBe('#dc2626');
    expect(getCriticalityColor('HIGH').label).toBe('High');
    expect(getCriticalityColor('medium').label).toBe('Medium');
    expect(getCriticalityColor(undefined).label).toBe('Unknown');
  });

  test('flags overdue inspections', () => {
    expect(getInspectionColor(true, '2026-08-15').label).toBe('Overdue');
    expect(getInspectionColor(false, '2027-01-10').label).toBe('In date');
    expect(getInspectionColor(false, null).label).toBe('No plan');
  });

  test('colours fitness-for-service results', () => {
    expect(getFitnessColor('not_fit_for_service').text).toBe('#dc2626');
    expect(getFitnessColor('fit_for_service').text).toBe('#16a34a');
    expect(getFitnessColor(undefined).text).toBe('#475569');
  });

  test('formats ISO 14224 class labels', () => {
    expect(getAssetClassLabel('electric submersible pump')).toBe('Electric Submersible Pump');
    expect(getAssetClassLabel('blowout_preventer')).toBe('Blowout Preventer');
    expect(getAssetClassLabel(null)).toBe('Equipment');
  });

  test('formats dates and currency safely', () => {
    expect(formatDate(null)).toBe('N/A');
    expect(formatDate('2026-09-18')).toContain('2026');
    expect(formatCurrency(27500)).toBe('$27,500');
    expect(formatCurrency(null)).toBe('N/A');
  });
});
