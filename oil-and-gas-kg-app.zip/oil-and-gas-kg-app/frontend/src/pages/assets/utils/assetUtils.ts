/**
 * Utility helpers for the Equipment (asset integrity) pages: styling and formatting
 */

export const getCriticalityColor = (
  criticality?: string | null
): { bg: string; text: string; border: string; label: string } => {
  switch (criticality?.toLowerCase()) {
    case 'critical':
      return { bg: '#fee2e2', text: '#dc2626', border: '#fecaca', label: 'Critical' };
    case 'high':
      return { bg: '#ffedd5', text: '#ea580c', border: '#fed7aa', label: 'High' };
    case 'medium':
      return { bg: '#fef3c7', text: '#d97706', border: '#fde68a', label: 'Medium' };
    case 'low':
      return { bg: '#f1f5f9', text: '#475569', border: '#cbd5e1', label: 'Low' };
    default:
      return { bg: '#f1f5f9', text: '#64748b', border: '#e2e8f0', label: criticality || 'Unknown' };
  }
};

// Inspection status relative to the as-of date of the backend (api.as_of_date)
export const getInspectionColor = (
  overdue: boolean,
  dueDate?: string | null
): { bg: string; text: string; border: string; label: string } => {
  if (!dueDate) return { bg: '#f8fafc', text: '#64748b', border: '#e2e8f0', label: 'No plan' };
  if (overdue) return { bg: '#fef2f2', text: '#dc2626', border: '#fecaca', label: 'Overdue' };
  return { bg: '#f0fdf4', text: '#16a34a', border: '#bbf7d0', label: 'In date' };
};

export const getFitnessColor = (result?: string | null): { bg: string; text: string } => {
  switch ((result || '').toLowerCase()) {
    case 'not_fit_for_service':
      return { bg: '#fef2f2', text: '#dc2626' };
    case 'fit_for_service_with_conditions':
    case 'conditional':
      return { bg: '#fffbeb', text: '#d97706' };
    case 'fit_for_service':
      return { bg: '#f0fdf4', text: '#16a34a' };
    default:
      return { bg: '#f8fafc', text: '#475569' };
  }
};

export const getAssetClassLabel = (assetClass?: string | null): string => {
  if (!assetClass) return 'Equipment';
  return assetClass
    .split(/[_\s]/)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');
};

export const formatDate = (dateStr?: string | null): string => {
  if (!dateStr) return 'N/A';
  try {
    const d = new Date(/^\d{4}-\d{2}-\d{2}$/.test(dateStr) ? `${dateStr}T00:00:00` : dateStr);
    return isNaN(d.getTime())
      ? dateStr
      : d.toLocaleDateString(undefined, {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
        });
  } catch {
    return dateStr;
  }
};

export const formatCurrency = (val?: number | null): string => {
  if (val === undefined || val === null) return 'N/A';
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(val);
};
