import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { MemoryRouter } from 'react-router-dom';
import { AssetsHeader } from '../components/AssetsHeader';
import { AssetStatistics } from '../components/AssetStatistics';
import { AssetFiltersBar } from '../components/AssetFiltersBar';
import { AssetTable } from '../components/AssetTable';
import { AssetDetailModal } from '../components/AssetDetailModal';
import { AssetSummaryItem, AssetDetailResponse, AssetOverviewResponse } from '../../../types/assets';

// Synthetic records from input_data (asset.equipment, asset.inspection_event, asset.failure_report)
const mockOverview: AssetOverviewResponse = {
  total_equipment: 50,
  safety_critical: 21,
  overdue_inspections: 5,
  failures: 50,
  open_work_orders: 12,
  criticality_counts: { critical: 16, high: 26, medium: 8 },
  class_counts: { vessel: 14, compressor: 10 },
  facility_counts: { 'Falcon Draw CTB-1': 6 },
  as_of: '2026-09-30',
};

const mockAssets: AssetSummaryItem[] = [
  {
    equipment_id: 5001,
    tag: 'FD1-K-201',
    name: 'Falcon Draw CTB-1 Gas Lift Compressor K-201',
    equipment_type: 'compressor',
    facility: 'Falcon Draw CTB-1',
    facility_code: 'FD-CTB1',
    criticality: 'critical',
    safety_critical: true,
    maintenance_strategy: 'condition_based',
    next_inspection_due_date: '2026-11-20',
    inspection_overdue: false,
    failure_count: 2,
    inspection_count: 2,
    work_order_count: 3,
    last_failure_date: '2026-03-02',
    mtbf_hours: 3200,
    std_class: 'Compressor',
  },
  {
    equipment_id: 5040,
    tag: 'R107-BOP',
    name: 'Rig 107 BOP stack',
    equipment_type: 'blowout preventer',
    facility: null,
    facility_code: null,
    criticality: 'critical',
    safety_critical: true,
    maintenance_strategy: 'preventive',
    next_inspection_due_date: '2026-08-15',
    inspection_overdue: true,
    failure_count: 0,
    inspection_count: 1,
    work_order_count: 0,
    last_failure_date: null,
    mtbf_hours: null,
    std_class: 'BlowoutPreventer',
  },
];

const mockDetail: AssetDetailResponse = {
  asset: {
    equipment_id: 5001,
    tag: 'FD1-K-201',
    equipment_name: 'Falcon Draw CTB-1 Gas Lift Compressor K-201',
    equipment_type: 'compressor',
    criticality_ranking: 'critical',
    is_safety_critical: true,
  },
  facility: { code: 'FD-CTB1', name: 'Falcon Draw CTB-1' },
  parent: null,
  children: [],
  functional_location: [{ code: 'FD-CTB1', iso14224_level: 'installation', name: 'Falcon Draw CTB-1' }],
  maintenance_plans: [],
  integrity_programs: [],
  inspections: [{ inspection: 'INS-2025-0001', date: '2025-08-20', type: 'ultrasonic_thickness', findings: '38% wall loss at the discharge elbow' }],
  failures: [{ failure: 'FR-2025-0001', date: '2025-09-18', repair_cost_usd: 27500, preceded_by_inspection: 'INS-2025-0001' }],
  work_orders: [],
  downtime: [],
  hse_events: [],
  drilling_npt: [],
  graph: { nodes: [], edges: [] },
};

const wrap = (el: React.ReactElement) => renderToStaticMarkup(<MemoryRouter>{el}</MemoryRouter>);

describe('Equipment Integrity Components', () => {
  test('AssetsHeader shows equipment and safety-critical counts', () => {
    const html = wrap(<AssetsHeader totalEquipment={50} safetyCritical={21} asOf="2026-09-30" isLoading={false} onRefresh={() => {}} />);
    expect(html).toContain('Equipment Integrity');
    expect(html).toContain('50 items');
    expect(html).toContain('21 safety-critical');
    expect(html).toContain('as of 2026-09-30');
  });

  test('AssetStatistics renders KPIs and ISO 14224 classes', () => {
    const html = wrap(<AssetStatistics overview={mockOverview} isLoading={false} />);
    expect(html).toContain('Overdue SCE inspections');
    expect(html).toContain('Critical: 16');
    expect(html).toContain('Compressor: 10');
  });

  test('AssetFiltersBar shows the search value and clear button', () => {
    const html = wrap(
      <AssetFiltersBar
        search="K-201"
        equipmentType=""
        criticality="critical"
        facilityCode=""
        safetyCriticalOnly={false}
        equipmentTypes={['compressor', 'vessel']}
        facilities={[{ code: 'FD-CTB1', name: 'Falcon Draw CTB-1' }]}
        onSearchChange={() => {}}
        onEquipmentTypeChange={() => {}}
        onCriticalityChange={() => {}}
        onFacilityChange={() => {}}
        onSafetyCriticalChange={() => {}}
        onClearFilters={() => {}}
      />
    );
    expect(html).toContain('K-201');
    expect(html).toContain('Clear');
    expect(html).toContain('Safety-critical only');
  });

  test('AssetTable lists equipment with overdue inspection badge', () => {
    const html = wrap(
      <AssetTable
        assets={mockAssets}
        total={2}
        page={0}
        rowsPerPage={25}
        isLoading={false}
        onPageChange={() => {}}
        onRowsPerPageChange={() => {}}
        onSelectAsset={() => {}}
      />
    );
    expect(html).toContain('FD1-K-201');
    expect(html).toContain('R107-BOP');
    expect(html).toContain('Overdue');
    expect(html).toContain('Blowout Preventer');
  });

  test('AssetTable shows an empty state', () => {
    const html = wrap(
      <AssetTable
        assets={[]}
        total={0}
        page={0}
        rowsPerPage={25}
        isLoading={false}
        onPageChange={() => {}}
        onRowsPerPageChange={() => {}}
        onSelectAsset={() => {}}
      />
    );
    expect(html).toContain('No equipment matches the filters.');
  });

  test('AssetDetailModal renders nothing visible when closed', () => {
    const html = wrap(<AssetDetailModal open={false} assetDetail={mockDetail} isLoading={false} onClose={() => {}} />);
    expect(html).not.toContain('FD1-K-201');
  });
});
