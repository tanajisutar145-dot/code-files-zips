/**
 * Model & Standards: how every oil_gas table, column and foreign key maps to the industry-standard reference
 * classes (OSDU, PPDM, Energistics, SPE-PRMS, ISO 14224, API RP 754...), the subject areas and use cases,
 * and the status of the pipeline steps. The semantic model is served before the graph is loaded.
 */

import React, { useMemo, useState } from 'react';
import {
  Alert,
  Box,
  Chip,
  CircularProgress,
  Grid,
  Tab,
  Tabs,
  TextField,
  Typography,
} from '@mui/material';
import { Schema as ModelIcon, CheckCircle as OkIcon, Cancel as NoIcon } from '@mui/icons-material';
import { useApi } from '../../hooks/useApi';
import { modelApi } from '../../services/api';
import { SectionCard } from '../../components/common/SectionCard';
import { DataTable } from '../../components/common/DataTable';
import { EvidenceGraph } from '../../components/common/EvidenceGraph';
import { ModelTable } from '../../types/model';
import { getDomainColor } from '../graph/utils/graphStyles';
import { getStatusColorInfo } from '../graph/utils/relationshipUtils';

const MatchChip: React.FC<{ match?: string | null }> = ({ match }) =>
  match ? (
    <Chip
      size="small"
      label={match}
      sx={{ height: 18, fontSize: '0.65rem', bgcolor: getStatusColorInfo(match).bg, color: getStatusColorInfo(match).text }}
    />
  ) : (
    <span style={{ color: '#cbd5e1' }}>—</span>
  );

const Flag: React.FC<{ ok?: boolean | null; label: string }> = ({ ok, label }) => (
  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
    {ok ? <OkIcon sx={{ fontSize: 16, color: '#059669' }} /> : <NoIcon sx={{ fontSize: 16, color: '#dc2626' }} />}
    <Typography variant="caption">{label}</Typography>
  </Box>
);

const ModelPage: React.FC = () => {
  const [tab, setTab] = useState(0);
  const [filter, setFilter] = useState('');
  const [selected, setSelected] = useState<string>('DrillingWell');
  const model = useApi(() => modelApi.model(), []);
  const standards = useApi(() => modelApi.standards(), []);
  const pipeline = useApi(() => modelApi.pipeline(), []);
  const sample = useApi(() => modelApi.classSample(selected, 10), [selected], tab === 1 && !!selected);

  const tables = useMemo(() => model.data?.tables || [], [model.data]);
  const table: ModelTable | undefined = tables.find((t) => t.label === selected);
  const shown = tables.filter(
    (t) =>
      !filter ||
      `${t.label} ${t.table} ${t.standard_class || ''} ${t.standard_package || ''} ${(t.subject_areas || []).join(' ')}`
        .toLowerCase()
        .includes(filter.toLowerCase())
  );
  const relsOut = (model.data?.relationships || []).filter((r) => r.from === selected);
  const relsIn = (model.data?.relationships || []).filter((r) => r.to === selected);
  const p = pipeline.data;

  return (
    <Box sx={{ width: '100%', maxWidth: 1700, mx: 'auto', pb: 4 }}>
      <Box sx={{ mb: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.25 }}>
          <ModelIcon sx={{ color: '#0f766e', fontSize: 28 }} />
          <Typography variant="h5" component="h1" sx={{ fontWeight: 700, color: '#0f172a' }}>
            Model & Standards
          </Typography>
        </Box>
        <Typography variant="body2" sx={{ color: '#64748b', mt: 0.5 }}>
          Semantic model extracted from the oil_gas DDL and OWL ontology, aligned to{' '}
          {model.data?.standard?.name || 'the oil & gas standards reference'}; every graph label carries its standard class as an extra{' '}
          <code>{model.data?.standard?.short || 'STD'}_</code> label.
        </Typography>
      </Box>

      {model.error && <Alert severity="error" sx={{ mb: 2 }}>{model.error} — run <code>python -m app.kg run --step model</code>.</Alert>}
      {model.loading && <CircularProgress size={24} />}

      <Grid container spacing={2.5}>
        <Grid item xs={12} md={4}>
          <SectionCard title="Pipeline status" subtitle={p?.config}>
            {pipeline.error && <Typography color="error" variant="caption">{pipeline.error}</Typography>}
            {p && (
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75 }}>
                <Flag ok={p.model_step.semantic_model} label={`Model step: ${p.model_step.classes} classes, ${p.model_step.relationships} relationships, ${p.model_step.aligned_classes} aligned`} />
                <Flag
                  ok={p.validation?.passed}
                  label={p.validation ? `Data validation: ${p.validation.rows} rows, ${p.validation.foreign_keys} foreign keys checked` : 'Data validation not run yet'}
                />
                <Flag ok={!!p.load_step} label={p.load_step ? 'Load step finished' : 'Graph not loaded yet (load step)'} />
                <Flag ok={p.neo4j.connected} label={`Neo4j database "${p.neo4j.database}" ${p.neo4j.connected ? 'reachable' : 'not reachable'}`} />
                <Flag ok={p.report} label={p.report ? 'Retriever comparison report written (rag step)' : 'Retriever comparison not run yet (rag step)'} />
                <Box sx={{ mt: 1, p: 1, bgcolor: '#0f172a', color: '#e2e8f0', borderRadius: 1.5, fontFamily: 'monospace', fontSize: '0.72rem' }}>
                  {Object.entries(p.commands).map(([k, v]) => (
                    <div key={k}>{v}</div>
                  ))}
                </Box>
              </Box>
            )}
          </SectionCard>
        </Grid>
        <Grid item xs={12} md={8}>
          <SectionCard title="Subject areas" subtitle={model.data ? `${tables.length} classes · ${model.data.sources?.triples?.toLocaleString?.() || ''} ontology triples read` : undefined}>
            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(2, 1fr)' }, gap: 1.25 }}>
              {(model.data?.domains || [])
                .filter((d) => tables.some((t) => t.schema === d.domain))
                .map((d) => (
                  <Box key={d.domain} sx={{ p: 1.25, border: '1px solid #e2e8f0', borderLeft: `4px solid ${d.color}`, borderRadius: 1.5 }}>
                    <Typography variant="caption" sx={{ fontWeight: 700, color: '#0f172a' }}>
                      {d.domain} · {tables.filter((t) => t.schema === d.domain).length} classes
                    </Typography>
                    <Typography variant="caption" sx={{ display: 'block', color: '#64748b', lineHeight: 1.35 }} title={d.comment}>
                      {(d.comment || '').slice(0, 170)}
                      {(d.comment || '').length > 170 ? '…' : ''}
                    </Typography>
                  </Box>
                ))}
            </Box>
          </SectionCard>
        </Grid>
      </Grid>

      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 2, borderBottom: '1px solid #e2e8f0', '& .MuiTab-root': { textTransform: 'none', fontWeight: 600 } }}>
        <Tab label={`Classes (${tables.length})`} />
        <Tab label={`Class detail · ${selected}`} />
        <Tab label={`Standards alignment (${standards.data?.classes.length || 0})`} />
        <Tab label={`Relationships (${(model.data?.relationships.length || 0) + (model.data?.extra_relationships.length || 0)})`} />
      </Tabs>

      {tab === 0 && (
        <SectionCard
          title="Ontology classes and their standard class"
          subtitle="Click a class for its columns, standard attributes, units, relationships and a sample of instances."
          action={<TextField size="small" placeholder="Filter classes" value={filter} onChange={(e) => setFilter(e.target.value)} />}
        >
          <DataTable
            rows={shown}
            maxHeight={620}
            onRowClick={(r) => {
              setSelected(r.label);
              setTab(1);
            }}
            columns={[
              { key: 'label', label: 'Class / label' },
              { key: 'table', label: 'Table' },
              {
                key: 'schema',
                label: 'Subject area',
                render: (v) => <Chip size="small" label={v} sx={{ height: 18, fontSize: '0.65rem', bgcolor: getDomainColor(v), color: '#fff' }} />,
              },
              { key: 'standard_class', label: 'Standard class' },
              { key: 'standard_match', label: 'Match', render: (v) => <MatchChip match={v} /> },
              { key: 'standard_package', label: 'Standard package' },
              {
                key: 'subject_areas',
                label: 'Use cases',
                render: (v: string[]) => (
                  <Box sx={{ display: 'flex', gap: 0.5 }}>
                    {(v || [])
                      .filter((s) => s.startsWith('UC'))
                      .map((s) => (
                        <Chip key={s} size="small" label={s} sx={{ height: 18, fontSize: '0.65rem' }} />
                      ))}
                  </Box>
                ),
              },
            ]}
          />
        </SectionCard>
      )}

      {tab === 1 && table && (
        <Box>
          <SectionCard
            title={`${table.label} (${table.table})`}
            subtitle={table.description}
            action={<MatchChip match={table.standard_match} />}
          >
            <Box sx={{ display: 'flex', gap: 0.75, flexWrap: 'wrap', mb: 1.5 }}>
              {table.standard_class && <Chip size="small" label={`Standard class: ${table.standard_class}`} />}
              {table.standard_package && <Chip size="small" variant="outlined" label={table.standard_package} />}
              {table.standard_standard && <Chip size="small" variant="outlined" label={table.standard_standard} />}
              {(table.standard_ancestors || []).length > 0 && (
                <Chip size="small" variant="outlined" label={`Ancestors: ${table.standard_ancestors.join(' → ')}`} />
              )}
              <Chip size="small" variant="outlined" label={`Primary key: ${table.primary_key}`} />
            </Box>
            <DataTable
              rows={(table.columns || []).map((c) => ({
                column: c.column,
                sql_type: c.sql_type,
                standard_attribute: c.standard_attribute,
                match: c.standard_match,
                unit: c.unit,
                enum_values: c.enum_values,
                description: c.description,
              }))}
              maxHeight={420}
              columns={[
                'column',
                'sql_type',
                'standard_attribute',
                { key: 'match', render: (v) => <MatchChip match={v} /> },
                'unit',
                'enum_values',
                { key: 'description', render: (v) => <span style={{ fontSize: '0.72rem', color: '#475569' }}>{v}</span> },
              ]}
            />
          </SectionCard>
          <Grid container spacing={2.5}>
            <Grid item xs={12} md={6}>
              <SectionCard title={`Outgoing relationships (${relsOut.length})`} subtitle="Foreign keys of this table: (this)-[TYPE]->(referenced class)">
                <DataTable rows={relsOut} columns={['type', 'to', 'fk', 'standard_association', 'cross_domain']} maxHeight={300} />
              </SectionCard>
            </Grid>
            <Grid item xs={12} md={6}>
              <SectionCard title={`Incoming relationships (${relsIn.length})`}>
                <DataTable rows={relsIn} columns={['from', 'type', 'fk', 'standard_association', 'cross_domain']} maxHeight={300} />
              </SectionCard>
            </Grid>
          </Grid>
          <SectionCard title="Sample instances from the graph" subtitle="Up to ten records of the class with their foreign-key and derived neighbours.">
            {sample.error ? (
              <Alert severity="info">{sample.error}</Alert>
            ) : sample.loading ? (
              <CircularProgress size={22} />
            ) : (
              <EvidenceGraph graph={sample.data} height={420} emptyText="No instances loaded for this class." />
            )}
          </SectionCard>
        </Box>
      )}

      {tab === 2 && (
        <Box>
          <SectionCard title="Standard classes and the ontology classes aligned to them" subtitle={standards.data?.standard?.namespace}>
            {standards.error && <Alert severity="error">{standards.error}</Alert>}
            <DataTable
              rows={(standards.data?.classes || []).map((c) => ({
                standard_class: c.standard_class,
                package: c.package,
                standard: c.standard,
                parents: c.parents,
                ontology_classes: c.classes.map((x) => `${x.label} (${x.match || 'aligned'})`),
              }))}
              maxHeight={520}
            />
          </SectionCard>
          <SectionCard title={`Column → standard attribute mappings (${standards.data?.attributes.length || 0})`} subtitle="With the unit of measure inferred from the column name.">
            <DataTable
              rows={standards.data?.attributes || []}
              maxHeight={520}
              columns={['class', 'column', 'standard_attribute', { key: 'match', render: (v) => <MatchChip match={v} /> }, 'unit']}
            />
          </SectionCard>
          {standards.data && Object.keys(standards.data.use_cases || {}).length > 0 && (
            <SectionCard title="Use-case concepts (SKOS)">
              <DataTable
                rows={Object.entries(standards.data.use_cases).map(([id, u]) => ({ id, label: u.label, definition: u.definition, scope_note: u.scope_note }))}
              />
            </SectionCard>
          )}
        </Box>
      )}

      {tab === 3 && (
        <Box>
          <SectionCard title="Derived relationships" subtitle="Created by the rules in backend/config.yaml (graph.derived_relationships) after the load.">
            <DataTable rows={model.data?.extra_relationships || []} columns={['type', 'kind', { key: 'std', label: 'Meaning' }]} />
          </SectionCard>
          <SectionCard title="Foreign-key relationships" subtitle="One relationship type per foreign key, named after the referenced class.">
            <DataTable rows={model.data?.relationships || []} maxHeight={620} columns={['from', 'type', 'to', 'fk', 'standard_association', 'cross_domain', 'resolution']} />
          </SectionCard>
        </Box>
      )}
    </Box>
  );
};

export default ModelPage;
