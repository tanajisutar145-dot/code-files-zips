import React from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
} from '@mui/material';
import { MonitorHeart as HealthIcon } from '@mui/icons-material';
import { HealthPanel } from '../../components/common/HealthPanel';
import { useHealth } from '../../hooks/useHealth';

const HealthPage: React.FC = () => {
  const { error, lastChecked, raw } = useHealth();

  return (
    <Box>
      <Box display="flex" alignItems="center" gap={2} mb={3}>
        <HealthIcon />
        <Typography variant="h4">
          System Health
        </Typography>
      </Box>
      
      <Typography variant="subtitle1" color="textSecondary" paragraph>
        Monitor the status of all backend services and system components.
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <HealthPanel 
            title="Service Status"
            showRefresh={true}
            autoRefresh={true}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Health Details
              </Typography>
              
              {lastChecked && (
                <Typography variant="body2" color="textSecondary" paragraph>
                  Last checked: {lastChecked.toLocaleString()}
                </Typography>
              )}

              <Box mb={2}>
                <Typography variant="subtitle2" gutterBottom>
                  Backend API
                </Typography>
                <Typography variant="body2" color="textSecondary">
                  Core FastAPI service providing REST endpoints for all system functionality.
                </Typography>
              </Box>

              <Box mb={2}>
                <Typography variant="subtitle2" gutterBottom>
                  Neo4j Database {raw?.database ? `(${raw.database})` : ''}
                </Typography>
                <Typography variant="body2" color="textSecondary">
                  Graph database holding the oil_gas records, the derived well identities, the semantic and standards layer,
                  narrative chunks with their vector and full-text indexes, and uploaded documents. Graph = loaded once the
                  load step has run (python -m app.kg run --step load).
                </Typography>
              </Box>

              <Box mb={2}>
                <Typography variant="subtitle2" gutterBottom>
                  Semantic model
                </Typography>
                <Typography variant="body2" color="textSecondary">
                  Classes, columns, units and standards alignment extracted from the DDL and ontology (model step,
                  backend/build/semantic_model.json).
                </Typography>
              </Box>

              <Box mb={2}>
                <Typography variant="subtitle2" gutterBottom>
                  LLM {raw?.models?.llm ? `(${raw.models.llm})` : ''}
                </Typography>
                <Typography variant="body2" color="textSecondary">
                  Writes Text2Cypher queries and the answers (LLM_* in backend/.env: OpenAI, Azure OpenAI, Anthropic,
                  OpenAI-compatible or Ollama).
                </Typography>
              </Box>

              <Box mb={2}>
                <Typography variant="subtitle2" gutterBottom>
                  Embedder {raw?.models?.embedder ? `(${raw.models.embedder})` : ''}
                </Typography>
                <Typography variant="body2" color="textSecondary">
                  Embeds narrative chunks, uploaded documents and questions for vector and hybrid retrieval (EMBEDDING_* in
                  backend/.env).
                </Typography>
              </Box>

              {error && (
                <Box mt={2}>
                  <Typography variant="subtitle2" color="error" gutterBottom>
                    Connection Issue
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    {error.message}
                  </Typography>
                </Box>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default HealthPage;