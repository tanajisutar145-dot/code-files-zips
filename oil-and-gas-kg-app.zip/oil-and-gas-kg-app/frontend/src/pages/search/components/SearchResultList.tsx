import React, { useState } from 'react';
import {
  Box,
  Card,
  Typography,
  Chip,
  Tooltip,
  LinearProgress,
  Button,
} from '@mui/material';
import {
  Description as DocumentIcon,
  Fingerprint as ChunkIcon,
  Person as SourceIcon,
  Label as TypeIcon,
  Hub as EntityIcon,
  ChevronRight as ChevronRightIcon,
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon,
  CheckCircle as SelectedIcon,
} from '@mui/icons-material';
import { SemanticSearchResult, GraphEvidence } from '../../../types/api';
import {
  formatSimilarityScore,
  highlightQueryTerms,
  extractLinkedEntities,
} from '../utils/searchUtils';

interface SearchResultListProps {
  results: SemanticSearchResult[];
  selectedChunkId: string | null;
  onSelectResult: (chunkId: string) => void;
  graphEvidence?: GraphEvidence;
  activeQuery: string;
}

export const SearchResultList: React.FC<SearchResultListProps> = ({
  results,
  selectedChunkId,
  onSelectResult,
  graphEvidence,
  activeQuery,
}) => {
  // Track expanded snippets per chunk
  const [expandedChunks, setExpandedChunks] = useState<Record<string, boolean>>({});

  const toggleExpand = (chunkId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedChunks((prev) => ({
      ...prev,
      [chunkId]: !prev[chunkId],
    }));
  };

  const getScoreColor = (score: number) => {
    if (score >= 0.8) return { text: '#0f766e', bg: 'rgba(15, 118, 110, 0.1)', bar: '#0f766e' };
    if (score >= 0.6) return { text: '#0284c7', bg: 'rgba(2, 132, 199, 0.1)', bar: '#0284c7' };
    return { text: '#d97706', bg: 'rgba(217, 119, 6, 0.1)', bar: '#d97706' };
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="subtitle1" sx={{ fontWeight: 700, color: '#0f172a' }}>
          Retrieved Chunks ({results.length})
        </Typography>
        <Typography variant="caption" sx={{ color: '#64748b' }}>
          Ranked by Cosine Vector Similarity
        </Typography>
      </Box>

      {results.map((result, index) => {
        const isSelected = result.chunk_id === selectedChunkId;
        const isExpanded = !!expandedChunks[result.chunk_id];
        const scoreColor = getScoreColor(result.score);
        const linkedEntities = extractLinkedEntities(result.document_id, graphEvidence);

        return (
          <Card
            key={result.chunk_id}
            onClick={() => onSelectResult(result.chunk_id)}
            elevation={0}
            sx={{
              p: 2.25,
              cursor: 'pointer',
              borderRadius: 2,
              border: isSelected ? '2px solid #0f766e' : '1px solid #e2e8f0',
              bgcolor: isSelected ? 'rgba(15, 118, 110, 0.02)' : '#ffffff',
              boxShadow: isSelected
                ? '0 4px 12px rgba(15, 118, 110, 0.1)'
                : '0 1px 3px rgba(0, 0, 0, 0.04)',
              transition: 'all 0.2s ease-in-out',
              '&:hover': {
                borderColor: isSelected ? '#0f766e' : '#cbd5e1',
                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.08)',
                transform: 'translateY(-1px)',
              },
            }}
          >
            {/* Header: Rank, Title, Score */}
            <Box
              sx={{
                display: 'flex',
                alignItems: 'flex-start',
                justifyContent: 'space-between',
                gap: 1.5,
                mb: 1.5,
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1.25, flex: 1 }}>
                {/* Rank Badge */}
                <Box
                  sx={{
                    minWidth: 28,
                    height: 28,
                    borderRadius: 1,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    bgcolor: isSelected ? '#0f766e' : '#f1f5f9',
                    color: isSelected ? '#ffffff' : '#475569',
                    fontWeight: 700,
                    fontSize: '0.75rem',
                  }}
                >
                  #{index + 1}
                </Box>

                <Box sx={{ flex: 1 }}>
                  <Typography
                    variant="subtitle2"
                    sx={{
                      fontWeight: 600,
                      color: isSelected ? '#0f766e' : '#0f172a',
                      fontSize: '0.9375rem',
                      lineHeight: 1.3,
                    }}
                  >
                    {result.document_title}
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 0.5, flexWrap: 'wrap' }}>
                    <Typography
                      variant="caption"
                      sx={{
                        color: '#64748b',
                        fontWeight: 600,
                        display: 'flex',
                        alignItems: 'center',
                        gap: 0.5,
                      }}
                    >
                      <DocumentIcon sx={{ fontSize: 13 }} />
                      {result.document_id}
                    </Typography>
                    <Typography variant="caption" sx={{ color: '#cbd5e1' }}>
                      •
                    </Typography>
                    <Typography
                      variant="caption"
                      sx={{
                        color: '#64748b',
                        display: 'flex',
                        alignItems: 'center',
                        gap: 0.5,
                      }}
                    >
                      <ChunkIcon sx={{ fontSize: 13 }} />
                      {result.chunk_id}
                    </Typography>
                  </Box>
                </Box>
              </Box>

              {/* Similarity Score Pill */}
              <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', minWidth: 96 }}>
                <Tooltip title={`Cosine vector similarity: ${result.score.toFixed(4)}`}>
                  <Chip
                    size="small"
                    label={`${formatSimilarityScore(result.score)} match`}
                    sx={{
                      bgcolor: scoreColor.bg,
                      color: scoreColor.text,
                      fontWeight: 700,
                      fontSize: '0.75rem',
                      height: 24,
                      border: `1px solid ${scoreColor.bar}40`,
                    }}
                  />
                </Tooltip>
                <Box sx={{ width: '100%', mt: 0.75 }}>
                  <LinearProgress
                    variant="determinate"
                    value={Math.min(100, Math.max(0, result.score * 100))}
                    sx={{
                      height: 4,
                      borderRadius: 2,
                      bgcolor: '#f1f5f9',
                      '& .MuiLinearProgress-bar': {
                        bgcolor: scoreColor.bar,
                      },
                    }}
                  />
                </Box>
              </Box>
            </Box>

            {/* Chunk Snippet Text */}
            <Box
              sx={{
                p: 1.5,
                bgcolor: '#f8fafc',
                border: '1px solid #e2e8f0',
                borderRadius: 1.5,
                mb: 1.5,
              }}
            >
              <Typography
                variant="body2"
                sx={{
                  color: '#334155',
                  fontSize: '0.875rem',
                  lineHeight: 1.6,
                  fontFamily: 'inherit',
                  whiteSpace: 'pre-wrap',
                }}
              >
                {isExpanded
                  ? highlightQueryTerms(result.text, activeQuery)
                  : highlightQueryTerms(
                      result.text.length > 220
                        ? `${result.text.slice(0, 220)}...`
                        : result.text,
                      activeQuery
                    )}
              </Typography>

              {result.text.length > 220 && (
                <Button
                  size="small"
                  onClick={(e) => toggleExpand(result.chunk_id, e)}
                  endIcon={
                    isExpanded ? (
                      <ExpandLessIcon sx={{ fontSize: 16 }} />
                    ) : (
                      <ExpandMoreIcon sx={{ fontSize: 16 }} />
                    )
                  }
                  sx={{
                    mt: 1,
                    p: 0,
                    minWidth: 'auto',
                    color: '#0f766e',
                    fontSize: '0.75rem',
                    fontWeight: 600,
                    textTransform: 'none',
                    '&:hover': { bgcolor: 'transparent', textDecoration: 'underline' },
                  }}
                >
                  {isExpanded ? 'Show less' : 'Expand full chunk text'}
                </Button>
              )}
            </Box>

            {/* Metadata Tags & Associated Graph Entities */}
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                gap: 1,
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 0.75 }}>
                {result.source && (
                  <Chip
                    size="small"
                    icon={<SourceIcon sx={{ fontSize: '13px !important' }} />}
                    label={result.source}
                    variant="outlined"
                    sx={{
                      height: 22,
                      fontSize: '0.6875rem',
                      color: '#475569',
                      borderColor: '#cbd5e1',
                    }}
                  />
                )}

                {result.metadata?.document_type && (
                  <Chip
                    size="small"
                    icon={<TypeIcon sx={{ fontSize: '13px !important' }} />}
                    label={result.metadata.document_type.replace('_', ' ')}
                    variant="outlined"
                    sx={{
                      height: 22,
                      fontSize: '0.6875rem',
                      color: '#475569',
                      borderColor: '#cbd5e1',
                      textTransform: 'capitalize',
                    }}
                  />
                )}

                {linkedEntities.length > 0 && (
                  <Tooltip
                    title={`Linked entities in knowledge graph: ${linkedEntities
                      .map((e) => `${e.entity_type} (${e.entity_id})`)
                      .join(', ')}`}
                  >
                    <Chip
                      size="small"
                      icon={<EntityIcon sx={{ fontSize: '13px !important', color: '#7c3aed !important' }} />}
                      label={`${linkedEntities.length} Linked Entit${
                        linkedEntities.length === 1 ? 'y' : 'ies'
                      }`}
                      sx={{
                        height: 22,
                        fontSize: '0.6875rem',
                        bgcolor: 'rgba(124, 58, 237, 0.08)',
                        color: '#7c3aed',
                        fontWeight: 600,
                        border: '1px solid rgba(124, 58, 237, 0.2)',
                      }}
                    />
                  </Tooltip>
                )}
              </Box>

              {/* Selection prompt / indicator */}
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                {isSelected ? (
                  <Chip
                    size="small"
                    icon={<SelectedIcon sx={{ fontSize: '14px !important', color: '#0f766e !important' }} />}
                    label="Inspecting Evidence"
                    sx={{
                      height: 22,
                      fontSize: '0.6875rem',
                      bgcolor: 'rgba(15, 118, 110, 0.1)',
                      color: '#0f766e',
                      fontWeight: 600,
                    }}
                  />
                ) : (
                  <Typography
                    variant="caption"
                    sx={{
                      color: '#94a3b8',
                      fontWeight: 500,
                      fontSize: '0.75rem',
                      display: 'flex',
                      alignItems: 'center',
                    }}
                  >
                    Click to view evidence <ChevronRightIcon sx={{ fontSize: 16 }} />
                  </Typography>
                )}
              </Box>
            </Box>
          </Card>
        );
      })}
    </Box>
  );
};
