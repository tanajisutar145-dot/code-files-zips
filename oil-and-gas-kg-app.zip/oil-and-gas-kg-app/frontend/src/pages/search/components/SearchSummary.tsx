import React from 'react';
import { Box, Card, Typography, Chip } from '@mui/material';
import {
  Speed as LatencyIcon,
  AutoGraph as GraphIcon,
  FactCheck as ResultsIcon,
  GpsFixed as TargetIcon,
} from '@mui/icons-material';
import { RetrievalResult } from '../../../types/api';
import { formatSimilarityScore, formatExecutionTime } from '../utils/searchUtils';

interface SearchSummaryProps {
  result: RetrievalResult;
}

export const SearchSummary: React.FC<SearchSummaryProps> = ({ result }) => {
  const count = result.semantic_results?.length || 0;
  const topScore = count > 0 ? result.semantic_results[0].score : undefined;
  const executionTime = result.metadata?.execution_time;
  const entityCount = result.graph_evidence?.entities?.length || result.metadata?.graph_entities_count || 0;
  const relCount = result.graph_evidence?.relationships?.length || result.metadata?.graph_relationships_count || 0;

  return (
    <Card
      elevation={0}
      sx={{
        p: 1.75,
        mb: 2.5,
        bgcolor: '#ffffff',
        border: '1px solid #e2e8f0',
        borderRadius: 2,
        display: 'flex',
        flexWrap: 'wrap',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 1.5,
      }}
    >
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, minWidth: 200, flex: '1 1 auto' }}>
        <Typography variant="body2" sx={{ color: '#64748b', fontWeight: 500, fontSize: '0.8125rem' }}>
          Query:
        </Typography>
        <Typography
          variant="body2"
          sx={{
            fontWeight: 600,
            color: '#0f172a',
            fontSize: '0.875rem',
            fontStyle: 'italic',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            maxWidth: { xs: 260, md: 480 },
          }}
          title={result.query}
        >
          "{result.query}"
        </Typography>
      </Box>

      <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 1 }}>
        {/* Results Count */}
        <Chip
          size="small"
          icon={<ResultsIcon sx={{ fontSize: '15px !important', color: '#0284c7 !important' }} />}
          label={`${count} Chunk${count === 1 ? '' : 's'}`}
          sx={{
            bgcolor: '#f0f9ff',
            color: '#0369a1',
            fontWeight: 600,
            fontSize: '0.75rem',
            border: '1px solid #bae6fd',
          }}
        />

        {/* Highest Similarity */}
        {topScore !== undefined && (
          <Chip
            size="small"
            icon={<TargetIcon sx={{ fontSize: '15px !important', color: '#0f766e !important' }} />}
            label={`Top Match: ${formatSimilarityScore(topScore)}`}
            sx={{
              bgcolor: 'rgba(15, 118, 110, 0.08)',
              color: '#0f766e',
              fontWeight: 600,
              fontSize: '0.75rem',
              border: '1px solid rgba(15, 118, 110, 0.25)',
            }}
          />
        )}

        {/* Graph Evidence Counts */}
        <Chip
          size="small"
          icon={<GraphIcon sx={{ fontSize: '15px !important', color: '#7c3aed !important' }} />}
          label={`${entityCount} Entit${entityCount === 1 ? 'y' : 'ies'}, ${relCount} Rel${relCount === 1 ? '' : 's'}`}
          sx={{
            bgcolor: '#f5f3ff',
            color: '#6d28d9',
            fontWeight: 600,
            fontSize: '0.75rem',
            border: '1px solid #ddd6fe',
          }}
        />

        {/* Latency */}
        {executionTime !== undefined && (
          <Chip
            size="small"
            icon={<LatencyIcon sx={{ fontSize: '15px !important', color: '#475569 !important' }} />}
            label={formatExecutionTime(executionTime)}
            sx={{
              bgcolor: '#f8fafc',
              color: '#475569',
              fontWeight: 600,
              fontSize: '0.75rem',
              border: '1px solid #e2e8f0',
            }}
          />
        )}
      </Box>
    </Card>
  );
};
