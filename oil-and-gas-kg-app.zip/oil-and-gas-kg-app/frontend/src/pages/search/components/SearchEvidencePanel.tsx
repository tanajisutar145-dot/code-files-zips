import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Card,
  Typography,
  Chip,
  Button,
  Tooltip,
  Divider,
  Table,
  TableBody,
  TableCell,
  TableRow,
  Accordion,
  AccordionSummary,
  AccordionDetails,
} from '@mui/material';
import {
  ContentCopy as CopyIcon,
  Check as CheckIcon,
  Description as DocumentIcon,
  AccountTree as RouteIcon,
  ArrowForward as ArrowForwardIcon,
  ExpandMore as ExpandMoreIcon,
  OpenInNew as OpenInNewIcon,
} from '@mui/icons-material';
import {
  SemanticSearchResult,
  GraphEvidence,
  GraphEntity,
  GraphRelationship,
} from '../../../types/api';
import {
  formatSimilarityScore,
  formatDate,
  extractLinkedEntities,
  extractLinkedRelationships,
} from '../utils/searchUtils';
import { getNodeColor } from '../../graph/utils/graphStyles';

interface SearchEvidencePanelProps {
  selectedResult: SemanticSearchResult | null;
  graphEvidence?: GraphEvidence;
  activeQuery: string;
}

export const SearchEvidencePanel: React.FC<SearchEvidencePanelProps> = ({
  selectedResult,
  graphEvidence,
  activeQuery,
}) => {
  const navigate = useNavigate();
  const [copied, setCopied] = useState(false);

  if (!selectedResult) {
    return (
      <Card
        elevation={0}
        sx={{
          p: 4,
          bgcolor: '#ffffff',
          border: '1px dashed #cbd5e1',
          borderRadius: 2,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          minHeight: 360,
          textAlign: 'center',
          gap: 1.5,
        }}
      >
        <DocumentIcon sx={{ fontSize: 44, color: '#94a3b8' }} />
        <Typography variant="subtitle1" sx={{ fontWeight: 600, color: '#475569' }}>
          No Chunk Selected
        </Typography>
        <Typography variant="body2" sx={{ color: '#64748b', maxWidth: 320 }}>
          Select any retrieved chunk from the search results to inspect its complete text,
          telemetry, and linked knowledge graph entities.
        </Typography>
      </Card>
    );
  }

  const handleCopyText = () => {
    if (selectedResult.text) {
      navigator.clipboard.writeText(selectedResult.text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const linkedEntities: GraphEntity[] = extractLinkedEntities(
    selectedResult.document_id,
    graphEvidence
  );

  const linkedRelationships: GraphRelationship[] = extractLinkedRelationships(
    selectedResult.document_id,
    graphEvidence
  );

  // Remaining entities from graph expansion not directly linked to this document
  const otherEntities: GraphEntity[] = (graphEvidence?.entities || []).filter(
    (e) => !linkedEntities.some((le) => le.entity_id === e.entity_id)
  );

  return (
    <Card
      elevation={0}
      sx={{
        p: 2.5,
        bgcolor: '#ffffff',
        border: '1px solid #e2e8f0',
        borderRadius: 2,
        display: 'flex',
        flexDirection: 'column',
        gap: 2.5,
        position: 'sticky',
        top: 24,
      }}
    >
      {/* Panel Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
            <Chip
              size="small"
              label={selectedResult.document_id}
              sx={{
                bgcolor: '#0f766e',
                color: '#ffffff',
                fontWeight: 700,
                fontSize: '0.6875rem',
                height: 22,
              }}
            />
            <Chip
              size="small"
              label={selectedResult.chunk_id}
              variant="outlined"
              sx={{
                borderColor: '#cbd5e1',
                color: '#64748b',
                fontSize: '0.6875rem',
                height: 22,
              }}
            />
          </Box>
          <Typography variant="h6" sx={{ fontSize: '1.05rem', fontWeight: 700, color: '#0f172a' }}>
            {selectedResult.document_title}
          </Typography>
        </Box>

        {/* Cosine Similarity Badge */}
        <Tooltip title="Cosine vector similarity score computed by Neo4j vector search index">
          <Chip
            size="small"
            label={`${formatSimilarityScore(selectedResult.score)} Similarity`}
            sx={{
              bgcolor: 'rgba(15, 118, 110, 0.1)',
              color: '#0f766e',
              fontWeight: 700,
              fontSize: '0.75rem',
              border: '1px solid rgba(15, 118, 110, 0.25)',
            }}
          />
        </Tooltip>
      </Box>

      <Divider sx={{ borderColor: '#f1f5f9' }} />

      {/* 1. Full Chunk Text */}
      <Box>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
          <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#334155' }}>
            Retrieved Evidence Text
          </Typography>
          <Button
            size="small"
            startIcon={
              copied ? (
                <CheckIcon sx={{ fontSize: 16, color: '#16a34a' }} />
              ) : (
                <CopyIcon sx={{ fontSize: 16 }} />
              )
            }
            onClick={handleCopyText}
            sx={{
              color: copied ? '#16a34a' : '#64748b',
              fontSize: '0.75rem',
              textTransform: 'none',
              p: '2px 8px',
            }}
          >
            {copied ? 'Copied' : 'Copy Text'}
          </Button>
        </Box>

        <Box
          sx={{
            p: 2,
            bgcolor: '#f8fafc',
            border: '1px solid #e2e8f0',
            borderRadius: 1.5,
            fontSize: '0.875rem',
            lineHeight: 1.65,
            color: '#1e293b',
            whiteSpace: 'pre-wrap',
            fontFamily: 'inherit',
            maxHeight: 280,
            overflowY: 'auto',
          }}
        >
          {selectedResult.text}
        </Box>
      </Box>

      {/* 2. Document & Chunk Metadata */}
      <Box>
        <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#334155', mb: 1 }}>
          Document Telemetry & Metadata
        </Typography>
        <Table size="small" sx={{ border: '1px solid #f1f5f9', borderRadius: 1 }}>
          <TableBody>
            <TableRow>
              <TableCell sx={{ color: '#64748b', fontWeight: 600, fontSize: '0.75rem', width: 140, py: 0.75 }}>
                Document ID
              </TableCell>
              <TableCell sx={{ color: '#0f172a', fontSize: '0.8125rem', py: 0.75 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span>{selectedResult.document_id}</span>
                  <Button
                    size="small"
                    variant="text"
                    onClick={() => navigate(`/documents?search=${encodeURIComponent(selectedResult.document_id)}`)}
                    endIcon={<OpenInNewIcon sx={{ fontSize: '13px !important' }} />}
                    sx={{ minWidth: 0, p: 0.25, fontSize: '0.7rem', color: '#00897b', textTransform: 'none' }}
                  >
                    View Document
                  </Button>
                </Box>
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell sx={{ color: '#64748b', fontWeight: 600, fontSize: '0.75rem', py: 0.75 }}>
                Source Author / Role
              </TableCell>
              <TableCell sx={{ color: '#0f172a', fontSize: '0.8125rem', py: 0.75 }}>
                {selectedResult.source || 'N/A'}
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell sx={{ color: '#64748b', fontWeight: 600, fontSize: '0.75rem', py: 0.75 }}>
                Document Type
              </TableCell>
              <TableCell sx={{ color: '#0f172a', fontSize: '0.8125rem', py: 0.75, textTransform: 'capitalize' }}>
                {selectedResult.metadata?.document_type?.replace('_', ' ') || 'N/A'}
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell sx={{ color: '#64748b', fontWeight: 600, fontSize: '0.75rem', py: 0.75 }}>
                Source Reference
              </TableCell>
              <TableCell sx={{ color: '#0f172a', fontSize: '0.8125rem', py: 0.75 }}>
                {selectedResult.metadata?.source_reference || 'N/A'}
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell sx={{ color: '#64748b', fontWeight: 600, fontSize: '0.75rem', py: 0.75 }}>
                Created Date
              </TableCell>
              <TableCell sx={{ color: '#0f172a', fontSize: '0.8125rem', py: 0.75 }}>
                {formatDate(selectedResult.metadata?.created_date)}
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell sx={{ color: '#64748b', fontWeight: 600, fontSize: '0.75rem', py: 0.75 }}>
                Raw Similarity Score
              </TableCell>
              <TableCell sx={{ color: '#0f766e', fontWeight: 700, fontSize: '0.8125rem', py: 0.75 }}>
                {selectedResult.score.toFixed(6)}
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </Box>

      {/* 3. Associated Graph Entities */}
      <Box>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
          <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#334155' }}>
            Linked Knowledge Graph Entities ({linkedEntities.length})
          </Typography>
          <Button
            size="small"
            endIcon={<OpenInNewIcon sx={{ fontSize: 14 }} />}
            onClick={() => navigate('/graph')}
            sx={{
              color: '#0f766e',
              fontSize: '0.75rem',
              textTransform: 'none',
              fontWeight: 600,
            }}
          >
            Explore in Graph View
          </Button>
        </Box>

        {linkedEntities.length === 0 ? (
          <Box
            sx={{
              p: 2,
              bgcolor: '#f8fafc',
              border: '1px solid #e2e8f0',
              borderRadius: 1.5,
              textAlign: 'center',
            }}
          >
            <Typography variant="caption" sx={{ color: '#64748b' }}>
              No direct domain entities linked to this document in current expansion depth.
            </Typography>
          </Box>
        ) : (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
            {linkedEntities.map((entity) => {
              const entityColor = getNodeColor(entity.entity_type);
              const entityName =
                entity.properties?.caption || entity.properties?.name || entity.properties?.tag || entity.entity_id;

              return (
                <Box
                  key={entity.entity_id}
                  sx={{
                    p: 1.5,
                    bgcolor: '#ffffff',
                    border: '1px solid #e2e8f0',
                    borderRadius: 1.5,
                    borderLeft: `4px solid ${entityColor.bg}`,
                  }}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Chip
                        size="small"
                        label={entity.entity_type}
                        sx={{
                          bgcolor: entityColor.bg,
                          color: entityColor.text,
                          fontWeight: 700,
                          fontSize: '0.6875rem',
                          height: 20,
                        }}
                      />
                      <Typography variant="caption" sx={{ fontWeight: 700, color: '#0f172a' }}>
                        {entity.entity_id}
                      </Typography>
                    </Box>

                    <Box sx={{ display: 'flex', gap: 0.5 }}>
                      {(entity.entity_type === 'Asset' || entity.properties?.asset_id) && (
                        <Tooltip title="View Asset Details">
                          <Button
                            size="small"
                            variant="text"
                            onClick={() => navigate(`/assets?search=${encodeURIComponent(entity.properties?.asset_id || entity.entity_id)}`)}
                            sx={{ minWidth: 0, p: 0.25, fontSize: '0.7rem', color: '#1d4ed8', textTransform: 'none' }}
                          >
                            Asset
                          </Button>
                        </Tooltip>
                      )}
                      <Tooltip title="Explore in Knowledge Graph">
                        <Button
                          size="small"
                          variant="text"
                          onClick={() => navigate(`/graph?query=${encodeURIComponent(entity.entity_id)}`)}
                          endIcon={<OpenInNewIcon sx={{ fontSize: '12px !important' }} />}
                          sx={{ minWidth: 0, p: 0.25, fontSize: '0.7rem', color: '#0f766e', textTransform: 'none' }}
                        >
                          Graph
                        </Button>
                      </Tooltip>
                    </Box>
                  </Box>

                  <Typography variant="body2" sx={{ fontWeight: 600, color: '#1e293b', mb: 0.75 }}>
                    {entityName}
                  </Typography>

                  {/* Key Properties display */}
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.75 }}>
                    {Object.entries(entity.properties)
                      .filter(
                        ([k]) =>
                          !['caption', 'name', 'entity_id', 'embedding', 'source_table', 'subject_area'].includes(k) &&
                          !k.startsWith('std_') &&
                          !k.endsWith('_id')
                      )
                      .slice(0, 4)
                      .map(([key, val]) => (
                        <Chip
                          key={key}
                          size="small"
                          label={`${key}: ${typeof val === 'object' ? JSON.stringify(val) : String(val)}`}
                          variant="outlined"
                          sx={{
                            fontSize: '0.6875rem',
                            height: 20,
                            borderColor: '#e2e8f0',
                            color: '#475569',
                            maxWidth: 260,
                            overflow: 'hidden',
                          }}
                        />
                      ))}
                  </Box>
                </Box>
              );
            })}
          </Box>
        )}
      </Box>

      {/* 4. Relationship Evidence */}
      {linkedRelationships.length > 0 && (
        <Box>
          <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#334155', mb: 1 }}>
            Graph Relationship Evidence ({linkedRelationships.length})
          </Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
            {linkedRelationships.map((rel, i) => (
              <Box
                key={i}
                sx={{
                  p: 1.25,
                  bgcolor: '#f8fafc',
                  border: '1px solid #e2e8f0',
                  borderRadius: 1.5,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 1,
                  fontSize: '0.75rem',
                }}
              >
                <Chip
                  size="small"
                  label={rel.source_id}
                  sx={{ height: 20, fontSize: '0.6875rem', bgcolor: '#e2e8f0', color: '#334155' }}
                />
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 0.5,
                    color: '#0f766e',
                    fontWeight: 600,
                  }}
                >
                  <RouteIcon sx={{ fontSize: 14 }} />
                  {rel.relationship_type}
                  <ArrowForwardIcon sx={{ fontSize: 13 }} />
                </Box>
                <Chip
                  size="small"
                  label={`${rel.target_type}: ${rel.target_id}`}
                  sx={{
                    height: 20,
                    fontSize: '0.6875rem',
                    bgcolor: 'rgba(15, 118, 110, 0.1)',
                    color: '#0f766e',
                    fontWeight: 600,
                  }}
                />
              </Box>
            ))}
          </Box>
        </Box>
      )}

      {/* 5. Expanded Graph Context (Multi-Hop) */}
      {otherEntities.length > 0 && (
        <Accordion
          elevation={0}
          sx={{
            border: '1px solid #e2e8f0',
            borderRadius: '8px !important',
            '&:before': { display: 'none' },
          }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon sx={{ fontSize: 18 }} />}>
            <Typography variant="caption" sx={{ fontWeight: 600, color: '#64748b' }}>
              Multi-Hop Graph Context ({otherEntities.length} additional entities)
            </Typography>
          </AccordionSummary>
          <AccordionDetails sx={{ pt: 0 }}>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.75 }}>
              {otherEntities.map((entity) => (
                <Chip
                  key={entity.entity_id}
                  size="small"
                  label={`${entity.entity_type}: ${
                    entity.properties?.name || entity.entity_id
                  }`}
                  sx={{
                    fontSize: '0.6875rem',
                    height: 22,
                    bgcolor: '#f1f5f9',
                    color: '#334155',
                  }}
                />
              ))}
            </Box>
          </AccordionDetails>
        </Accordion>
      )}
    </Card>
  );
};
