import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { MemoryRouter } from 'react-router-dom';
import { SearchHeader } from '../components/SearchHeader';
import { SearchSummary } from '../components/SearchSummary';
import { SearchControls } from '../components/SearchControls';
import { SearchResultList } from '../components/SearchResultList';
import { SearchEvidencePanel } from '../components/SearchEvidencePanel';
import { RetrievalResult } from '../../../types/api';

const mockSearchResult: RetrievalResult = {
  query: 'Which kicks were taken at the Wolfcamp B transition?',
  semantic_results: [
    {
      chunk_id: 'DOC-001_chunk_000',
      document_id: 'DOC-001',
      document_title: 'Daily drilling report DDR-2024-0007 Red Mesa 12-2H',
      text: 'Kick WCE-2024-0001 on Red Mesa 12-2H (DW-24002) revealed an 18 bbl pit gain at the Wolfcamp B transition.',
      score: 0.88528,
      source: 'OGX Energy (synthetic) - Drilling',
      metadata: {
        created_date: '2026-08-08T08:12:57.413643000+00:00',
        source_reference: 'WCE-2024-0001',
        document_type: 'drilling_report',
      },
    },
  ],
  graph_evidence: {
    entities: [
      {
        entity_id: 'DW-24002',
        entity_type: 'DrillingWell',
        properties: {
          name: 'Red Mesa 12-2H',
          model: 'M501F',
          operational_status: 'operational',
        },
      },
    ],
    relationships: [
      {
        source_id: 'DOC-001',
        target_id: 'DW-24002',
        relationship_type: 'MENTIONS_RECORD',
        source_type: 'Document',
        target_type: 'DrillingWell',
        properties: {},
      },
    ],
  },
  metadata: {
    execution_time: 0.145,
    top_k: 5,
    graph_depth: 1,
    min_similarity: 0.0,
    retrieval_method: 'vector+graph',
    semantic_results_count: 1,
    graph_entities_count: 1,
    graph_relationships_count: 1,
  },
};

describe('Semantic Search Subcomponents Rendering', () => {
  it('renders SearchHeader with active vector index badge', () => {
    const html = renderToStaticMarkup(<SearchHeader isBackendHealthy={true} />);
    expect(html).toContain('Semantic Search');
    expect(html).toContain('Vector Index Active');
  });

  it('renders SearchSummary with accurate retrieval telemetry', () => {
    const html = renderToStaticMarkup(<SearchSummary result={mockSearchResult} />);
    expect(html).toContain('Which kicks were taken at the Wolfcamp B transition?');
    expect(html).toContain('1 Chunk');
    expect(html).toContain('88.5%');
    expect(html).toContain('145 ms');
  });

  it('renders SearchControls with suggested chips and inputs', () => {
    const html = renderToStaticMarkup(
      <SearchControls
        query=""
        onQueryChange={jest.fn()}
        config={{ top_k: 5, graph_depth: 1, min_similarity: 0.0 }}
        onConfigChange={jest.fn()}
        onSearch={jest.fn()}
        isLoading={false}
      />
    );
    expect(html).toContain('Natural Language Query');
    expect(html).toContain('Which kicks were taken at the Wolfcamp B transition?');
    expect(html).toContain('What wall loss was found on compressor discharge piping before it leaked?');
  });

  it('renders SearchResultList with ranked cards and similarity metrics', () => {
    const html = renderToStaticMarkup(
      <SearchResultList
        results={mockSearchResult.semantic_results}
        selectedChunkId="DOC-001_chunk_000"
        onSelectResult={jest.fn()}
        graphEvidence={mockSearchResult.graph_evidence}
        activeQuery="pit gain"
      />
    );
    expect(html).toContain('Daily drilling report DDR-2024-0007 Red Mesa 12-2H');
    expect(html).toContain('88.5% match');
    expect(html).toContain('DOC-001');
    expect(html).toContain('DOC-001_chunk_000');
    expect(html).toContain('OGX Energy (synthetic) - Drilling');
  });

  it('renders SearchEvidencePanel with full chunk text and graph entities', () => {
    const html = renderToStaticMarkup(
      <MemoryRouter>
        <SearchEvidencePanel
          selectedResult={mockSearchResult.semantic_results[0]}
          graphEvidence={mockSearchResult.graph_evidence}
          activeQuery="pit gain"
        />
      </MemoryRouter>
    );
    expect(html).toContain('Retrieved Evidence Text');
    expect(html).toContain('revealed an 18 bbl pit gain');
    expect(html).toContain('DW-24002');
    expect(html).toContain('Red Mesa 12-2H');
    expect(html).toContain('MENTIONS_RECORD');
  });

  it('renders empty prompt in SearchEvidencePanel when no chunk selected', () => {
    const html = renderToStaticMarkup(
      <MemoryRouter>
        <SearchEvidencePanel
          selectedResult={null}
          graphEvidence={mockSearchResult.graph_evidence}
          activeQuery="pit gain"
        />
      </MemoryRouter>
    );
    expect(html).toContain('No Chunk Selected');
  });
});
