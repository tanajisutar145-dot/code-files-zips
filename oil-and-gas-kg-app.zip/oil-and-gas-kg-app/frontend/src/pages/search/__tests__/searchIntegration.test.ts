import { retrieveSemanticResults, api } from '../../../services/api';
import { RetrievalRequest, RetrievalResult } from '../../../types/api';

describe('Semantic Search API and Logic Integration', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  const mockSuccessfulResponse: RetrievalResult = {
    query: 'Which kicks were taken at the Wolfcamp B transition?',
    semantic_results: [
      {
        chunk_id: 'DOC-001_chunk_000',
        document_id: 'DOC-001',
        document_title: 'Daily drilling report DDR-2024-0007 Red Mesa 12-2H',
        text: 'Kick WCE-2024-0001 on Red Mesa 12-2H (DW-24002) revealed an 18 bbl pit gain at the Wolfcamp B transition.',
        score: 0.8852847218513489,
        source: 'OGX Energy (synthetic) - Drilling',
        metadata: {
          created_date: '2026-08-08T08:12:57.413643000+00:00',
          source_reference: 'WCE-2024-0001',
          document_type: 'drilling_report',
        },
      },
      {
        chunk_id: 'DOC-007_chunk_000',
        document_id: 'DOC-007',
        document_title: 'Preventive Maintenance Completion - Generator Inspection',
        text: 'Completed quarterly preventive maintenance inspection on Falcon Draw 10-2H per maintenance plan MP-015.',
        score: 0.8535959720611572,
        source: 'Senior Technician',
        metadata: {
          created_date: '2026-09-10T14:20:00.000000000+00:00',
          source_reference: 'MP-015',
          document_type: 'lessons_learned',
        },
      },
    ],
    graph_evidence: {
      entities: [
        {
          entity_id: 'DW-24002',
          entity_type: 'DrillingWell',
          properties: {
            name: 'Red Mesa 12-2H',
            model: 'M501F',
            operational_status: 'operational',
          },
        },
        {
          entity_id: 'DW-24005',
          entity_type: 'DrillingWell',
          properties: {
            name: 'Falcon Draw 10-2H',
            model: 'LM6000',
            operational_status: 'operational',
          },
        },
      ],
      relationships: [
        {
          source_id: 'DOC-001',
          target_id: 'DW-24002',
          relationship_type: 'MENTIONS_RECORD',
          source_type: 'Document',
          target_type: 'DrillingWell',
          properties: {},
        },
      ],
    },
    metadata: {
      execution_time: 0.145,
      top_k: 5,
      graph_depth: 1,
      min_similarity: 0.0,
      retrieval_method: 'vector+graph',
      semantic_results_count: 2,
      graph_entities_count: 2,
      graph_relationships_count: 1,
    },
  };

  it('sends correct request payload to POST /api/search/retrieve', async () => {
    const postSpy = jest.spyOn(api, 'post').mockResolvedValueOnce({ data: mockSuccessfulResponse });

    const request: RetrievalRequest = {
      query: 'Which kicks were taken at the Wolfcamp B transition?',
      top_k: 5,
      graph_depth: 1,
      min_similarity: 0.0,
      include_metadata: true,
    };

    const result = await retrieveSemanticResults(request);

    expect(postSpy).toHaveBeenCalledWith('/api/search/retrieve', request);
    expect(result).toBeDefined();
    expect(result.query).toBe('Which kicks were taken at the Wolfcamp B transition?');
    expect(result.semantic_results).toHaveLength(2);
    expect(result.semantic_results[0].chunk_id).toBe('DOC-001_chunk_000');
    expect(result.semantic_results[0].score).toBeCloseTo(0.8853);
    expect(result.graph_evidence.entities).toHaveLength(2);
  });

  it('handles backend 500 error without converting to empty results', async () => {
    jest.spyOn(api, 'post').mockRejectedValueOnce(new Error('Vector index search failed'));

    await expect(
      retrieveSemanticResults({
        query: 'test query',
        top_k: 5,
      })
    ).rejects.toThrow('Vector index search failed');
  });

  it('parses empty results when no chunks match similarity threshold', async () => {
    const emptyResponse: RetrievalResult = {
      query: 'obscure condition',
      semantic_results: [],
      graph_evidence: { entities: [], relationships: [] },
      metadata: {
        execution_time: 0.02,
        top_k: 5,
        graph_depth: 1,
        min_similarity: 0.95,
        semantic_results_count: 0,
        graph_entities_count: 0,
        graph_relationships_count: 0,
      },
    };

    jest.spyOn(api, 'post').mockResolvedValueOnce({ data: emptyResponse });

    const result = await retrieveSemanticResults({
      query: 'obscure condition',
      min_similarity: 0.95,
    });

    expect(result.semantic_results).toHaveLength(0);
    expect(result.graph_evidence.entities).toHaveLength(0);
    expect(result.metadata.semantic_results_count).toBe(0);
  });

  it('validates stale response prevention pattern', async () => {
    let activeRequestId = 0;

    // Simulate query 1 (slow)
    const reqId1 = ++activeRequestId;
    // Simulate query 2 (fast)
    const reqId2 = ++activeRequestId;

    let appliedResult: string | null = null;

    // Fast request finishes first
    if (reqId2 === activeRequestId) {
      appliedResult = 'Result from query 2';
    }

    // Slow request finishes later
    if (reqId1 === activeRequestId) {
      appliedResult = 'Result from query 1';
    }

    // Active result must be from Query 2, never overwritten by Query 1
    expect(appliedResult).toBe('Result from query 2');
  });
});
