import {
  formatEntityLabel,
  formatRelationshipLabel,
  describeRelationshipSentence,
  getParentEntity,
  getStatusColorInfo,
  formatPropertyLabel,
  formatPropertyValue,
} from '../utils/relationshipUtils';
import { getNodeColor, getDomainOfLabel, darken, DOMAIN_COLORS } from '../utils/graphStyles';
import { GraphNode, GraphRelationship } from '../../../types/graph';

// Synthetic records (input_data): kick WCE-2024-0001 on Red Mesa 12-2H, compressor FD1-K-201
const node = (id: string, label: string, name: string, properties: Record<string, any> = {}): GraphNode => ({
  id,
  label,
  labels: [label, `STD_${label}`],
  name,
  entity_id: id,
  properties,
});

const wce = node('n-wce', 'WellControlEvent', 'WCE-2024-0001', { event_type: 'kick' });
const well = node('n-dw', 'DrillingWell', 'Red Mesa 12-2H');
const rig = node('n-rig', 'Rig', 'Patterson 104');
const npt = node('n-npt', 'NptEvent', 'NPT-2024-0001');

describe('relationshipUtils', () => {
  describe('formatEntityLabel', () => {
    it('uses friendly names for oil & gas classes', () => {
      expect(formatEntityLabel('NptEvent')).toBe('NPT Event');
      expect(formatEntityLabel('HseCorrectiveAction')).toBe('HSE Corrective Action (CAPA)');
      expect(formatEntityLabel('WellIdentity')).toBe('Well Identity (API-10)');
      expect(formatEntityLabel('Hierarchy')).toBe('Functional Location (ISO 14224)');
    });

    it('splits other PascalCase labels and standard labels', () => {
      expect(formatEntityLabel('ProcessSafetyEvent')).toBe('Process Safety Event');
      expect(formatEntityLabel('STD_FailureEvent')).toBe('Standard: Failure Event');
      expect(formatEntityLabel('')).toBe('Entity');
    });
  });

  describe('formatRelationshipLabel', () => {
    it('maps derived relationships in both directions', () => {
      expect(formatRelationshipLabel('IDENTIFIED_BY', true)).toBe('Identified by API Number');
      expect(formatRelationshipLabel('IDENTIFIED_BY', false)).toBe('Identity of Record');
      expect(formatRelationshipLabel('PARENT_WELLBORE_DRILLING_WELL', true)).toBe('Sidetrack of');
      expect(formatRelationshipLabel('PREVIOUS_FAILURE_REPORT', false)).toBe('Followed by Failure');
    });

    it('falls back to the referenced class for foreign-key relationships', () => {
      expect(formatRelationshipLabel('DRILLING_WELL', true)).toBe('Drilling Well');
      expect(formatRelationshipLabel('DRILLING_WELL', false)).toBe('Referenced as Drilling Well');
    });
  });

  describe('describeRelationshipSentence', () => {
    it('describes sidetracks, identity conflicts and generic references', () => {
      const st = node('n-st', 'DrillingWell', 'Red Mesa 12-3H ST01');
      const parent = node('n-p', 'DrillingWell', 'Red Mesa 12-3H');
      expect(describeRelationshipSentence(st, 'PARENT_WELLBORE_DRILLING_WELL', parent)).toBe(
        'Red Mesa 12-3H ST01 is a sidetrack of Red Mesa 12-3H.'
      );
      const pw = node('n-pw', 'ProductionWell', 'Falcon Draw 11-1H');
      const dw = node('n-dw2', 'DrillingWell', 'Falcon Draw 11-1H');
      expect(describeRelationshipSentence(pw, 'NAME_MATCH_API_CONFLICT', dw)).toContain('different API number');
      expect(describeRelationshipSentence(wce, 'DRILLING_WELL', well)).toBe(
        'WCE-2024-0001 references wellbore (drilling register) Red Mesa 12-2H (DRILLING_WELL).'
      );
    });
  });

  describe('getParentEntity', () => {
    it('picks the target of the most specific outgoing foreign key', () => {
      const rels: GraphRelationship[] = [
        { id: 'r1', source: 'n-wce', target: 'n-rig', type: 'RIG', properties: {} },
        { id: 'r2', source: 'n-wce', target: 'n-dw', type: 'DRILLING_WELL', properties: {} },
        { id: 'r3', source: 'n-npt', target: 'n-wce', type: 'WELL_CONTROL_EVENT', properties: {} },
      ];
      const parent = getParentEntity(wce, [rig, well, npt], rels);
      expect(parent?.name).toBe('Red Mesa 12-2H');
      expect(parent?.friendlyLabel).toBe('Wellbore (Drilling Register)');
      expect(parent?.relationship).toBe('Drilling Well');
    });

    it('ignores incoming relationships and returns null without neighbours', () => {
      const rels: GraphRelationship[] = [{ id: 'r3', source: 'n-npt', target: 'n-wce', type: 'WELL_CONTROL_EVENT', properties: {} }];
      expect(getParentEntity(wce, [npt], rels)).toBeNull();
      expect(getParentEntity(wce, [], [])).toBeNull();
    });
  });

  describe('getStatusColorInfo', () => {
    it('colours integrity, HSE and production statuses', () => {
      expect(getStatusColorInfo('not_fit_for_service').text).toBe('#be123c');
      expect(getStatusColorInfo('Tier 1').text).toBe('#be123c');
      expect(getStatusColorInfo('ineffective').text).toBe('#be123c');
      expect(getStatusColorInfo('partially_effective').text).toBe('#b45309');
      expect(getStatusColorInfo('fit_for_service_with_conditions').text).toBe('#b45309');
      expect(getStatusColorInfo('in_progress').text).toBe('#b45309');
      expect(getStatusColorInfo('producing').text).toBe('#15803d');
      expect(getStatusColorInfo('effective').text).toBe('#15803d');
      expect(getStatusColorInfo('exact').text).toBe('#1d4ed8');
      expect(getStatusColorInfo(undefined).text).toBe('#475569');
    });
  });

  describe('formatPropertyLabel and formatPropertyValue', () => {
    it('labels oil & gas columns', () => {
      expect(formatPropertyLabel('api_well_number')).toBe('API Well Number');
      expect(formatPropertyLabel('npt_event_id')).toBe('NPT Event ID');
      expect(formatPropertyLabel('pse_tier_classification')).toBe('PSE Tier (API RP 754)');
      expect(formatPropertyLabel('pit_gain_volume_bbl')).toBe('Pit Gain Volume BBL');
    });

    it('formats values with the unit of the column name', () => {
      expect(formatPropertyValue('pit_gain_volume_bbl', 18)).toBe('18 bbl');
      expect(formatPropertyValue('measured_depth_ft', 11420)).toBe('11,420 ft');
      expect(formatPropertyValue('estimated_cost_impact_usd', 412000)).toBe('$412,000');
      expect(formatPropertyValue('bsw_pct', 0.4)).toBe('0.4%');
      expect(formatPropertyValue('duration_hours', 31.5)).toBe('31.5 h');
      expect(formatPropertyValue('co2e_tonnes', 9153.6)).toBe('9,153.6 t');
    });

    it('keeps identifiers, enumerations and empty values readable', () => {
      expect(formatPropertyValue('api_well_number', '42-301-43582-00-00')).toBe('42-301-43582-00-00');
      expect(formatPropertyValue('event_number', 'WCE-2024-0001')).toBe('WCE-2024-0001');
      expect(formatPropertyValue('fitness_for_service_result', 'not_fit_for_service')).toBe('not fit for service');
      expect(formatPropertyValue('is_safety_critical', true)).toBe('Yes');
      expect(formatPropertyValue('production_month', '2026-08')).toBe('2026-08');
      expect(formatPropertyValue('lessons_learned', null)).toBe('Not available');
      expect(formatPropertyValue('failure_date', '2025-09-18')).toBe('Sep 18, 2025');
    });
  });
});

describe('graphStyles', () => {
  it('colours labels by the subject area of the oil_gas model', () => {
    expect(getDomainOfLabel('NptEvent')).toBe('drilling');
    expect(getDomainOfLabel('CustodyTransfer')).toBe('logistics');
    expect(getNodeColor('DrillingWell').bg).toBe(DOMAIN_COLORS.drilling);
    expect(getNodeColor('WellIdentity').bg).toBe(DOMAIN_COLORS.identity);
    expect(getNodeColor('STD_Well').bg).toBe(DOMAIN_COLORS.semantic);
    expect(getNodeColor('SomethingElse').bg).toBe('#64748b');
    expect(getNodeColor('Equipment', '#123456').bg).toBe('#123456');
  });

  it('darkens colours for borders', () => {
    expect(darken('#ffffff', 0.5)).toBe('#808080');
    expect(darken('not-a-colour')).toBe('#475569');
  });
});
