import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { MemoryRouter } from 'react-router-dom';

import { NodeIdentityHeader } from '../components/NodeIdentityHeader';
import { NodeSummaryCards } from '../components/NodeSummaryCards';
import { RelatedEntitiesList } from '../components/RelatedEntitiesList';
import { NodeEntityInformation } from '../components/NodeEntityInformation';
import { NodeModalActions } from '../components/NodeModalActions';
import { GraphNode, GraphRelationship } from '../../../types/graph';

// Synthetic records from input_data, with the properties the load step writes (std_*, subject_area, source_table)
const mockNodes: Record<string, GraphNode> = {
  FailureReport: {
    id: 'fr-1',
    label: 'FailureReport',
    labels: ['FailureReport', 'STD_FailureEvent'],
    name: 'FR-2025-0001',
    entity_id: '30001',
    properties: {
      failure_report_id: 30001,
      failure_report_number: 'FR-2025-0001',
      failure_date: '2025-09-18',
      failure_mode: 'external leakage - process medium',
      failure_cause: 'erosion-corrosion at the discharge elbow',
      failure_status: 'closed',
      downtime_hours: 48,
      repair_cost: 27500,
      production_impact_boe: 1850,
      std_class: 'FailureEvent',
      std_match: 'exact',
      std_package: 'ISO 14224 failure data',
      subject_area: 'asset',
      source_table: 'asset.failure_report',
    },
  },
  Equipment: {
    id: 'eq-1',
    label: 'Equipment',
    labels: ['Equipment', 'STD_Compressor'],
    name: 'FD1-K-201',
    entity_id: '5001',
    properties: {
      equipment_id: 5001,
      tag: 'FD1-K-201',
      equipment_name: 'Falcon Draw CTB-1 Gas Lift Compressor K-201',
      equipment_type: 'compressor',
      criticality_ranking: 'critical',
      is_safety_critical: true,
      next_inspection_due_date: '2026-11-20',
      std_class: 'Compressor',
      subject_area: 'asset',
    },
  },
  InspectionEvent: {
    id: 'ins-1',
    label: 'InspectionEvent',
    labels: ['InspectionEvent'],
    name: 'INS-2025-0001',
    entity_id: '29001',
    properties: { inspection_number: 'INS-2025-0001', inspection_date: '2025-08-20', defect_severity: 'high' },
  },
  WorkOrder: {
    id: 'wo-1',
    label: 'WorkOrder',
    labels: ['WorkOrder'],
    name: 'WO-2025-0101',
    entity_id: '31001',
    properties: { work_order_number: 'WO-2025-0101', work_order_status: 'closed' },
  },
  DrillingWell: {
    id: 'dw-1',
    label: 'DrillingWell',
    labels: ['DrillingWell', 'STD_Wellbore'],
    name: 'Red Mesa 12-2H',
    entity_id: '24002',
    properties: {
      well_name: 'Red Mesa 12-2H',
      api_well_number: '42-301-43582-00-00',
      api10: '4230143582',
      well_status: 'completed',
      measured_depth_ft: 19850,
    },
  },
  WellIdentity: {
    id: 'id-1',
    label: 'WellIdentity',
    labels: ['WellIdentity'],
    name: 'API 42-301-43582',
    entity_id: '4230143582',
    properties: { api10: '4230143582', caption: 'API 42-301-43582' },
  },
  ProcessSafetyEvent: {
    id: 'pse-1',
    label: 'ProcessSafetyEvent',
    labels: ['ProcessSafetyEvent', 'STD_ProcessSafetyEvent'],
    name: 'PSE-2026-001',
    entity_id: '42001',
    properties: { pse_number: 'PSE-2026-001', pse_tier_classification: 'Tier 1', release_quantity: 52 },
  },
  Chunk: {
    id: 'ch-1',
    label: 'Chunk',
    labels: ['Chunk'],
    name: 'DOC-INS-2025-0001#0',
    entity_id: 'DOC-INS-2025-0001#0',
    properties: { chunk_index: 0, text: 'Inspection report INS-2025-0001 ...' },
  },
};

const rels: GraphRelationship[] = [
  { id: 'r1', source: 'fr-1', target: 'eq-1', type: 'EQUIPMENT', properties: {} },
  { id: 'r2', source: 'fr-1', target: 'ins-1', type: 'INSPECTION_EVENT', properties: {} },
  { id: 'r3', source: 'wo-1', target: 'fr-1', type: 'FAILURE_REPORT', properties: {} },
];

describe('Node Intelligence Popup Components', () => {
  describe('NodeIdentityHeader', () => {
    it('renders friendly label, identifier, status and parent for a wellbore', () => {
      const html = renderToStaticMarkup(
        <NodeIdentityHeader
          node={mockNodes.DrillingWell}
          parentEntity={{
            id: 'id-1',
            name: 'API 42-301-43582',
            label: 'WellIdentity',
            friendlyLabel: 'Well Identity (API-10)',
            entity_id: '4230143582',
            relationship: 'Identified by API Number',
          }}
          onClose={() => {}}
        />
      );
      expect(html).toContain('Wellbore (Drilling Register)');
      expect(html).toContain('24002');
      expect(html).toContain('Red Mesa 12-2H');
      expect(html).toContain('Identified by API Number');
      expect(html).toContain('API 42-301-43582');
      expect(html).toContain('completed');
    });

    it('renders close button with accessibility label', () => {
      const html = renderToStaticMarkup(<NodeIdentityHeader node={mockNodes.Equipment} onClose={() => {}} />);
      expect(html).toContain('aria-label="close"');
    });
  });

  describe('NodeSummaryCards', () => {
    Object.entries(mockNodes).forEach(([label, n]) => {
      it(`renders summary cards for ${label} without leaking undefined values`, () => {
        const html = renderToStaticMarkup(
          <NodeSummaryCards
            node={n}
            parentEntity={{ id: 'p', name: 'Parent record', label: 'Parent', friendlyLabel: 'Parent', relationship: 'Parent Entity' }}
            neighbors={[n]}
            relationships={[]}
          />
        );
        expect(html.length).toBeGreaterThan(50);
        expect(html).not.toContain('NaN');
        expect(html).not.toContain('undefined');
        expect(html).toContain('Connected Records');
      });
    });

    it('shows standard class, cost, deferred production and downtime for a failure report', () => {
      const html = renderToStaticMarkup(<NodeSummaryCards node={mockNodes.FailureReport} />);
      expect(html).toContain('Standard Class');
      expect(html).toContain('FailureEvent (exact)');
      expect(html).toContain('$27,500');
      expect(html).toContain('1,850 BOE');
      expect(html).toContain('48 h');
      expect(html).toContain('Sep 18, 2025');
    });

    it('shows the API-10 identity of well records and highlights Tier 1 events', () => {
      expect(renderToStaticMarkup(<NodeSummaryCards node={mockNodes.DrillingWell} />)).toContain('API-10 Identity');
      expect(renderToStaticMarkup(<NodeSummaryCards node={mockNodes.ProcessSafetyEvent} />)).toContain('Tier 1');
    });
  });

  describe('RelatedEntitiesList', () => {
    it('renders directional relationship descriptions', () => {
      const html = renderToStaticMarkup(
        <RelatedEntitiesList
          centerNode={mockNodes.FailureReport}
          neighbors={[mockNodes.Equipment, mockNodes.InspectionEvent, mockNodes.WorkOrder]}
          relationships={rels}
          onSelectNeighbor={() => {}}
        />
      );
      expect(html).toContain('Related Entities');
      expect(html).toContain('FD1-K-201');
      expect(html).toContain('Inspection Event');
      expect(html).toContain('Referenced as Failure Report');
    });

    it('renders empty state when neighbors array is empty', () => {
      const html = renderToStaticMarkup(
        <RelatedEntitiesList centerNode={mockNodes.FailureReport} neighbors={[]} relationships={[]} onSelectNeighbor={() => {}} />
      );
      expect(html).toContain('No related entities found.');
    });
  });

  describe('NodeEntityInformation', () => {
    it('groups properties into identification, standards, operational and history sections', () => {
      const html = renderToStaticMarkup(
        <MemoryRouter>
          <NodeEntityInformation node={mockNodes.FailureReport} />
        </MemoryRouter>
      );
      expect(html).toContain('Entity Information');
      expect(html).toContain('Identification');
      expect(html).toContain('Standards Alignment');
      expect(html).toContain('Operational Information');
      expect(html).toContain('History &amp; Operational Records');
      expect(html).toContain('Repair Cost');
      expect(html).toContain('$27,500');
      expect(html).toContain('Downtime Hours');
      expect(html).toContain('48 h');
      expect(html).toContain('Technical Details');
    });

    it('renders linked documents when present in detail', () => {
      const detail = {
        node: mockNodes.Equipment,
        connected_count: 5,
        connected_by_type: { EQUIPMENT: 2 },
        neighbors_preview: [],
        document_links: [
          {
            document_id: 'DOC-INS-2025-0001',
            title: 'Inspection report INS-2025-0001: compressor FD1-K-201 discharge piping',
            chunk_id: 'DOC-INS-2025-0001#0',
            snippet: 'The discharge elbow showed localised wall loss of 38%',
          },
        ],
      };
      const html = renderToStaticMarkup(
        <MemoryRouter>
          <NodeEntityInformation node={mockNodes.Equipment} detail={detail} />
        </MemoryRouter>
      );
      expect(html).toContain('Linked Grounding Documents');
      expect(html).toContain('Inspection report INS-2025-0001');
      expect(html).toContain('DOC-INS-2025-0001#0');
      expect(html).toContain('wall loss of 38%');
    });
  });

  describe('NodeModalActions', () => {
    it('renders Search Evidence, Ask Intelligence, View in Full Graph, and Close', () => {
      const html = renderToStaticMarkup(
        <MemoryRouter>
          <NodeModalActions node={mockNodes.Equipment} onViewInFullGraph={() => {}} onClose={() => {}} />
        </MemoryRouter>
      );
      expect(html).toContain('Search Evidence');
      expect(html).toContain('Ask Intelligence');
      expect(html).toContain('View in Full Graph');
      expect(html).toContain('Close');
    });
  });
});
