/**
 * Utility functions for friendly entity labels, relationship mapping, parent derivation,
 * and property formatting in the Knowledge Graph Node Intelligence Popup.
 *
 * In this graph a foreign key becomes a relationship from the referencing record to the referenced
 * one, named after the referenced class (e.g. (:FailureReport)-[:EQUIPMENT]->(:Equipment),
 * (:NptEvent)-[:DRILLING_WELL]->(:DrillingWell)). The "parent" of a record is therefore the target of
 * one of its outgoing relationships.
 */

import { GraphNode, GraphRelationship } from '../../../types/graph';

// 1. Friendly Entity Type Mapping (labels not listed are split at capitals)
export const ENTITY_LABEL_MAP: Record<string, string> = {
  NptEvent: 'NPT Event',
  HseCorrectiveAction: 'HSE Corrective Action (CAPA)',
  GhgEmission: 'GHG Emission',
  LdarSurvey: 'LDAR Survey',
  WellIdentity: 'Well Identity (API-10)',
  WellAsset: 'Well (Asset Register)',
  DrillingWell: 'Wellbore (Drilling Register)',
  ProductionWell: 'Well (Production Register)',
  ExplorationWell: 'Exploration Well',
  Hierarchy: 'Functional Location (ISO 14224)',
  OntologyClass: 'Ontology Class',
  OntologyProperty: 'Ontology Property',
  StandardClass: 'Standard Class',
  StandardAttribute: 'Standard Attribute',
  SubjectArea: 'Subject Area',
  Document: 'Document',
  Chunk: 'Text Chunk',
};

export const formatEntityLabel = (label: string): string => {
  if (!label) return 'Entity';
  if (ENTITY_LABEL_MAP[label]) return ENTITY_LABEL_MAP[label];
  if (label.startsWith('STD_')) return `Standard: ${label.slice(4).replace(/([a-z])([A-Z])/g, '$1 $2')}`;
  // Insert spaces before capitals for unknown PascalCase labels
  return label.replace(/([a-z])([A-Z])/g, '$1 $2');
};

// 2. Centralized Relationship Display Mapping (Forward & Reverse)
// Derived relationships (config.yaml graph.derived_relationships), semantic layer and lexical graph
export const RELATIONSHIP_LABELS_FORWARD: Record<string, string> = {
  IDENTIFIED_BY: 'Identified by API Number',
  NAME_MATCH_API_CONFLICT: 'API Conflict with Wellbore',
  SAME_FACILITY_AS: 'Same Facility As',
  LOCATES: 'Locates',
  CHILD_OF: 'Child of Location',
  PROGRAM_FOR: 'Program for Wellbore',
  PARENT_WELLBORE_DRILLING_WELL: 'Sidetrack of',
  PREVIOUS_FAILURE_REPORT: 'Repeat of Failure',
  PREVIOUS_ACTION_HSE_CORRECTIVE_ACTION: 'Follows up Action',
  PARENT_EQUIPMENT: 'Part of Equipment',
  INSTANCE_OF: 'Instance of Class',
  SPECIALIZES: 'Specializes Standard Class',
  SUBCLASS_OF: 'Subclass of',
  MAPS_TO: 'Maps to Standard Attribute',
  HAS_PROPERTY: 'Has Property',
  IN_SUBJECT_AREA: 'In Subject Area',
  HAS_NARRATIVE: 'Has Narrative',
  MENTIONS_RECORD: 'Mentions Record',
  FROM_DOCUMENT: 'Chunk of Document',
  NEXT_CHUNK: 'Next Chunk',
};

export const RELATIONSHIP_LABELS_REVERSE: Record<string, string> = {
  IDENTIFIED_BY: 'Identity of Record',
  NAME_MATCH_API_CONFLICT: 'API Conflict with Production Record',
  SAME_FACILITY_AS: 'Same Facility As',
  LOCATES: 'Located by',
  CHILD_OF: 'Parent Location of',
  PROGRAM_FOR: 'Has Well Program',
  PARENT_WELLBORE_DRILLING_WELL: 'Parent Wellbore of',
  PREVIOUS_FAILURE_REPORT: 'Followed by Failure',
  PREVIOUS_ACTION_HSE_CORRECTIVE_ACTION: 'Followed up by Action',
  PARENT_EQUIPMENT: 'Contains Equipment',
  INSTANCE_OF: 'Class of Record',
  SPECIALIZES: 'Specialized by Ontology Class',
  SUBCLASS_OF: 'Superclass of',
  MAPS_TO: 'Mapped from Property',
  HAS_PROPERTY: 'Property of',
  IN_SUBJECT_AREA: 'Subject Area of',
  HAS_NARRATIVE: 'Narrative of Record',
  MENTIONS_RECORD: 'Mentioned in Chunk',
  FROM_DOCUMENT: 'Contains Chunk',
  NEXT_CHUNK: 'Previous Chunk',
};

const titleCase = (s: string) =>
  s
    .toLowerCase()
    .split('_')
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');

/**
 * Format relationship label according to direction relative to current node.
 * Foreign-key relationships are named after the referenced class: outbound = "references X",
 * inbound = "referenced by".
 */
export const formatRelationshipLabel = (relType: string, isOutbound: boolean = true): string => {
  const dictionary = isOutbound ? RELATIONSHIP_LABELS_FORWARD : RELATIONSHIP_LABELS_REVERSE;
  if (dictionary[relType]) {
    return dictionary[relType];
  }
  return isOutbound ? titleCase(relType) : `Referenced as ${titleCase(relType)}`;
};

/**
 * Generate a friendly human-readable sentence for two connected nodes
 */
export const describeRelationshipSentence = (sourceNode: GraphNode, relType: string, targetNode: GraphNode): string => {
  switch (relType) {
    case 'IDENTIFIED_BY':
      return `${sourceNode.name} resolves to physical well ${targetNode.name} (PPDM API-10 identity).`;
    case 'NAME_MATCH_API_CONFLICT':
      return `${sourceNode.name} has the same well name as wellbore ${targetNode.name} but a different API number.`;
    case 'SAME_FACILITY_AS':
      return `${sourceNode.name} is the same facility as ${targetNode.name} in the asset register.`;
    case 'LOCATES':
      return `Functional location ${sourceNode.name} locates ${targetNode.name}.`;
    case 'CHILD_OF':
      return `${sourceNode.name} sits below ${targetNode.name} in the ISO 14224 hierarchy.`;
    case 'PROGRAM_FOR':
      return `Well program ${sourceNode.name} was written for ${targetNode.name}.`;
    case 'PARENT_WELLBORE_DRILLING_WELL':
      return `${sourceNode.name} is a sidetrack of ${targetNode.name}.`;
    case 'PREVIOUS_FAILURE_REPORT':
      return `Failure ${sourceNode.name} repeats the earlier failure ${targetNode.name}.`;
    case 'PREVIOUS_ACTION_HSE_CORRECTIVE_ACTION':
      return `Corrective action ${sourceNode.name} follows up ${targetNode.name}.`;
    case 'MENTIONS_RECORD':
      return `Text chunk ${sourceNode.name} mentions ${targetNode.name}.`;
    case 'HAS_NARRATIVE':
      return `${sourceNode.name} has the narrative document ${targetNode.name}.`;
    default:
      return `${sourceNode.name} references ${formatEntityLabel(targetNode.label).toLowerCase()} ${targetNode.name} (${relType}).`;
  }
};

export interface ParentEntityInfo {
  id: string;
  name: string;
  label: string;
  friendlyLabel: string;
  entity_id?: string;
  relationship: string;
}

// Outgoing relationship types that point to a record's "owner", most specific first
const PARENT_REL_TYPES = [
  'PARENT_WELLBORE_DRILLING_WELL',
  'PARENT_EQUIPMENT',
  'EQUIPMENT',
  'PIPELINE_SEGMENT',
  'DRILLING_WELL',
  'WELL_ASSET',
  'PRODUCTION_WELL',
  'EXPLORATION_WELL',
  'INCIDENT',
  'INCIDENT_INVESTIGATION',
  'PROCESS_SAFETY_EVENT',
  'WELL_CONTROL_EVENT',
  'CUSTODY_TRANSFER',
  'METER_STATION',
  'PRODUCTION_FACILITY',
  'ASSET_FACILITY',
  'RESERVOIR',
  'FORMATION',
  'PROSPECT',
  'PLAY',
  'BASIN',
  'FIELD',
  'RIG',
  'CHILD_OF',
  'IDENTIFIED_BY',
  'FROM_DOCUMENT',
];

/**
 * Deterministically find the parent entity using actual graph topology
 */
export const getParentEntity = (
  node: GraphNode,
  neighbors: GraphNode[],
  relationships: GraphRelationship[]
): ParentEntityInfo | null => {
  if (!node || !neighbors || neighbors.length === 0) return null;

  const neighborMap = new Map<string, GraphNode>();
  neighbors.forEach((n) => {
    neighborMap.set(n.id, n);
    if (n.entity_id) neighborMap.set(n.entity_id, n);
  });

  for (const relType of PARENT_REL_TYPES) {
    const parentEdge = relationships.find((r) => r.type === relType && r.source === node.id);
    if (parentEdge) {
      const parentNode = neighborMap.get(parentEdge.target);
      if (parentNode) {
        return {
          id: parentNode.id,
          name: parentNode.name,
          label: parentNode.label,
          friendlyLabel: formatEntityLabel(parentNode.label),
          entity_id: parentNode.entity_id,
          relationship: formatRelationshipLabel(relType, true),
        };
      }
    }
  }

  return null;
};

// 3. Status Badge Color / Variant Resolver
export interface StatusColorInfo {
  bg: string;
  text: string;
  border: string;
}

export const getStatusColorInfo = (rawStatus?: any): StatusColorInfo => {
  if (!rawStatus) {
    return { bg: '#f8fafc', text: '#475569', border: '#e2e8f0' };
  }

  const s = String(rawStatus).toLowerCase().trim();

  // Red / Critical / Failed / Not fit for service / Tier 1
  if (
    s.includes('critical') ||
    s.includes('fail') ||
    s.includes('not_fit') ||
    s.includes('not fit') ||
    s.includes('ineffective') ||
    s.includes('overdue') ||
    s.includes('shut') ||
    s.includes('tier 1') ||
    s.includes('major') ||
    s.includes('high') ||
    s.includes('rejected')
  ) {
    return { bg: '#fff1f2', text: '#be123c', border: '#fecdd3' };
  }

  // Amber / In progress / Pending / Partially effective / Tier 2 / Moderate (checked before green:
  // 'partially_effective' and 'fit_for_service_with_conditions' must not read as green)
  if (
    s.includes('progress') ||
    s.includes('pending') ||
    s.includes('open') ||
    s.includes('suspended') ||
    s.includes('preliminary') ||
    s.includes('partial') ||
    s.includes('tier 2') ||
    s.includes('moderate') ||
    s.includes('medium') ||
    s.includes('condition') ||
    s.includes('scheduled')
  ) {
    return { bg: '#fffbeb', text: '#b45309', border: '#fde68a' };
  }

  // Green / Producing / Completed / Closed / Effective / Fit for service
  if (
    s.includes('producing') ||
    s.includes('active') ||
    s.includes('completed') ||
    s.includes('closed') ||
    s.includes('effective') ||
    s.includes('fit_for_service') ||
    s.includes('approved') ||
    s.includes('operational') ||
    s.includes('final') ||
    s.includes('pass') ||
    s.includes('success')
  ) {
    return { bg: '#f0fdf4', text: '#15803d', border: '#bbf7d0' };
  }

  // Blue / Planned / Draft / Exact match
  if (s.includes('planned') || s.includes('draft') || s.includes('exact') || s.includes('low')) {
    return { bg: '#eff6ff', text: '#1d4ed8', border: '#bfdbfe' };
  }

  return { bg: '#f8fafc', text: '#475569', border: '#cbd5e1' };
};

// 4. Human-Readable Property Labels
const PROPERTY_LABEL_OVERRIDES: Record<string, string> = {
  api_well_number: 'API Well Number',
  api_number: 'API Number',
  api10: 'API-10',
  api_wellbore_code: 'API Wellbore Code',
  uwi: 'UWI',
  std_class: 'Standard Class',
  std_match: 'Standard Match',
  std_package: 'Standard Package',
  std_standard: 'Standard',
  subject_area: 'Subject Area',
  source_table: 'Source Table',
  npt: 'NPT',
  npt_hours: 'NPT Hours',
  iadc_npt_code: 'IADC NPT Code',
  pse: 'PSE',
  pse_tier: 'PSE Tier',
  pse_tier_classification: 'PSE Tier (API RP 754)',
  co2e_t: 'CO2e (t)',
  co2e_tonnes: 'CO2e (t)',
  ch4_t: 'CH4 (t)',
  ldar_leaks: 'LDAR Leaks',
  md_ft: 'MD (ft)',
  tvd_ft: 'TVD (ft)',
  measured_depth_ft: 'Measured Depth',
  true_vertical_depth_ft: 'True Vertical Depth',
  gov: 'Gross Observed Volume',
  gsv: 'Gross Standard Volume',
  nsv: 'Net Standard Volume',
  bsw_pct: 'BS&W',
  mtbf_hours: 'MTBF',
  iso14224_class: 'ISO 14224 Class',
  iso14224_level: 'ISO 14224 Level',
  capa: 'CAPA',
  ptw: 'Permit to Work',
  oil_bopd: 'Oil Rate',
  gas_mcfd: 'Gas Rate',
  best_oil_bopd: 'Best Oil Rate',
  current_bopd: 'Current Oil Rate',
  deferred_boe: 'Deferred Production',
  repair_cost_usd: 'Repair Cost',
  penalty_usd: 'Penalty',
  cost_usd: 'Cost',
  npt_cost_usd: 'NPT Cost',
};

export const formatPropertyLabel = (key: string): string => {
  if (PROPERTY_LABEL_OVERRIDES[key]) {
    return PROPERTY_LABEL_OVERRIDES[key];
  }
  return key
    .split('_')
    .map((word) => (word.length <= 3 && /^(id|ptw|hse|npt|api|boe|bbl|mcf|usd|pse|uwi|gor|wor|ft|psi|ppg|md|tvd)$/.test(word)
      ? word.toUpperCase()
      : word.charAt(0).toUpperCase() + word.slice(1)))
    .join(' ');
};

// Unit suffixes of the oil_gas column names (see ontology.unit_suffixes in backend/config.yaml)
const UNIT_SUFFIXES: [RegExp, string][] = [
  [/(_bopd)$/, 'BOPD'],
  [/(_bwpd)$/, 'BWPD'],
  [/(_mcfd)$/, 'Mcf/d'],
  [/(_mcf)$/, 'Mcf'],
  [/(_bbl|_bbls|_barrels)$/, 'bbl'],
  [/(_boe)$/, 'BOE'],
  [/(_ft)$/, 'ft'],
  [/(_psi)$/, 'psi'],
  [/(_ppg)$/, 'ppg'],
  [/(_f)$/, '°F'],
  [/(_tonnes|_t)$/, 't'],
  [/(_hours|_hrs)$/, 'h'],
  [/(_days)$/, 'days'],
  [/(_md)$/, 'mD'],
  [/(_mm_per_year)$/, 'mm/yr'],
  [/(_hp)$/, 'hp'],
];

const NUMBER = new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 });

// 5. Value Formatter
export const formatPropertyValue = (key: string, value: any): string => {
  if (value === null || value === undefined || value === '') {
    return 'Not available';
  }

  if (typeof value === 'boolean') {
    return value ? 'Yes' : 'No';
  }

  if (Array.isArray(value)) {
    return value.join(', ');
  }

  if (typeof value === 'object') {
    return JSON.stringify(value);
  }

  const k = key.toLowerCase();
  const numeric = typeof value === 'number' || (typeof value === 'string' && value.trim() !== '' && !isNaN(Number(value)) && !/^0\d/.test(value));
  const isIdentifier = /(_id|_number|_code|api|uwi|_ref|reference|year|month)$/.test(k) || k === 'api10';

  // Currency
  if (numeric && !isIdentifier && (k.endsWith('_usd') || k.includes('cost') || k.includes('penalty') || k === 'npv')) {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(Number(value));
  }

  // Percentages
  if (numeric && !isIdentifier && (k.endsWith('_pct') || k.includes('percent') || k.endsWith('_percentage'))) {
    return `${NUMBER.format(Number(value))}%`;
  }

  // Units from column-name suffixes
  if (numeric && !isIdentifier) {
    const unit = UNIT_SUFFIXES.find(([rx]) => rx.test(k));
    if (unit) return `${NUMBER.format(Number(value))} ${unit[1]}`;
    if (k.includes('co2e')) return `${NUMBER.format(Number(value))} t CO2e`;
    if (typeof value === 'number') return NUMBER.format(value);
  }

  // Date formatting if ISO string
  if ((k.includes('date') || k.includes('_at') || k.includes('timestamp') || k === 'due' || k === 'start') &&
      typeof value === 'string' && /^\d{4}-\d{2}-\d{2}/.test(value)) {
    try {
      const hasTime = /T\d{2}:\d{2}|\s\d{2}:\d{2}/.test(value);
      const parsed = new Date(hasTime ? value : `${value.slice(0, 10)}T00:00:00`);
      if (!isNaN(parsed.getTime())) {
        return parsed.toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          ...(hasTime ? { hour: '2-digit', minute: '2-digit' } : {}),
        });
      }
    } catch {
      // Fall through to string value
    }
  }

  // snake_case enumeration values (not_fit_for_service, electrical_isolation) read better with spaces
  const text = String(value);
  return /^[a-z0-9]+(_[a-z0-9]+)+$/.test(text) ? text.replace(/_/g, ' ') : text;
};
