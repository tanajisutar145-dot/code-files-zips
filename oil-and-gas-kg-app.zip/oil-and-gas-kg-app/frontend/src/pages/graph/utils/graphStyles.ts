/**
 * Graph visual design system: node colors, badge tokens, and Cytoscape stylesheets.
 *
 * Node colours follow the subject area (domain) of each oil_gas class, using the same palette as
 * viz.domain_colors in backend/config.yaml, so the explorer, the evidence graphs and the pyvis
 * renderings of the pipeline look alike.
 */

export const DOMAIN_COLORS: Record<string, string> = {
  exploration: '#72B7B2',
  reservoir: '#54A24B',
  drilling: '#E45756',
  production: '#4C78A8',
  asset: '#B279A2',
  hse: '#F58518',
  compliance: '#9D755D',
  logistics: '#EECA3B',
  customer: '#FF9DA6',
  product: '#BAB0AC',
  identity: '#1F77B4',
  semantic: '#7F6A93',
  extracted: '#7F7F7F',
  document: '#475569',
};

// Ontology class (Neo4j label) -> subject area of the oil_gas data model
export const LABEL_DOMAIN: Record<string, string> = {
  // exploration
  Basin: 'exploration',
  Block: 'exploration',
  Discovery: 'exploration',
  ExplorationWell: 'exploration',
  Formation: 'exploration',
  Play: 'exploration',
  Prospect: 'exploration',
  // reservoir
  DevelopmentPlan: 'reservoir',
  ReservesEstimate: 'reservoir',
  Reservoir: 'reservoir',
  WellTest: 'reservoir',
  Zone: 'reservoir',
  // drilling
  CasingDesign: 'drilling',
  CementingJob: 'drilling',
  DailyDrillingReport: 'drilling',
  DrillingWell: 'drilling',
  NptEvent: 'drilling',
  Rig: 'drilling',
  WellControlEvent: 'drilling',
  WellProgram: 'drilling',
  WellStatusHistory: 'drilling',
  // production
  ArtificialLift: 'production',
  DailyProduction: 'production',
  DowntimeEvent: 'production',
  Field: 'production',
  FlareRecord: 'production',
  MeterStation: 'production',
  ProductionAllocation: 'production',
  ProductionFacility: 'production',
  ProductionWell: 'production',
  // asset
  AssetFacility: 'asset',
  Equipment: 'asset',
  FailureReport: 'asset',
  Hierarchy: 'asset',
  InspectionEvent: 'asset',
  IntegrityProgram: 'asset',
  PipelineSegment: 'asset',
  PreventiveMaintenancePlan: 'asset',
  WellAsset: 'asset',
  WorkOrder: 'asset',
  // hse
  EmissionSource: 'hse',
  GhgEmission: 'hse',
  HseCorrectiveAction: 'hse',
  Incident: 'hse',
  IncidentInvestigation: 'hse',
  LdarSurvey: 'hse',
  PermitToWork: 'hse',
  ProcessSafetyEvent: 'hse',
  SpillEvent: 'hse',
  // compliance
  Permit: 'compliance',
  RegulatoryAuthority: 'compliance',
  Violation: 'compliance',
  // logistics, customer, product
  CustodyTransfer: 'logistics',
  MeasurementPoint: 'logistics',
  DeliveryPoint: 'customer',
  CrudeGrade: 'product',
  // derived identity hub, semantic layer, lexical graph
  WellIdentity: 'identity',
  OntologyClass: 'semantic',
  OntologyProperty: 'semantic',
  StandardClass: 'semantic',
  StandardAttribute: 'semantic',
  SubjectArea: 'semantic',
  Document: 'document',
  Chunk: 'document',
  __Entity__: 'extracted',
};

export const DEFAULT_NODE_COLOR = { bg: '#64748b', border: '#475569', text: '#ffffff' };

/** Darken a #rrggbb colour by a factor (0..1) for borders. */
export const darken = (hex: string, factor: number = 0.22): string => {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  if (!m) return DEFAULT_NODE_COLOR.border;
  const n = parseInt(m[1], 16);
  const f = (c: number) => Math.max(0, Math.round(c * (1 - factor)));
  const r = f((n >> 16) & 255);
  const g = f((n >> 8) & 255);
  const b = f(n & 255);
  return `#${((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1)}`;
};

export const getDomainOfLabel = (label: string): string | undefined => LABEL_DOMAIN[label];

export const getDomainColor = (domain?: string | null): string =>
  (domain && DOMAIN_COLORS[domain]) || DEFAULT_NODE_COLOR.bg;

// Kept for compatibility with the explorer components: label -> {bg, border, text}
export const NODE_COLORS: Record<string, { bg: string; border: string; text: string }> = Object.keys(LABEL_DOMAIN).reduce(
  (acc, label) => {
    const bg = getDomainColor(LABEL_DOMAIN[label]);
    acc[label] = { bg, border: darken(bg), text: '#ffffff' };
    return acc;
  },
  {} as Record<string, { bg: string; border: string; text: string }>
);

export const getNodeColor = (label: string, override?: string | null) => {
  if (override) return { bg: override, border: darken(override), text: '#ffffff' };
  if (label && label.startsWith('STD_')) return { bg: DOMAIN_COLORS.semantic, border: darken(DOMAIN_COLORS.semantic), text: '#ffffff' };
  return NODE_COLORS[label] || DEFAULT_NODE_COLOR;
};

export const CYTOSCAPE_STYLESHEET: any = [
  {
    selector: 'node',
    style: {
      'background-color': 'data(color)',
      'label': 'data(shortLabel)',
      'color': '#1e293b',
      'font-size': '10px',
      'font-weight': '600',
      'text-valign': 'bottom',
      'text-margin-y': 5,
      'text-wrap': 'wrap',
      'text-max-width': '140px',
      'text-background-color': '#ffffff',
      'text-background-opacity': 0.85,
      'text-background-padding': '2px',
      'text-background-shape': 'roundrectangle',
      'width': 34,
      'height': 34,
      'border-width': 2,
      'border-color': 'data(borderColor)',
      'transition-property': 'background-color, border-color, width, height, border-width',
      'transition-duration': '0.2s',
    },
  },
  {
    selector: 'node.evidence',
    style: {
      'border-width': 4,
      'border-color': '#0f172a',
      'width': 40,
      'height': 40,
    },
  },
  {
    selector: 'node:selected',
    style: {
      'border-width': 4,
      'border-color': '#0f172a',
      'width': 42,
      'height': 42,
      'font-size': '11px',
      'font-weight': '700',
      'z-index': 999,
    },
  },
  {
    selector: 'node.highlighted',
    style: {
      'border-width': 4,
      'border-color': '#0f766e',
      'z-index': 900,
    },
  },
  {
    selector: 'edge',
    style: {
      'width': 1.5,
      'line-color': '#94a3b8',
      'target-arrow-color': '#94a3b8',
      'target-arrow-shape': 'triangle',
      'curve-style': 'bezier',
      'label': 'data(type)',
      'font-size': '8px',
      'color': '#64748b',
      'text-background-color': '#ffffff',
      'text-background-opacity': 0.9,
      'text-background-padding': '1px',
      'text-rotation': 'autorotate',
      'arrow-scale': 0.8,
      'opacity': 0.85,
    },
  },
  {
    selector: 'edge.derived',
    style: {
      'line-style': 'dashed',
      'line-color': '#1F77B4',
      'target-arrow-color': '#1F77B4',
    },
  },
  {
    selector: 'edge:selected',
    style: {
      'width': 3,
      'line-color': '#0f766e',
      'target-arrow-color': '#0f766e',
      'color': '#0f766e',
      'font-weight': '700',
      'z-index': 950,
      'opacity': 1,
    },
  },
  {
    selector: 'edge.highlighted',
    style: {
      'width': 2.5,
      'line-color': '#0f766e',
      'target-arrow-color': '#0f766e',
      'z-index': 900,
      'opacity': 1,
    },
  },
];

// Relationship types created by the derivation rules in config.yaml (graph.derived_relationships)
export const DERIVED_RELATIONSHIPS = new Set([
  'IDENTIFIED_BY',
  'NAME_MATCH_API_CONFLICT',
  'SAME_FACILITY_AS',
  'LOCATES',
  'CHILD_OF',
  'PROGRAM_FOR',
]);
