import React, { useState } from 'react';
import {
  Box,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Chip,
} from '@mui/material';
import {
  ExpandMore as ExpandMoreIcon,
  Description as DocumentIcon,
  Code as TechnicalIcon,
  InfoOutlined as InfoIcon,
  ArrowForward as ArrowForwardIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { GraphNode, GraphNodeDetailResponse } from '../../../types/graph';
import {
  formatPropertyLabel,
  formatPropertyValue,
  getStatusColorInfo,
} from '../utils/relationshipUtils';

interface NodeEntityInformationProps {
  node: GraphNode;
  detail?: GraphNodeDetailResponse | null;
}

export const NodeEntityInformation: React.FC<NodeEntityInformationProps> = ({
  node,
  detail,
}) => {
  const navigate = useNavigate();
  const [techExpanded, setTechExpanded] = useState<boolean>(false);

  const props = node.properties || {};

  // Group properties into logical sections by column-name pattern (the oil_gas model has ~2,700 columns)
  const keys = Object.keys(props).sort();
  const isId = (k: string) =>
    /(^caption$|^name$|^title$|_name$|_number$|^tag$|^api|^uwi$|_code$|^document_id$|^chunk_id$|^chunk_index$)/.test(k);
  const isStandard = (k: string) => /^(std_|subject_area$|source_table$)/.test(k);
  const isOperational = (k: string) =>
    /(_status$|_type$|_category$|_subcategory$|criticality|_classification$|_flag$|^is_|_ranking$|_strategy$|_method$|_level$|severity|priority|tier)/.test(k);
  const isHistory = (k: string) =>
    /(date|timestamp|_hours$|cost|_usd$|_bbl$|_mcf|_boe$|_bopd$|_ft$|_psi$|_ppg$|_tonnes$|description|findings|lessons|root_cause|cause|_notes$|comments|_action)/.test(k);

  // 1. Identification keys
  const idKeys = keys.filter((k) => isId(k) && !isStandard(k));

  // 2. Standards alignment (semantic layer properties written by the load step)
  const standardKeys = keys.filter(isStandard);

  // 3. Operational keys
  const operationalKeys = keys.filter((k) => !isId(k) && !isStandard(k) && isOperational(k));

  // 4. History & Records keys
  const historyKeys = keys.filter((k) => !isId(k) && !isStandard(k) && !isOperational(k) && isHistory(k));

  // Internal keys to omit from human sections
  const hiddenInternalKeys = new Set([
    'embedding',
    'embedding_dimension',
    'embedding_model',
    'embedding_updated',
    'content_hash',
    'text', // Chunks have full text, which would overwhelm normal property table
    'content',
    'geo_point',
  ]);

  const assignedKeys = new Set([...idKeys, ...standardKeys, ...operationalKeys, ...historyKeys, ...Array.from(hiddenInternalKeys)]);

  // Remaining keys
  const otherKeys = Object.keys(props).filter((k) => !assignedKeys.has(k));

  const renderPropertyRows = (keys: string[]) => {
    const presentKeys = keys.filter(
      (k) => props[k] !== undefined && props[k] !== null && props[k] !== ''
    );

    if (presentKeys.length === 0) return null;

    return (
      <TableContainer
        component={Paper}
        elevation={0}
        sx={{
          border: '1px solid #e2e8f0',
          borderRadius: 1.5,
          overflow: 'hidden',
          mb: 2,
        }}
      >
        <Table size="small">
          <TableBody>
            {presentKeys.map((key) => {
              const val = props[key];
              const formattedVal = formatPropertyValue(key, val);
              const label = formatPropertyLabel(key);

              // Status highlight if key is a status
              const isStatusKey =
                key.includes('status') || key.includes('criticality') || key === 'priority' || key === 'std_match' ||
                key.includes('tier') || key.includes('fitness_for_service') || key.includes('severity');
              const statusColors = isStatusKey ? getStatusColorInfo(val) : null;

              return (
                <TableRow
                  key={key}
                  sx={{
                    '&:last-child td': { borderBottom: 0 },
                    '&:hover': { bgcolor: '#f8fafc' },
                  }}
                >
                  <TableCell
                    sx={{
                      fontWeight: 600,
                      color: '#475569',
                      fontSize: '0.75rem',
                      width: '38%',
                      py: 0.85,
                      px: 1.5,
                      bgcolor: '#fcfcfd',
                      borderRight: '1px solid #f1f5f9',
                    }}
                  >
                    {label}
                  </TableCell>
                  <TableCell
                    sx={{
                      color: '#0f172a',
                      fontSize: '0.75rem',
                      py: 0.85,
                      px: 1.5,
                      wordBreak: 'break-word',
                    }}
                  >
                    {statusColors && isStatusKey ? (
                      <Chip
                        label={formattedVal}
                        size="small"
                        sx={{
                          height: 20,
                          fontSize: '0.68rem',
                          fontWeight: 600,
                          bgcolor: statusColors.bg,
                          color: statusColors.text,
                          border: `1px solid ${statusColors.border}`,
                          textTransform: 'capitalize',
                        }}
                      />
                    ) : (
                      formattedVal
                    )}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
    );
  };

  const hasIdRows = idKeys.some((k) => props[k] !== undefined);
  const hasStandardRows = standardKeys.some((k) => props[k] !== undefined);
  const hasOpRows = operationalKeys.some((k) => props[k] !== undefined);
  const hasHistoryRows = historyKeys.some((k) => props[k] !== undefined);
  const hasOtherRows = otherKeys.length > 0;

  const docLinks = detail?.document_links || [];

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        bgcolor: '#ffffff',
        border: '1px solid #e2e8f0',
        borderRadius: 2,
        overflow: 'hidden',
        boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)',
      }}
    >
      {/* Header */}
      <Box
        sx={{
          px: 2,
          py: 1.25,
          bgcolor: '#f8fafc',
          borderBottom: '1px solid #e2e8f0',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexShrink: 0,
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <InfoIcon sx={{ fontSize: 18, color: '#0f766e' }} />
          <Typography
            variant="subtitle2"
            sx={{
              fontWeight: 700,
              color: '#0f172a',
              letterSpacing: '0.02em',
              textTransform: 'uppercase',
              fontSize: '0.78rem',
            }}
          >
            Entity Information
          </Typography>
        </Box>
      </Box>

      {/* Body */}
      <Box sx={{ p: 2, overflowY: 'auto', flexGrow: 1 }}>
        {/* IDENTIFICATION */}
        {hasIdRows && (
          <Box sx={{ mb: 1.5 }}>
            <Typography
              variant="caption"
              sx={{
                color: '#64748b',
                fontWeight: 700,
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
                display: 'block',
                mb: 0.75,
                fontSize: '0.7rem',
              }}
            >
              Identification
            </Typography>
            {renderPropertyRows(idKeys)}
          </Box>
        )}

        {/* STANDARDS ALIGNMENT */}
        {hasStandardRows && (
          <Box sx={{ mb: 1.5 }}>
            <Typography
              variant="caption"
              sx={{
                color: '#64748b',
                fontWeight: 700,
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
                display: 'block',
                mb: 0.75,
                fontSize: '0.7rem',
              }}
            >
              Standards Alignment
            </Typography>
            {renderPropertyRows(standardKeys)}
          </Box>
        )}

        {/* OPERATIONAL INFORMATION */}
        {hasOpRows && (
          <Box sx={{ mb: 1.5 }}>
            <Typography
              variant="caption"
              sx={{
                color: '#64748b',
                fontWeight: 700,
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
                display: 'block',
                mb: 0.75,
                fontSize: '0.7rem',
              }}
            >
              Operational Information
            </Typography>
            {renderPropertyRows(operationalKeys)}
          </Box>
        )}

        {/* HISTORY & RELATED RECORDS */}
        {hasHistoryRows && (
          <Box sx={{ mb: 1.5 }}>
            <Typography
              variant="caption"
              sx={{
                color: '#64748b',
                fontWeight: 700,
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
                display: 'block',
                mb: 0.75,
                fontSize: '0.7rem',
              }}
            >
              History & Operational Records
            </Typography>
            {renderPropertyRows(historyKeys)}
          </Box>
        )}

        {/* OTHER PROPERTIES (if any) */}
        {hasOtherRows && (
          <Box sx={{ mb: 1.5 }}>
            <Typography
              variant="caption"
              sx={{
                color: '#64748b',
                fontWeight: 700,
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
                display: 'block',
                mb: 0.75,
                fontSize: '0.7rem',
              }}
            >
              Additional Attributes
            </Typography>
            {renderPropertyRows(otherKeys)}
          </Box>
        )}

        {/* LINKED GROUNDING DOCUMENTS (if present) */}
        {docLinks.length > 0 && (
          <Box sx={{ mb: 2 }}>
            <Typography
              variant="caption"
              sx={{
                color: '#64748b',
                fontWeight: 700,
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
                display: 'flex',
                alignItems: 'center',
                gap: 0.5,
                mb: 0.75,
                fontSize: '0.7rem',
              }}
            >
              <DocumentIcon sx={{ fontSize: 14, color: '#2563eb' }} />
              Linked Grounding Documents ({docLinks.length})
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              {docLinks.map((doc, idx) => (
                <Box
                  key={idx}
                  onClick={() =>
                    navigate(
                      `/documents?search=${encodeURIComponent(
                        doc.chunk_id || doc.title
                      )}`
                    )
                  }
                  sx={{
                    p: 1.25,
                    borderRadius: 1.5,
                    bgcolor: '#f8fafc',
                    border: '1px solid #e2e8f0',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease',
                    '&:hover': {
                      bgcolor: '#f0fdfa',
                      borderColor: '#99f6e4',
                    },
                  }}
                >
                  <Box
                    sx={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'flex-start',
                    }}
                  >
                    <Typography
                      variant="caption"
                      sx={{
                        fontWeight: 700,
                        color: '#0f172a',
                        display: 'block',
                      }}
                    >
                      {doc.title}
                    </Typography>
                    <ArrowForwardIcon
                      sx={{
                        fontSize: 13,
                        color: '#94a3b8',
                        ml: 1,
                        flexShrink: 0,
                      }}
                    />
                  </Box>
                  <Typography
                    variant="caption"
                    sx={{
                      color: '#64748b',
                      fontSize: '0.7rem',
                      display: 'block',
                      mt: 0.25,
                    }}
                  >
                    Chunk ID: {doc.chunk_id}
                  </Typography>
                  {doc.snippet && (
                    <Typography
                      variant="caption"
                      sx={{
                        color: '#475569',
                        fontSize: '0.72rem',
                        display: 'block',
                        mt: 0.5,
                        fontStyle: 'italic',
                      }}
                    >
                      "{doc.snippet}..."
                    </Typography>
                  )}
                </Box>
              ))}
            </Box>
          </Box>
        )}

        {/* TECHNICAL DETAILS (Collapsed by default) */}
        <Accordion
          expanded={techExpanded}
          onChange={() => setTechExpanded(!techExpanded)}
          elevation={0}
          sx={{
            border: '1px solid #e2e8f0',
            borderRadius: '8px !important',
            bgcolor: '#ffffff',
            '&:before': { display: 'none' },
            overflow: 'hidden',
            mt: 2,
          }}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon sx={{ fontSize: 18 }} />}
            sx={{
              bgcolor: '#f8fafc',
              minHeight: 40,
              py: 0.5,
              px: 1.5,
              '& .MuiAccordionSummary-content': { my: 0.5 },
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <TechnicalIcon sx={{ fontSize: 16, color: '#64748b' }} />
              <Typography
                variant="caption"
                sx={{
                  fontWeight: 700,
                  color: '#475569',
                  textTransform: 'uppercase',
                  letterSpacing: '0.04em',
                  fontSize: '0.72rem',
                }}
              >
                Technical Details
              </Typography>
              <Chip
                label="Advanced"
                size="small"
                sx={{
                  height: 18,
                  fontSize: '0.62rem',
                  fontWeight: 600,
                  bgcolor: '#e2e8f0',
                  color: '#475569',
                }}
              />
            </Box>
          </AccordionSummary>
          <AccordionDetails sx={{ p: 1.5, bgcolor: '#ffffff' }}>
            <Box sx={{ mb: 1.5 }}>
              <Typography
                variant="caption"
                sx={{
                  color: '#64748b',
                  fontWeight: 600,
                  display: 'block',
                  mb: 0.5,
                  fontSize: '0.7rem',
                }}
              >
                Database Element ID:
              </Typography>
              <Typography
                variant="body2"
                component="code"
                sx={{
                  fontFamily: 'monospace',
                  fontSize: '0.75rem',
                  color: '#0f172a',
                  bgcolor: '#f1f5f9',
                  p: '2px 6px',
                  borderRadius: 1,
                  display: 'inline-block',
                }}
              >
                {node.id}
              </Typography>
            </Box>

            <Box sx={{ mb: 1.5 }}>
              <Typography
                variant="caption"
                sx={{
                  color: '#64748b',
                  fontWeight: 600,
                  display: 'block',
                  mb: 0.5,
                  fontSize: '0.7rem',
                }}
              >
                Neo4j Graph Labels:
              </Typography>
              <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                {(node.labels || [node.label]).map((lbl) => (
                  <Chip
                    key={lbl}
                    label={lbl}
                    size="small"
                    variant="outlined"
                    sx={{
                      fontFamily: 'monospace',
                      fontSize: '0.68rem',
                      height: 20,
                    }}
                  />
                ))}
              </Box>
            </Box>

            {detail?.connected_by_type && (
              <Box sx={{ mb: 1.5 }}>
                <Typography
                  variant="caption"
                  sx={{
                    color: '#64748b',
                    fontWeight: 600,
                    display: 'block',
                    mb: 0.5,
                    fontSize: '0.7rem',
                  }}
                >
                  Raw Relationship Types ({detail.connected_count}):
                </Typography>
                <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                  {Object.entries(detail.connected_by_type).map(([rType, count]) => (
                    <Chip
                      key={rType}
                      label={`${rType}: ${count}`}
                      size="small"
                      sx={{
                        fontFamily: 'monospace',
                        fontSize: '0.68rem',
                        height: 20,
                        bgcolor: '#f1f5f9',
                      }}
                    />
                  ))}
                </Box>
              </Box>
            )}

            <Typography
              variant="caption"
              sx={{
                color: '#64748b',
                fontWeight: 600,
                display: 'block',
                mb: 0.5,
                fontSize: '0.7rem',
              }}
            >
              Raw Properties Dictionary:
            </Typography>
            <TableContainer
              component={Paper}
              elevation={0}
              sx={{
                border: '1px solid #f1f5f9',
                borderRadius: 1.5,
                maxHeight: 220,
              }}
            >
              <Table size="small">
                <TableBody>
                  {Object.entries(props).map(([k, v]) => (
                    <TableRow key={k}>
                      <TableCell
                        sx={{
                          fontFamily: 'monospace',
                          fontSize: '0.68rem',
                          color: '#475569',
                          py: 0.5,
                          px: 1,
                          width: '40%',
                          bgcolor: '#fafafa',
                        }}
                      >
                        {k}
                      </TableCell>
                      <TableCell
                        sx={{
                          fontFamily: 'monospace',
                          fontSize: '0.68rem',
                          color: '#0f172a',
                          py: 0.5,
                          px: 1,
                          wordBreak: 'break-all',
                        }}
                      >
                        {typeof v === 'object' ? JSON.stringify(v) : String(v)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </AccordionDetails>
        </Accordion>
      </Box>
    </Box>
  );
};
