import React from 'react';
import {
  Box,
  TextField,
  MenuItem,
  Button,
  IconButton,
  Tooltip,
  Typography,
  Chip,
  InputAdornment,
} from '@mui/material';
import {
  Search as SearchIcon,
  Clear as ClearIcon,
  FilterList as FilterIcon,
  CenterFocusStrong as FitIcon,
  Tune as LayoutIcon,
  WarningAmber as WarningIcon,
} from '@mui/icons-material';
import { GraphOverviewResponse, GraphFilters } from '../../../types/graph';

interface GraphToolbarProps {
  filters: GraphFilters;
  overview: GraphOverviewResponse | null;
  onFilterChange: (newFilters: Partial<GraphFilters>) => void;
  onApply: () => void;
  onReset: () => void;
  onFitView: () => void;
  onReLayout: () => void;
  layoutName: string;
  onLayoutChange: (layout: string) => void;
  totalLoadedNodes: number;
  totalLoadedRels: number;
  isTruncated: boolean;
  isLoading: boolean;
}

export const GraphToolbar: React.FC<GraphToolbarProps> = ({
  filters,
  overview,
  onFilterChange,
  onApply,
  onReset,
  onFitView,
  onReLayout,
  layoutName,
  onLayoutChange,
  totalLoadedNodes,
  totalLoadedRels,
  isTruncated,
  isLoading,
}) => {
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      onApply();
    }
  };

  return (
    <Box
      sx={{
        p: 2,
        bgcolor: '#ffffff',
        borderRadius: 2,
        border: '1px solid #e2e8f0',
        mb: 2,
        boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)',
        display: 'flex',
        flexDirection: 'column',
        gap: 1.5,
      }}
    >
      {/* Top Filter Controls Row */}
      <Box
        sx={{
          display: 'flex',
          flexWrap: 'wrap',
          gap: 1.5,
          alignItems: 'center',
        }}
      >
        {/* Search Input */}
        <TextField
          size="small"
          placeholder="Search entities by name, ID, or tag..."
          value={filters.query || ''}
          onChange={(e) => onFilterChange({ query: e.target.value })}
          onKeyDown={handleKeyDown}
          sx={{
            flexGrow: 1,
            minWidth: 240,
            '& .MuiOutlinedInput-root': {
              borderRadius: 1.5,
              fontSize: '0.875rem',
            },
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon sx={{ color: '#94a3b8', fontSize: 18 }} />
              </InputAdornment>
            ),
            endAdornment: filters.query ? (
              <InputAdornment position="end">
                <IconButton
                  size="small"
                  onClick={() => {
                    onFilterChange({ query: '' });
                  }}
                >
                  <ClearIcon sx={{ fontSize: 16 }} />
                </IconButton>
              </InputAdornment>
            ) : null,
          }}
        />

        {/* Node Label Select */}
        <TextField
          select
          size="small"
          label="Entity Label"
          value={filters.node_label || ''}
          onChange={(e) => onFilterChange({ node_label: e.target.value || undefined })}
          sx={{ minWidth: 160, '& .MuiOutlinedInput-root': { borderRadius: 1.5 } }}
        >
          <MenuItem value="">
            <em>All Entity Types</em>
          </MenuItem>
          {overview?.available_labels.map((lbl) => {
            const count = overview.node_counts_by_label[lbl] || 0;
            return (
              <MenuItem key={lbl} value={lbl}>
                {lbl} ({count})
              </MenuItem>
            );
          })}
        </TextField>

        {/* Relationship Type Select */}
        <TextField
          select
          size="small"
          label="Relationship Type"
          value={filters.rel_type || ''}
          onChange={(e) => onFilterChange({ rel_type: e.target.value || undefined })}
          sx={{ minWidth: 170, '& .MuiOutlinedInput-root': { borderRadius: 1.5 } }}
        >
          <MenuItem value="">
            <em>All Relationships</em>
          </MenuItem>
          {overview?.available_relationship_types.map((rt) => {
            const count = overview.relationship_counts_by_type[rt] || 0;
            return (
              <MenuItem key={rt} value={rt}>
                {rt} ({count})
              </MenuItem>
            );
          })}
        </TextField>

        {/* Result Limit Select */}
        <TextField
          select
          size="small"
          label="Limit"
          value={filters.limit || 100}
          onChange={(e) => onFilterChange({ limit: Number(e.target.value) })}
          sx={{ width: 100, '& .MuiOutlinedInput-root': { borderRadius: 1.5 } }}
        >
          <MenuItem value={25}>25</MenuItem>
          <MenuItem value={50}>50</MenuItem>
          <MenuItem value={100}>100</MenuItem>
          <MenuItem value={200}>200</MenuItem>
        </TextField>

        {/* Filter Action Buttons */}
        <Button
          variant="contained"
          size="small"
          onClick={onApply}
          disabled={isLoading}
          startIcon={<FilterIcon sx={{ fontSize: 16 }} />}
          sx={{
            bgcolor: '#0f766e',
            color: '#ffffff',
            fontWeight: 600,
            textTransform: 'none',
            borderRadius: 1.5,
            px: 2,
            boxShadow: 'none',
            '&:hover': {
              bgcolor: '#115e59',
            },
          }}
        >
          Apply Filters
        </Button>

        <Button
          variant="outlined"
          size="small"
          onClick={onReset}
          disabled={isLoading}
          sx={{
            borderColor: '#cbd5e1',
            color: '#475569',
            fontWeight: 600,
            textTransform: 'none',
            borderRadius: 1.5,
            '&:hover': {
              borderColor: '#94a3b8',
              bgcolor: '#f8fafc',
            },
          }}
        >
          Clear
        </Button>
      </Box>

      {/* Bottom Visualization Controls & Stats Row */}
      <Box
        sx={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: 1.5,
          pt: 1,
          borderTop: '1px solid #f1f5f9',
        }}
      >
        {/* Count indicators and Truncation Notice */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, flexWrap: 'wrap' }}>
          <Typography variant="body2" sx={{ color: '#475569', fontSize: '0.8125rem' }}>
            Displaying: <strong>{totalLoadedNodes}</strong> nodes • <strong>{totalLoadedRels}</strong> relationships
          </Typography>

          {isTruncated && (
            <Tooltip title="Result limit reached. Additional matching entities exist in Neo4j. Increase the limit or refine filters to explore specific subgraphs.">
              <Chip
                icon={<WarningIcon sx={{ fontSize: '14px !important' }} />}
                label={`Truncated at ${filters.limit || 100} nodes`}
                size="small"
                sx={{
                  bgcolor: '#fffbeb',
                  color: '#b45309',
                  fontSize: '0.72rem',
                  fontWeight: 600,
                  border: '1px solid #fde68a',
                  height: 22,
                }}
              />
            </Tooltip>
          )}
        </Box>

        {/* Canvas Layout & Navigation Controls */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <TextField
            select
            size="small"
            value={layoutName}
            onChange={(e) => onLayoutChange(e.target.value)}
            sx={{
              width: 130,
              '& .MuiOutlinedInput-root': { borderRadius: 1.5, fontSize: '0.75rem', py: 0 },
              '& .MuiSelect-select': { py: 0.5 },
            }}
          >
            <MenuItem value="cose">Force (COSE)</MenuItem>
            <MenuItem value="concentric">Concentric</MenuItem>
            <MenuItem value="breadthfirst">Hierarchical</MenuItem>
            <MenuItem value="circle">Circular</MenuItem>
            <MenuItem value="grid">Grid</MenuItem>
          </TextField>

          <Tooltip title="Re-calculate Graph Layout">
            <Button
              variant="outlined"
              size="small"
              onClick={onReLayout}
              startIcon={<LayoutIcon sx={{ fontSize: 14 }} />}
              sx={{
                borderColor: '#cbd5e1',
                color: '#475569',
                fontSize: '0.75rem',
                textTransform: 'none',
                py: 0.5,
                borderRadius: 1.5,
              }}
            >
              Re-Layout
            </Button>
          </Tooltip>

          <Tooltip title="Fit Canvas to View">
            <Button
              variant="outlined"
              size="small"
              onClick={onFitView}
              startIcon={<FitIcon sx={{ fontSize: 14 }} />}
              sx={{
                borderColor: '#cbd5e1',
                color: '#475569',
                fontSize: '0.75rem',
                textTransform: 'none',
                py: 0.5,
                borderRadius: 1.5,
              }}
            >
              Fit View
            </Button>
          </Tooltip>
        </Box>
      </Box>
    </Box>
  );
};
