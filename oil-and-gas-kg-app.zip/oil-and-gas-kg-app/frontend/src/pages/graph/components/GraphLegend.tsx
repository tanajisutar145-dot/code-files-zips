import React, { useState } from 'react';
import { Box, Typography, Collapse } from '@mui/material';
import { KeyboardArrowDown as ArrowDownIcon, KeyboardArrowUp as ArrowUpIcon } from '@mui/icons-material';
import { getNodeColor } from '../utils/graphStyles';

interface GraphLegendProps {
  availableLabels: string[];
  labelCounts: Record<string, number>;
  selectedLabel?: string;
  onSelectLabel: (label: string) => void;
}

export const GraphLegend: React.FC<GraphLegendProps> = ({
  availableLabels,
  labelCounts,
  selectedLabel,
  onSelectLabel,
}) => {
  const [open, setOpen] = useState(false);

  return (
    <Box
      sx={{
        position: 'absolute',
        bottom: 16,
        left: 16,
        zIndex: 10,
        bgcolor: 'rgba(255, 255, 255, 0.95)',
        backdropFilter: 'blur(6px)',
        border: '1px solid #e2e8f0',
        borderRadius: 2,
        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.08)',
        p: 1.25,
        maxWidth: 320,
      }}
    >
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          cursor: 'pointer',
          gap: 1,
        }}
        onClick={() => setOpen(!open)}
      >
        <Typography variant="caption" sx={{ fontWeight: 700, color: '#0f172a', fontSize: '0.75rem' }}>
          Entity Legend ({availableLabels.length} types)
        </Typography>
        {open ? <ArrowDownIcon sx={{ fontSize: 16 }} /> : <ArrowUpIcon sx={{ fontSize: 16 }} />}
      </Box>

      <Collapse in={open}>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: 'repeat(2, 1fr)',
            gap: 0.75,
            pt: 1,
            mt: 0.5,
            borderTop: '1px solid #f1f5f9',
            maxHeight: 180,
            overflowY: 'auto',
          }}
        >
          {availableLabels.map((lbl) => {
            const colors = getNodeColor(lbl);
            const count = labelCounts[lbl] || 0;
            const isSelected = selectedLabel === lbl;

            return (
              <Box
                key={lbl}
                onClick={() => onSelectLabel(isSelected ? '' : lbl)}
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 0.75,
                  p: 0.5,
                  borderRadius: 1,
                  cursor: 'pointer',
                  bgcolor: isSelected ? '#f0fdfa' : 'transparent',
                  border: isSelected ? '1px solid #99f6e4' : '1px solid transparent',
                  '&:hover': { bgcolor: '#f8fafc' },
                }}
              >
                <Box
                  sx={{
                    width: 9,
                    height: 9,
                    borderRadius: '50%',
                    bgcolor: colors.bg,
                    flexShrink: 0,
                  }}
                />
                <Typography
                  variant="caption"
                  sx={{
                    fontSize: '0.68rem',
                    color: isSelected ? '#0f766e' : '#334155',
                    fontWeight: isSelected ? 700 : 500,
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                  }}
                >
                  {lbl} ({count})
                </Typography>
              </Box>
            );
          })}
        </Box>
      </Collapse>
    </Box>
  );
};
