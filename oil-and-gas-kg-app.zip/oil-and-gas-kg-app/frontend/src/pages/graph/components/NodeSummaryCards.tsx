import React from 'react';
import { Box, Card, Typography, Tooltip } from '@mui/material';
import {
  Hub as ConnectedIcon,
  AccountTree as ParentIcon,
  Verified as StandardIcon,
  Category as DomainIcon,
  Flag as StatusIcon,
  Event as DateIcon,
  AttachMoney as CostIcon,
  WaterDrop as VolumeIcon,
  Timer as TimerIcon,
  Shield as CriticalityIcon,
  Fingerprint as IdentityIcon,
} from '@mui/icons-material';
import { GraphNode, GraphRelationship } from '../../../types/graph';
import { formatPropertyLabel, formatPropertyValue, ParentEntityInfo } from '../utils/relationshipUtils';

interface SummaryCardItem {
  id: string;
  label: string;
  value: string;
  icon: React.ReactNode;
  hint?: string;
  highlight?: boolean;
}

interface NodeSummaryCardsProps {
  node: GraphNode;
  parentEntity?: ParentEntityInfo | null;
  neighbors?: GraphNode[];
  relationships?: GraphRelationship[];
  connectedByType?: Record<string, number>;
}

const firstKey = (props: Record<string, any>, rx: RegExp, exclude?: RegExp): string | undefined =>
  Object.keys(props)
    .sort()
    .find((k) => rx.test(k) && (!exclude || !exclude.test(k)) && props[k] !== null && props[k] !== undefined && props[k] !== '');

const ALERT_VALUES = /(critical|tier 1|not_fit|fail|overdue|ineffective|major|high)/i;

export const NodeSummaryCards: React.FC<NodeSummaryCardsProps> = ({
  node,
  parentEntity,
  relationships = [],
  connectedByType = {},
}) => {
  const props = node.properties || {};
  const cards: SummaryCardItem[] = [];

  // Standard alignment written by the load step (std_class / std_match / std_package)
  if (props.std_class) {
    cards.push({
      id: 'standard',
      label: 'Standard Class',
      value: `${props.std_class}${props.std_match ? ` (${props.std_match})` : ''}`,
      hint: [props.std_package, props.std_standard].filter(Boolean).join(' · '),
      icon: <StandardIcon sx={{ fontSize: 18, color: '#7F6A93' }} />,
    });
  }
  if (props.subject_area) {
    cards.push({
      id: 'domain',
      label: 'Subject Area',
      value: String(props.subject_area),
      hint: props.source_table ? `Source table ${props.source_table}` : undefined,
      icon: <DomainIcon sx={{ fontSize: 18, color: '#0f766e' }} />,
    });
  }
  if (props.api10) {
    cards.push({
      id: 'api10',
      label: 'API-10 Identity',
      value: String(props.api10),
      hint: 'PPDM US Well Number core shared by every register of the physical well',
      icon: <IdentityIcon sx={{ fontSize: 18, color: '#1F77B4' }} />,
    });
  }

  const statusKey = firstKey(props, /(_status$|tier_classification$|fitness_for_service_result$|effectiveness_review_status$)/);
  if (statusKey) {
    const v = formatPropertyValue(statusKey, props[statusKey]);
    cards.push({
      id: 'status',
      label: formatPropertyLabel(statusKey),
      value: v,
      icon: <StatusIcon sx={{ fontSize: 18, color: '#0284c7' }} />,
      highlight: ALERT_VALUES.test(String(props[statusKey])),
    });
  }

  const critKey = firstKey(props, /(criticality|severity|risk_rank|risk_level)/);
  if (critKey) {
    cards.push({
      id: 'criticality',
      label: formatPropertyLabel(critKey),
      value: formatPropertyValue(critKey, props[critKey]),
      icon: <CriticalityIcon sx={{ fontSize: 18, color: '#e11d48' }} />,
      highlight: ALERT_VALUES.test(String(props[critKey])),
    });
  }

  const dateKey = firstKey(props, /(event_date|failure_date|inspection_date|spud_date|transfer_date|incident_date|test_start_date|production_month|effective_date|event_timestamp|_date$)/,
    /(created|modified|updated|approved|closure)/);
  if (dateKey) {
    cards.push({
      id: 'date',
      label: formatPropertyLabel(dateKey),
      value: formatPropertyValue(dateKey, props[dateKey]),
      icon: <DateIcon sx={{ fontSize: 18, color: '#16a34a' }} />,
    });
  }

  const costKey = firstKey(props, /(_usd$|repair_cost$|penalty_amount$|actual_material_cost$|total_capex_usd$)/);
  if (costKey) {
    cards.push({
      id: 'cost',
      label: formatPropertyLabel(costKey),
      value: formatPropertyValue(costKey, props[costKey]),
      icon: <CostIcon sx={{ fontSize: 18, color: '#ea580c' }} />,
    });
  }

  const volumeKey = firstKey(props, /(_bbl$|_mcf$|_boe$|_bopd$|co2e_tonnes$|pit_gain_volume_bbl$|release_quantity$)/);
  if (volumeKey) {
    cards.push({
      id: 'volume',
      label: formatPropertyLabel(volumeKey),
      value: formatPropertyValue(volumeKey, props[volumeKey]),
      icon: <VolumeIcon sx={{ fontSize: 18, color: '#4C78A8' }} />,
    });
  }

  const hoursKey = firstKey(props, /(duration_hours$|downtime_hours$|mtbf_hours$)/);
  if (hoursKey) {
    cards.push({
      id: 'hours',
      label: formatPropertyLabel(hoursKey),
      value: formatPropertyValue(hoursKey, props[hoursKey]),
      icon: <TimerIcon sx={{ fontSize: 18, color: '#d97706' }} />,
    });
  }

  const totalConnected = Object.values(connectedByType).reduce((a, b) => a + b, 0) || relationships.length;
  cards.push({
    id: 'total_connected',
    label: 'Connected Records',
    value: String(totalConnected),
    icon: <ConnectedIcon sx={{ fontSize: 18, color: '#0f766e' }} />,
  });
  if (parentEntity?.name) {
    cards.push({
      id: 'parent_entity',
      label: parentEntity.relationship,
      value: parentEntity.name,
      hint: parentEntity.friendlyLabel,
      icon: <ParentIcon sx={{ fontSize: 18, color: '#0284c7' }} />,
    });
  }

  if (cards.length === 0) {
    return null;
  }

  return (
    <Box
      sx={{
        px: { xs: 2, sm: 3 },
        py: 1.5,
        bgcolor: '#f8fafc',
        borderBottom: '1px solid #e2e8f0',
        display: 'flex',
        alignItems: 'stretch',
        gap: 1.5,
        overflowX: 'auto',
        flexShrink: 0,
        '&::-webkit-scrollbar': { height: 4 },
        '&::-webkit-scrollbar-thumb': { bgcolor: '#cbd5e1', borderRadius: 2 },
      }}
    >
      {cards.map((card) => (
        <Card
          key={card.id}
          elevation={0}
          sx={{
            minWidth: { xs: 140, sm: 165 },
            flex: '1 1 0px',
            maxWidth: { xs: 220, md: 240 },
            p: 1.5,
            bgcolor: '#ffffff',
            border: card.highlight ? '1px solid #fecdd3' : '1px solid #e2e8f0',
            borderRadius: 2,
            boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.03)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            transition: 'all 0.15s ease',
            '&:hover': {
              borderColor: '#0f766e',
              boxShadow: '0 2px 6px 0 rgba(15, 118, 110, 0.08)',
            },
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, mb: 0.5 }}>
            {card.icon}
            <Typography
              variant="caption"
              sx={{
                fontWeight: 700,
                color: '#64748b',
                textTransform: 'uppercase',
                fontSize: '0.68rem',
                letterSpacing: '0.04em',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
              }}
            >
              {card.label}
            </Typography>
          </Box>
          <Tooltip title={card.hint ? `${card.value} — ${card.hint}` : card.value}>
            <Typography
              variant="body1"
              sx={{
                fontWeight: 700,
                color: card.highlight ? '#be123c' : '#0f172a',
                fontSize: { xs: '0.875rem', sm: '0.95rem' },
                lineHeight: 1.3,
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
              }}
            >
              {card.value}
            </Typography>
          </Tooltip>
        </Card>
      ))}
    </Box>
  );
};
