import React, { useState } from 'react';
import {
  Box,
  Typography,
  Chip,
  IconButton,
  Button,
  TextField,
  InputAdornment,
} from '@mui/material';
import {
  ArrowForward as ArrowForwardIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
  Hub as HubIcon,
} from '@mui/icons-material';
import { GraphNode, GraphRelationship } from '../../../types/graph';
import { getNodeColor } from '../utils/graphStyles';
import {
  formatEntityLabel,
  formatRelationshipLabel,
  ParentEntityInfo,
} from '../utils/relationshipUtils';

interface RelatedEntitiesListProps {
  centerNode: GraphNode;
  neighbors: GraphNode[];
  relationships: GraphRelationship[];
  parentEntity?: ParentEntityInfo | null;
  onSelectNeighbor: (nodeId: string) => void;
  onExpandNeighbors?: () => void;
  hasMoreNeighbors?: boolean;
}

interface EnrichedNeighborItem {
  node: GraphNode;
  friendlyLabel: string;
  relationshipDescription: string;
  isParent: boolean;
  category: string;
}

export const RelatedEntitiesList: React.FC<RelatedEntitiesListProps> = ({
  centerNode,
  neighbors,
  relationships,
  parentEntity,
  onSelectNeighbor,
  onExpandNeighbors,
  hasMoreNeighbors = false,
}) => {
  const [searchFilter, setSearchFilter] = useState('');
  const [showAllPerGroup, setShowAllPerGroup] = useState<Record<string, boolean>>({});

  // Build enriched list with correct directional descriptions
  const enrichedItems: EnrichedNeighborItem[] = neighbors.map((neigh) => {
    const isParent = parentEntity?.id === neigh.id;

    // Find relationship connecting centerNode and this neighbor
    const edge = relationships.find(
      (r) =>
        (r.source === centerNode.id && r.target === neigh.id) ||
        (r.target === centerNode.id && r.source === neigh.id)
    );

    let relationshipDescription = 'Connected Entity';
    if (edge) {
      const isOutbound = edge.source === centerNode.id;
      relationshipDescription = formatRelationshipLabel(edge.type, isOutbound);
    } else if (isParent) {
      relationshipDescription = parentEntity?.relationship || 'Parent Entity';
    }

    const friendlyLabel = formatEntityLabel(neigh.label);

    let category = friendlyLabel;
    if (isParent) {
      category = 'Parent Entity';
    }

    return {
      node: neigh,
      friendlyLabel,
      relationshipDescription,
      isParent,
      category,
    };
  });

  // Filter items by search text
  const filtered = enrichedItems.filter((item) => {
    if (!searchFilter.trim()) return true;
    const q = searchFilter.toLowerCase();
    return (
      item.node.name.toLowerCase().includes(q) ||
      (item.node.entity_id && item.node.entity_id.toLowerCase().includes(q)) ||
      item.friendlyLabel.toLowerCase().includes(q) ||
      item.relationshipDescription.toLowerCase().includes(q)
    );
  });

  // Group by category, putting Parent Entity first if present
  const grouped = filtered.reduce<Record<string, EnrichedNeighborItem[]>>((acc, item) => {
    const cat = item.category;
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(item);
    return acc;
  }, {});

  const categories = Object.keys(grouped).sort((a, b) => {
    if (a === 'Parent Entity') return -1;
    if (b === 'Parent Entity') return 1;
    return a.localeCompare(b);
  });

  const toggleGroupExpand = (cat: string) => {
    setShowAllPerGroup((prev) => ({ ...prev, [cat]: !prev[cat] }));
  };

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        bgcolor: '#ffffff',
        border: '1px solid #e2e8f0',
        borderRadius: 2,
        overflow: 'hidden',
        boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)',
      }}
    >
      {/* Header */}
      <Box
        sx={{
          px: 2,
          py: 1.25,
          bgcolor: '#f8fafc',
          borderBottom: '1px solid #e2e8f0',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexShrink: 0,
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Typography
            variant="subtitle2"
            sx={{
              fontWeight: 700,
              color: '#0f172a',
              letterSpacing: '0.02em',
              textTransform: 'uppercase',
              fontSize: '0.78rem',
            }}
          >
            Related Entities
          </Typography>
          <Chip
            label={neighbors.length}
            size="small"
            sx={{
              height: 20,
              fontSize: '0.68rem',
              fontWeight: 700,
              bgcolor: '#e2e8f0',
              color: '#334155',
            }}
          />
        </Box>
      </Box>

      {/* Optional Search filter if > 4 neighbors */}
      {neighbors.length > 4 && (
        <Box sx={{ p: 1, borderBottom: '1px solid #f1f5f9' }}>
          <TextField
            placeholder="Filter related entities..."
            size="small"
            fullWidth
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ fontSize: 16, color: '#94a3b8' }} />
                </InputAdornment>
              ),
              endAdornment: searchFilter ? (
                <InputAdornment position="end">
                  <IconButton size="small" onClick={() => setSearchFilter('')} sx={{ p: 0.25 }}>
                    <ClearIcon sx={{ fontSize: 14 }} />
                  </IconButton>
                </InputAdornment>
              ) : null,
              sx: {
                fontSize: '0.75rem',
                height: 32,
                borderRadius: 1.5,
                bgcolor: '#f8fafc',
              },
            }}
          />
        </Box>
      )}

      {/* Scrollable list */}
      <Box
        sx={{
          p: 1.5,
          overflowY: 'auto',
          flexGrow: 1,
          display: 'flex',
          flexDirection: 'column',
          gap: 2,
        }}
      >
        {neighbors.length === 0 ? (
          <Box sx={{ p: 3, textAlign: 'center', color: '#94a3b8' }}>
            <HubIcon sx={{ fontSize: 32, color: '#cbd5e1', mb: 1 }} />
            <Typography variant="body2" sx={{ fontSize: '0.8rem', color: '#64748b' }}>
              No related entities found.
            </Typography>
          </Box>
        ) : filtered.length === 0 ? (
          <Box sx={{ p: 2, textAlign: 'center', color: '#94a3b8' }}>
            <Typography variant="caption">No entities match "{searchFilter}"</Typography>
          </Box>
        ) : (
          categories.map((category) => {
            const items = grouped[category];
            const isExpanded = showAllPerGroup[category] || false;
            const displayItems = isExpanded ? items : items.slice(0, 6);

            return (
              <Box key={category}>
                {/* Group Header */}
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    mb: 0.75,
                    px: 0.5,
                  }}
                >
                  <Typography
                    variant="caption"
                    sx={{
                      fontWeight: 700,
                      color: category === 'Parent Entity' ? '#0f766e' : '#64748b',
                      textTransform: 'uppercase',
                      letterSpacing: '0.04em',
                      fontSize: '0.7rem',
                    }}
                  >
                    {category} ({items.length})
                  </Typography>

                  {items.length > 6 && (
                    <Button
                      size="small"
                      onClick={() => toggleGroupExpand(category)}
                      sx={{
                        fontSize: '0.68rem',
                        textTransform: 'none',
                        p: 0,
                        minWidth: 0,
                        color: '#0f766e',
                        fontWeight: 600,
                      }}
                    >
                      {isExpanded ? 'Show Less' : `+${items.length - 6} More`}
                    </Button>
                  )}
                </Box>

                {/* Items in Category */}
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75 }}>
                  {displayItems.map((item) => {
                    const col = getNodeColor(item.node.label);
                    return (
                      <Box
                        key={item.node.id}
                        onClick={() => onSelectNeighbor(item.node.id)}
                        sx={{
                          p: 1.25,
                          borderRadius: 1.5,
                          border: item.isParent
                            ? '1px solid #99f6e4'
                            : '1px solid #f1f5f9',
                          bgcolor: item.isParent ? '#f0fdfa' : '#ffffff',
                          cursor: 'pointer',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          transition: 'all 0.15s ease',
                          '&:hover': {
                            borderColor: '#0f766e',
                            bgcolor: '#f0fdfa',
                            transform: 'translateX(2px)',
                            boxShadow: '0 2px 5px rgba(15, 118, 110, 0.08)',
                          },
                        }}
                      >
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.25, minWidth: 0 }}>
                          {/* Entity Color Dot */}
                          <Box
                            sx={{
                              width: 8,
                              height: 8,
                              borderRadius: '50%',
                              bgcolor: col.bg,
                              flexShrink: 0,
                            }}
                          />

                          <Box sx={{ minWidth: 0 }}>
                            <Typography
                              variant="body2"
                              sx={{
                                fontWeight: 700,
                                color: '#0f172a',
                                fontSize: '0.8125rem',
                                lineHeight: 1.25,
                                whiteSpace: 'nowrap',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                              }}
                            >
                              {item.node.name}
                            </Typography>

                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, mt: 0.25 }}>
                              <Typography
                                variant="caption"
                                sx={{
                                  color: '#0f766e',
                                  fontSize: '0.7rem',
                                  fontWeight: 600,
                                }}
                              >
                                {item.relationshipDescription}
                              </Typography>
                              {item.node.entity_id && (
                                <Typography
                                  variant="caption"
                                  sx={{
                                    color: '#94a3b8',
                                    fontSize: '0.68rem',
                                  }}
                                >
                                  • {item.node.entity_id}
                                </Typography>
                              )}
                            </Box>
                          </Box>
                        </Box>

                        <ArrowForwardIcon
                          sx={{
                            fontSize: 14,
                            color: '#94a3b8',
                            flexShrink: 0,
                            ml: 1,
                          }}
                        />
                      </Box>
                    );
                  })}
                </Box>
              </Box>
            );
          })
        )}

        {/* Global Expand Neighbors button if bounded */}
        {hasMoreNeighbors && onExpandNeighbors && (
          <Box sx={{ pt: 1, textAlign: 'center' }}>
            <Button
              variant="outlined"
              size="small"
              onClick={onExpandNeighbors}
              sx={{
                textTransform: 'none',
                fontSize: '0.75rem',
                borderColor: '#cbd5e1',
                color: '#0f766e',
                borderRadius: 1.5,
              }}
            >
              Expand Additional Graph Neighbors
            </Button>
          </Box>
        )}
      </Box>
    </Box>
  );
};
