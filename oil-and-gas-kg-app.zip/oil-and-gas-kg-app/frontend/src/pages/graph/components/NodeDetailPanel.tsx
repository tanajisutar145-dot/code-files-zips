import React from 'react';
import {
  Box,
  Typography,
  Chip,
  IconButton,
  Button,
  CircularProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  Paper,
} from '@mui/material';
import {
  Close as CloseIcon,
  Hub as HubIcon,
  CenterFocusStrong as CenterIcon,
  Description as DocumentIcon,
  ArrowForward as ArrowForwardIcon,
  Search as SearchIcon,
  Psychology as IntelligenceIcon,
  PrecisionManufacturing as AssetIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { GraphNodeDetailResponse, GraphNode } from '../../../types/graph';
import { getNodeColor } from '../utils/graphStyles';

interface NodeDetailPanelProps {
  detail: GraphNodeDetailResponse | null;
  isLoading: boolean;
  isExpanding: boolean;
  onClose: () => void;
  onExpandNeighbors: (nodeId: string) => void;
  onSelectNeighbor: (node: GraphNode) => void;
  onCenterNode: (nodeId: string) => void;
}

export const NodeDetailPanel: React.FC<NodeDetailPanelProps> = ({
  detail,
  isLoading,
  isExpanding,
  onClose,
  onExpandNeighbors,
  onSelectNeighbor,
  onCenterNode,
}) => {
  const navigate = useNavigate();

  if (isLoading) {
    return (
      <Box
        sx={{
          p: 3,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          height: '100%',
          gap: 1.5,
        }}
      >
        <CircularProgress size={28} sx={{ color: '#0f766e' }} />
        <Typography variant="caption" sx={{ color: '#64748b' }}>
          Loading entity telemetry...
        </Typography>
      </Box>
    );
  }

  if (!detail) {
    return (
      <Box sx={{ p: 3, textAlign: 'center', color: '#94a3b8' }}>
        <Typography variant="body2">No entity selected</Typography>
      </Box>
    );
  }

  const { node, connected_count, connected_by_type, neighbors_preview, document_links } = detail;
  const colors = getNodeColor(node.label);

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        bgcolor: '#ffffff',
      }}
    >
      {/* Panel Header */}
      <Box
        sx={{
          p: 2,
          pb: 1.5,
          borderBottom: '1px solid #e2e8f0',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'flex-start',
        }}
      >
        <Box sx={{ flexGrow: 1, pr: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.75 }}>
            <Chip
              label={node.label}
              size="small"
              sx={{
                bgcolor: colors.bg,
                color: colors.text,
                fontWeight: 700,
                fontSize: '0.72rem',
                height: 22,
              }}
            />
            {node.entity_id && (
              <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 600 }}>
                {node.entity_id}
              </Typography>
            )}
          </Box>

          <Typography
            variant="subtitle1"
            sx={{
              fontWeight: 700,
              color: '#0f172a',
              lineHeight: 1.25,
              fontSize: '1rem',
            }}
          >
            {node.name}
          </Typography>
        </Box>

        <IconButton size="small" onClick={onClose} sx={{ color: '#94a3b8' }}>
          <CloseIcon sx={{ fontSize: 18 }} />
        </IconButton>
      </Box>

      {/* Action Buttons Bar */}
      <Box
        sx={{
          p: 1.5,
          display: 'flex',
          gap: 1,
          bgcolor: '#f8fafc',
          borderBottom: '1px solid #f1f5f9',
        }}
      >
        <Button
          variant="contained"
          size="small"
          onClick={() => onExpandNeighbors(node.id)}
          disabled={isExpanding}
          startIcon={
            isExpanding ? <CircularProgress size={14} color="inherit" /> : <HubIcon sx={{ fontSize: 16 }} />
          }
          sx={{
            flex: 1,
            bgcolor: '#0f766e',
            color: '#ffffff',
            fontWeight: 600,
            textTransform: 'none',
            fontSize: '0.75rem',
            boxShadow: 'none',
            borderRadius: 1.5,
            '&:hover': { bgcolor: '#115e59' },
          }}
        >
          {isExpanding ? 'Expanding...' : `Expand Neighbors (${connected_count})`}
        </Button>

        <Button
          variant="outlined"
          size="small"
          onClick={() => onCenterNode(node.id)}
          startIcon={<CenterIcon sx={{ fontSize: 16 }} />}
          sx={{
            borderColor: '#cbd5e1',
            color: '#334155',
            fontWeight: 600,
            textTransform: 'none',
            fontSize: '0.75rem',
            borderRadius: 1.5,
            '&:hover': { bgcolor: '#f1f5f9', borderColor: '#94a3b8' },
          }}
        >
          Center
        </Button>
      </Box>

      {/* Quick Cross-Navigation Bar */}
      <Box
        sx={{
          px: 1.5,
          py: 1,
          display: 'flex',
          gap: 0.75,
          bgcolor: '#ffffff',
          borderBottom: '1px solid #f1f5f9',
          flexWrap: 'wrap',
        }}
      >
        {node.label === 'Equipment' && (
          <Button
            variant="outlined"
            size="small"
            onClick={() => navigate(`/assets?search=${encodeURIComponent(node.properties?.tag || node.name)}`)}
            startIcon={<AssetIcon sx={{ fontSize: 14 }} />}
            sx={{
              textTransform: 'none',
              fontSize: '0.72rem',
              py: 0.25,
              px: 1,
              borderColor: '#93c5fd',
              color: '#1d4ed8',
              borderRadius: 1.5,
              '&:hover': { bgcolor: '#eff6ff' },
            }}
          >
            Equipment Record
          </Button>
        )}
        <Button
          variant="outlined"
          size="small"
          onClick={() => navigate(`/search?q=${encodeURIComponent(node.name || node.entity_id)}`)}
          startIcon={<SearchIcon sx={{ fontSize: 14 }} />}
          sx={{
            textTransform: 'none',
            fontSize: '0.72rem',
            py: 0.25,
            px: 1,
            borderColor: '#cbd5e1',
            color: '#334155',
            borderRadius: 1.5,
            '&:hover': { bgcolor: '#f8fafc' },
          }}
        >
          Search Evidence
        </Button>
        <Button
          variant="outlined"
          size="small"
          onClick={() => navigate(`/intelligence?q=${encodeURIComponent(`What is the operational status and history of ${node.name || node.entity_id}?`)}`)}
          startIcon={<IntelligenceIcon sx={{ fontSize: 14 }} />}
          sx={{
            textTransform: 'none',
            fontSize: '0.72rem',
            py: 0.25,
            px: 1,
            borderColor: '#99f6e4',
            color: '#0f766e',
            borderRadius: 1.5,
            '&:hover': { bgcolor: '#f0fdfa' },
          }}
        >
          Ask Intelligence
        </Button>
      </Box>

      {/* Scrollable Content Body */}
      <Box sx={{ p: 2, overflowY: 'auto', flexGrow: 1, display: 'flex', flexDirection: 'column', gap: 2.5 }}>
        {/* Connected Edge Type Summary */}
        <Box>
          <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.04em', display: 'block', mb: 1 }}>
            Connected Relationships ({connected_count})
          </Typography>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.75 }}>
            {Object.entries(connected_by_type).map(([relType, count]) => (
              <Chip
                key={relType}
                label={`${relType}: ${count}`}
                size="small"
                variant="outlined"
                sx={{
                  borderColor: '#cbd5e1',
                  color: '#334155',
                  fontSize: '0.7rem',
                  fontWeight: 600,
                  height: 22,
                }}
              />
            ))}
          </Box>
        </Box>

        {/* Immediate Neighbors Preview List */}
        {neighbors_preview.length > 0 && (
          <Box>
            <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.04em', display: 'block', mb: 1 }}>
              Immediate Neighbors ({neighbors_preview.length} sample)
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75 }}>
              {neighbors_preview.map((neigh) => {
                const nColor = getNodeColor(neigh.label);
                return (
                  <Box
                    key={neigh.id}
                    onClick={() => onSelectNeighbor(neigh)}
                    sx={{
                      p: 1,
                      borderRadius: 1.5,
                      border: '1px solid #f1f5f9',
                      bgcolor: '#ffffff',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      transition: 'all 0.15s ease',
                      '&:hover': {
                        borderColor: '#0f766e',
                        bgcolor: '#f0fdfa',
                      },
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, minWidth: 0 }}>
                      <Box
                        sx={{
                          width: 8,
                          height: 8,
                          borderRadius: '50%',
                          bgcolor: nColor.bg,
                          flexShrink: 0,
                        }}
                      />
                      <Box sx={{ minWidth: 0 }}>
                        <Typography
                          variant="caption"
                          sx={{
                            fontWeight: 600,
                            color: '#0f172a',
                            display: 'block',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >
                          {neigh.name}
                        </Typography>
                        <Typography variant="caption" sx={{ color: '#94a3b8', fontSize: '0.68rem' }}>
                          {neigh.label} {neigh.entity_id ? `• ${neigh.entity_id}` : ''}
                        </Typography>
                      </Box>
                    </Box>

                    <ArrowForwardIcon sx={{ fontSize: 13, color: '#94a3b8', flexShrink: 0, ml: 1 }} />
                  </Box>
                );
              })}
            </Box>
          </Box>
        )}

        {/* Linked Documents (if any) */}
        {document_links && document_links.length > 0 && (
          <Box>
            <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.04em', display: 'flex', alignItems: 'center', gap: 0.5, mb: 1 }}>
              <DocumentIcon sx={{ fontSize: 14, color: '#2563eb' }} />
              Linked Grounding Documents ({document_links.length})
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              {document_links.map((doc, idx) => (
                <Box
                  key={idx}
                  onClick={() => navigate(`/documents?search=${encodeURIComponent(doc.chunk_id || doc.title)}`)}
                  sx={{
                    p: 1.25,
                    borderRadius: 1.5,
                    bgcolor: '#f8fafc',
                    border: '1px solid #e2e8f0',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease',
                    '&:hover': { bgcolor: '#f1f5f9', borderColor: '#cbd5e1' },
                  }}
                >
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <Typography variant="caption" sx={{ fontWeight: 700, color: '#0f172a', display: 'block' }}>
                      {doc.title}
                    </Typography>
                    <ArrowForwardIcon sx={{ fontSize: 13, color: '#94a3b8', ml: 1, flexShrink: 0 }} />
                  </Box>
                  <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.7rem', display: 'block', mt: 0.25 }}>
                    Chunk: {doc.chunk_id}
                  </Typography>
                  {doc.snippet && (
                    <Typography variant="caption" sx={{ color: '#475569', fontSize: '0.72rem', display: 'block', mt: 0.5, fontStyle: 'italic' }}>
                      "{doc.snippet}..."
                    </Typography>
                  )}
                </Box>
              ))}
            </Box>
          </Box>
        )}

        {/* Node Properties Table */}
        <Box>
          <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.04em', display: 'block', mb: 1 }}>
            Properties ({Object.keys(node.properties).length})
          </Typography>
          <TableContainer
            component={Paper}
            elevation={0}
            sx={{ border: '1px solid #f1f5f9', borderRadius: 1.5, maxHeight: 280 }}
          >
            <Table size="small">
              <TableBody>
                {Object.entries(node.properties).map(([key, val]) => (
                  <TableRow key={key} sx={{ '&:last-child td': { border: 0 } }}>
                    <TableCell
                      sx={{
                        fontWeight: 600,
                        color: '#475569',
                        fontSize: '0.72rem',
                        width: '38%',
                        py: 0.75,
                        px: 1,
                        bgcolor: '#fafafa',
                      }}
                    >
                      {key}
                    </TableCell>
                    <TableCell
                      sx={{
                        color: '#0f172a',
                        fontSize: '0.72rem',
                        py: 0.75,
                        px: 1,
                        wordBreak: 'break-word',
                      }}
                    >
                      {String(val)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Box>
    </Box>
  );
};
