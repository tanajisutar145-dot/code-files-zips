import React from 'react';
import { Box, Typography, Chip, IconButton, Tooltip } from '@mui/material';
import {
  Close as CloseIcon,
  AccountTree as ParentIcon,
  FiberManualRecord as StatusDotIcon,
} from '@mui/icons-material';
import { GraphNode } from '../../../types/graph';
import { getNodeColor } from '../utils/graphStyles';
import {
  formatEntityLabel,
  getStatusColorInfo,
  ParentEntityInfo,
} from '../utils/relationshipUtils';

interface NodeIdentityHeaderProps {
  node: GraphNode;
  parentEntity?: ParentEntityInfo | null;
  onClose: () => void;
  onSelectEntity?: (entityId: string) => void;
}

export const NodeIdentityHeader: React.FC<NodeIdentityHeaderProps> = ({
  node,
  parentEntity,
  onClose,
  onSelectEntity,
}) => {
  const colors = getNodeColor(node.label);
  const friendlyLabel = formatEntityLabel(node.label);

  // Derive status if available in properties
  const statusKey = Object.keys(node.properties || {})
    .sort()
    .find((k) => k === 'status' || k.endsWith('_status'));
  const rawStatus = statusKey ? node.properties[statusKey] : undefined;

  const statusColors = rawStatus ? getStatusColorInfo(rawStatus) : null;

  return (
    <Box
      sx={{
        px: { xs: 2, sm: 3 },
        py: 2,
        bgcolor: '#ffffff',
        borderBottom: '1px solid #e2e8f0',
        display: 'flex',
        alignItems: 'flex-start',
        justifyContent: 'space-between',
        gap: 2,
        flexShrink: 0,
      }}
    >
      {/* Entity Identity Info */}
      <Box sx={{ minWidth: 0, flexGrow: 1 }}>
        {/* Top Badges Row */}
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 1,
            flexWrap: 'wrap',
            mb: 0.75,
          }}
        >
          {/* Friendly Entity Type Chip */}
          <Chip
            label={friendlyLabel}
            size="small"
            sx={{
              bgcolor: colors.bg,
              color: colors.text,
              fontWeight: 700,
              fontSize: '0.75rem',
              height: 24,
              boxShadow: '0 1px 2px rgba(0,0,0,0.06)',
            }}
          />

          {/* Identifier Badge */}
          {node.entity_id && (
            <Chip
              label={node.entity_id}
              size="small"
              variant="outlined"
              sx={{
                borderColor: '#cbd5e1',
                color: '#475569',
                fontWeight: 600,
                fontSize: '0.72rem',
                height: 24,
                bgcolor: '#f8fafc',
              }}
            />
          )}

          {/* Status Badge (only if actual data provides one) */}
          {statusColors && rawStatus && (
            <Chip
              icon={
                <StatusDotIcon
                  sx={{
                    fontSize: '10px !important',
                    color: `${statusColors.text} !important`,
                  }}
                />
              }
              label={String(rawStatus)}
              size="small"
              sx={{
                bgcolor: statusColors.bg,
                color: statusColors.text,
                border: `1px solid ${statusColors.border}`,
                fontWeight: 600,
                fontSize: '0.72rem',
                height: 24,
                textTransform: 'capitalize',
              }}
            />
          )}
        </Box>

        {/* Primary Display Name */}
        <Typography
          variant="h5"
          component="h2"
          sx={{
            fontWeight: 700,
            color: '#0f172a',
            lineHeight: 1.25,
            fontSize: { xs: '1.15rem', sm: '1.35rem' },
            letterSpacing: '-0.015em',
            wordBreak: 'break-word',
          }}
        >
          {node.name || node.entity_id || friendlyLabel}
        </Typography>

        {/* Parent Entity Breadcrumb Link (when available) */}
        {parentEntity && (
          <Box
            sx={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 0.75,
              mt: 0.5,
              cursor: onSelectEntity ? 'pointer' : 'default',
              p: '2px 8px',
              borderRadius: 1.5,
              bgcolor: '#f8fafc',
              border: '1px solid #e2e8f0',
              transition: 'all 0.15s ease',
              '&:hover': onSelectEntity
                ? {
                    bgcolor: '#f0fdfa',
                    borderColor: '#99f6e4',
                  }
                : {},
            }}
            onClick={() => onSelectEntity && onSelectEntity(parentEntity.id)}
          >
            <ParentIcon sx={{ fontSize: 14, color: '#0f766e' }} />
            <Typography
              variant="caption"
              sx={{
                color: '#64748b',
                fontWeight: 500,
                fontSize: '0.75rem',
              }}
            >
              {parentEntity.relationship}:
            </Typography>
            <Typography
              variant="caption"
              sx={{
                color: '#0f766e',
                fontWeight: 700,
                fontSize: '0.75rem',
                textDecoration: onSelectEntity ? 'underline' : 'none',
              }}
            >
              {parentEntity.name}
            </Typography>
            {parentEntity.entity_id && (
              <Typography
                variant="caption"
                sx={{
                  color: '#94a3b8',
                  fontSize: '0.7rem',
                  fontWeight: 500,
                }}
              >
                ({parentEntity.entity_id})
              </Typography>
            )}
          </Box>
        )}
      </Box>

      {/* Close Button */}
      <Tooltip title="Close Popup (Esc)">
        <IconButton
          onClick={onClose}
          aria-label="close"
          size="medium"
          sx={{
            color: '#64748b',
            bgcolor: '#f8fafc',
            border: '1px solid #e2e8f0',
            borderRadius: 2,
            transition: 'all 0.15s ease',
            '&:hover': {
              bgcolor: '#fee2e2',
              color: '#ef4444',
              borderColor: '#fca5a5',
            },
          }}
        >
          <CloseIcon sx={{ fontSize: 20 }} />
        </IconButton>
      </Tooltip>
    </Box>
  );
};
