import React, { useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import { Box } from '@mui/material';
import cytoscape, { Core, EventObject } from 'cytoscape';
import { GraphNode, GraphRelationship } from '../../../types/graph';
import { CYTOSCAPE_STYLESHEET, getNodeColor } from '../utils/graphStyles';

export interface GraphCanvasHandle {
  fit: () => void;
  runLayout: (layoutType?: string) => void;
  centerNode: (nodeId: string) => void;
}

interface GraphCanvasProps {
  nodes: GraphNode[];
  relationships: GraphRelationship[];
  selectedNodeId: string | null;
  onSelectNode: (nodeId: string) => void;
  onClearSelection: () => void;
  layoutName: string;
}

export const GraphCanvas = forwardRef<GraphCanvasHandle, GraphCanvasProps>(
  (
    {
      nodes,
      relationships,
      selectedNodeId,
      onSelectNode,
      onClearSelection,
      layoutName,
    },
    ref
  ) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const cyRef = useRef<Core | null>(null);

    // Expose control methods
    useImperativeHandle(ref, () => ({
      fit: () => {
        if (cyRef.current && !cyRef.current.destroyed()) {
          cyRef.current.fit(undefined, 35);
        }
      },
      runLayout: (customLayout?: string) => {
        if (cyRef.current && !cyRef.current.destroyed()) {
          const lName = customLayout || layoutName;
          const layout = cyRef.current.layout(getLayoutConfig(lName));
          layout.run();
        }
      },
      centerNode: (nodeId: string) => {
        if (cyRef.current && !cyRef.current.destroyed()) {
          const node = cyRef.current.getElementById(nodeId);
          if (node.length > 0) {
            cyRef.current.center(node);
            cyRef.current.zoom({ level: 1.25, position: node.position() });
          }
        }
      },
    }));

    const getLayoutConfig = (name: string) => {
      switch (name) {
        case 'breadthfirst':
          return { name: 'breadthfirst', directed: true, padding: 30, animate: true, animationDuration: 400 };
        case 'concentric':
          return {
            name: 'concentric',
            padding: 30,
            animate: true,
            animationDuration: 400,
            minNodeSpacing: 35,
          };
        case 'circle':
          return { name: 'circle', padding: 30, animate: true, animationDuration: 400 };
        case 'grid':
          return { name: 'grid', padding: 30, animate: true, animationDuration: 400 };
        case 'cose':
        default:
          return {
            name: 'cose',
            animate: true,
            animationDuration: 500,
            padding: 40,
            nodeRepulsion: 450000,
            idealEdgeLength: 70,
            edgeElasticity: 100,
            nestingFactor: 5,
            gravity: 80,
            numIter: 800,
          };
      }
    };

    // Initialize Cytoscape
    useEffect(() => {
      if (!containerRef.current) return;

      const cy = cytoscape({
        container: containerRef.current,
        elements: [],
        style: CYTOSCAPE_STYLESHEET,
        boxSelectionEnabled: false,
        wheelSensitivity: 0.25,
      });

      cy.on('tap', 'node', (evt: EventObject) => {
        const id = evt.target.id();
        onSelectNode(id);
      });

      cy.on('tap', (evt: EventObject) => {
        if (evt.target === cy) {
          onClearSelection();
        }
      });

      cyRef.current = cy;

      // Handle container resizing
      const resizeObserver = new ResizeObserver(() => {
        if (cy && !cy.destroyed()) {
          cy.resize();
        }
      });
      resizeObserver.observe(containerRef.current);

      return () => {
        resizeObserver.disconnect();
        if (cy && !cy.destroyed()) {
          cy.destroy();
        }
        cyRef.current = null;
      };
    }, [onSelectNode, onClearSelection]);

    // Update Elements when nodes or relationships change
    useEffect(() => {
      const cy = cyRef.current;
      if (!cy || cy.destroyed()) return;

      cy.batch(() => {
        cy.elements().remove();

        // Add nodes
        const cyNodes = nodes.map((n) => {
          const colors = getNodeColor(n.label);
          const shortLabel = n.name.length > 20 ? n.name.slice(0, 18) + '...' : n.name;
          return {
            group: 'nodes' as const,
            data: {
              id: n.id,
              shortLabel,
              fullName: n.name,
              nodeType: n.label,
              entityId: n.entity_id,
              color: colors.bg,
              borderColor: colors.border,
            },
          };
        });

        // Add relationships
        const cyEdges = relationships.map((r) => ({
          group: 'edges' as const,
          data: {
            id: r.id,
            source: r.source,
            target: r.target,
            type: r.type,
          },
        }));

        cy.add([...cyNodes, ...cyEdges]);
      });

      // Run layout
      if (nodes.length > 0) {
        const layout = cy.layout(getLayoutConfig(layoutName));
        layout.run();
        cy.fit(undefined, 30);
      }
    }, [nodes, relationships, layoutName]);

    // Handle node selection highlight
    useEffect(() => {
      const cy = cyRef.current;
      if (!cy) return;

      cy.batch(() => {
        cy.elements().removeClass('highlighted');
        cy.nodes().unselect();
        cy.edges().unselect();

        if (selectedNodeId) {
          const selectedNode = cy.getElementById(selectedNodeId);
          if (selectedNode.length > 0) {
            selectedNode.select();
            const connectedEdges = selectedNode.connectedEdges();
            const neighborNodes = connectedEdges.connectedNodes();

            connectedEdges.addClass('highlighted');
            neighborNodes.addClass('highlighted');
          }
        }
      });
    }, [selectedNodeId]);

    return (
      <Box
        ref={containerRef}
        sx={{
          width: '100%',
          height: '100%',
          bgcolor: '#fafafa',
          borderRadius: 2,
          position: 'relative',
          overflow: 'hidden',
          '&:focus': { outline: 'none' },
        }}
      />
    );
  }
);
