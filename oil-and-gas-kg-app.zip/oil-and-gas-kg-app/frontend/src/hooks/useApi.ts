/**
 * Minimal data-fetching hook: runs an async loader, tracks loading / error, and re-runs when the
 * dependency list changes or refresh() is called. Late responses of superseded calls are ignored.
 */

import { DependencyList, useCallback, useEffect, useRef, useState } from 'react';
import { errorMessage } from '../services/api';

interface UseApiReturn<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
  refresh: () => void;
}

export function useApi<T>(loader: () => Promise<T>, deps: DependencyList = [], enabled: boolean = true): UseApiReturn<T> {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState<boolean>(enabled);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);
  const callId = useRef(0);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const load = useCallback(loader, deps);

  useEffect(() => {
    if (!enabled) {
      setLoading(false);
      return;
    }
    const id = ++callId.current;
    setLoading(true);
    setError(null);
    load()
      .then((result) => {
        if (id === callId.current) setData(result);
      })
      .catch((err) => {
        if (id === callId.current) setError(errorMessage(err, 'Request failed'));
      })
      .finally(() => {
        if (id === callId.current) setLoading(false);
      });
  }, [load, tick, enabled]);

  const refresh = useCallback(() => setTick((t) => t + 1), []);
  return { data, loading, error, refresh };
}

export default useApi;
