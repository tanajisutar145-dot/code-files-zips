/**
 * Hook for managing live dashboard summary data
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { DashboardSummaryResponse } from '../types/dashboard';
import { ApiError } from '../types/api';
import { getDashboardSummary } from '../services/api';

interface UseDashboardReturn {
  data: DashboardSummaryResponse | null;
  loading: boolean;
  isRefreshing: boolean;
  error: ApiError | null;
  lastUpdated: Date | null;
  refresh: () => Promise<void>;
}

export const useDashboard = (autoRefreshInterval?: number): UseDashboardReturn => {
  const [data, setData] = useState<DashboardSummaryResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<ApiError | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  // In-flight request tracker to prevent overlapping requests
  const inFlightRef = useRef<boolean>(false);

  const fetchDashboard = useCallback(async (isManualRefresh: boolean = false) => {
    if (inFlightRef.current) {
      return;
    }

    inFlightRef.current = true;
    if (isManualRefresh) {
      setIsRefreshing(true);
    } else {
      setLoading(true);
    }
    setError(null);

    try {
      const summary = await getDashboardSummary();
      setData(summary);
      setLastUpdated(new Date());
      setError(null);
    } catch (err: any) {
      console.error('Failed to fetch dashboard summary:', err);
      const errorMessage =
        err?.response?.data?.detail ||
        err?.response?.data?.message ||
        (err?.request && !err?.response ? 'Unable to connect to the backend service' : null) ||
        err?.message ||
        'Failed to retrieve dashboard metrics';

      const apiError: ApiError = {
        message: errorMessage,
        status: err?.response?.status || 0,
        details: err?.response?.data || err,
      };
      setError(apiError);
    } finally {
      setLoading(false);
      setIsRefreshing(false);
      inFlightRef.current = false;
    }
  }, []);

  // Initial load
  useEffect(() => {
    fetchDashboard(false);
  }, [fetchDashboard]);

  // Optional periodic auto-refresh
  useEffect(() => {
    if (!autoRefreshInterval || autoRefreshInterval <= 0) return;

    const interval = setInterval(() => {
      fetchDashboard(true);
    }, autoRefreshInterval);

    return () => clearInterval(interval);
  }, [fetchDashboard, autoRefreshInterval]);

  const handleRefresh = useCallback(async () => {
    await fetchDashboard(true);
  }, [fetchDashboard]);

  return {
    data,
    loading,
    isRefreshing,
    error,
    lastUpdated,
    refresh: handleRefresh,
  };
};

export default useDashboard;
