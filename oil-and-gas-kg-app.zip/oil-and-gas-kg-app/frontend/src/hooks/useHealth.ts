/**
 * Hook for managing backend health status
 */

import { useState, useEffect, useCallback } from 'react';
import { HealthResponse, ServiceHealth, ServiceStatus, ApiError } from '../types/api';
import api, { errorMessage } from '../services/api';

interface UseHealthReturn {
  health: ServiceHealth | null;
  raw: HealthResponse | null;
  loading: boolean;
  error: ApiError | null;
  lastChecked: Date | null;
  refresh: () => Promise<void>;
}

const KNOWN: ServiceStatus[] = [
  'healthy',
  'configured',
  'connected',
  'loaded',
  'built',
  'empty',
  'missing',
  'disconnected',
  'not_configured',
  'unavailable',
  'offline',
];

export const mapServiceStatus = (status?: string): ServiceStatus => {
  const s = (status || '').toLowerCase() as ServiceStatus;
  return KNOWN.indexOf(s) >= 0 ? s : 'unknown';
};

const OFFLINE: ServiceHealth = {
  backend: 'offline',
  neo4j: 'unknown',
  graph: 'unknown',
  semantic_model: 'unknown',
  llm: 'unknown',
  embedder: 'unknown',
};

export const useHealth = (autoRefreshInterval?: number): UseHealthReturn => {
  const [health, setHealth] = useState<ServiceHealth | null>(null);
  const [raw, setRaw] = useState<HealthResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<ApiError | null>(null);
  const [lastChecked, setLastChecked] = useState<Date | null>(null);

  const checkHealth = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await api.get<HealthResponse>('/health');
      const data = response.data;
      const s = data.services || ({} as HealthResponse['services']);

      setRaw(data);
      setHealth({
        backend: mapServiceStatus(s.backend),
        neo4j: mapServiceStatus(s.neo4j),
        graph: mapServiceStatus(s.graph),
        semantic_model: mapServiceStatus(s.semantic_model),
        llm: mapServiceStatus(s.llm),
        embedder: mapServiceStatus(s.embedder),
      });
      setLastChecked(new Date());
    } catch (err: any) {
      console.error('Health check failed:', err);
      setError({
        message: errorMessage(err, 'Health check failed'),
        status: err?.response?.status || 0,
        details: err?.response?.data || err,
      });
      // Set all services as offline when health check fails
      setRaw(null);
      setHealth(OFFLINE);
    } finally {
      setLoading(false);
    }
  }, []);

  // Initial health check
  useEffect(() => {
    checkHealth();
  }, [checkHealth]);

  // Auto-refresh interval
  useEffect(() => {
    if (!autoRefreshInterval) return;

    const interval = setInterval(() => {
      checkHealth();
    }, autoRefreshInterval);

    return () => clearInterval(interval);
  }, [checkHealth, autoRefreshInterval]);

  return {
    health,
    raw,
    loading,
    error,
    lastChecked,
    refresh: checkHealth,
  };
};

export default useHealth;
