/**
 * Jest stand-in for react-markdown (ESM-only, not transformed by the CRA Jest setup): renders the
 * markdown source as plain text so component tests can assert on the answer text.
 */
import React from 'react';

const ReactMarkdown: React.FC<{ children?: React.ReactNode }> = ({ children }) => <>{children}</>;

export default ReactMarkdown;
