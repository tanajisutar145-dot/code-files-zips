/**
 * Centralized API client for backend integration
 */

import axios, { AxiosInstance } from 'axios';
import {
  HealthResponse,
  GraphRAGRequest,
  GraphRAGResponse,
  SimpleGraphRAGResponse,
  RetrievalRequest,
  RetrievalResult,
  IntelligenceInfo,
  JobState,
  JobSubmitResponse,
  VerificationItem,
} from '../types/api';
import { DashboardSummaryResponse } from '../types/dashboard';
import {
  GraphOverviewResponse,
  GraphExploreResponse,
  GraphNodeDetailResponse,
  GraphNeighborsResponse,
  GraphFilters,
} from '../types/graph';
import {
  DocumentOverviewResponse,
  DocumentListResponse,
  DocumentDetailResponse,
  DocumentUploadResult,
  DocumentFilters,
} from '../types/documents';
import {
  AssetOverviewResponse,
  AssetListResponse,
  AssetDetailResponse,
  AssetFilters,
} from '../types/assets';
import {
  AllocationVariance,
  BadActors,
  CypherResult,
  FormationWells,
  IdentityIssues,
  Lineage,
  NptSummary,
  OffsetBrief,
  OverdueResult,
  ProgramRow,
  PseStory,
  PtwIncidents,
  UseCase,
  Well360,
  WellsResult,
} from '../types/usecases';
import { ModelPayload, PipelineStatus, StandardsSummary } from '../types/model';
import { VisGraph } from '../types/api';

// Centralized Axios client. Empty baseURL uses the CRA dev proxy (package.json "proxy");
// REACT_APP_API_BASE_URL points a production build at the API.
const api: AxiosInstance = axios.create({
  baseURL: process.env.REACT_APP_API_BASE_URL || '',
  headers: {
    'Content-Type': 'application/json',
  },
});

const get = async <T>(url: string, params?: Record<string, any>): Promise<T> => {
  const response = await api.get<T>(url, { params });
  return response.data;
};

// Health endpoint - hits GET /health through CRA proxy
export const getHealth = async (): Promise<HealthResponse> => get<HealthResponse>('/health');

// Dashboard summary endpoint - hits GET /api/dashboard/summary
export const getDashboardSummary = async (): Promise<DashboardSummaryResponse> =>
  get<DashboardSummaryResponse>('/api/dashboard/summary');

// Knowledge Graph Explorer endpoints
export const getGraphOverview = async (): Promise<GraphOverviewResponse> => get<GraphOverviewResponse>('/api/graph/overview');

export const exploreGraph = async (filters?: GraphFilters): Promise<GraphExploreResponse> => {
  const params: Record<string, any> = {};
  if (filters?.node_label) params.node_label = filters.node_label;
  if (filters?.rel_type) params.rel_type = filters.rel_type;
  if (filters?.query) params.query = filters.query;
  if (filters?.limit) params.limit = filters.limit;
  return get<GraphExploreResponse>('/api/graph/explore', params);
};

export const getGraphNodeDetail = async (nodeId: string): Promise<GraphNodeDetailResponse> =>
  get<GraphNodeDetailResponse>(`/api/graph/node/${encodeURIComponent(nodeId)}`);

export const getGraphNodeNeighbors = async (
  nodeId: string,
  limit: number = 50,
  relType?: string
): Promise<GraphNeighborsResponse> => {
  const params: Record<string, any> = { limit };
  if (relType) params.rel_type = relType;
  return get<GraphNeighborsResponse>(`/api/graph/node/${encodeURIComponent(nodeId)}/neighbors`, params);
};

// GraphRAG endpoints
export const askGraphRAG = async (request: GraphRAGRequest): Promise<GraphRAGResponse> => {
  const response = await api.post<GraphRAGResponse>('/api/intelligence/ask', request);
  return response.data;
};

export const askGraphRAGSimple = async (request: GraphRAGRequest): Promise<SimpleGraphRAGResponse> => {
  const response = await api.post<SimpleGraphRAGResponse>('/api/intelligence/ask/simple', request);
  return response.data;
};

// Asynchronous GraphRAG jobs (live trace)
export const getIntelligenceInfo = async (): Promise<IntelligenceInfo> => get<IntelligenceInfo>('/api/intelligence/info');

export const submitQuestionJob = async (request: GraphRAGRequest): Promise<JobSubmitResponse> => {
  const response = await api.post<JobSubmitResponse>('/api/intelligence/jobs', request);
  return response.data;
};

export const getQuestionJob = async (jobId: string): Promise<JobState> =>
  get<JobState>(`/api/intelligence/jobs/${encodeURIComponent(jobId)}`);

export const getQuestionJobResponse = async (jobId: string): Promise<GraphRAGResponse> =>
  get<GraphRAGResponse>(`/api/intelligence/jobs/${encodeURIComponent(jobId)}/response`);

// Semantic retrieval endpoint
export const retrieveSemanticResults = async (request: RetrievalRequest): Promise<RetrievalResult> => {
  const response = await api.post<RetrievalResult>('/api/search/retrieve', request);
  return response.data;
};

// Document Management endpoints
export const getDocumentsOverview = async (): Promise<DocumentOverviewResponse> =>
  get<DocumentOverviewResponse>('/api/documents/overview');

export const listDocuments = async (params?: DocumentFilters & { skip?: number; limit?: number }): Promise<DocumentListResponse> => {
  const queryParams: Record<string, any> = {};
  if (params?.search) queryParams.search = params.search;
  if (params?.document_type) queryParams.document_type = params.document_type;
  if (params?.kind) queryParams.kind = params.kind;
  if (params?.skip !== undefined) queryParams.skip = params.skip;
  if (params?.limit !== undefined) queryParams.limit = params.limit;
  return get<DocumentListResponse>('/api/documents/', queryParams);
};

// Record-narrative document ids may contain '/', so the path-safe /detail route is used
export const getDocumentDetail = async (documentId: string): Promise<DocumentDetailResponse> =>
  get<DocumentDetailResponse>(`/api/documents/${encodeURIComponent(documentId)}/detail`);

export const uploadDocument = async (file: File): Promise<DocumentUploadResult> => {
  const formData = new FormData();
  formData.append('file', file);
  const response = await api.post<DocumentUploadResult>('/api/documents/upload', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  });
  return response.data;
};

export const deleteDocument = async (documentId: string): Promise<{ message: string; document_id: string }> => {
  const response = await api.delete<{ message: string; document_id: string }>(`/api/documents/${encodeURIComponent(documentId)}`);
  return response.data;
};

// Asset (equipment integrity) endpoints
export const getAssetsOverview = async (): Promise<AssetOverviewResponse> => get<AssetOverviewResponse>('/api/assets/overview');

export const listAssets = async (params?: AssetFilters & { skip?: number; limit?: number }): Promise<AssetListResponse> => {
  const queryParams: Record<string, any> = {};
  if (params?.search) queryParams.search = params.search;
  if (params?.equipment_type) queryParams.equipment_type = params.equipment_type;
  if (params?.criticality) queryParams.criticality = params.criticality;
  if (params?.facility_code) queryParams.facility_code = params.facility_code;
  if (params?.safety_critical !== undefined) queryParams.safety_critical = params.safety_critical;
  if (params?.skip !== undefined) queryParams.skip = params.skip;
  if (params?.limit !== undefined) queryParams.limit = params.limit;
  return get<AssetListResponse>('/api/assets/', queryParams);
};

export const getAssetDetail = async (assetKey: string): Promise<AssetDetailResponse> =>
  get<AssetDetailResponse>(`/api/assets/${encodeURIComponent(assetKey)}`);

// Use-case endpoints (deterministic Cypher, no LLM)
export const useCaseApi = {
  list: () => get<UseCase[]>('/api/usecases/'),
  // UC1 Well & subsurface 360
  wells: () => get<WellsResult>('/api/usecases/uc1/wells'),
  well360: (api10: string) => get<Well360>(`/api/usecases/uc1/wells/${encodeURIComponent(api10)}`),
  identityIssues: () => get<IdentityIssues>('/api/usecases/uc1/identity-issues'),
  formationWells: (formation: string) => get<FormationWells>('/api/usecases/uc1/formation-wells', { formation }),
  // UC2 Drilling
  npt: () => get<NptSummary>('/api/usecases/uc2/npt'),
  programs: () => get<ProgramRow[]>('/api/usecases/uc2/programs'),
  offsetBrief: (program: string) => get<OffsetBrief>('/api/usecases/uc2/offset-brief', { program }),
  wellControlChains: () => get<CypherResult>('/api/usecases/uc2/well-control-chains'),
  // UC3 Asset integrity
  precursors: () => get<CypherResult>('/api/usecases/uc3/precursors'),
  badActors: () => get<BadActors>('/api/usecases/uc3/bad-actors'),
  overdue: () => get<OverdueResult>('/api/usecases/uc3/overdue'),
  hierarchy: (facilityCode?: string) =>
    get<CypherResult>('/api/usecases/uc3/hierarchy', facilityCode ? { facility_code: facilityCode } : undefined),
  // UC4 HSE
  pseList: () => get<CypherResult>('/api/usecases/uc4/pse'),
  pseStory: (pse: string) => get<PseStory>(`/api/usecases/uc4/pse/${encodeURIComponent(pse)}`),
  rootCauses: () => get<CypherResult>('/api/usecases/uc4/root-causes'),
  ptwIncidents: () => get<PtwIncidents>('/api/usecases/uc4/ptw-incidents'),
  // UC5 Traceability
  custodyTransfers: () => get<CypherResult>('/api/usecases/uc5/custody-transfers'),
  lineage: (ref: string) => get<Lineage>(`/api/usecases/uc5/custody-transfers/${encodeURIComponent(ref)}/lineage`),
  emissions: () => get<CypherResult>('/api/usecases/uc5/emissions'),
  allocationVariance: (threshold: number = 150) => get<AllocationVariance>('/api/usecases/uc5/allocation-variance', { threshold }),
};

// Model & Standards endpoints (semantic model is available before the graph is loaded)
export const modelApi = {
  model: () => get<ModelPayload>('/api/model/'),
  standards: () => get<StandardsSummary>('/api/model/standards'),
  classSample: (label: string, limit: number = 12) => get<VisGraph>(`/api/model/class/${encodeURIComponent(label)}`, { limit }),
  pipeline: () => get<PipelineStatus>('/api/model/pipeline'),
};

// Human verification queue
export const verificationApi = {
  items: () => get<VerificationItem[]>('/api/verification/items'),
  stats: () => get<Record<string, any>>('/api/verification/stats'),
  flag: async (payload: { question: string; answer: string; confidence?: number; reason?: string; job_id?: string | null; retriever?: string }) =>
    (await api.post<VerificationItem>('/api/verification/flag', payload)).data,
  review: async (itemId: string, decision: 'approved' | 'rejected', comment?: string) =>
    (await api.post<VerificationItem>(`/api/verification/review/${encodeURIComponent(itemId)}`, { decision, comment })).data,
};

// Human-readable message for an axios / network error
export const errorMessage = (err: any, fallback: string = 'Request failed'): string =>
  err?.response?.data?.detail ||
  err?.response?.data?.message ||
  (err?.request && !err?.response ? 'Unable to connect to the backend service' : null) ||
  err?.message ||
  fallback;

// Check if backend is reachable
export const isBackendReachable = async (): Promise<boolean> => {
  try {
    await getHealth();
    return true;
  } catch {
    return false;
  }
};

// Backward-compatible apiClient object
export const apiClient = {
  get: <T>(url: string) => api.get<T>(url).then((r) => r.data),
  post: <T>(url: string, data?: any) => api.post<T>(url, data).then((r) => r.data),
  getHealth,
  getDashboardSummary,
  getGraphOverview,
  exploreGraph,
  getGraphNodeDetail,
  getGraphNodeNeighbors,
  askGraphRAG,
  askGraphRAGSimple,
  getIntelligenceInfo,
  submitQuestionJob,
  getQuestionJob,
  getQuestionJobResponse,
  retrieveSemanticResults,
  getDocumentsOverview,
  listDocuments,
  getDocumentDetail,
  uploadDocument,
  deleteDocument,
  getAssetsOverview,
  listAssets,
  getAssetDetail,
  isBackendReachable,
};

export { api };
export default api;
