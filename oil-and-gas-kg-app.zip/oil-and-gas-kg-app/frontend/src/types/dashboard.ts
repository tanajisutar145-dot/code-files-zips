/**
 * TypeScript interfaces for Dashboard API (backend/app/models/dashboard.py)
 */

export interface KpiGroup {
  title: string;
  values: Record<string, any>;
}

export interface DashboardKPIs {
  wells?: KpiGroup;
  production?: KpiGroup;
  drilling?: KpiGroup;
  integrity?: KpiGroup;
  hse?: KpiGroup;
  emissions?: KpiGroup;
  [key: string]: KpiGroup | undefined;
}

export interface DashboardGraphStats {
  total_nodes: number;
  total_relationships: number;
  data_nodes: number;
  semantic_nodes: number;
  document_nodes: number;
  identity_nodes: number;
  nodes_by_domain: Record<string, number>;
  aligned_classes: number;
  standard_classes: number;
}

export interface DashboardDocumentStats {
  total_documents: number;
  uploaded_documents: number;
  total_chunks: number;
  embedded_chunks: number;
  embedding_model: string;
  embedding_dimension?: number | null;
  vector_index_name: string;
  vector_index_status: string;
  vector_index_population: number;
}

export interface UseCaseSummary {
  id: string;
  title: string;
  owner: string;
  summary: string;
  standards: string[];
  questions: string[];
  kpis: Record<string, any>;
}

export interface DashboardHighlight {
  use_case: string;
  text: string;
}

export interface DashboardTrends {
  production_by_month?: { month: string; gross_oil_bbl: number; gross_gas_mcf: number }[];
  npt_by_category?: { category: string; hours: number; events: number }[];
  co2e_by_quarter?: { quarter_end: string; co2e_t: number }[];
  pse_by_tier?: { tier: string; events: number }[];
  failures_by_class?: { equipment_class: string; failures: number }[];
  [key: string]: Record<string, any>[] | undefined;
}

export interface DashboardSummaryResponse {
  generated_at: string;
  status: string;
  project: Record<string, any>;
  as_of: string;
  kpis: DashboardKPIs;
  graph: DashboardGraphStats;
  documents: DashboardDocumentStats;
  use_cases: UseCaseSummary[];
  trends: DashboardTrends;
  highlights: DashboardHighlight[];
}
