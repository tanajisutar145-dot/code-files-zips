/**
 * TypeScript types for the use-case API (backend/app/services/usecase_service.py).
 * Every analysis returns its rows together with the Cypher that produced them.
 */

import { VisGraph } from './api';
import { UseCaseSummary } from './dashboard';

export type Row = Record<string, any>;

export interface CypherResult<T extends Row = Row> {
  rows: T[];
  count: number;
  cypher: string;
  graph?: VisGraph;
  [key: string]: any;
}

export type UseCase = UseCaseSummary;

// ---- UC1 Well & subsurface 360 ------------------------------------------------------
export interface WellRow extends Row {
  api10: string;
  api: string;
  well_name: string;
  wellbores: number;
  in_exploration: boolean;
  in_drilling: boolean;
  in_production: boolean;
  in_asset: boolean;
  asset_status?: string | null;
  current_bopd?: number | null;
  field?: string | null;
  target_formation?: string | null;
}

export interface WellsResult extends CypherResult<WellRow> {
  registers: Record<string, number>;
  complete_identities: number;
}

export interface Well360 {
  api10: string;
  found: boolean;
  records: Row[];
  wellbores: Row[];
  tests: Row[];
  reserves: Row[];
  drilling_events: Row[];
  production: Row[];
  hse: Row[];
  graph: VisGraph;
  cypher: Record<string, string>;
}

export interface IdentityIssues {
  api_conflicts: CypherResult;
  production_without_asset: CypherResult;
  name_aliases: CypherResult;
  single_register: CypherResult;
}

export interface FormationWells extends CypherResult {
  formation: string;
  formations: string[];
}

// ---- UC2 Drilling -------------------------------------------------------------------
export interface NptSummary {
  by_category: CypherResult;
  by_rig: CypherResult;
}

export interface ProgramRow extends Row {
  program: string;
  name: string;
  status: string;
  formation?: string | null;
  well?: string | null;
}

export interface OffsetBrief extends CypherResult {
  program: Row | null;
  lessons: Row[];
}

// ---- UC3 Integrity ------------------------------------------------------------------
export interface BadActors extends CypherResult {
  recurrence_chains: { tag: string; failure_chain: string[] }[];
}

export interface OverdueResult {
  as_of: string;
  overdue: CypherResult;
  not_fit_for_service: CypherResult;
}

// ---- UC4 HSE ------------------------------------------------------------------------
export interface PseStory {
  event: Row | null;
  incidents: Row[];
  investigations: Row[];
  corrective_actions: Row[];
  related_records: Row[];
  graph: VisGraph;
}

export interface PtwIncidents extends CypherResult {
  totals: { incidents?: number; under_ptw?: number };
}

// ---- UC5 Traceability ---------------------------------------------------------------
export interface Lineage extends CypherResult {
  transfer: Row | null;
  reconciliation: { allocated_gross_oil_bbl: number; ticket_gov: number; difference_pct: number | null } | null;
}

export interface AllocationVariance extends CypherResult {
  threshold: number;
  as_of: string;
}
