/**
 * TypeScript interfaces for backend API integration
 * Based on the backend Pydantic models (backend/app/intelligence/models.py, backend/app/api/routes.py)
 */

// Health endpoint response
export interface HealthResponse {
  status: string;
  application: string;
  environment: string;
  services: {
    backend: string;
    neo4j: string;
    graph: string;
    semantic_model: string;
    llm: string;
    embedder: string;
  };
  models?: {
    llm: string;
    embedder: string;
    embedding_dimensions?: string | number | null;
  };
  database?: string;
}

// Confidence levels from backend
export type ConfidenceLevel = 'high' | 'medium' | 'low' | 'very_low';

// Verification result from backend
export interface VerificationResult {
  verified: boolean;
  grounding_score: number;
  supported_claims: string[];
  unsupported_claims: string[];
  warnings: string[];
  evidence_gaps: string[];
}

// Retriever modes understood by /api/intelligence/jobs and /ask
export type RetrieverMode = 'auto' | 'compare' | 'text2cypher' | 'vector_cypher' | 'hybrid_cypher';

export interface ChatTurn {
  role: 'user' | 'assistant';
  content: string;
}

// GraphRAG request
export interface GraphRAGRequest {
  question: string;
  mode?: RetrieverMode;
  history?: ChatTurn[];
  top_k?: number;
  graph_depth?: number;
  min_similarity?: number;
  include_verification?: boolean;
}

// Evidence graph (vis-network JSON from backend/app/kg/qa/graphjson.py)
export interface VisNode {
  id: string;
  label: string;
  group: string;
  domain?: string;
  color?: string;
  title?: string;
  evidence?: boolean;
  props: Record<string, any>;
  std?: {
    std_class?: string | null;
    std_match?: string | null;
    std_package?: string | null;
    std_standard?: string | null;
  };
  std_labels?: string[];
  lat?: number | null;
  lon?: number | null;
}

export interface VisEdge {
  id: string;
  from: string;
  to: string;
  label: string;
  std?: string | null;
}

export interface VisGraph {
  nodes: VisNode[];
  edges: VisEdge[];
}

// One retriever run (compare mode returns all three)
export interface RetrieverRun {
  retriever: string;
  label: string;
  answer: string;
  error?: string | null;
  cypher?: string;
  retrieval_query?: string;
  context: string[];
  paths: string[];
  retrieval_s: number;
  generation_s: number;
  total_s: number;
  score?: number | null;
  matched: string[];
  missing: string[];
}

// One backend step of the answer trace
export interface TraceStep {
  key: string;
  title: string;
  status: 'pending' | 'running' | 'done' | 'error' | 'skipped';
  seconds?: number | null;
  summary: string;
  detail: Record<string, any>;
}

// Ground truth check for curated demo questions
export interface GroundTruthCheck {
  checks?: string[];
  ground_truth_cypher?: string;
  ground_truth?: Record<string, any>[];
  expected_answer?: string;
  score?: number;
  matched?: string[];
  missing?: string[];
}

// GraphRAG response
export interface GraphRAGResponse {
  question: string;
  answer: string;
  confidence: ConfidenceLevel;
  verification: VerificationResult;
  evidence: {
    semantic_results: SemanticSearchResult[];
    graph_evidence: GraphEvidence;
    evidence_graph?: VisGraph;
  };
  sources: {
    documents: string[];
    entities: string[];
  };
  metadata: {
    execution_time: number;
    retrieval_method?: string;
    llm_model?: string | null;
    verification_enabled?: boolean;
    question_id?: string | null;
    ground_truth?: GroundTruthCheck | null;
    cypher?: string | null;
    retrieval_query?: string | null;
    verify_summary?: string | null;
    status?: string;
    [key: string]: any;
  };
  retriever?: string;
  runs?: RetrieverRun[];
  trace?: TraceStep[];
  job_id?: string | null;
}

// Live job state (GET /api/intelligence/jobs/{id})
export interface JobState {
  id: string;
  question: string;
  mode: string;
  status: 'queued' | 'running' | 'done' | 'error';
  steps: TraceStep[];
  answer: string;
  retriever: string;
  runs: RetrieverRun[];
  graph: VisGraph;
  verification?: GroundTruthCheck | null;
  error?: string | null;
  started: number;
  finished?: number | null;
  elapsed: number;
}

export interface JobSubmitResponse {
  job_id?: string;
  reply?: string;
}

export interface QuestionBrief {
  id: string;
  kind: 'demo' | 'sample';
  title: string;
  question: string;
  retriever: string;
  pattern: string;
  use_case: string;
}

// GET /api/intelligence/info
export interface IntelligenceInfo {
  project: Record<string, any>;
  standard: Record<string, any>;
  llm: string;
  embedder: string;
  database: string;
  labels: { label: string; count: number; color: string }[];
  domains: { domain: string; color: string }[];
  relationships: number;
  has_chunks: boolean;
  demo_questions: QuestionBrief[];
  sample_questions: QuestionBrief[];
  retrievers: { id: RetrieverMode; label: string }[];
}

// In-memory conversation message pair
export interface ChatMessage {
  id: string;
  timestamp: string;
  question: string;
  mode?: RetrieverMode;
  job?: JobState;
  response?: GraphRAGResponse;
  reply?: string;
  error?: string;
  isLoading?: boolean;
}

// Simple GraphRAG response
export interface SimpleGraphRAGResponse {
  question: string;
  answer: string;
  confidence: ConfidenceLevel;
  verified: boolean;
  retriever?: string;
  execution_time: number;
}

// Semantic retrieval request
export interface RetrievalRequest {
  query: string;
  top_k?: number;
  graph_depth?: number;
  min_similarity?: number;
  include_metadata?: boolean;
}

// Semantic search result
export interface SemanticSearchResult {
  chunk_id: string;
  document_id: string;
  document_title: string;
  text: string;
  score: number;
  source?: string;
  metadata: Record<string, any>;
}

// Graph evidence entities
export interface GraphEntity {
  entity_id: string;
  entity_type: string;
  properties: Record<string, any>;
}

// Graph evidence relationships
export interface GraphRelationship {
  source_id: string;
  target_id: string;
  relationship_type: string;
  source_type: string;
  target_type: string;
  properties: Record<string, any>;
}

// Graph evidence
export interface GraphEvidence {
  entities: GraphEntity[];
  relationships: GraphRelationship[];
}

// Retrieval result
export interface RetrievalResult {
  query: string;
  semantic_results: SemanticSearchResult[];
  graph_evidence: GraphEvidence;
  metadata: {
    execution_time: number;
    retrieval_method?: string;
    top_k?: number;
    graph_depth?: number;
    min_similarity?: number;
    semantic_results_count?: number;
    graph_entities_count?: number;
    graph_relationships_count?: number;
    error?: string;
    [key: string]: any;
  };
}

// Human review queue (GET /api/verification/items)
export interface VerificationItem {
  id: string;
  content: string;
  type: string;
  status: 'pending' | 'approved' | 'rejected';
  confidence: number;
  created_at: string;
  question?: string | null;
  reason?: string | null;
  job_id?: string | null;
  retriever?: string | null;
  reviewed_at?: string | null;
  reviewer?: string | null;
  comment?: string | null;
}

// API Error types
export interface ApiError {
  message: string;
  status?: number;
  details?: any;
}

// Status types for components
export type ServiceStatus =
  | 'connected'
  | 'configured'
  | 'healthy'
  | 'loaded'
  | 'built'
  | 'empty'
  | 'missing'
  | 'offline'
  | 'unavailable'
  | 'disconnected'
  | 'not_configured'
  | 'loading'
  | 'unknown';

export interface ServiceHealth {
  backend: ServiceStatus;
  neo4j: ServiceStatus;
  graph: ServiceStatus;
  semantic_model: ServiceStatus;
  llm: ServiceStatus;
  embedder: ServiceStatus;
}
