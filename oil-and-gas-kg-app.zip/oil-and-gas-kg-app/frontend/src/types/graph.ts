/**
 * TypeScript definitions for Knowledge Graph Explorer
 */

export interface GraphNode {
  id: string;
  label: string;
  labels: string[];
  name: string;
  entity_id: string;
  properties: Record<string, any>;
}

export interface GraphRelationship {
  id: string;
  source: string;
  target: string;
  type: string;
  properties: Record<string, any>;
}

export interface GraphOverviewResponse {
  total_nodes: number;
  total_relationships: number;
  node_counts_by_label: Record<string, number>;
  relationship_counts_by_type: Record<string, number>;
  available_labels: string[];
  available_relationship_types: string[];
}

export interface GraphExploreResponse {
  nodes: GraphNode[];
  relationships: GraphRelationship[];
  total_nodes: number;
  total_relationships: number;
  is_truncated: boolean;
  filters_applied: Record<string, any>;
}

export interface GraphNodeDetailResponse {
  node: GraphNode;
  connected_count: number;
  connected_by_type: Record<string, number>;
  neighbors_preview: GraphNode[];
  document_links: Array<{
    document_id: string;
    title: string;
    chunk_id: string;
    snippet: string;
  }>;
}

export interface GraphNeighborsResponse {
  center_node: GraphNode;
  neighbor_nodes: GraphNode[];
  relationships: GraphRelationship[];
  total_neighbors: number;
}

export interface GraphFilters {
  node_label?: string;
  rel_type?: string;
  query?: string;
  limit?: number;
}
