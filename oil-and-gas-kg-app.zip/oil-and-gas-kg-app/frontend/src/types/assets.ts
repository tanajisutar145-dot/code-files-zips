/**
 * TypeScript types for the Assets (equipment integrity) API (backend/app/models/assets.py)
 */

import { VisGraph } from './api';

export interface AssetOverviewResponse {
  total_equipment: number;
  safety_critical: number;
  overdue_inspections: number;
  failures: number;
  open_work_orders: number;
  criticality_counts: Record<string, number>;
  class_counts: Record<string, number>;
  facility_counts: Record<string, number>;
  as_of: string;
}

export interface AssetSummaryItem {
  equipment_id: number;
  tag: string;
  name: string;
  equipment_type?: string | null;
  facility?: string | null;
  facility_code?: string | null;
  criticality?: string | null;
  safety_critical: boolean;
  maintenance_strategy?: string | null;
  next_inspection_due_date?: string | null;
  inspection_overdue: boolean;
  failure_count: number;
  inspection_count: number;
  work_order_count: number;
  last_failure_date?: string | null;
  mtbf_hours?: number | null;
  std_class?: string | null;
}

export interface AssetListResponse {
  assets: AssetSummaryItem[];
  total: number;
  skip: number;
  limit: number;
  filters_applied: Record<string, any>;
}

export type AssetRecord = Record<string, any>;

export interface AssetDetailResponse {
  asset: AssetRecord;
  facility?: AssetRecord | null;
  parent?: AssetRecord | null;
  children: AssetRecord[];
  functional_location: AssetRecord[];
  maintenance_plans: AssetRecord[];
  integrity_programs: AssetRecord[];
  inspections: AssetRecord[];
  failures: AssetRecord[];
  work_orders: AssetRecord[];
  downtime: AssetRecord[];
  hse_events: AssetRecord[];
  drilling_npt: AssetRecord[];
  graph: VisGraph;
}

export interface AssetFilters {
  search?: string;
  equipment_type?: string;
  criticality?: string;
  facility_code?: string;
  safety_critical?: boolean;
}
