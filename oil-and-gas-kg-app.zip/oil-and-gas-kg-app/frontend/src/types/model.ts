/**
 * TypeScript types for the Model & Standards API (backend/app/services/model_service.py, backend/app/kg/qa/payload.py)
 */

export interface StandardInfo {
  name: string;
  short: string;
  namespace: string;
  root_class: string;
}

export interface ModelColumn {
  column: string;
  sql_type?: string;
  nullable?: boolean;
  label?: string;
  description?: string;
  business_term?: string | null;
  standard_attribute?: string | null;
  standard_match?: string | null;
  datatype?: string | null;
  unit?: string | null;
  enum_values?: string[];
  sensitivity?: string[];
  resolution?: string;
  [key: string]: any;
}

export interface ModelTable {
  table: string;
  schema: string;
  label: string;
  class_iri: string;
  description: string;
  primary_key: string;
  standard_class?: string | null;
  standard_match?: string | null;
  standard_package?: string | null;
  standard_standard?: string | null;
  standard_ancestors: string[];
  subject_areas: string[];
  data_classification?: string | null;
  location_role?: string | null;
  columns?: ModelColumn[];
  [key: string]: any;
}

export interface ModelRelationship {
  from: string;
  to: string;
  type: string;
  fk: string;
  standard_association?: string | null;
  cross_domain: boolean;
  resolution: string;
}

export interface StandardClassInfo {
  iri: string;
  label: string;
  comment: string;
  package: string;
  standard: string;
  parents: string[];
}

export interface ModelPayload {
  project: Record<string, any>;
  standard: StandardInfo;
  namespace: string;
  sources: Record<string, any>;
  domains: { domain: string; color: string; comment?: string }[];
  colors: Record<string, string>;
  tables: ModelTable[];
  relationships: ModelRelationship[];
  extra_relationships: { type: string; kind: string; std?: string | null }[];
  standard_classes: Record<string, StandardClassInfo>;
  [key: string]: any;
}

export interface StandardsSummary {
  standard: StandardInfo;
  classes: {
    standard_class: string;
    package?: string | null;
    standard?: string | null;
    parents: string[];
    classes: { label: string; table: string; match?: string | null }[];
  }[];
  attributes: { class: string; column: string; standard_attribute: string; match?: string | null; unit?: string | null }[];
  use_cases: Record<string, { iri: string; label: string; definition?: string; scope_note?: string; broader?: string[] }>;
}

export interface PipelineStatus {
  config: string;
  model_step: {
    semantic_model: boolean;
    graph_schema: boolean;
    ontology_subset: boolean;
    classes: number;
    relationships: number;
    aligned_classes: number;
  };
  validation: { passed?: boolean; rows?: number; foreign_keys?: number; issues?: Record<string, any> } | null;
  load_step: Record<string, any> | null;
  report: boolean;
  neo4j: { configured: boolean; connected: boolean; database: string };
  commands: Record<string, string>;
}
