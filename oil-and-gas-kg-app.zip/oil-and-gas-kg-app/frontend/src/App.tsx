import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';

import Layout from './components/layout/Layout';
import Dashboard from './pages/dashboard/Dashboard';
import UseCasesPage from './pages/usecases/UseCasesPage';
import GraphView from './pages/graph/GraphView';
import SearchPage from './pages/search/SearchPage';
import IntelligencePage from './pages/intelligence/IntelligencePage';
import DocumentsPage from './pages/documents/DocumentsPage';
import AssetsPage from './pages/assets/AssetsPage';
import ModelPage from './pages/model/ModelPage';
import VerificationPage from './pages/verification/VerificationPage';
import HealthPage from './pages/health/HealthPage';
import SettingsPage from './pages/settings/SettingsPage';

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#0f766e',
    },
    secondary: {
      main: '#c2410c',
    },
    background: {
      default: '#f5f5f5',
    },
  },
  typography: {
    h4: {
      fontWeight: 600,
    },
    h6: {
      fontWeight: 500,
    },
  },
  components: {
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
        },
      },
    },
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/usecases" element={<UseCasesPage />} />
            <Route path="/usecases/:ucId" element={<UseCasesPage />} />
            <Route path="/graph" element={<GraphView />} />
            <Route path="/search" element={<SearchPage />} />
            <Route path="/intelligence" element={<IntelligencePage />} />
            <Route path="/documents" element={<DocumentsPage />} />
            <Route path="/assets" element={<AssetsPage />} />
            <Route path="/model" element={<ModelPage />} />
            <Route path="/verification" element={<VerificationPage />} />
            <Route path="/health" element={<HealthPage />} />
            <Route path="/settings" element={<SettingsPage />} />
          </Routes>
        </Layout>
      </Router>
    </ThemeProvider>
  );
}

export default App;
