// jest-dom / test environment setup for CRA

jest.mock('react-markdown', () => {
  return function DummyMarkdown(props: any) {
    const React = require('react');
    return React.createElement('div', { 'data-testid': 'markdown-content' }, props.children);
  };
});
