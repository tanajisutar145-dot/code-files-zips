# input_data — synthetic oil_gas dataset (one-time, read only)

**All records in this folder are synthetic.** They describe a fictional operator, *OGX Energy*, with
ten fields in the Permian Basin (Delaware and Midland sub-basins, Texas and New Mexico). Basin,
formation and regulator names are real public names; every well, facility, event, volume, person
and number is invented. Nothing here is proprietary company data.

| | |
|---|---|
| Data model | *oil_gas* v1 **MVM** (Databricks Industry Data Models) — `../data_model/ddl` |
| Scope | 56 tables in 10 subject areas (the 5 use cases in `../docs/01_OilGas_KG_Research_and_Use_Cases.md`) |
| Rows | 1,875 (about 50 per transactional/master table; reference tables are smaller — see below) |
| Format | `<schema>/<table>.csv`, UTF-8, header row = DDL column names in DDL order |
| As-of date | 2026-09-30; history from 2024-01 |
| Generator | one-time, deterministic (seed 20261030); **not part of the application**: the app only reads these files. The scripts are kept beside the app in `../../_synthetic_data_generator/` and reproduce this folder byte for byte |
| Manifest | `manifest.json`: rows, columns, populated columns and a SHA-256 prefix per file |

## How the data was generated

1. The generator parsed the MVM DDL (tables, columns, types, primary keys, the 2,664 foreign keys
   and the `Valid values are ...` enumerations in the column comments) and kept the 56 in-scope
   tables, ordered so parents are written before children (no FK cycles in this scope).
2. A small reference world was defined once: 10 fields with real county/state codes, 18 Permian
   formations with their typical depths and drilling hazards, 6 basins, 10 plays, 15 reservoirs,
   58 physical wells, 20 facilities, 50 tagged equipment items, 12 rigs, 25 pipeline segments,
   15 delivery points, 10 crude grades and 10 regulators.
3. Each table has a builder that sets the business-relevant columns and every in-scope foreign
   key from that world (so the links are meaningful, not random). Remaining columns are typed
   from the DDL and filled with oilfield-realistic ranges inferred from the column name
   (`_ft`, `_psi`, `_bbl`, `_mcf`, `_ppg`, `_usd`, `_pct`...); enumerated columns use only the
   values the DDL allows. Columns no rule understands are left empty rather than filled with noise.
4. **Foreign keys to tables outside the scope** (finance, venture, land, procurement...) are
   always empty. They are reported as "dangling" by the app's model step, not loaded.
5. The output was validated before writing: unique primary keys, no NULL in NOT NULL columns,
   **zero FK orphans** across the 297 in-scope foreign keys, all enumerations respected.

## Domain standards and conventions

| Topic | Convention used |
|---|---|
| Well identity | API / US Well Number (PPDM): `SS-CCC-UUUUU` core (state 42 = Texas, 30 = New Mexico; real county codes, e.g. Reeves 389, Loving 301, Eddy 015) + 2-digit wellbore (sidetrack) + 2-digit event code. Each register uses a different, realistic format: `drilling_well.api_well_number` = `42-389-40000-00-00`, `exploration_well.api_number` = `42-389-40000`, `production_well.api_number` = `4238940000` and `uwi` = `42389400000000`, `well_asset.api_number` = `42389400000000`. Sidetracks carry wellbore code `01` and a `parent_wellbore_drilling_well_id` |
| Well vs wellbore | One physical well can have several wellbores (`... ST01`); all four registers resolve to the same API-10 |
| Units | Oilfield units as encoded in the column names: ft (MD/TVD), psi, bbl, Mcf/MMcf, BOPD, ppg, °F, USD; decimals follow `DECIMAL(18,2)` |
| Coordinates | WGS84 decimal degrees (two decimals, as the DDL scale allows) |
| Dates | ISO 8601 (`YYYY-MM-DD`, `YYYY-MM-DD HH:MM:SS`, local time) |
| Reserves | SPE-PRMS / SEC categories (1P/2P/3P, PDP/PDNP/PUD) |
| Process safety | API RP 754 / IOGP 456 tiers (Tier 1–4), LOPC flag |
| Equipment | ISO 14224 equipment classes (compressor, vessel, valve, pump, ESP, BOP...), CFIHOS-style tags `<facility>-<class>-<number>` |
| Equipment hierarchy | `asset/hierarchy.csv` holds ISO 14224 taxonomy levels 3 (installation), 5 (system) and 6 (equipment unit) with a `path`; the app links it to equipment and facilities by code |
| Inspections | API 510/570/653, API RP 576 (PSVs), API RP 580/581 (RBI) references |
| NPT codes | IADC-style category mnemonics (`WC`, `LC`, `SP`, `WBI`, `EQ-TD`, `EQ-MP`, `CMT`, `WOW`) — illustrative, not official IADC numeric codes |
| Emissions | EPA 40 CFR 98 Subpart W factors and source categories, GWP CH₄ = 28, OGI LDAR surveys |
| Measurement | API MPMS proving / custody-transfer conventions (GOV, GSV, NSV, BS&W) |

## Planted stories (ground truth for the demo questions)

The data contains deliberate, verifiable stories. The app's demo questions
(`backend/user_questions/questions.yaml`) are answered from them and checked with deterministic
Cypher.

| UC | Story | Where |
|---|---|---|
| UC1 | **Falcon Draw 10-1H** exists in all four well registers under four API formats (and an upper-case alias in the asset register); best test 2,480 BOPD from Wolfcamp A; 1P/PDP reserves | `drilling_well`, `exploration_well`, `production_well`, `well_asset`, `well_test`, `reserves_estimate` |
| UC1 | Three production records carry a **mistyped API** (`Falcon Draw 11-1H`, `Red Mesa 13-1H`, `Mesquite Bend 18-2H`) and three **acquired legacy wells** have no drilling or asset record | `production_well` |
| UC2 | **Kick chain**: Wolfcamp B kick on *Red Mesa 12-2H* (WCE-2024-0001, 18 bbl gain at 11,420 ft) → incident INC-2024-0001 → violation NOV-RRC-2024-0001 (late notification, USD 18,500) → NPT-2024-0001 (31.5 h, USD 412,000) → flaring FLR-2024-0001 (2,850 Mcf) → Tier 2 PSE → SIMOPS shut-in of the offset producer | `well_control_event`, `incident`, `violation`, `npt_event`, `flare_record`, `process_safety_event`, `downtime_event` |
| UC2 | Formation hazards: Wolfcamp B kicks, Bell/Cherry Canyon losses, Salado stuck pipe (sidetrack of *Falcon Draw 10-3H*), poor cement across Bell Canyon with remedial squeezes; an **approved program WP-2026-022 for Red Mesa 13-4H** into Wolfcamp B (offset-well brief) | `npt_event`, `cementing_job`, `well_program`, `formation.drilling_hazard_notes` |
| UC3 | **Inspection → failure** precursors: compressor FD1-K-201 (38 % wall loss → leak), ESP RM-ESP-09 (motor temperature trend → burnout), level valve CF2-LCV-110 (sticky actuator → failed open), gathering line FD-07 (external pitting → pinhole leak) | `inspection_event`, `failure_report`, `work_order`, `downtime_event` |
| UC3 | **Bad actors**: RM-ESP-09 (3 failures), R104 top drive (3 failures + 5 NPT events), FD1-K-201 (2 failures); safety-critical equipment with overdue inspections and two not-fit-for-service results | `failure_report.previous_failure_report_id`, `equipment`, `inspection_event` |
| UC4 | **Tier 1 LOPC** at Coyote Flats CTB-2 (PSE-2026-001): 52 bbl released while the high-level trip was bypassed under PTW-2026-0001; investigation INV-2026-0001, CAPAs CA-2026-0001..0003 (one follow-up on a partially effective action), spill SPL-2026-0001, violation NOV-OCD-2026-0002 (USD 48,500) | `process_safety_event`, `incident`, `incident_investigation`, `hse_corrective_action`, `spill_event`, `violation`, `permit_to_work` |
| UC4 | **Recurring root cause**: inadequate energy isolation in four investigations at four facilities, with ineffective CAPAs; 15 incidents occurred under an active permit to work | `incident_investigation`, `hse_corrective_action`, `incident.permit_to_work_id` |
| UC5 | **Custody transfer CT-2026-0815** (Falcon Draw LACT, August 2026) receives the allocations of eight wells through meters FD-LACT-01 and FD-LACT-02; the ticket equals the allocated gross oil + 0.4 % BS&W | `custody_transfer`, `production_allocation`, `meter_station`, `measurement_point`, `delivery_point` |
| UC5 | Coyote Flats CTB-2 has the highest CO₂e, heavy flaring and the most LDAR leaks; its meter **CF-LACT-02** is past its calibration due date and carries allocation variances of 200–420 bbl | `ghg_emission`, `flare_record`, `ldar_survey`, `meter_station`, `production_allocation` |

## Files

Reference tables are intentionally smaller than 50 rows where a larger count would be unrealistic
for one operator (6 basins, 10 regulators, 10 crude grades, 10 fields, 12 rigs...).

| File | Rows | Columns (populated) | Links to (in-scope FKs) | Description (from the DDL table comment) |
|---|---|---|---|---|
| `exploration/basin.csv` | 6 | 43 (42) | regulatory_authority | Master record for sedimentary basins under evaluation |
| `exploration/play.csv` | 10 | 41 (41) | basin, formation | Master record for petroleum plays within a basin |
| `exploration/prospect.csv` | 20 | 48 (39) | asset_facility, basin, block, formation, play | Master record for individual drillable prospects identified within a play |
| `exploration/block.csv` | 15 | 42 (33) | basin, regulatory_authority | Master record for exploration license blocks and concession areas |
| `exploration/formation.csv` | 18 | 33 (33) | - | Reference master for stratigraphic formations and reservoir units relevant to exploration targeting and well evaluation |
| `exploration/discovery.csv` | 12 | 48 (40) | asset_facility, basin, block, crude_grade, formation, play, prospect, well_asset | Transactional record capturing the formal declaration of a hydrocarbon discovery following a successful exploration well result |
| `exploration/exploration_well.csv` | 25 | 67 (52) | asset_facility, basin, crude_grade, formation, permit, prospect, rig, well_asset | Master record for exploration and appraisal wells across their full lifecycle - from planning through drilling to post-drill evaluation |
| `reservoir/reservoir.csv` | 15 | 43 (37) | formation, play | Core master entity representing a subsurface reservoir unit - the SSOT for reservoir identity, geometry, fluid type, drive mechanism, and classification |
| `reservoir/zone.csv` | 30 | 41 (37) | formation, reservoir | Defines stratigraphic zones and pay intervals within a reservoir, serving as the SSOT for zone-level characterization |
| `reservoir/well_test.csv` | 50 | 46 (40) | crude_grade, exploration_well, permit, permit_to_work, process_safety_event, prospect, well_asset, work_order, zone | Manages well test data including DST (Drill Stem Test), production tests, and pressure transient analysis (PTA) results |
| `reservoir/reserves_estimate.csv` | 50 | 54 (37) | asset_facility, crude_grade, prospect, reservoir, well_asset | SSOT for SEC and SPE-PRMS reserves classification and booking |
| `reservoir/development_plan.csv` | 12 | 53 (42) | asset_facility, crude_grade, reservoir | Stores the Field Development Plan (FDP) and reservoir development scenarios including well count, well type, drilling schedule, facility requirements, production profiles... |
| `drilling/drilling_well.csv` | 50 | 61 (44) | asset_facility, block, crude_grade, delivery_point, development_plan, drilling_well, formation, permit, prospect, reservoir, rig, well_asset | Master record for every wellbore drilled or planned by Oil Gas, serving as the SSOT for well identity across the drilling domain |
| `drilling/rig.csv` | 12 | 45 (36) | asset_facility, equipment | Master record for drilling rigs contracted or owned by Oil Gas, capturing rig name, rig type (jackup, semi-submersible, drillship, land rig), rig class, contractor name, ... |
| `drilling/well_program.csv` | 25 | 53 (41) | crude_grade, formation, prospect | Approved drilling and completion program document for a well, capturing the full engineering design basis including target formation, planned trajectory, casing design, m... |
| `drilling/daily_drilling_report.csv` | 50 | 46 (40) | drilling_well, formation, incident, permit_to_work, rig, well_asset, zone | Daily operational report (DDR) capturing 24-hour drilling activity for a well-rig combination |
| `drilling/npt_event.csv` | 50 | 43 (35) | drilling_well, equipment, incident, rig, well_asset, well_control_event, zone | Non-Productive Time (NPT) and well control event record capturing every instance of unplanned downtime or well control incident during drilling operations |
| `drilling/casing_design.csv` | 50 | 40 (39) | crude_grade, formation, well_program | Casing string and cementing record for each casing/liner run in a well, capturing both the design basis and cement job execution |
| `drilling/cementing_job.csv` | 50 | 48 (41) | casing_design, drilling_well, equipment, rig, well_asset, zone | Cementing job record capturing the execution details of each primary or remedial cement job on a well |
| `drilling/well_control_event.csv` | 25 | 49 (44) | daily_drilling_report, drilling_well, incident, process_safety_event, rig, violation, well_asset, zone | Well control event record capturing any kick, influx, or well control incident during drilling operations |
| `drilling/well_status_history.csv` | 50 | 34 (24) | drilling_well, reservoir, well_asset | Lifecycle status and regulatory permit history record tracking every status transition and permit milestone of a well from initial APD submission through final P&A |
| `production/field.csv` | 10 | 37 (31) | basin, crude_grade, play | Master reference table for field |
| `production/production_well.csv` | 50 | 61 (42) | crude_grade, field, formation, permit, play, prospect, reservoir, zone | Master record for every well in the production domain, including producing, injection, observation, and disposal wells |
| `production/production_facility.csv` | 15 | 48 (35) | crude_grade, field, permit_to_work | Master record for surface production facilities including wellpads, gathering stations, gas processing plants, FPSOs, offshore platforms, compressor stations, and meterin... |
| `production/daily_production.csv` | 50 | 55 (42) | artificial_lift, crude_grade, exploration_well, meter_station, production_facility, reservoir, well_test, zone | Core transactional record capturing daily allocated production volumes at the well level |
| `production/production_allocation.csv` | 50 | 57 (40) | crude_grade, custody_transfer, meter_station, production_facility, production_well, well_test, zone | Transactional record that distributes facility-level or commingled production volumes back to individual wells and ownership interests |
| `production/downtime_event.csv` | 50 | 56 (43) | equipment, field, incident, permit_to_work, pipeline_segment, process_safety_event, production_facility, production_well, reservoir, rig, spill_event, violation, well_control_event, work_order | Transactional record capturing production downtime and deferment events at the well or facility level |
| `production/artificial_lift.csv` | 40 | 43 (35) | equipment, production_well | Master record for artificial lift installations on producing wells |
| `production/meter_station.csv` | 25 | 48 (40) | delivery_point, equipment, measurement_point, meter_station, permit, production_facility | Master record for fiscal and allocation metering stations at production facilities, capturing meter type, calibration schedule, proving records, and measurement uncertain... |
| `production/flare_record.csv` | 50 | 53 (40) | drilling_well, emission_source, equipment, flare_record, ghg_emission, meter_station, production_facility, reservoir, well_control_event, zone | Transactional record of gas flaring and venting volumes at production facilities, capturing flare system identifier, flare volume (MSCF), flare reason code, duration, and... |
| `asset/asset_facility.csv` | 20 | 51 (34) | delivery_point | Master registry of all physical facilities operated by Oil Gas, including upstream wellpads, midstream compressor stations, FPSOs, LNG terminals, refineries, petrochemica... |
| `asset/equipment.csv` | 50 | 52 (34) | asset_facility, delivery_point, equipment, permit | Master record for every individual piece of physical equipment tracked in the CMMS, including compressors, pumps, heat exchangers, BOP stacks... |
| `asset/hierarchy.csv` | 50 | 36 (29) | - | Defines the parent-child hierarchical relationships among assets in the CMMS asset tree, enabling roll-up of maintenance costs, failure events, and performance metrics |
| `asset/pipeline_segment.csv` | 25 | 53 (39) | delivery_point, permit | Master record for each discrete pipeline segment managed as an asset, including gathering lines, transmission pipelines, and injection flowlines |
| `asset/inspection_event.csv` | 50 | 53 (37) | equipment, integrity_program, permit, permit_to_work, pipeline_segment, preventive_maintenance_plan, process_safety_event, production_facility, production_well, well_asset, work_order | Records all asset inspection activities including API RP 510 pressure vessel inspections, API RP 570 piping inspections, API RP 653 tank inspections... |
| `asset/failure_report.csv` | 50 | 51 (45) | equipment, failure_report, incident, inspection_event, pipeline_segment, preventive_maintenance_plan, process_safety_event, production_facility, production_well, spill_event, well_asset, work_order | Records equipment failures and functional failures identified during operations or inspections, capturing failure date/time, failure mode, failure cause... |
| `asset/work_order.csv` | 50 | 57 (39) | equipment, incident, permit, permit_to_work, pipeline_segment, process_safety_event, production_facility, well_asset | CMMS work order record capturing all planned and unplanned maintenance activities executed against assets |
| `asset/preventive_maintenance_plan.csv` | 40 | 48 (35) | equipment, pipeline_segment, production_facility, production_well, well_asset | Defines scheduled preventive maintenance (PM) programs and the governing maintenance strategy for assets |
| `asset/integrity_program.csv` | 20 | 43 (33) | asset_facility, equipment, permit, pipeline_segment, well_asset | Defines the ISO 55001-aligned asset integrity management program for each asset or asset class... |
| `asset/well_asset.csv` | 50 | 57 (41) | asset_facility, block, crude_grade, delivery_point, permit, reservoir | Master asset record for each wellbore as a physical infrastructure asset, distinct from the drilling and reservoir domains which own subsurface and completion data |
| `hse/incident.csv` | 50 | 59 (37) | block, delivery_point, permit_to_work, production_facility, production_well, prospect, rig, violation, well_asset | Unified HSE event register serving as the single master record for all health, safety, and environmental events... |
| `hse/incident_investigation.csv` | 30 | 50 (39) | asset_facility, equipment, incident, violation | Detailed investigation record linked to an HSE incident |
| `hse/hse_corrective_action.csv` | 50 | 61 (44) | asset_facility, equipment, hse_corrective_action, incident, incident_investigation, ldar_survey, pipeline_segment, process_safety_event, spill_event, violation, well_asset | Tracks corrective and preventive actions (CAPAs) arising from incident investigations, audit findings, inspection deficiencies, and near-miss reports |
| `hse/permit_to_work.csv` | 50 | 53 (33) | asset_facility, delivery_point, equipment, exploration_well, permit, pipeline_segment, rig, well_asset | Permit-to-Work (PTW) master record authorizing specific high-risk work activities at oil and gas facilities |
| `hse/process_safety_event.csv` | 20 | 55 (42) | crude_grade, drilling_well, equipment, pipeline_segment, production_facility, rig, violation, well_asset | Process Safety Event (PSE) record capturing Tier 1 and Tier 2 process safety incidents as defined by API RP 754... |
| `hse/spill_event.csv` | 20 | 72 (43) | block, crude_grade, delivery_point, equipment, incident, pipeline_segment, production_facility, production_well, rig, violation, well_asset | Environmental spill and release event record capturing unplanned releases of crude oil, refined products, chemicals, produced water... |
| `hse/emission_source.csv` | 40 | 57 (37) | asset_facility, delivery_point, drilling_well, equipment, permit, rig, well_asset | Master record for stationary and fugitive emission sources at oil and gas facilities subject to GHG and criteria pollutant reporting |
| `hse/ghg_emission.csv` | 50 | 43 (34) | asset_facility, crude_grade, emission_source, ldar_survey | Greenhouse gas (GHG) emission measurement and calculation record capturing CO2, CH4, N2O and other GHG emissions by source, facility and reporting period |
| `hse/ldar_survey.csv` | 30 | 41 (31) | emission_source, production_facility, rig | Leak Detection and Repair (LDAR) survey record capturing fugitive emissions monitoring activities at oil and gas facilities |
| `compliance/regulatory_authority.csv` | 10 | 20 (15) | regulatory_authority | Master reference table for regulatory_authority |
| `compliance/permit.csv` | 40 | 48 (41) | regulatory_authority | Master register of all permits held or applied for by the company (drilling, air, water/UIC, pipeline...) |
| `compliance/violation.csv` | 25 | 51 (44) | asset_facility, equipment, permit, pipeline_segment, regulatory_authority, well_asset | Transactional record of each regulatory violation, notice of violation (NOV), or non-compliance finding |
| `logistics/custody_transfer.csv` | 40 | 54 (35) | crude_grade, delivery_point, drilling_well, reservoir | Transactional record capturing the official transfer of title and custody of petroleum products between parties at a defined measurement point |
| `logistics/measurement_point.csv` | 25 | 48 (34) | asset_facility, block, delivery_point, emission_source, exploration_well, permit, pipeline_segment | Master data entity representing a physical or fiscal measurement location where petroleum product volumes and qualities are measured |
| `customer/delivery_point.csv` | 15 | 45 (35) | - | Physical or logical delivery location (terminal, pipeline interconnect, truck rack, LACT) |
| `product/crude_grade.csv` | 10 | 42 (34) | - | Reference master for crude oil grades and pricing benchmarks used in trading, refining and marketing |

"Columns (populated)" counts columns with at least one value; the gap is mostly foreign keys to
out-of-scope tables, which stay empty by design.
