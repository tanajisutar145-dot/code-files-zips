"""Framework of the one-time generator: scope, ids, physical-well world, row assembly."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from typing import Any, Callable

from genlib import AS_OF, Ctx, heuristic
from world import FIELDS, FORMATIONS, NEW_PROSPECTS, RESERVOIRS, WELLS_PER_FIELD

# load order (parents first) computed from the DDL foreign keys of the 56 in-scope tables
TABLES = ['asset.hierarchy', 'compliance.regulatory_authority', 'customer.delivery_point', 'exploration.formation',
          'product.crude_grade', 'asset.asset_facility', 'compliance.permit', 'exploration.basin', 'asset.equipment',
          'asset.pipeline_segment', 'exploration.block', 'exploration.play', 'drilling.rig', 'exploration.prospect',
          'production.field', 'reservoir.reservoir', 'asset.well_asset', 'drilling.well_program',
          'reservoir.development_plan', 'reservoir.zone', 'asset.integrity_program', 'compliance.violation',
          'drilling.casing_design', 'drilling.drilling_well', 'exploration.discovery', 'exploration.exploration_well',
          'production.production_well', 'reservoir.reserves_estimate', 'drilling.cementing_job',
          'drilling.well_status_history', 'hse.emission_source', 'hse.permit_to_work', 'logistics.custody_transfer',
          'production.artificial_lift', 'logistics.measurement_point', 'production.production_facility',
          'asset.preventive_maintenance_plan', 'hse.incident', 'hse.ldar_survey', 'hse.process_safety_event',
          'production.meter_station', 'asset.work_order', 'drilling.daily_drilling_report', 'hse.ghg_emission',
          'hse.incident_investigation', 'hse.spill_event', 'asset.inspection_event', 'drilling.well_control_event',
          'hse.hse_corrective_action', 'reservoir.well_test', 'asset.failure_report', 'drilling.npt_event',
          'production.daily_production', 'production.downtime_event', 'production.flare_record',
          'production.production_allocation']

BASE = {tid: (k + 1) * 1000 for k, tid in enumerate(TABLES)}


def P(tid: str, i: int) -> int:
    """Primary key of the i-th (0-based) row of a table."""
    return BASE[tid] + i + 1


FORM_IDX = {f[0]: i for i, f in enumerate(FORMATIONS)}


@dataclass
class Well:
    idx: int
    name: str
    field: int | None           # FIELDS index (None for wildcats)
    prospect: int               # prospect row index
    state: str
    state_api: str
    county: str
    county_api: str
    unique: int
    lat: float
    lon: float
    formation: str              # target formation code
    reservoir: int | None       # RESERVOIRS index
    kind: str                   # development | appraisal | wildcat | planned | legacy | swd
    result: str                 # producing | dry_hole | suspended | planned | injecting
    spud: date | None

    @property
    def api10(self) -> str:
        return f"{self.state_api}{self.county_api}{self.unique:05d}"

    def api(self, style: str, sidetrack: int = 0) -> str:
        s, c, u = self.state_api, self.county_api, f"{self.unique:05d}"
        if style == "dash14":
            return f"{s}-{c}-{u}-{sidetrack:02d}-00"
        if style == "dash10":
            return f"{s}-{c}-{u}"
        if style == "compact10":
            return f"{s}{c}{u}"
        return f"{s}{c}{u}{sidetrack:02d}00"  # compact14


def build_wells(ctx: Ctx) -> list[Well]:
    wells: list[Well] = []
    rng = ctx.rng
    idx = 0
    for f, n in enumerate(WELLS_PER_FIELD):
        code, fname, st, st_api, county, c_api, lat, lon, _, _ = FIELDS[f]
        res = [i for i, (fi, _) in enumerate(RESERVOIRS) if fi == f]
        for j in range(n):
            sec = 10 + f * 2 + j // 4
            name = f"{fname} {sec}-{j % 4 + 1}H"
            r = res[j % len(res)]
            spud = date(2024, 2, 5) + timedelta(days=int((idx * 17.3) % 840))
            kind = "appraisal" if j == 0 or (j == 1 and f in (0, 1, 2, 3, 4, 8)) else "development"
            result = "suspended" if idx == 30 else "producing"
            wells.append(Well(idx, name, f, f, st, st_api, county, c_api, 40000 + (idx * 397) % 9000 + idx,
                              round(lat + rng.uniform(-0.06, 0.06), 2), round(lon + rng.uniform(-0.06, 0.06), 2),
                              RESERVOIRS[r][1], r, kind, result, spud))
            idx += 1
    # wildcats on new prospects (drilled)
    wild = [("Javelina", "TX", "42", "Pecos", "371", 31.12, -103.48, "WCA", "producing"),
            ("Roadrunner", "TX", "42", "Reeves", "389", 31.30, -103.85, "WCB", "producing"),
            ("Salt Cedar", "NM", "30", "Eddy", "015", 32.15, -103.95, "BS2", "dry_hole"),
            ("Agave", "TX", "42", "Culberson", "109", 31.62, -104.20, "STRN", "suspended")]
    for k, (pn, st, sa, county, ca, lat, lon, form, result) in enumerate(wild):
        wells.append(Well(idx, f"{pn} 1", None, 10 + k, st, sa, county, ca, 40000 + (idx * 397) % 9000 + idx, lat, lon,
                          form, None, "wildcat", result, date(2025, 3, 10) + timedelta(days=k * 61)))
        idx += 1
    # planned exploration wells (permitted, not spud)
    for k, pn in enumerate(NEW_PROSPECTS[4:9]):
        wells.append(Well(idx, f"{pn} 1", None, 14 + k, "TX", "42", "Reeves", "389", 40000 + (idx * 397) % 9000 + idx,
                          round(31.0 + k * 0.08, 2), round(-103.9 + k * 0.05, 2), ["WCA", "WCB", "BS3", "AVLN", "WCC"][k],
                          None, "planned", "planned", None))
        idx += 1
    # legacy producing wells acquired with Yucca Ridge / Ocotillo (production register only)
    for k, (fi, nm) in enumerate([(8, "Yucca Ridge 3-1"), (8, "Yucca Ridge 3-2"), (9, "Ocotillo 7-1")]):
        code, fname, st, st_api, county, c_api, lat, lon, _, _ = FIELDS[fi]
        wells.append(Well(idx, f"{nm} (acquired)", fi, fi, st, st_api, county, c_api, 30000 + idx * 13, round(lat + 0.03, 2),
                          round(lon - 0.03, 2), "USPB" if fi == 8 else "WCA", None, "legacy", "producing", date(2018, 5, 1)))
        idx += 1
    # salt-water disposal / injection wells (production + asset registers; drilled before 2024)
    for k, fi in enumerate([0, 1, 2, 4]):
        code, fname, st, st_api, county, c_api, lat, lon, _, _ = FIELDS[fi]
        nm = f"{fname} {'WI' if fi == 2 else 'SWD'} 1"
        wells.append(Well(idx, nm, fi, fi, st, st_api, county, c_api, 20000 + idx * 11, round(lat - 0.04, 2),
                          round(lon + 0.04, 2), "BELL" if fi != 2 else "BS2", None, "swd", "injecting", date(2016, 8, 1)))
        idx += 1
    return wells


DRILLED = list(range(0, 46))                 # P0..P45 have drilling_well rows
SIDETRACK_OF = [2, 10, 17, 23]               # drilling rows 46..49 are ST01 of these wells
EXPLORATION = [0, 1, 8, 9, 15, 16, 21, 22, 26, 27, 30, 33, 36, 38, 39, 40] + [42, 43, 44, 45] + [46, 47, 48, 49, 50]
PRODUCING = [i for i in range(0, 44) if i != 30] + [51, 52, 53] + [54, 55, 56, 57]
ASSETS = list(range(0, 46)) + [54, 55, 56, 57]
API_TYPO = {4: 7, 12: 70, 27: 700}           # production register holds a mistyped API (unique + delta)


Builder = Callable[[Ctx, int, dict[str, Any]], None]


class Generator:
    def __init__(self, model, scope_tables: list[str], ctx: Ctx, builders: dict[str, tuple[int, Builder]], full_model):
        self.model = model
        self.full = full_model           # unscoped model: knows the FKs that point outside the scope
        self.ctx = ctx
        self.builders = builders
        self.scope = set(scope_tables)

    def run(self) -> dict[str, list[dict[str, Any]]]:
        out = {}
        for tid in TABLES:
            t = self.model.tables[tid]
            count, fn = self.builders[tid]
            cols = {c.name: c for c in t.columns}
            fks = {fk.column: fk for fk in self.full.fks_from(tid)}
            rows = []
            self.ctx.rows[tid] = rows
            for i in range(count):
                row: dict[str, Any] = {t.primary_key[0]: P(tid, i)}
                fn(self.ctx, i, row)
                bad = [k for k in row if not k.startswith("_") and k not in cols]
                if bad:
                    raise SystemExit(f"{tid}: builder set unknown columns {bad}")
                for name, c in cols.items():
                    if name in row:
                        continue
                    if name in fks:
                        row[name] = None  # only meaningful links are set by the builders
                        continue
                    row[name] = heuristic(self.ctx, tid, name, c.type, row, c.enum_values)
                for name, fk in fks.items():
                    if fk.ref_table_id not in self.scope:
                        row[name] = None
                rows.append(row)
            self.ctx.by_pk[tid] = {r[t.primary_key[0]]: r for r in rows}
            out[tid] = rows
        return out


def clamp_date(d: date) -> date:
    return min(d, AS_OF)
