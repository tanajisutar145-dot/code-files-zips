# Synthetic data generator (one-time; not part of the application)

These scripts were used once to create the synthetic dataset and the standards-alignment TTL inputs of
`oil-and-gas-kg-app`. They live outside the application package on purpose: the app only reads
`input_data/` and `data_model/`. All generated records are synthetic (fictitious operator "OGX Energy").

| File | Role |
|---|---|
| `gen_data.py` | Entry point. Parses the oil_gas DDL with the app's parser, builds every in-scope table and validates PKs, NOT NULL, enumerations and FK orphans before writing |
| `scope.py` | The 56 in-scope tables |
| `genlib.py` | Seeded random context, column-name heuristics (units, ranges), formatting |
| `world.py`, `assets_world.py` | Reference world: fields, formations, basins, plays, reservoirs, wells, facilities, equipment, rigs, pipelines |
| `gen_core.py`, `story.py` | Table order, id ranges, the well register and the planted stories behind the demo questions |
| `b_subsurface.py`, `b_ops.py` | One builder per table (subsurface, drilling, production, asset, HSE, compliance, logistics) |
| `make_ttl.py` | Writes `og_standards_reference.ttl`, `og_standards_alignment.ttl` and `og_subject_areas.skos.ttl` |

Reproduce the files byte for byte. Run from this folder with the app's virtual environment:

```powershell
..\oil-and-gas-kg-app\backend\.venv\Scripts\python -I gen_data.py ..\oil-and-gas-kg-app\backend ..\oil-and-gas-kg-app\data_model\ddl <output dir>
..\oil-and-gas-kg-app\backend\.venv\Scripts\python -I make_ttl.py <output dir>
```

Both commands were checked on 2026-10-30: the output was identical to `input_data/` and to the three TTL files in
`data_model/ontology/`. The method, the domain conventions and the planted facts are described in
`oil-and-gas-kg-app/input_data/README.md`.
