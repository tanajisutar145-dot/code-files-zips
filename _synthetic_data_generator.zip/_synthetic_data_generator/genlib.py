"""Generic helpers for the one-time synthetic oil_gas dataset.

Not part of the application: the app only reads the CSV files written by gen_data.py.
Values are deterministic (seeded) and typed from the DDL; column-name conventions of the
oil_gas model (``_ft``, ``_psi``, ``_bbl``, ``_mcf``, ``_usd``, ``_pct``...) drive realistic
oilfield ranges. Columns no rule recognises are left empty instead of being filled with noise.
"""

from __future__ import annotations

import random
import re
from datetime import date, datetime, timedelta
from typing import Any

AS_OF = date(2026, 9, 30)
WINDOW_START = date(2024, 1, 1)

FIRST = ["Ava", "Ben", "Carla", "Dev", "Elena", "Femi", "Grace", "Hiro", "Isla", "Jon", "Kemi", "Luis", "Maya",
         "Nate", "Omar", "Priya", "Quinn", "Rosa", "Sam", "Tara", "Uma", "Victor", "Wen", "Yara", "Zane"]
LAST = ["Alvarez", "Brooks", "Chen", "Dubois", "Eze", "Fischer", "Garcia", "Hughes", "Ibrahim", "Jensen", "Khan",
        "Larsen", "Morales", "Nakamura", "Okafor", "Patel", "Quiroga", "Reyes", "Silva", "Thompson", "Usman",
        "Vargas", "Walker", "Young", "Zhou"]

STATUS_WORDS = {"status": ["active", "completed", "closed", "open"]}


class Ctx:
    def __init__(self, seed: int = 20261030):
        self.rng = random.Random(seed)
        self.rows: dict[str, list[dict[str, Any]]] = {}
        self.by_pk: dict[str, dict[Any, dict[str, Any]]] = {}

    # -- randomness -----------------------------------------------------------
    def pick(self, seq, weights=None):
        seq = list(seq)
        return self.rng.choices(seq, weights=weights, k=1)[0] if weights else self.rng.choice(seq)

    def chance(self, p: float) -> bool:
        return self.rng.random() < p

    def num(self, lo: float, hi: float, nd: int = 2) -> float:
        return round(self.rng.uniform(lo, hi), nd)

    def int_(self, lo: int, hi: int) -> int:
        return self.rng.randint(lo, hi)

    def person(self) -> str:
        return f"{self.pick(FIRST)} {self.pick(LAST)}"

    def date_between(self, a: date, b: date) -> date:
        if b <= a:
            return a
        return a + timedelta(days=self.rng.randint(0, (b - a).days))

    def ts_on(self, d: date, h0: int = 0, h1: int = 23) -> datetime:
        return datetime(d.year, d.month, d.day, self.rng.randint(h0, h1), self.rng.choice([0, 15, 30, 45]))

    # -- parents --------------------------------------------------------------
    def parents(self, table: str) -> list[dict[str, Any]]:
        return self.rows.get(table, [])

    def parent_ids(self, table: str, pk: str) -> list[Any]:
        return [r[pk] for r in self.rows.get(table, [])]


def fmt(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, float):
        return f"{v:.2f}".rstrip("0").rstrip(".") if abs(v) < 1e15 else str(v)
    return str(v)


# ---------------------------------------------------------------------------
# heuristic filler (used for columns a table builder did not set)
# ---------------------------------------------------------------------------
_AUDIT_TS = re.compile(r"(created|modified|updated|last_modified|record_created|record_updated)")


def _anchor(row: dict[str, Any]) -> date:
    a = row.get("_anchor")
    if isinstance(a, datetime):
        return a.date()
    if isinstance(a, date):
        return a
    return date(2025, 6, 1)


def heuristic(ctx: Ctx, table: str, col: str, sql_type: str, row: dict[str, Any], enum_values: list[str]) -> Any:
    base = sql_type.split("(")[0].upper()
    name = col.lower()
    anchor = _anchor(row)
    if enum_values:
        # first values of a 'Valid values' list are the common case in the model's comments
        w = [max(1.0, len(enum_values) - i) ** 1.3 for i in range(len(enum_values))]
        return ctx.pick(enum_values, w)
    if base == "BOOLEAN":
        if name.startswith("is_") or name.endswith("_flag") or name.endswith("_required") or name.startswith("has_"):
            return ctx.chance(0.25)
        return ctx.chance(0.3)
    if base == "TIMESTAMP":
        if _AUDIT_TS.search(name):
            if "created" in name:
                return ctx.ts_on(anchor - timedelta(days=ctx.int_(0, 3)), 6, 18)
            return ctx.ts_on(min(AS_OF, anchor + timedelta(days=ctx.int_(1, 60))), 6, 18)
        return ctx.ts_on(anchor)
    if base == "DATE":
        if any(k in name for k in ("next_", "due", "expir", "renewal", "end_date", "economic_limit", "planned_decommission",
                                   "warranty", "termination", "relinquish")):
            return ctx.date_between(AS_OF + timedelta(days=15), AS_OF + timedelta(days=700))
        if any(k in name for k in ("commission", "installation", "effective", "discovery", "first_", "acquisition",
                                   "identified", "issue", "application", "approval", "certification")):
            return ctx.date_between(date(2012, 1, 1), anchor)
        return ctx.date_between(anchor - timedelta(days=120), min(AS_OF, anchor + timedelta(days=30)))
    if base in ("BIGINT", "INT", "INTEGER"):
        if name.endswith("_code"):
            return ctx.int_(1000, 9999)
        return ctx.int_(1, 500)
    if base in ("DECIMAL", "DOUBLE", "FLOAT"):
        return _number(ctx, name)
    if base == "STRING":
        return _string(ctx, table, name, row)
    return None


def _number(ctx: Ctx, n: str) -> float | None:
    if n in ("latitude",) or n.endswith("_latitude"):
        return ctx.num(31.2, 32.8)
    if n in ("longitude",) or n.endswith("_longitude"):
        return ctx.num(-104.3, -101.6)
    if n.endswith(("_pct", "_percent", "_percentage")) or "percent" in n:
        if "interest" in n:
            return ctx.num(25, 100)
        if "uncertainty" in n:
            return ctx.num(0.25, 2.0)
        if "efficiency" in n:
            return ctx.num(95, 99.8)
        return ctx.num(2, 60)
    if n.endswith(("_fraction", "_decimal")) or n.endswith("_ratio") and "oil" not in n:
        return ctx.num(0.05, 0.95)
    if "score" in n:
        return ctx.num(20, 95)
    if n.endswith(("_usd", "_cost", "_amount", "_value")) or "cost" in n or "usd" in n or "npv" in n or n.endswith("_mm"):
        if n.endswith("_mm") or "usd_mm" in n:
            return ctx.num(5, 400)
        if "penalty" in n:
            return ctx.num(5000, 150000, 0)
        return ctx.num(2500, 250000, 0)
    if "depth" in n or n.endswith(("_ft", "_md", "_tvd", "_md_ft", "_tvd_ft")):
        if "water_depth" in n:
            return 0.0
        if "thickness" in n or "net_pay" in n:
            return ctx.num(20, 450)
        if "length" in n or "lateral" in n:
            return ctx.num(7500, 12500, 0)
        return ctx.num(4500, 21000, 0)
    if n.endswith("_psi") or "pressure" in n:
        return ctx.num(300, 6500, 0)
    if n.endswith("_bar"):
        return ctx.num(5, 120)
    if n.endswith(("_f", "_fahrenheit")) or "temperature" in n:
        return ctx.num(60, 240, 1)
    if n.endswith("_c"):
        return ctx.num(10, 120, 1)
    if n.endswith("_hours") or n.endswith("_hr"):
        return ctx.num(0.5, 36, 1)
    if n.endswith("_days"):
        return ctx.num(1, 40, 1)
    if n.endswith("_years"):
        return ctx.num(1, 30, 1)
    if n.endswith(("_bbl", "_barrels", "_bopd", "_bwpd", "_bpd", "_stb", "_mmbbl", "_mmstb", "_mmboe", "_boe")):
        if n.startswith(("ooip", "stoiip")) or n.endswith(("_mmbbl", "_mmstb", "_mmboe")):
            return ctx.num(5, 450)
        return ctx.num(20, 2500, 1)
    if n.endswith(("_mcf", "_mcfd", "_mscf", "_mmcfd", "_bcf", "_mmcf")):
        if n.endswith("_bcf") or n.startswith(("ogip", "giip")):
            return ctx.num(20, 900)
        if n.endswith("_mmcfd"):
            return ctx.num(2, 120)
        return ctx.num(50, 9000, 1)
    if n.endswith("_md") or "permeability" in n:
        return ctx.num(0.001, 5, 3)
    if "porosity" in n:
        return ctx.num(4, 14)
    if n.endswith("_ppg"):
        return ctx.num(8.6, 14.5)
    if n.endswith("_rpm"):
        return ctx.num(60, 180, 0)
    if n.endswith(("_klbs", "_lbs", "_lb")):
        return ctx.num(15, 450, 0)
    if n.endswith("_gpm"):
        return ctx.num(400, 900, 0)
    if n.endswith("_mph"):
        return ctx.num(2, 25, 1)
    if n.endswith(("_in", "_inches")):
        return ctx.num(2, 24)
    if n.endswith("_miles"):
        return ctx.num(0.5, 25)
    if n.endswith(("_acres", "_sq_km", "_sq_miles")):
        return ctx.num(40, 5000, 0)
    if "factor" in n:
        return ctx.num(0.7, 1.3, 3)
    if "rate" in n:
        return ctx.num(1, 100)
    if "tonnes" in n or "tons" in n:
        return ctx.num(1, 5000)
    if n.endswith("_hp") or "horsepower" in n:
        return ctx.num(100, 3000, 0)
    if "gravity" in n:
        return ctx.num(35, 48, 1)
    if "gor" in n:
        return ctx.num(600, 3500, 0)
    return None


_PEOPLE = re.compile(r"(_by$|_by_user$|approved_by|investigated_by|manager_name|inspector_name|engineer_name|"
                     r"geophysicist_name|program_owner|reported_by|resolved_by|closed_by|verified_by|created_by|"
                     r"contact_name|operator_name|capa_responsible_party|verifier_name|team_members)")


def _string(ctx: Ctx, table: str, n: str, row: dict[str, Any]) -> str | None:
    if n == "country_code" or n.endswith("_country_code"):
        return "US"
    if n in ("state_province", "state_code"):
        return row.get("_state") or ctx.pick(["TX", "TX", "NM"])
    if n in ("county", "county_parish", "county_district"):
        return row.get("_county") or ctx.pick(["Reeves", "Loving", "Midland", "Martin", "Eddy", "Lea"])
    if _PEOPLE.search(n):
        if "team_members" in n:
            return "; ".join(ctx.person() for _ in range(3))
        return ctx.person()
    if "email" in n:
        return f"{ctx.pick(FIRST).lower()}.{ctx.pick(LAST).lower()}@ogx-energy.example"
    if "phone" in n:
        return f"+1-432-555-{ctx.int_(100, 999):04d}"
    if n.endswith("_url"):
        return f"https://docs.ogx-energy.example/{table.split('.')[-1]}/{ctx.int_(10000, 99999)}"
    if n.endswith("_count") or n in ("depth", "accommodation_capacity", "processing_train_count", "separator_count",
                                     "flow_period_count", "shutin_period_count", "pump_stages", "witness_count",
                                     "attachments_count", "capa_count"):
        return str(ctx.int_(0, 12))
    if n in ("build_year", "installation_year"):
        return str(ctx.int_(2006, 2023))
    if n == "useful_life_years":
        return str(ctx.pick([15, 20, 25, 30]))
    if n.endswith("_days") or n.endswith("_months") or n.endswith("_frequency_days") or n in ("frequency_value",):
        return str(ctx.pick([7, 14, 30, 60, 90, 180, 365]))
    if n in ("cost_center",):
        return f"CC-{ctx.int_(4100, 4199)}"
    if n == "moc_reference_number":
        return f"MOC-{ctx.int_(2024, 2026)}-{ctx.int_(100, 999)}"
    if n.endswith("_reference_number") or n.endswith("_reference") or n == "document_reference":
        return f"REF-{ctx.int_(10000, 99999)}"
    if n in ("data_source_system", "data_source", "source_system"):
        return ctx.pick(["drilling data store", "production accounting", "CMMS", "HSE management system",
                         "historian", "manual entry"])
    if n in ("time_zone",):
        return "America/Chicago"
    if n in ("currency_code", "budget_currency_code", "penalty_currency", "bond_currency"):
        return "USD"
    if n in ("geographic_region", "operating_region", "region"):
        return ctx.pick(["Permian - Delaware Basin", "Permian - Midland Basin"])
    if n in ("regulatory_jurisdiction", "jurisdiction", "issuing_jurisdiction"):
        return ctx.pick(["Texas (RRC)", "New Mexico (OCD)", "Federal (EPA)"])
    if n in ("weather_conditions", "environmental_conditions"):
        return ctx.pick(["clear, 92F, light wind", "overcast, 61F", "high wind 28 mph, dust", "thunderstorms nearby",
                         "clear, 104F", "freezing fog, 29F"])
    return None
