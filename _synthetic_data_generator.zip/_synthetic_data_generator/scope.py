SCOPE = {
 "exploration": ["basin","play","prospect","block","formation","discovery","exploration_well"],
 "reservoir": ["reservoir","zone","well_test","reserves_estimate","development_plan"],
 "drilling": ["drilling_well","rig","well_program","daily_drilling_report","npt_event","casing_design","cementing_job","well_control_event","well_status_history"],
 "production": ["field","production_well","production_facility","daily_production","production_allocation","downtime_event","artificial_lift","meter_station","flare_record"],
 "asset": ["asset_facility","equipment","hierarchy","pipeline_segment","inspection_event","failure_report","work_order","preventive_maintenance_plan","integrity_program","well_asset"],
 "hse": ["incident","incident_investigation","hse_corrective_action","permit_to_work","process_safety_event","spill_event","emission_source","ghg_emission","ldar_survey"],
 "compliance": ["regulatory_authority","permit","violation"],
 "logistics": ["custody_transfer","measurement_point"],
 "customer": ["delivery_point"],
 "product": ["crude_grade"],
}
IDS = [f"{s}.{t}" for s, ts in SCOPE.items() for t in ts]
