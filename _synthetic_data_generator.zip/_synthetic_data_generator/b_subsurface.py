"""Builders: reference data, exploration, reservoir and drilling tables."""

from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Any

import story as S
from assets_world import EQUIP_IDX, FACILITY_OF_FIELD, RIGS
from gen_core import (API_TYPO, ASSETS, DRILLED, EXPLORATION, FORM_IDX, P, PRODUCING, SIDETRACK_OF, Well)
from genlib import AS_OF, Ctx
from world import (BASINS, CRUDE_GRADES, DELIVERY_POINTS, FIELDS, FORMATIONS, NEW_PROSPECTS, OPERATOR, PLAYS,
                   REGULATORS, RESERVOIRS)

WELLS: list[Well] = []          # set by gen_data before building
GRADE_OF_FIELD = [3, 4, 5, 0, 6, 0, 7, 8, 9, 6]
PERMIT_WELLS = [0, 1, 2, 3, 8, 9, 10, 15, 16, 17, 21, 22, 23, 26, 27, 30, 33, 36, 38, 40, 42, 43, 44, 45, 46]
MIDLAND = {26, 27, 28, 29, 38, 39, 40, 41}
DELAWARE = [k for k in DRILLED if k not in MIDLAND]
WCB_WELLS = [1, 4, 7, 11, 13, 27, 29, 43]      # wells whose target is Wolfcamp B (kick risk)
WCA_WELLS = [0, 3, 6, 8, 10, 12, 21, 23, 25, 30, 32, 42]


def facility_of_well(widx: int) -> int | None:
    """Asset/production facility row that handles a well's production (CTB)."""
    w = WELLS[widx]
    if widx in (4, 5, 6, 7):
        return 1                       # Falcon Draw CTB-2
    if widx in (17, 18, 19, 20):
        return 5                       # Coyote Flats CTB-2
    if w.kind == "swd":
        return {0: 14, 1: 18}.get(w.field, FACILITY_OF_FIELD[w.field])
    if w.field is None:
        return 9 if widx in (42, 43) else None   # wildcat discoveries on extended test via Pecos Bend CTB-1
    return FACILITY_OF_FIELD[w.field]


def permit_of_well(widx: int) -> int | None:
    return P("compliance.permit", PERMIT_WELLS.index(widx)) if widx in PERMIT_WELLS else None


def setup(wells: list[Well]) -> None:
    WELLS.clear()
    WELLS.extend(wells)


def form(code: str) -> int:
    return P("exploration.formation", FORM_IDX[code])


def well_reservoir_zone(w: Well) -> tuple[int | None, int | None]:
    if w.reservoir is None:
        return None, None
    return P("reservoir.reservoir", w.reservoir), P("reservoir.zone", w.reservoir * 2 + (w.idx % 2))


def drill_row_of_well(widx: int) -> int:
    return P("drilling.drilling_well", DRILLED.index(widx))


def asset_row_of_well(widx: int) -> int:
    return P("asset.well_asset", ASSETS.index(widx))


def well_dates(w: Well) -> dict[str, date]:
    spud = w.spud or date(2026, 11, 15)
    days = 14 + (w.idx * 5) % 15
    td = spud + timedelta(days=days)
    rig_release = td + timedelta(days=3)
    comp = rig_release + timedelta(days=35 + (w.idx * 3) % 25)
    first = comp + timedelta(days=10 + w.idx % 9)
    return {"spud": spud, "td": td, "rig_release": rig_release, "completion": comp, "first_prod": first}


# ---------------------------------------------------------------------------
# reference
# ---------------------------------------------------------------------------
def regulatory_authority(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    name, abbr, kind, jur, scope, parent = REGULATORS[i]
    r.update(regulatory_authority_name=name, abbreviation=abbr, authority_type=kind, jurisdiction=jur,
             compliance_scope=scope, active_status="active", regulatory_body_code=abbr,
             parent_regulatory_authority_id=P("compliance.regulatory_authority", parent) if parent is not None else None,
             regulatory_authority_description=f"{name} - {scope}. Reference record in a synthetic dataset.",
             data_submission_method=ctx.pick(["online portal", "electronic filing", "e-mail"]),
             reporting_frequency=ctx.pick(["event-driven", "monthly", "annual"]),
             website_url=None, contact_email=None, address=None, phone_number=None,
             effective_date=date(2000, 1, 1), termination_date=None, _anchor=date(2024, 1, 2))


def delivery_point(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    code, name, kind, mode, st, county, lat, lon, custody = DELIVERY_POINTS[i]
    r.update(delivery_point_code=code, delivery_point_name=name, delivery_point_type=kind, delivery_mode=mode,
             state_province=st, city=county + " County", country_code="US", latitude=lat, longitude=lon,
             custody_transfer_point=custody, offshore_indicator=False, water_depth_m=0.0,
             operational_status="inactive" if not custody else "active", h2s_service=code in ("DP-11",),
             throughput_capacity_bopd=ctx.num(8000, 120000, 0), storage_capacity_bbl=ctx.num(20000, 600000, 0),
             pipeline_system_name=f"{name.split()[0]} Gathering System" if mode == "pipeline" else None,
             unlocode="USCRP" if code == "DP-10" else None, berth_number="2" if code == "DP-10" else None,
             max_vessel_dwt=160000.0 if code == "DP-10" else None, min_vessel_dwt=40000.0 if code == "DP-10" else None,
             loading_arm_count="4" if mode in ("truck", "tanker") else "0", time_zone="America/Chicago",
             tariff_code=f"TRF-{code[-2:]}", metering_system_code=f"MS-{code[-2:]}", region="Permian",
             regulatory_jurisdiction="New Mexico (OCD)" if st == "NM" else "Texas (RRC)",
             effective_date=date(2019, 1, 1) + timedelta(days=i * 90), decommission_date=None, address_line=None,
             postal_code=None, customs_port_code=None, _anchor=date(2024, 3, 1))


def formation(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    code, name, period, epoch, lith, top, hazard, hc = FORMATIONS[i]
    thick = ctx.num(150, 650, 0)
    r.update(formation_code=code, formation_name=name, stratigraphic_age_period=period, stratigraphic_age_epoch=epoch,
             stratigraphic_age_stage=epoch.split("(")[-1].rstrip(")") if "(" in epoch else epoch,
             lithology_type=lith, drilling_hazard_notes=hazard, hydrocarbon_type=hc,
             average_thickness_ft=thick, thickness_range_min_ft=round(thick * 0.6), thickness_range_max_ft=round(thick * 1.4),
             top_marker=f"Top {name}", base_marker=f"Base {name}", source_rock_indicator=code in ("WCA", "WCB", "WCC", "WCD", "AVLN"),
             average_porosity_percent=ctx.num(3, 14) if hc != "unknown" else ctx.num(0.5, 3),
             average_permeability_md=ctx.num(0.0005, 0.05, 4) if code.startswith("WC") else ctx.num(0.01, 25, 3),
             formation_status="active", data_source="regional stratigraphic framework (synthetic)",
             regional_extent="Delaware Basin" if code not in ("USPB", "LSPB", "DEAN") else "Midland Basin",
             depositional_environment=ctx.pick(["deep-water basin floor", "slope apron", "evaporite basin", "carbonate shelf margin"])
             if hc != "unknown" else "restricted evaporite basin",
             reservoir_quality_class="Non-Reservoir" if hc == "unknown" else ctx.pick(["Class II", "Class III", "Class IV"]),
             seal_quality="excellent" if code in ("SALD", "CAST") else ctx.pick(["good", "fair"]),
             exploration_maturity="mature" if code in ("WCA", "BS2", "USPB") else ctx.pick(["emerging", "mature"]),
             prms_resource_class="2P" if code in ("WCA", "WCB", "BS2", "BS3", "USPB", "LSPB") else ctx.pick(["Contingent", "Prospective", "Unknown"]),
             play_type="shale" if code.startswith("WC") or code == "AVLN" else "conventional",
             completion_type_recommendation="plug-and-perf horizontal, 10,000 ft lateral" if code in ("WCA", "WCB", "BS2", "BS3", "AVLN", "USPB", "LSPB") else None,
             net_to_gross_ratio=ctx.num(0.4, 0.9), eur_estimate_boe=ctx.num(350000, 1200000, 0) if hc != "unknown" else None,
             type_section_reference=f"Type log OGX-TS-{i + 1:02d}", chronostratigraphic_chart_reference="ICS 2023/09",
             remarks=f"{name}: {lith}. Typical top about {top:,} ft TVD in the Delaware Basin.",
             last_updated_date=date(2025, 11, 1), _anchor=date(2025, 11, 1))


def crude_grade(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    code, name, api, sulfur, band, sclass, cls, diff = CRUDE_GRADES[i]
    r.update(grade_code=code, grade_name=name, api_gravity=api, sulfur_content_percent=sulfur, api_gravity_band=band,
             sulfur_classification=sclass, grade_classification=cls, pricing_differential_usd_per_bbl=diff,
             crude_grade_status="active", origin_country_code="US", origin_basin="Permian",
             origin_field_name=name.split(" (")[0] if cls == "equity" else None,
             delivery_point="Midland" if code == "WTIM" else ("Cushing" if code == "WTIC" else "Permian"),
             transportation_mode="pipeline", environmental_classification="conventional",
             carbon_intensity_kg_co2_per_bbl=ctx.num(8, 22), tan_value=ctx.num(0.02, 0.2), h2s_content_ppm=ctx.num(0, 5) if sclass == "sweet" else ctx.num(20, 120),
             viscosity_cst=ctx.num(2, 9), viscosity_reference_temp_c=40.0, pour_point_c=ctx.num(-35, -5),
             yield_gasoline_percent=ctx.num(28, 40), yield_diesel_percent=ctx.num(25, 33), yield_residual_percent=ctx.num(8, 22),
             refinery_compatibility_rating="excellent" if sclass == "sweet" else "good",
             regulatory_classification="UN1267 petroleum crude oil", assay_date=date(2025, 4, 1) + timedelta(days=i * 20),
             effective_date=date(2024, 1, 1), expiration_date=None, _anchor=date(2025, 4, 1))


def permit(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    # 0-24 drilling permits (APD) for wells, 25-32 air, 33-36 SWD/UIC, 37 pipeline, 38-39 flaring authorisations
    if i < 25:
        w = WELLS[PERMIT_WELLS[i]]
        tx = w.state == "TX"
        auth = 2 if tx else 4
        num = f"W1-{1012300 + i * 37}" if tx else f"C101-{30015 + i}-{2024 + i % 3}"
        app = (w.spud or date(2026, 10, 1)) - timedelta(days=75)
        r.update(permit_type="drilling_permit", subtype="Form W-1 (horizontal)" if tx else "Form C-101 APD",
                 title=f"Permit to drill {w.name}", permit_number=num, regulatory_authority_id=P("compliance.regulatory_authority", auth),
                 authorized_activity=f"Drill and complete horizontal well {w.name} (API {w.api('dash10')})",
                 application_date=app, approval_date=app + timedelta(days=21), effective_date=app + timedelta(days=21),
                 expiration_date=app + timedelta(days=21 + 730), permit_status="active" if w.kind == "planned" else "approved",
                 jurisdiction_level="state", issuing_jurisdiction="Texas" if tx else "New Mexico", state_code=w.state,
                 hse_classification="major", lease_number=f"LSE-{w.field if w.field is not None else 9}{i:03d}",
                 permit_description=f"{'RRC' if tx else 'NMOCD'} drilling permit for {w.name}; casing and cementing per state rules.",
                 _anchor=app)
    elif i < 33:
        fac = i - 25
        nm = ["Falcon Draw CTB-1", "Red Mesa CTB-1", "Coyote Flats CTB-2", "Sandhill Ridge CTB-1", "Mesquite Bend CTB-1",
              "Tumbleweed CTB-1", "Mesa Junction Compressor Station", "Coyote Flats Compressor Station"][fac]
        nm_state = "NM" if "Coyote" in nm or "Tumbleweed" in nm else "TX"
        r.update(permit_type="air_permit", subtype="Permit by Rule 106.352" if nm_state == "TX" else "General Construction Permit (GCP-O&G)",
                 title=f"Air authorisation {nm}", permit_number=(f"PBR-{170000 + fac * 211}" if nm_state == "TX" else f"GCP-{8800 + fac}"),
                 regulatory_authority_id=P("compliance.regulatory_authority", 3 if nm_state == "TX" else 5),
                 authorized_activity=f"Operate separators, tanks, flare and engines at {nm}",
                 emission_limit_value=ctx.num(25, 95), emission_limit_unit="tons_per_year", jurisdiction_level="state",
                 issuing_jurisdiction="Texas" if nm_state == "TX" else "New Mexico", state_code=nm_state,
                 permit_status="active", hse_classification="major", application_date=date(2022, 3, 1) + timedelta(days=fac * 40),
                 _anchor=date(2023, 1, 1))
    elif i < 37:
        nm = ["Falcon Draw SWD 1", "Red Mesa SWD 1", "Coyote Flats WI 1", "Mesquite Bend SWD 1"][i - 33]
        nm_state = "NM" if "Coyote" in nm else "TX"
        r.update(permit_type="injection_permit", subtype="UIC Class II disposal (Form H-1)" if nm_state == "TX" else "UIC Class II injection (C-108)",
                 title=f"Injection authority {nm}", permit_number=f"UIC-{nm_state}-{4400 + i}",
                 regulatory_authority_id=P("compliance.regulatory_authority", 2 if nm_state == "TX" else 4),
                 authorized_activity=f"Dispose produced water into {nm} (max 25,000 BWPD)", jurisdiction_level="state",
                 issuing_jurisdiction="Texas" if nm_state == "TX" else "New Mexico", state_code=nm_state,
                 permit_status="active", hse_classification="major", application_date=date(2015, 6, 1), _anchor=date(2016, 1, 1))
    elif i == 37:
        r.update(permit_type="pipeline_operation", subtype="Gathering line registration (49 CFR 195)",
                 title="Falcon Draw crude gathering system", permit_number="PHMSA-OPID-39xx1",
                 regulatory_authority_id=P("compliance.regulatory_authority", 6), jurisdiction_level="federal",
                 authorized_activity="Operate regulated crude gathering lines FD-01 to FD-08", permit_status="active",
                 hse_classification="critical", issuing_jurisdiction="United States", state_code="TX",
                 application_date=date(2021, 2, 1), _anchor=date(2021, 3, 1))
    else:
        nm = ["Red Mesa CTB-1", "Coyote Flats CTB-2"][i - 38]
        nm_state = "NM" if "Coyote" in nm else "TX"
        r.update(permit_type="flaring_authorisation", subtype="Statewide Rule 32 exception" if nm_state == "TX" else "Venting and flaring (19.15.27 NMAC)",
                 title=f"Flaring authorisation {nm}", permit_number=f"FLR-{nm_state}-{2025}-{100 + i}",
                 regulatory_authority_id=P("compliance.regulatory_authority", 2 if nm_state == "TX" else 4),
                 authorized_activity=f"Flare casinghead gas at {nm} during takeaway constraints", emission_limit_value=ctx.num(1500, 4000, 0),
                 emission_limit_unit="mcfd", jurisdiction_level="state", state_code=nm_state,
                 issuing_jurisdiction="Texas" if nm_state == "TX" else "New Mexico", permit_status="active",
                 hse_classification="major", application_date=date(2025, 1, 15), _anchor=date(2025, 2, 1))
    r.setdefault("permit_status", "active")
    r.update(country_code="US", fee_amount=ctx.num(375, 9500, 0), bond_amount=ctx.num(25000, 250000, 0), bond_currency="USD",
             is_transferable=False, is_reportable_to_sec=False, renewal_status="not_required",
             responsible_business_unit="Permian Operations", violation_count="0", geographic_area="Permian Basin",
             block_number=None, conditions_summary="Standard permit conditions apply; see document reference.")


def basin(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    name, code, kind, tect, status = BASINS[i]
    r.update(basin_name=name, basin_code=code, basin_type=kind, tectonic_setting=tect, basin_status=status,
             country_code="US", geographic_region="Permian Basin" if i < 3 else "West Texas", onshore_offshore_flag="onshore",
             area_sq_km=[26000, 19000, 13000, 8000, 21000, 3000][i], regulatory_authority_id=P("compliance.regulatory_authority", 2),
             regulatory_authority="Railroad Commission of Texas / NM OCD" if i == 0 else "Railroad Commission of Texas",
             primary_source_rock="Wolfcamp shale" if i < 2 else "Pennsylvanian shale",
             primary_reservoir_rock="Wolfcamp and Bone Spring" if i == 0 else ("Spraberry and Wolfcamp" if i == 1 else "Strawn carbonate"),
             trap_style="unconventional (continuous accumulation)" if i < 2 else "structural",
             exploration_maturity=["mature", "mature", "mature", "frontier", "frontier", "declining"][i],
             hydrocarbon_system_maturity="peak_mature" if i < 2 else "late_mature",
             infrastructure_maturity="mature" if i < 3 else "limited", fiscal_regime_type="royalty_tax",
             environmental_sensitivity="moderate" if i else "high", water_depth_min_ft=0.0, water_depth_max_ft=0.0,
             prms_classification_tier="2P" if i < 3 else "prospective", active_flag=status != "relinquished",
             ooip_mmbbl=[42000, 31000, 9000, 1200, 800, 150][i], ogip_bcf=[160000, 70000, 30000, 9000, 2500, 400][i],
             eur_mmboe=[9500, 7200, 1800, 120, 60, 5][i], well_count=str([28, 12, 0, 0, 0, 0][i]),
             play_count=str([5, 2, 1, 1, 1, 0][i]), prospect_count=str([14, 5, 1, 0, 0, 0][i]),
             lead_count=str(ctx.int_(2, 9)), discovery_count=str([9, 3, 0, 0, 0, 0][i]),
             business_unit="Permian Upstream", seismic_coverage_percent=[92, 85, 70, 25, 15, 40][i],
             last_assessment_date=date(2026, 3, 31), next_review_date=date(2027, 3, 31), _anchor=date(2026, 3, 31))


def block(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    f = FIELDS[i % 10]
    nm = f"{f[1]} Unit" if i < 10 else f"{NEW_PROSPECTS[i - 10]} Exploration Block"
    r.update(block_name=nm, block_number=f"BLK-{f[0] if i < 10 else 'EX'}-{i + 1:02d}", basin_id=P("exploration.basin", f[8] if i < 10 else 0),
             regulatory_authority_id=P("compliance.regulatory_authority", 4 if f[2] == "NM" and i < 10 else 2),
             country_code="US", offshore_onshore_flag="onshore", water_depth_min_m=0.0, water_depth_max_m=0.0,
             area_sq_km=ctx.num(12, 95), hydrocarbon_type="oil" if f[0] != "LB" else "gas", fiscal_regime_type="concession",
             working_interest_pct=ctx.pick([100.0, 87.5, 75.0, 62.5]), net_revenue_interest_pct=ctx.num(72, 80),
             royalty_rate_pct=ctx.pick([18.75, 20.0, 25.0]), discovery_flag=i < 12,
             prms_classification="proved" if i < 10 else ("contingent" if i < 12 else "prospective"),
             seismic_data_availability="3d_available", primary_target_formation="Wolfcamp A" if i % 3 else "2nd Bone Spring Sand",
             play_type="shale oil", effective_date=date(2018, 1, 1) + timedelta(days=i * 75),
             first_discovery_date=date(2019, 6, 1) + timedelta(days=i * 60) if i < 12 else None,
             minimum_work_program_well_count=str(ctx.int_(1, 4)), minimum_work_program_seismic_km=ctx.num(20, 150, 0),
             relinquishment_schedule="25% of undeveloped acreage at year 5" if i >= 10 else "held by production",
             well_count=str(ctx.int_(0, 8)), prospect_count=str(1), environmental_sensitivity_flag=i in (2, 6),
             resource_potential_boe=ctx.num(2e6, 60e6, 0), cost_recovery_limit_pct=None, remarks=None,
             last_seismic_survey_date=date(2021, 9, 1) + timedelta(days=i * 30), _anchor=date(2025, 1, 1))


def play(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    name, b, fcode, ptype, hc = PLAYS[i]
    r.update(play_name=name, play_code=f"PLY-{i + 1:02d}", basin_id=P("exploration.basin", b), formation_id=form(fcode),
             play_type=ptype, hydrocarbon_type=hc, play_status="active" if i < 6 else ctx.pick(["emerging", "dormant"]),
             reservoir_lithology="shale" if "Shale" in name else ("carbonate" if "Strawn" in name else "sandstone"),
             trap_style="unconventional" if ptype in ("shale_oil", "shale_gas", "unconventional") else "structural",
             seal_type="shale", seal_integrity="proven" if i < 6 else "probable", charge_risk="low" if i < 6 else "moderate",
             source_rock_formation="Wolfcamp shale", source_rock_maturity="peak_oil" if hc == "oil" else "gas",
             prms_resource_class="reserves" if i < 6 else "contingent", prms_maturity_subclass="2P" if i < 6 else "prospect",
             technical_maturity_level="mature" if i < 6 else "emerging", well_control_density="dense" if i < 6 else "sparse",
             reservoir_quality="good" if i < 6 else "fair", depth_range_top_ft=float(FORMATIONS[FORM_IDX[fcode]][5]),
             depth_range_base_ft=float(FORMATIONS[FORM_IDX[fcode]][5] + 900), average_net_pay_thickness_ft=ctx.num(120, 400, 0),
             average_porosity_percent=ctx.num(5, 10), average_permeability_md=ctx.num(0.0005, 0.01, 4),
             geological_chance_of_success_percent=ctx.num(70, 95) if i < 6 else ctx.num(15, 45),
             exploration_success_rate_percent=ctx.num(80, 98) if i < 6 else ctx.num(10, 40),
             risked_resource_estimate_mmboe=ctx.num(150, 900), unrisked_resource_estimate_mmboe=ctx.num(900, 3500),
             discovery_count=str(ctx.int_(1, 6) if i < 6 else 0), dry_hole_count=str(ctx.int_(0, 2)),
             migration_pathway="vertical migration from mature Wolfcamp source", trap_configuration="continuous accumulation",
             analogue_play_reference="Midland Wolfcamp" if i == 0 else "Delaware Wolfcamp", seismic_coverage_percent=ctx.num(60, 95),
             area_sq_miles=ctx.num(300, 4000, 0), identified_date=date(2012, 1, 1) + timedelta(days=i * 200),
             _anchor=date(2025, 6, 1))


def rig(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    name, contractor, eq = RIGS[i]
    r.update(rig_name=name, rig_number=f"R{101 + i}", rig_type="land", rig_class="AC triple, 1,500 hp, walking",
             api_rig_number=f"API-RIG-{8100 + i}", bsee_rig_code=None, imo_number=None, ownership_type="contracted",
             current_location=ctx.pick([f[1] for f in FIELDS[:8]]) + " pad", operating_region="Permian Basin",
             operational_status="drilling" if i < 9 else ctx.pick(["stacked", "moving"]),
             equipment_id=EQUIP_IDX.get(eq), asset_facility_id=P("asset.asset_facility", 19),
             drawworks_horsepower=1500.0, hook_load_capacity_lbs=750000.0, top_drive_capacity_tons=500.0,
             mud_pump_capacity_hp=ctx.pick([1600.0, 2200.0]), max_drilling_depth_ft=25000.0, derrick_height_ft=142.0,
             bop_pressure_rating_psi=10000.0, bop_stack_configuration="13-5/8 in 10M: annular + double ram + single ram",
             rated_water_depth_ft=0.0, dynamic_positioning_class="not_applicable", active_heave_compensation=False,
             build_year=str(2012 + i % 9), accommodation_capacity="0", registration_flag="US",
             variable_deck_load_capacity_lbs=None, rotary_table_size_in=27.5,
             latitude=ctx.num(31.3, 32.4), longitude=ctx.num(-104.1, -101.9),
             mobilization_date=date(2024, 1, 15) + timedelta(days=i * 40), demobilization_date=None,
             last_certification_date=date(2025, 8, 1) + timedelta(days=i * 11), next_certification_due_date=date(2026, 8, 1) + timedelta(days=i * 23),
             hse_rating=ctx.pick(["A", "A", "B"]), total_recordable_incident_rate=ctx.num(0.2, 1.4),
             _anchor=date(2025, 1, 1))
    r["contract_id"] = None
    r["_contractor"] = contractor


def prospect(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i < 10:
        f = FIELDS[i]
        nm, lat, lon, bidx, pidx, status = f[1], f[6], f[7], f[8], f[9], "drilled"
        fcode = RESERVOIRS[[k for k, (fi, _) in enumerate(RESERVOIRS) if fi == i][0]][1]
        blk = i
    else:
        nm = NEW_PROSPECTS[i - 10]
        lat, lon = round(31.05 + (i - 10) * 0.12, 2), round(-103.95 + (i - 10) * 0.06, 2)
        bidx, pidx = 0, [0, 0, 1, 3, 0, 0, 1, 2, 8, 0][i - 10]
        status = ["drilled", "drilled", "drilled", "drilled", "matured", "matured", "matured", "evaluated", "matured", "identified"][i - 10]
        fcode = ["WCA", "WCB", "BS2", "STRN", "WCA", "WCB", "BS3", "AVLN", "WCC", "WCA"][i - 10]
        blk = 10 + (i - 10) % 5
    p50 = ctx.num(8, 45)
    r.update(prospect_name=nm, prospect_code=f"PRS-{i + 1:03d}", basin_id=P("exploration.basin", bidx), play_id=P("exploration.play", pidx),
             block_id=P("exploration.block", blk), formation_id=form(fcode), prospect_status=status,
             maturity_level="drillable_prospect" if status in ("drilled", "matured") else "prospect",
             hydrocarbon_type="gas" if fcode == "STRN" else "oil", trap_type="stratigraphic",
             surface_latitude=lat, surface_longitude=lon, target_depth_tvd_ft=float(FORMATIONS[FORM_IDX[fcode]][5] + 250),
             eur_p90_mmboe=round(p50 * 0.55, 2), eur_p50_mmboe=p50, eur_p10_mmboe=round(p50 * 1.8, 2),
             stoiip_unrisked_mmboe=round(p50 * 9, 2), giip_unrisked_bcf=ctx.num(40, 400),
             geological_chance_of_success_pct=ctx.num(55, 92) if i < 14 else ctx.num(18, 48),
             prms_resource_class="2P" if i < 10 else ("contingent" if i < 12 else "prospective"),
             estimated_drill_cost_usd=ctx.num(6.5e6, 11.5e6, 0), water_depth_ft=0.0,
             asset_facility_id=P("asset.asset_facility", FACILITY_OF_FIELD[i]) if i < 10 else None,
             geophysicist_name=ctx.person(), interpretation_date=date(2023, 1, 10) + timedelta(days=i * 23),
             _anchor=date(2023, 6, 1))


def field(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    code, name, st, _, county, _, lat, lon, b, pl = FIELDS[i]
    r.update(field_code=f"FLD-{code}", field_name=name, basin_id=P("exploration.basin", b), play_id=P("exploration.play", pl),
             crude_grade_id=P("product.crude_grade", GRADE_OF_FIELD[i]), state_province=st, county=county, country_code="US",
             latitude=lat, longitude=lon, field_type="oil" if code != "LB" else "gas", field_status="producing",
             classification="unconventional", discovery_date=date(2019, 3, 1) + timedelta(days=i * 95),
             first_production_date=date(2020, 1, 1) + timedelta(days=i * 95), last_production_date=date(2026, 9, 29),
             current_production_bopd=ctx.num(2500, 22000, 0), cumulative_oil_produced=ctx.num(2e6, 28e6, 0),
             cumulative_gas_produced=ctx.num(5e6, 90e6, 0), gas_oil_ratio=ctx.num(1100, 4200, 0), water_cut_percent=ctx.num(35, 75),
             royalty_rate_percent=ctx.pick([18.75, 20.0, 25.0]), joint_venture_share_percent=ctx.pick([100.0, 75.0, 62.5]),
             depth_ft=str(FORMATIONS[FORM_IDX[RESERVOIRS[[k for k, (fi, _) in enumerate(RESERVOIRS) if fi == i][0]][1]]][5]),
             regulatory_status="compliant", reporting_status="current",
             field_description=f"{name} field ({county} County, {st}), operated by {OPERATOR}. Synthetic record.",
             notes=None, last_report_date=date(2026, 9, 1), _state=st, _county=county, _anchor=date(2026, 9, 1))


def reservoir(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    fi, fcode = RESERVOIRS[i]
    f = FIELDS[fi]
    fm = FORMATIONS[FORM_IDX[fcode]]
    top = float(fm[5] + (fi * 37) % 400)
    pi = round(top * ctx.num(0.55, 0.78), 0)
    r.update(reservoir_name=f"{f[1]} {fm[1]}", reservoir_code=f"RES-{f[0]}-{fcode}", formation_id=form(fcode),
             play_id=P("exploration.play", f[9]), reservoir_type="gas" if fcode == "STRN" else "oil",
             fluid_type="dry_gas" if fcode == "STRN" else ("volatile_oil" if fcode in ("WCB", "WCC") else "black_oil"),
             drive_mechanism="solution_gas", reservoir_status="active", top_depth_tvd_ft=top, base_depth_tvd_ft=top + ctx.num(250, 600, 0),
             datum_depth_ft=top + 150, initial_reservoir_pressure_psi=pi, current_reservoir_pressure_psi=round(pi * ctx.num(0.55, 0.85), 0),
             temperature_f=round(110 + top / 100, 1), average_porosity_percent=ctx.num(5, 10), average_permeability_md=ctx.num(0.0005, 0.02, 4),
             net_pay_thickness_ft=ctx.num(120, 380, 0), gross_thickness_ft=ctx.num(400, 900, 0), areal_extent_acres=ctx.num(8000, 42000, 0),
             ooip_mmbbl=ctx.num(250, 1400), stoiip_mmbbl=ctx.num(250, 1400), ogip_bcf=ctx.num(300, 2400), eur_mmboe=ctx.num(25, 160),
             recovery_factor_percent=ctx.num(6, 12), gor_scf_stb=ctx.num(900, 4500, 0), api_gravity=CRUDE_GRADES[GRADE_OF_FIELD[fi]][2],
             h2s_content_ppm=ctx.num(0, 15) if fcode != "STRN" else ctx.num(300, 1800), co2_content_percent=ctx.num(0.5, 4),
             wor_bbl_bbl=ctx.num(0.8, 3.5), prms_classification="2P", active_well_count=str(ctx.int_(2, 8)),
             discovery_date=date(2019, 3, 1) + timedelta(days=fi * 95), first_production_date=date(2020, 1, 1) + timedelta(days=fi * 95),
             gas_oil_contact_tvd_ft=None, oil_water_contact_tvd_ft=None, eor_program_type=None,
             last_simulation_date=date(2025, 10, 1), _anchor=date(2025, 10, 1))


def zone(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    ri, upper = i // 2, i % 2 == 0
    fi, fcode = RESERVOIRS[ri]
    fm = FORMATIONS[FORM_IDX[fcode]]
    top = float(fm[5] + (fi * 37) % 400 + (0 if upper else 220))
    r.update(zone_name=f"{FIELDS[fi][1]} {fm[1]} {'Upper' if upper else 'Lower'}", zone_code=f"Z-{FIELDS[fi][0]}-{fcode}-{'U' if upper else 'L'}",
             reservoir_id=P("reservoir.reservoir", ri), formation_id=form(fcode), zone_type="pay", zone_status="active",
             fluid_type="gas" if fcode == "STRN" else "oil", drive_mechanism="solution-gas", porosity_type="matrix",
             top_depth_tvd_ft=top, bottom_depth_tvd_ft=top + ctx.num(150, 230, 0), top_depth_md_ft=top + 20, bottom_depth_md_ft=top + 240,
             net_pay_thickness_ft=ctx.num(60, 200, 0), gross_thickness_ft=ctx.num(180, 240, 0), net_to_gross_ratio=ctx.num(0.55, 0.9),
             average_porosity_fraction=ctx.num(0.05, 0.10), average_water_saturation_fraction=ctx.num(0.25, 0.45),
             hydrocarbon_saturation_fraction=ctx.num(0.55, 0.75), average_permeability_md=ctx.num(0.0005, 0.02, 4),
             permeability_range_min_md=0.0001, permeability_range_max_md=0.05, reserves_category="PDP" if upper else "PUD",
             initial_reservoir_pressure_psi=round(top * 0.68, 0), current_reservoir_pressure_psi=round(top * 0.5, 0),
             primary_lithology=fm[4], lithology_description=fm[4], depositional_environment="deep-water basin floor",
             ooip_mmstb=ctx.num(80, 600), stoiip_mmstb=ctx.num(80, 600), ogip_bcf=ctx.num(100, 900), eur_mmstb=ctx.num(5, 60),
             recovery_factor_fraction=ctx.num(0.06, 0.12), discovery_date=date(2019, 3, 1) + timedelta(days=fi * 95),
             first_production_date=date(2020, 1, 1) + timedelta(days=fi * 95), eor_method=None,
             gas_oil_contact_tvd_ft=None, oil_water_contact_tvd_ft=None, gas_water_contact_tvd_ft=None, _anchor=date(2025, 10, 1))


def well_asset(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    w = WELLS[ASSETS[i]]
    d = well_dates(w)
    res, _ = well_reservoir_zone(w)
    fi = w.field
    name = w.name.upper() if w.idx == S.Q1_WELL else w.name   # register keeps an upper-case alias of the same well
    status = {"producing": "producing", "dry_hole": "plugged_and_abandoned", "suspended": "temporarily_abandoned",
              "injecting": "active_injection", "planned": "planned"}[w.result]
    wtype = ("disposal" if w.kind == "swd" else "dry_hole" if w.result == "dry_hole" else
             "suspended" if w.result == "suspended" else "producer")
    r.update(well_name=name, api_number=w.api("compact14"), well_type=wtype, well_status=status, permit_id=permit_of_well(w.idx),
             wellbore_trajectory="vertical" if w.kind == "swd" or w.kind == "wildcat" and w.result == "dry_hole" else "horizontal",
             surface_latitude=w.lat, surface_longitude=w.lon, spud_date=d["spud"] if w.kind != "swd" else w.spud,
             completion_date=d["completion"] if w.result in ("producing", "injecting") else None,
             first_production_date=d["first_prod"] if w.result == "producing" else None,
             plugged_abandoned_date=d["rig_release"] + timedelta(days=4) if w.result == "dry_hole" else None,
             total_depth_md=float(w.unique % 3000 + 19000) if w.kind != "swd" else 6200.0,
             total_depth_tvd=float(FORMATIONS[FORM_IDX[w.formation]][5] + 300),
             asset_facility_id=P("asset.asset_facility", facility_of_well(w.idx)) if facility_of_well(w.idx) is not None else None,
             reservoir_id=res, block_id=P("exploration.block", fi if fi is not None else 10 + (w.prospect - 10) % 5),
             crude_grade_id=P("product.crude_grade", GRADE_OF_FIELD[fi]) if fi is not None else P("product.crude_grade", 7),
             delivery_point_id=P("customer.delivery_point", [2, 1, 3, 12, 7, 8, 6, 10, 13, 11][fi]) if fi is not None else None,
             maximo_asset_number=f"WELL-{w.api10}", wellhead_equipment_tag=f"WH-{w.api10[-5:]}",
             artificial_lift_type=None, integrity_status="compliant" if w.idx not in (30, 45) else "remediation_required",
             reserves_category="PDP" if w.result == "producing" else ("unproved" if w.result == "dry_hole" else "PDNP"),
             environmental_classification="onshore", h2s_present_flag=w.formation == "STRN", norm_classification="low",
             working_interest_pct=ctx.pick([100.0, 87.5, 75.0]), net_revenue_interest_pct=ctx.num(70, 80),
             estimated_ultimate_recovery_boe=ctx.num(380000, 1150000, 0) if w.result == "producing" else 0.0,
             total_capex_usd=ctx.num(7.2e6, 11.8e6, 0) if w.kind != "swd" else ctx.num(2e6, 3.5e6, 0),
             asset_retirement_obligation_usd=ctx.num(90000, 180000, 0), capex_classification="drilling",
             dda_method="unit_of_production", record_status="active", regulatory_jurisdiction="NM OCD" if w.state == "NM" else "Texas RRC",
             data_source_system="fixed-asset register", last_inspection_date=date(2026, 4, 1) + timedelta(days=i * 3),
             next_inspection_due_date=date(2027, 4, 1) + timedelta(days=i * 3), _state=w.state, _county=w.county,
             _anchor=d["spud"] if w.spud else date(2026, 6, 1))


def well_program(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    planned = ["Red Mesa 13-4H", "Falcon Draw 12-1H", "Coyote Flats 16-1H", "Caliche 1"]
    if i < 21:
        w = WELLS[i]
        wn, fcode, prospect_i, status = w.name, w.formation, w.prospect, "executed"
        appr = w.spud - timedelta(days=30)
    else:
        wn = planned[i - 21]
        fcode = ["WCB", "WCA", "BS2", "WCA"][i - 21]
        prospect_i = [1, 0, 2, 14][i - 21]
        status = "approved" if i == S.PLANNED_PROGRAM else "draft"
        appr = date(2026, 9, 2) + timedelta(days=(i - 21) * 6)
    top = FORMATIONS[FORM_IDX[fcode]][5]
    r.update(program_name=f"Drilling and completion program - {wn}", program_number=f"WP-{appr.year}-{i + 1:03d}",
             program_type="drilling", program_status=status, prospect_id=P("exploration.prospect", prospect_i), formation_id=form(fcode),
             approval_date=appr if status != "draft" else None, approved_by=ctx.person() if status != "draft" else None,
             revision_number=str(ctx.int_(0, 3)), revision_date=appr, depth_uom="ft", planned_td_tvd=float(top + 300),
             planned_td_md=float(top + 300 + 10000), well_trajectory_type="horizontal", drilling_method="top_drive",
             rig_type_required="land", mud_system_type="oil_based", mud_weight_min=9.2,
             mud_weight_max=13.8 if fcode == "WCB" else 11.6, mud_weight_uom="ppg",
             max_anticipated_pressure_psi=float(round(top * (0.72 if fcode == "WCB" else 0.6))), max_anticipated_temperature_f=float(round(115 + top / 100)),
             hpht_classification="standard", h2s_present=fcode == "STRN", h2s_concentration_ppm=0.0, co2_present=False,
             completion_strategy="cased_hole", estimated_drilling_days=str(18 if fcode == "WCB" else 15), estimated_completion_days="14",
             bop_configuration="13-5/8 in 10M stack", bop_rating_psi="10000", max_inclination_angle=90.5, max_dogleg_severity=10.0,
             casing_design_summary="20 in conductor; 13-3/8 in surface below Rustler; 9-5/8 in intermediate below Castile/Bell Canyon; 5-1/2 in production to TD",
             cementing_program_summary="Two-stage intermediate with DV tool across Bell Canyon losses; lead/tail production cement to 500 ft above KOP",
             mwd_lwd_program="MWD gamma + azimuthal gamma in lateral; pressure-while-drilling across Wolfcamp B" if fcode == "WCB" else "MWD gamma",
             dst_planned=False, environmental_disposal_classification="non_hazardous", created_date=appr - timedelta(days=20),
             last_modified_date=appr, _anchor=appr)


def development_plan(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i < 10:
        f = FIELDS[i]
        nm, res = f"{f[1]} full-field development", [k for k, (fi, _) in enumerate(RESERVOIRS) if fi == i][0]
    else:
        nm, res = ["Javelina appraisal and early production", "Roadrunner appraisal"][i - 10], 10 if i == 10 else 1
    r.update(plan_name=nm, plan_code=f"FDP-{i + 1:02d}", reservoir_id=P("reservoir.reservoir", res),
             asset_facility_id=P("asset.asset_facility", FACILITY_OF_FIELD[i]) if i < 10 else None,
             crude_grade_id=P("product.crude_grade", GRADE_OF_FIELD[i] if i < 10 else 7), plan_type="full_field" if i < 10 else "phase",
             approval_status="approved" if i < 10 else "pending", plan_status="executing" if i < 10 else "under review",
             approval_date=date(2023, 5, 1) + timedelta(days=i * 30) if i < 10 else None, approved_by=ctx.person() if i < 10 else None,
             development_scenario="2-mile laterals, 6 wells per DSU, shared CTB", facility_type="onshore",
             planned_producer_count=str(ctx.int_(8, 40)), planned_injector_count="0", planned_observation_well_count=str(ctx.int_(0, 2)),
             development_capex_usd_mm=ctx.num(90, 650), development_opex_usd_mm=ctx.num(15, 120), npv10_usd_mm=ctx.num(60, 900),
             irr_percent=ctx.num(18, 55), payout_period_years=ctx.num(1.2, 3.5), oil_price_assumption_usd_bbl=70.0,
             gas_price_assumption_usd_mcf=2.75, eur_oil_mmbbl=ctx.num(10, 90), eur_gas_bcf=ctx.num(20, 260), eur_ngl_mmbbl=ctx.num(3, 25),
             plateau_rate_oil_bopd=ctx.num(5000, 30000, 0), plateau_rate_gas_mmcfd=ctx.num(10, 90), plateau_duration_years=ctx.num(1, 3),
             processing_capacity_bopd=ctx.num(10000, 40000, 0), processing_capacity_mmcfd=ctx.num(20, 120),
             recovery_factor_oil_percent=ctx.num(6, 12), recovery_factor_gas_percent=ctx.num(10, 20), prms_reserves_category="2p",
             sec_reserves_category="pud", environmental_impact_assessment_completed=True, regulatory_approval_required=i >= 10,
             first_production_date=date(2020, 1, 1) + timedelta(days=i * 95), development_drilling_start_date=date(2024, 2, 1) + timedelta(days=i * 25),
             eor_program_type=None, field_code=1000 + i, _anchor=date(2024, 1, 1))


def casing_design(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    prog, prod = i // 2, i % 2 == 1
    fcode = WELLS[prog].formation if prog < 21 else ["WCB", "WCA", "BS2", "WCA"][prog - 21]
    top = FORMATIONS[FORM_IDX[fcode]][5]
    failed = (not prod) and prog in (2, 9)   # intermediate cement problems on the stuck-pipe and kick wells
    r.update(well_program_id=P("drilling.well_program", prog), casing_string_number=str(2 if not prod else 3),
             casing_string_type="production" if prod else "intermediate", outer_diameter_in=5.5 if prod else 9.625,
             weight_per_foot_lb=23.0 if prod else 40.0, casing_grade="P-110 ICY" if prod else "HCL-80", connection_type="premium semi-flush" if prod else "BTC",
             setting_depth_md_ft=float(top + 10300) if prod else 5400.0, setting_depth_tvd_ft=float(top + 300) if prod else 5390.0,
             top_of_casing_md_ft=0.0, top_of_cement_md_ft=float(top - 1500) if prod else 0.0,
             formation_id=form(fcode) if prod else form("CHER"), burst_rating_psi=14530.0 if prod else 5750.0,
             collapse_rating_psi=14540.0 if prod else 3090.0, tension_rating_lb=729000.0 if prod else 916000.0,
             burst_design_factor=1.25, collapse_design_factor=1.125, tension_design_factor=1.6,
             design_status="installed" if prog < 21 else ("approved" if prog == S.PLANNED_PROGRAM else "planned"),
             bsee_approval_status="not_required", cement_job_type="primary", cement_bond_log_result=("poor" if failed else "good") if prog < 21 else "not_run",
             job_quality_assessment=("failed" if failed else "successful") if prog < 21 else "pending_evaluation",
             zonal_isolation_verified_flag=(not failed) if prog < 21 else False,
             cement_slurry_design="lead 11.5 ppg lightweight / tail 15.6 ppg class H" if not prod else "lead 12.5 ppg / tail 14.8 ppg acid-soluble",
             lead_cement_volume_bbl=ctx.num(180, 420, 0), tail_cement_volume_bbl=ctx.num(60, 140, 0),
             displacement_fluid_type="brine", displacement_volume_bbl=ctx.num(200, 450, 0), pump_rate_bpm=ctx.num(5, 9, 1),
             final_circulating_pressure_psi=ctx.num(900, 2600, 0), pressure_test_result_psi=ctx.num(1500, 5000, 0),
             pressure_test_duration_min="30", crude_grade_id=None, _anchor=WELLS[prog].spud if prog < 21 else date(2026, 10, 1))


def drilling_well(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i < 46:
        w, st = WELLS[DRILLED[i]], 0
    else:
        w, st = WELLS[SIDETRACK_OF[i - 46]], 1
    d = well_dates(w)
    res, _ = well_reservoir_zone(w)
    fi = w.field
    rig_i = (w.idx * 7) % 12 if w.idx != S.KICK_WELL else 3
    if st:
        d = {k: v + timedelta(days=9) for k, v in d.items()}
    r.update(well_name=w.name + (" ST01" if st else ""), api_well_number=w.api("dash14", st),
             parent_wellbore_drilling_well_id=drill_row_of_well(w.idx) if st else None,
             well_type="sidetrack" if st else {"wildcat": "exploration", "appraisal": "appraisal"}.get(w.kind, "development"),
             well_class={"dry_hole": "dry_hole", "suspended": "suspended"}.get(w.result, "gas" if w.formation == "STRN" else "oil"),
             well_status={"dry_hole": "plugged_and_abandoned", "suspended": "suspended"}.get(w.result, "completed"),
             trajectory_type="vertical" if w.result == "dry_hole" else "horizontal", directional_drilling_flag=w.result != "dry_hole",
             spud_date=d["spud"], rig_release_date=d["rig_release"], completion_date=d["completion"] if w.result == "producing" else None,
             plugged_abandoned_date=d["rig_release"] + timedelta(days=4) if w.result == "dry_hole" else None,
             surface_latitude=w.lat, surface_longitude=w.lon, bottom_hole_latitude=round(w.lat - 0.03, 2), bottom_hole_longitude=w.lon,
             measured_depth_ft=float(w.unique % 3000 + 19000) if w.result != "dry_hole" else float(FORMATIONS[FORM_IDX[w.formation]][5] + 400),
             true_vertical_depth_ft=float(FORMATIONS[FORM_IDX[w.formation]][5] + 300),
             total_depth_ft=float(w.unique % 3000 + 19000) if w.result != "dry_hole" else float(FORMATIONS[FORM_IDX[w.formation]][5] + 400),
             water_depth_ft=0.0, drilling_days_planned=float(15 if w.formation != "WCB" else 18),
             drilling_days_actual=float((d["td"] - d["spud"]).days + (6 if w.idx in (S.KICK_WELL, S.STUCK_WELL) else 0)),
             mud_system_type="oil_based", mwd_lwd_vendor=None, regulatory_jurisdiction="state_onshore",
             rig_id=P("drilling.rig", rig_i), formation_id=form(w.formation), reservoir_id=res, prospect_id=P("exploration.prospect", w.prospect),
             block_id=P("exploration.block", fi if fi is not None else 10 + (w.prospect - 10) % 5),
             development_plan_id=P("reservoir.development_plan", fi if fi is not None else (10 if w.prospect == 10 else 11)) if w.result != "dry_hole" else None,
             asset_facility_id=P("asset.asset_facility", facility_of_well(w.idx)) if facility_of_well(w.idx) is not None else None,
             well_asset_id=asset_row_of_well(w.idx), crude_grade_id=P("product.crude_grade", GRADE_OF_FIELD[fi]) if fi is not None else P("product.crude_grade", 7),
             delivery_point_id=None, permit_id=permit_of_well(w.idx),
             authorized_afe_amount_usd=ctx.num(7.0e6, 9.5e6, 0), total_drilling_cost_usd=ctx.num(6.8e6, 10.9e6, 0) * (1.25 if w.idx in (S.KICK_WELL, S.STUCK_WELL) else 1),
             initial_production_bopd=ctx.num(650, 2100, 0) if w.result == "producing" else 0.0,
             initial_production_mcfd=ctx.num(900, 4200, 0) if w.result == "producing" else 0.0,
             bop_test_date=d["spud"] + timedelta(days=2), dst_performed_flag=w.kind == "wildcat",
             casing_program_design="20 / 13-3/8 / 9-5/8 / 5-1/2 in", record_created_timestamp=datetime.combine(d["spud"] - timedelta(days=40), datetime.min.time()),
             _state=w.state, _county=w.county, _anchor=d["spud"])


def discovery(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i < 10:
        f = FIELDS[i]
        nm, pi, wi, bidx, pl, fcode = f"{f[1]} discovery", i, [0, 8, 15, 21, 26, 30, 33, 36, 38, 40][i], f[8], f[9], RESERVOIRS[[k for k, (fi, _) in enumerate(RESERVOIRS) if fi == i][0]][1]
        dd = date(2019, 3, 1) + timedelta(days=i * 95)
        status = "commercial"
    else:
        nm, pi, wi, bidx, pl, fcode = f"{NEW_PROSPECTS[i - 10]} discovery", i, 42 + (i - 10), 0, 0 if i == 10 else 0, ["WCA", "WCB"][i - 10]
        dd = WELLS[wi].spud + timedelta(days=30)
        status = "under_appraisal"
    p50 = ctx.num(6, 40)
    w = WELLS[wi]
    r.update(discovery_name=nm, discovery_code=f"DSC-{i + 1:02d}", discovery_date=dd, discovery_status=status,
             commerciality_status="commercial" if i < 10 else "under_evaluation", prospect_id=P("exploration.prospect", pi),
             play_id=P("exploration.play", pl), basin_id=P("exploration.basin", bidx), block_id=P("exploration.block", pi if i < 10 else 10 + (i - 10)),
             formation_id=form(fcode), well_asset_id=asset_row_of_well(wi), crude_grade_id=P("product.crude_grade", GRADE_OF_FIELD[i] if i < 10 else 7),
             asset_facility_id=P("asset.asset_facility", FACILITY_OF_FIELD[i]) if i < 10 else None, hydrocarbon_type="oil",
             fluid_type_detail="volatile oil with associated gas", api_gravity=ctx.num(39, 46, 1), gor_scf_stb=ctx.num(1100, 3800, 0),
             depth_tvd_ft=float(FORMATIONS[FORM_IDX[fcode]][5] + 300), depth_md_ft=float(w.unique % 3000 + 19000), water_depth_ft=0.0,
             net_pay_thickness_ft=ctx.num(120, 350, 0), porosity_percent=ctx.num(5, 10), permeability_md=ctx.num(0.0005, 0.02, 4),
             hydrocarbon_saturation_percent=ctx.num(55, 75), initial_reservoir_pressure_psi=float(round(FORMATIONS[FORM_IDX[fcode]][5] * 0.68)),
             reservoir_temperature_f=float(round(115 + FORMATIONS[FORM_IDX[fcode]][5] / 100)),
             initial_production_rate_bopd=ctx.num(700, 2200, 0), initial_production_rate_mcfd=ctx.num(1000, 4500, 0),
             eur_p90_mmboe=round(p50 * 0.5, 2), eur_p50_mmboe=p50, eur_p10_mmboe=round(p50 * 1.9, 2), stoiip_mmbbl=round(p50 * 10, 1),
             giip_bcf=ctx.num(60, 600), recovery_factor_percent=ctx.num(6, 11), prms_resource_class="2P" if i < 10 else "contingent",
             prms_maturity_subclass="on production" if i < 10 else "development pending", country_code="US", _anchor=dd)


def exploration_well(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    w = WELLS[EXPLORATION[i]]
    d = well_dates(w)
    fi = w.field
    planned = w.kind == "planned"
    result = {"dry_hole": "dry_hole", "suspended": "shows", "planned": None}.get(w.result, "discovery" if w.kind in ("wildcat",) or w.kind == "appraisal" and w.idx in (0, 8, 15, 21, 26, 30, 33, 36, 38, 40) else "technical_success")
    r.update(well_name=w.name, api_number=w.api("dash10"),
             well_type="wildcat" if w.kind in ("wildcat", "planned") else "appraisal", well_status="planned" if planned else ("plugged and abandoned" if w.result == "dry_hole" else "completed"),
             well_result=result, prospect_id=P("exploration.prospect", w.prospect), basin_id=P("exploration.basin", FIELDS[fi][8] if fi is not None else 0),
             formation_id=form(w.formation), rig_id=None if planned else P("drilling.rig", (w.idx * 7) % 12 if w.idx != S.KICK_WELL else 3),
             well_asset_id=None if planned else asset_row_of_well(w.idx), permit_id=permit_of_well(w.idx), crude_grade_id=P("product.crude_grade", GRADE_OF_FIELD[fi]) if fi is not None else None,
             asset_facility_id=P("asset.asset_facility", FACILITY_OF_FIELD[fi]) if fi is not None else None,
             spud_date=None if planned else d["spud"], td_date=None if planned else d["td"], surface_latitude=w.lat, surface_longitude=w.lon,
             bottom_hole_latitude=round(w.lat - 0.03, 2), bottom_hole_longitude=w.lon, environment_type="onshore", water_depth=0.0,
             trajectory_type="vertical" if w.kind in ("wildcat", "planned") else "horizontal", depth_uom="feet",
             planned_tvd_depth=float(FORMATIONS[FORM_IDX[w.formation]][5] + 300), planned_td_depth=float(FORMATIONS[FORM_IDX[w.formation]][5] + 600),
             actual_tvd_depth=None if planned else float(FORMATIONS[FORM_IDX[w.formation]][5] + 300),
             actual_md_depth=None if planned else float(FORMATIONS[FORM_IDX[w.formation]][5] + 600 if w.kind == "wildcat" else w.unique % 3000 + 19000),
             drilling_days=None if planned else str((d["td"] - d["spud"]).days), npt_days=None if planned else ctx.num(0, 4, 1),
             estimated_cost=ctx.num(5.5e6, 9e6, 0), actual_cost=None if planned else ctx.num(5.8e6, 10.5e6, 0),
             hydrocarbon_type="none" if w.result == "dry_hole" else ("gas" if w.formation == "STRN" else "oil"),
             dst_performed_flag=w.kind == "wildcat" and not planned, dst_fluid_type="water" if w.result == "dry_hole" else "oil",
             dst_flow_rate=None if planned else ctx.num(150, 1200, 0), dst_shut_in_pressure=None if planned else ctx.num(4000, 8500, 0),
             net_pay_thickness=None if planned or w.result == "dry_hole" else ctx.num(80, 300, 0), gross_pay_thickness=None if planned else ctx.num(200, 600, 0),
             api_gravity=None if planned or w.result == "dry_hole" else ctx.num(39, 47, 1), gor=None if planned else ctx.num(1000, 4000, 0),
             h2s_content_ppm=ctx.num(200, 900) if w.formation == "STRN" else 0.0, co2_content_percent=ctx.num(0.5, 3),
             objective=f"Test {FORMATIONS[FORM_IDX[w.formation]][1]} at {w.name}" + (" - first well on the prospect" if w.kind != "appraisal" else " - appraisal of the discovery"),
             pay_zone_summary=None if planned else ("No moveable hydrocarbons; wet sands with residual oil shows." if w.result == "dry_hole" else
                                                   f"{FORMATIONS[FORM_IDX[w.formation]][1]} pay with oil shows across the interval; see well test."),
             recommendation=None if planned else ("Plug and abandon; downgrade the Salt Cedar Bone Spring prospect." if w.result == "dry_hole" else
                                                  ("Suspend pending gas takeaway and sour-gas treating economics." if w.result == "suspended" else "Proceed to development / extended production test.")),
             state_province=w.state, country_code="US", permit_issue_date=(w.spud or date(2026, 8, 1)) - timedelta(days=60),
             permit_expiry_date=(w.spud or date(2026, 8, 1)) + timedelta(days=670), _state=w.state, _anchor=w.spud or date(2026, 8, 1))


def production_well(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    w = WELLS[PRODUCING[i]]
    d = well_dates(w)
    res, zn = well_reservoir_zone(w)
    fi = w.field
    unique = w.unique + API_TYPO.get(w.idx, 0)
    api10 = f"{w.state_api}{w.county_api}{unique:05d}"
    r.update(well_name=w.name, api_number=api10, uwi=f"{api10}0000", field_id=P("production.field", fi) if fi is not None else None,
             reservoir_id=res, zone_id=zn, formation_id=form(w.formation), play_id=P("exploration.play", FIELDS[fi][9]) if fi is not None else P("exploration.play", 0),
             prospect_id=P("exploration.prospect", w.prospect), crude_grade_id=P("product.crude_grade", GRADE_OF_FIELD[fi]) if fi is not None else P("product.crude_grade", 7),
             permit_id=P("compliance.permit", 33 + [54, 55, 56, 57].index(w.idx)) if w.kind == "swd" else None,
             well_status="injecting" if w.kind == "swd" else "producing", wellbore_type="vertical" if w.kind == "swd" else "horizontal",
             artificial_lift_type=None, spud_date=w.spud if w.kind in ("swd", "legacy") else d["spud"],
             completion_date=(w.spud + timedelta(days=60)) if w.kind in ("swd", "legacy") else d["completion"],
             first_production_date=(w.spud + timedelta(days=75)) if w.kind == "legacy" else (None if w.kind == "swd" else d["first_prod"]),
             surface_latitude=w.lat, surface_longitude=w.lon, bottom_hole_latitude=round(w.lat - 0.03, 2), bottom_hole_longitude=w.lon,
             measured_depth_ft=6200.0 if w.kind == "swd" else float(w.unique % 3000 + 19000),
             true_vertical_depth_ft=float(FORMATIONS[FORM_IDX[w.formation]][5] + 300), lateral_length_ft=None if w.kind == "swd" else ctx.num(9500, 10600, 0),
             initial_production_bopd=0.0 if w.kind == "swd" else ctx.num(650, 2100, 0), initial_production_mcfd=0.0 if w.kind == "swd" else ctx.num(900, 4200, 0),
             current_production_bopd=0.0 if w.kind == "swd" else ctx.num(120, 900, 0), current_production_mcfd=0.0 if w.kind == "swd" else ctx.num(300, 2600, 0),
             cumulative_oil_bbls=0.0 if w.kind == "swd" else ctx.num(40000, 420000, 0), cumulative_gas_mcf=0.0 if w.kind == "swd" else ctx.num(80000, 950000, 0),
             water_cut_percent=ctx.num(35, 75), gor_scf_bbl=ctx.num(900, 4500, 0), wor_ratio=ctx.num(0.6, 3.5),
             injection_type="saltwater_disposal" if w.kind == "swd" and w.field != 2 else ("waterflood" if w.kind == "swd" else None),
             injection_rate_bpd=ctx.num(8000, 22000, 0) if w.kind == "swd" else None, permitted_injection_rate_bpd=25000.0 if w.kind == "swd" else None,
             injection_rate_mcfd=None, uic_permit_number=f"UIC-{w.state}-{4400 + 33 + [54, 55, 56, 57].index(w.idx)}" if w.kind == "swd" else None,
             working_interest_percent=ctx.pick([100.0, 87.5, 75.0]), net_revenue_interest_percent=ctx.num(70, 80),
             regulatory_district="RRC District 8" if w.state == "TX" else "OCD District 1" if w.county == "Lea" else "OCD District 2",
             _state=w.state, _anchor=d["first_prod"] if w.spud else date(2026, 1, 1))


def reserves_estimate(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i < 38:
        widx = [k for k in range(44) if k != 30][i]
        w = WELLS[widx]
        res, _ = well_reservoir_zone(w)
        cat, sub = "1P", "PDP"
        wa = asset_row_of_well(widx)
        fi = w.field
        res = res or P("reservoir.reservoir", 10 if widx == 42 else 1)
        label = w.name
    else:
        k = i - 38
        res = P("reservoir.reservoir", k)
        cat, sub = ("2P", "PUD") if k % 2 == 0 else ("3P", "PUD")
        wa, fi, label = None, RESERVOIRS[k][0], f"reservoir {RESERVOIRS[k]}"
    proved = ctx.num(180, 650, 0) if cat == "1P" else ctx.num(2500, 9000, 0)
    r.update(estimate_number=f"RSV-2025-{i + 1:03d}", reservoir_id=res, well_asset_id=wa, reserves_category=cat, reserves_sub_category=sub,
             estimation_method="decline_curve" if cat == "1P" else "volumetric", booking_status="approved", effective_date=date(2025, 12, 31),
             certification_date=date(2026, 2, 15), reserves_volume_uom="BOE" if cat == "1P" else "BOE", eur_uom="BOE",
             proved_reserves_volume=proved * 1000 if cat == "1P" else proved * 1000, probable_reserves_volume=proved * 600 if cat != "1P" else None,
             possible_reserves_volume=proved * 300 if cat == "3P" else None, p90_reserves_volume=proved * 850, p50_reserves_volume=proved * 1000,
             p10_reserves_volume=proved * 1350, net_reserves_volume=round(proved * 1000 * 0.77), eur=proved * 1000 * 1.4,
             recovery_factor=ctx.num(0.06, 0.11), discount_rate=10.0, npv=ctx.num(2e6, 9e6, 0) if cat == "1P" else ctx.num(30e6, 180e6, 0),
             npv_currency="USD", price_currency="USD", sec_price_per_unit=71.2, sec_pricing_method="12_month_average",
             revision_type="technical" if i % 7 == 3 else "none", revision_reason="Faster-than-forecast decline; type curve lowered 8%." if i % 7 == 3 else None,
             comments=f"Year-end 2025 SPE-PRMS / SEC booking for {label} (synthetic).",
             asset_facility_id=P("asset.asset_facility", FACILITY_OF_FIELD[fi]) if fi is not None else None,
             crude_grade_id=P("product.crude_grade", GRADE_OF_FIELD[fi]) if fi is not None else None, field_code=1000 + (fi or 0),
             economic_limit_date=date(2045, 12, 31), forecast_production_profile="hyperbolic b=1.1, Di=72%/yr, terminal 6%",
             _anchor=date(2026, 1, 15))


def cementing_job(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i < 46:
        w, remedial = WELLS[DRILLED[i]], False
    else:
        w, remedial = WELLS[[2, 9, 17, 23][i - 46]], True
    d = well_dates(w)
    prog = w.idx if w.idx < 21 else None
    bad = w.idx in (2, 9) and not remedial
    start = datetime.combine(d["td"] + timedelta(days=1 if not remedial else 4), datetime.min.time()) + timedelta(hours=ctx.int_(2, 20))
    _, zn = well_reservoir_zone(w)
    r.update(job_number=f"CMT-{d['td'].year}-{i + 1:03d}", job_type="squeeze" if remedial else "primary",
             drilling_well_id=drill_row_of_well(w.idx), casing_design_id=P("drilling.casing_design", prog * 2 + (0 if (remedial or bad) else 1)) if prog is not None else None,
             rig_id=P("drilling.rig", (w.idx * 7) % 12 if w.idx != S.KICK_WELL else 3), well_asset_id=asset_row_of_well(w.idx), zone_id=zn,
             equipment_id=None, job_start_timestamp=start, job_end_timestamp=start + timedelta(hours=7 if not remedial else 5),
             job_duration_hours=7.0 if not remedial else 5.0, job_status="completed",
             job_quality_assessment="requires_remediation" if bad else ("successful" if not remedial or i != 47 else "marginal"),
             cement_bond_quality="poor" if bad else "good", cement_bond_log_run_flag=True, zonal_isolation_achieved_flag=not bad,
             top_of_cement_planned_md_ft=float(FORMATIONS[FORM_IDX[w.formation]][5] - 1500), top_of_cement_actual_md_ft=float(FORMATIONS[FORM_IDX[w.formation]][5] - (300 if bad else 1550)),
             casing_shoe_depth_md_ft=5400.0 if bad or remedial else float(w.unique % 3000 + 19000), casing_shoe_depth_tvd_ft=5390.0 if bad or remedial else float(FORMATIONS[FORM_IDX[w.formation]][5] + 300),
             lead_slurry_type="lightweight extended" if not remedial else "squeeze slurry", lead_slurry_density_ppg=11.8 if not remedial else 15.8,
             lead_slurry_volume_bbl=ctx.num(180, 400, 0) if not remedial else ctx.num(25, 60, 0), tail_slurry_type="class H acid-soluble",
             tail_slurry_density_ppg=15.6, tail_slurry_volume_bbl=ctx.num(60, 130, 0), spacer_volume_bbl=ctx.num(40, 80, 0),
             displacement_fluid_type="brine", displacement_fluid_volume_bbl=ctx.num(250, 450, 0), pump_rate_bpm=ctx.num(5, 9, 1),
             max_pump_pressure_psi=ctx.num(2500, 4800, 0), final_circulating_pressure_psi=ctx.num(900, 2600, 0), plug_bump_pressure_psi=ctx.num(1500, 3500, 0),
             cement_compressive_strength_psi=ctx.num(1800, 3600, 0), wait_on_cement_hours=ctx.num(8, 14, 1),
             actual_cost_usd=ctx.num(95000, 240000, 0) if not remedial else ctx.num(60000, 140000, 0),
             remarks=("Losses to Bell Canyon during displacement; top of cement 1,250 ft low. Remedial squeeze required." if bad else
                      ("Remedial squeeze across Bell Canyon after poor CBL; isolation confirmed by second CBL." if remedial else "Full returns; plug bumped.")),
             bsee_reporting_required_flag=False, bsee_report_submitted_flag=False, _anchor=start)


def well_status_history(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    seq = [("PERMITTED", "APD approved"), ("SPUDDED", "conductor set, rig on location"), ("DRILLING", "surface casing set"),
           ("TD", "total depth reached"), ("COMPLETED", "stimulation complete"), ("PRODUCING", "first sales")]
    wells = [0, 2, 9, 30, 42, 44, 45, 1, 8]
    k = i // 6 if i < 54 else 0
    w = WELLS[wells[min(k, len(wells) - 1)]]
    step = i % 6
    st, why = seq[step]
    d = well_dates(w)
    when = [d["spud"] - timedelta(days=45), d["spud"], d["spud"] + timedelta(days=2), d["td"], d["completion"], d["first_prod"]][step]
    if w.result == "dry_hole" and step >= 4:
        st, why, when = ("PLUGGED_ABANDONED", "dry hole, no moveable hydrocarbons", d["rig_release"] + timedelta(days=4)) if step == 4 else ("RELEASED", "location restored", d["rig_release"] + timedelta(days=40))
    if w.result == "suspended" and step >= 4:
        st, why = ("SUSPENDED", "awaiting sour-gas treating" if w.idx == 45 else "mechanical issue: parted casing at 8,950 ft") if step == 4 else ("TEMPORARILY_ABANDONED", "TA status filed")
    if w.idx == S.STUCK_WELL and step == 3:
        st, why = "SIDETRACK", "stuck pipe in Salado washout; fish left in hole, sidetrack ST01 kicked off"
    r.update(drilling_well_id=drill_row_of_well(w.idx), well_asset_id=asset_row_of_well(w.idx), reservoir_id=well_reservoir_zone(w)[0],
             event_sequence_number=str(step + 1), event_type="permit_event" if step == 0 else "status_change", status_code=st,
             previous_status_code=None if step == 0 else seq[step - 1][0], status_change_reason=why, effective_date=min(when, AS_OF),
             event_timestamp=datetime.combine(min(when, AS_OF), datetime.min.time()) + timedelta(hours=9),
             regulatory_notification_date=min(when + timedelta(days=1), AS_OF), regulatory_notification_method="electronic_filing",
             authorizing_engineer_name=ctx.person(), operator_code=1001, data_source_system="drilling data store",
             bsee_reportable_flag=False, bsee_incident_number=None, sec_reserves_impact_flag=st in ("PRODUCING", "PLUGGED_ABANDONED"),
             reserves_category_before="PUD" if st == "PRODUCING" else None, reserves_category_after="PDP" if st == "PRODUCING" else None,
             permit_conditions="Standard RRC/OCD conditions" if step == 0 else None, bond_amount_usd=None,
             event_remarks=f"{w.name}: {why}.", _anchor=min(when, AS_OF))


DDR_WELLS = [S.KICK_WELL, S.STUCK_WELL, 8, 42, 44]


def daily_drilling_report(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    w = WELLS[DDR_WELLS[i // 10]]
    day = i % 10
    d = well_dates(w)
    rd = d["spud"] + timedelta(days=day + 1)
    depth = min(1000 + day * 1900, FORMATIONS[FORM_IDX[w.formation]][5] + (0 if w.result == "dry_hole" else 9000) + 400)
    depth = {(S.KICK_WELL, 7): 11420, (S.STUCK_WELL, 1): 2050, (8, 2): 4480, (44, 5): 6900}.get((w.idx, day), depth)
    form_now = max((f for f in FORMATIONS if f[5] <= depth and (f[0] not in ("USPB", "LSPB", "DEAN"))), key=lambda f: f[5])
    npt, summary, inc = 0.0, f"Drilled {form_now[1]} from {max(depth - 2100, 0):,} to {depth:,} ft MD; ROP steady, no losses.", None
    if w.idx == S.KICK_WELL and day == 7:
        npt, summary = 31.5, ("Drilling Wolfcamp B at 11,420 ft MD: 18 bbl pit gain, flow check positive. Shut in on annular, SIDPP 650 psi, "
                              "SICP 980 psi. Killed with wait-and-weight, MW raised 12.4 to 13.6 ppg. Gas to flare during circulation.")
    elif w.idx == S.STUCK_WELL and day == 1:
        npt, summary = 46.0, ("Tight hole and washout in Salado salt at 2,050 ft; pipe stuck while back-reaming. Jarred 6 h, spotted pipe "
                              "freeing pill, no success. Backed off; fish left in hole. Plan sidetrack.")
    elif w.idx == 8 and day == 2:
        npt, summary = 14.0, "Total losses in Bell Canyon at 4,480 ft; pumped 3 LCM pills, regained 70% returns, drilled ahead with reduced ECD."
    elif w.idx == 44 and day == 5:
        npt, summary = 9.5, "Top drive failure (hydraulic leak at IBOP actuator) at 6,900 ft; changed actuator, pressure tested."
    if w.idx == S.KICK_WELL and day == 7:
        inc = P("hse.incident", S.INC_KICK)
    r.update(report_number=f"DDR-{w.name.replace(' ', '')}-{day + 1:03d}", report_date=rd, drilling_well_id=drill_row_of_well(w.idx),
             rig_id=P("drilling.rig", (w.idx * 7) % 12 if w.idx != S.KICK_WELL else 3), well_asset_id=asset_row_of_well(w.idx),
             formation_id=form(form_now[0]), zone_id=well_reservoir_zone(w)[1] if form_now[0] == w.formation else None, incident_id=inc,
             measured_depth_ft=float(depth), true_vertical_depth_ft=float(min(depth, FORMATIONS[FORM_IDX[w.formation]][5] + 300)),
             depth_drilled_ft=float(0 if npt > 20 else 2100), formation_top_depth_ft=float(form_now[5]),
             non_productive_time_hours=npt, productive_time_hours=round(24 - min(npt, 24), 1),
             npt_category={31.5: "well control", 46.0: "stuck pipe", 14.0: "lost circulation", 9.5: "equipment failure"}.get(npt),
             operations_summary=summary, operation_status="drilling" if npt == 0 else "non-productive",
             mud_type="oil_based" if depth > 5400 else "water_based", mud_weight_ppg=13.6 if w.idx == S.KICK_WELL and day >= 7 else (10.0 if depth > 5400 else 9.2),
             mud_viscosity_seconds=ctx.num(45, 70, 0), equivalent_circulating_density_ppg=ctx.num(10.2, 14.1),
             rate_of_penetration_ft_per_hr=0.0 if npt > 20 else ctx.num(60, 210, 0), weight_on_bit_klbs=ctx.num(18, 45, 0),
             rotary_speed_rpm=ctx.num(80, 160, 0), torque_ft_lbs=ctx.num(9000, 26000, 0), standpipe_pressure_psi=ctx.num(2800, 4800, 0),
             flow_rate_gpm=ctx.num(500, 750, 0), hookload_klbs=ctx.num(180, 420, 0), bit_depth_in_ft=float(max(depth - 2100, 0)), bit_depth_out_ft=float(depth),
             daily_cost_usd=ctx.num(72000, 96000, 0) + npt * 4200, cumulative_cost_usd=ctx.num(80000, 95000, 0) * (day + 1),
             afe_variance_usd=npt * 4200, crew_on_board_count=str(ctx.int_(18, 26)), hse_incidents_count="1" if npt in (31.5,) else "0",
             bop_test_date=d["spud"] + timedelta(days=2), bop_test_pressure_psi=10000.0, permit_to_work_id=None, _anchor=rd)


def well_control_event(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    # 0: planted kick on the KICK_WELL; others: kicks in Wolfcamp B / Castile brine flows / losses
    kinds = ["kick"] * 9 + ["lost_circulation"] * 8 + ["influx"] * 5 + ["well_integrity_failure"] * 3
    if i == 0:
        w, kind = WELLS[S.KICK_WELL], "kick"
    else:
        kind = kinds[i]
        w = WELLS[(WCB_WELLS + [8, 10, 2, 15, 16, 21, 33, 36] + [3, 6, 22, 31, 35] + [2, 9, 17])[i - 1]]
    d = well_dates(w)
    fcode = {"kick": "WCB", "lost_circulation": ctx.pick(["BELL", "CHER"]), "influx": "CAST", "well_integrity_failure": w.formation}[kind]
    when = datetime.combine(d["spud"] + timedelta(days=7 if fcode == "WCB" else 3), datetime.min.time()) + timedelta(hours=ctx.int_(0, 23))
    md = 11420.0 if i == 0 else float(FORMATIONS[FORM_IDX[fcode]][5] + ctx.int_(50, 400))
    gain = 18.0 if i == 0 else (ctx.num(5, 25, 1) if kind in ("kick", "influx") else 0.0)
    sev = "major" if i == 0 else ("moderate" if kind == "kick" else "minor")
    ddr = P("drilling.daily_drilling_report", 7) if i == 0 else (P("drilling.daily_drilling_report", 22) if w.idx == 8 and kind == "lost_circulation" else None)
    r.update(event_number=f"WCE-{when.year}-{i + 1:04d}", event_type=kind, event_category="well control" if kind != "lost_circulation" else "lost circulation",
             event_severity=sev, event_status="closed", event_timestamp=when, event_end_timestamp=when + timedelta(hours=31.5 if i == 0 else ctx.num(3, 14, 1)),
             duration_hours=31.5 if i == 0 else ctx.num(3, 14, 1), drilling_well_id=drill_row_of_well(w.idx), daily_drilling_report_id=ddr,
             rig_id=P("drilling.rig", (w.idx * 7) % 12 if w.idx != S.KICK_WELL else 3), well_asset_id=asset_row_of_well(w.idx),
             zone_id=well_reservoir_zone(w)[1] if fcode == w.formation else None, measured_depth_ft=md, true_vertical_depth_ft=min(md, 11400.0) if fcode == "WCB" else md,
             influx_type="gas" if kind in ("kick", "influx") and fcode != "CAST" else ("water" if fcode == "CAST" else "unknown"),
             influx_volume_bbl=gain, pit_gain_volume_bbl=gain, sidpp_psi=650.0 if i == 0 else (ctx.num(150, 600, 0) if kind == "kick" else None),
             sicp_psi=980.0 if i == 0 else (ctx.num(300, 900, 0) if kind == "kick" else None), kill_method=("wait_and_weight" if i == 0 else "drillers_method") if kind == "kick" else None,
             kill_mud_weight_ppg=13.6 if i == 0 else (ctx.num(12.8, 13.9) if kind == "kick" else None), kill_fluid_volume_bbl=ctx.num(300, 900, 0) if kind == "kick" else None,
             formation_pressure_psi=float(round(md * 0.69)) if kind == "kick" else None, choke_manifold_pressure_psi=ctx.num(400, 1100, 0) if kind == "kick" else None,
             bop_activation_method="manual" if kind in ("kick", "influx") else None, bop_configuration="13-5/8 in 10M annular + rams",
             iadc_code={"kick": "WC-KICK", "lost_circulation": "LC", "influx": "WC-FLOW", "well_integrity_failure": "WI"}[kind],
             environmental_release_flag=i == 0, injury_count="0", personnel_evacuated_count="0" if i else "6",
             estimated_cost_impact_usd=412000.0 if i == 0 else ctx.num(25000, 180000, 0),
             root_cause=("Wolfcamp B pore pressure ramp encountered 300 ft shallower than the offset-well model; trip sheet not updated during connection."
                         if i == 0 else {"kick": "Underbalanced at the Wolfcamp B pressure transition.", "lost_circulation": "Fractured Bell/Cherry Canyon sands with high ECD.",
                                         "influx": "Castile brine pocket with trace H2S.", "well_integrity_failure": "Micro-annulus after poor cement bond."}[kind]),
             corrective_action_taken="Shut in on annular, killed with wait-and-weight, raised MW to 13.6 ppg, flared gas under monitoring." if i == 0 else
             {"kick": "Shut in, circulated out with driller's method, weighted up.", "lost_circulation": "Pumped LCM, reduced pump rate.", "influx": "Weighted up, H2S monitoring.",
              "well_integrity_failure": "Squeeze cemented, pressure tested."}[kind],
             preventive_measures=("Update the Wolfcamp B pressure model from offsets; run pressure-while-drilling and set MW 13.4 ppg before the transition; "
                                  "enforce trip-sheet checks at every connection." if i == 0 else "Apply offset-well lessons in the next program."),
             responsible_party="operator", bsee_reportable_flag=False, bsee_incident_number=None, bsee_notification_timestamp=None,
             wellbore_code=int(w.api10[-5:]), _anchor=when)
    r["incident_id"] = P("hse.incident", S.INC_KICK) if i == 0 else None
    r["process_safety_event_id"] = P("hse.process_safety_event", S.PSE_KICK) if i == 0 else None
    r["violation_id"] = P("compliance.violation", S.VIO_KICK) if i == 0 else None


NPT_PLAN = (
    # (category, formation, count, hours range, iadc, responsible)
    [("well control", "WCB", 9, (8, 34), "WC", "operator")] +
    [("lost circulation", "BELL", 9, (6, 22), "LC", "operator")] +
    [("stuck pipe", "SALD", 7, (10, 46), "SP", "operator")] +
    [("lost circulation", "CHER", 5, (4, 14), "LC", "operator")] +
    [("wellbore instability", "WCA", 6, (5, 18), "WBI", "operator")] +
    [("equipment failure - top drive", None, 5, (4, 12), "EQ-TD", "drilling_contractor")] +
    [("equipment failure - mud pump", None, 3, (3, 9), "EQ-MP", "drilling_contractor")] +
    [("remedial cementing", "BELL", 4, (18, 40), "CMT", "service_provider")] +
    [("waiting on weather", None, 2, (6, 14), "WOW", "force_majeure")]
)
NPT_ROWS = [(c, f, h, code, resp) for c, f, n, h, code, resp in NPT_PLAN for _ in range(n)]

LESSONS = {
    "well control": "Treat the Wolfcamp B transition as a high-risk interval: raise MW before the top, run pressure-while-drilling and keep trip-sheet discipline.",
    "lost circulation": "Pre-treat the active system with LCM before entering Bell/Cherry Canyon and keep ECD under 10.4 ppg; consider managed pressure drilling.",
    "stuck pipe": "Use saturated-salt or oil-based mud through the Salado, minimise back-reaming and keep the string moving at connections.",
    "wellbore instability": "Control ROP in the curve, ream each stand and keep MW above the shale collapse gradient in Wolfcamp A.",
    "equipment failure - top drive": "Top drive IBOP actuator leaks repeat on Rig R104; add actuator inspection to the 500-hour PM and stock spares on location.",
    "equipment failure - mud pump": "Fluid-end liner washouts: move to ceramic liners and condition monitoring on pump 2.",
    "remedial cementing": "Losses during displacement across Bell Canyon caused low top of cement; use a DV tool and lightweight lead slurry.",
    "waiting on weather": "High winds stop crane lifts; plan rig moves around the spring wind season.",
}


def npt_event(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    cat, fcode, (h0, h1), code, resp = NPT_ROWS[i]
    hours, cost = ctx.num(h0, h1, 1), 0.0
    if i == 0:
        w, hours, cost = WELLS[S.KICK_WELL], 31.5, 412000.0
    elif code == "WC":
        w = WELLS[WCB_WELLS[i - 1]]
    elif i == 18:
        w, hours, cost = WELLS[S.STUCK_WELL], 46.0, 640000.0
    elif code == "WBI":
        w = WELLS[WCA_WELLS[(i * 5) % len(WCA_WELLS)]]
    elif code == "EQ-TD":
        w = WELLS[[44, 5, 12, 25, 35][i - 36]]
    elif code in ("EQ-MP", "WOW"):
        w = WELLS[DRILLED[(i * 7 + 3) % 46]]
    elif code == "CMT":
        w = WELLS[[2, 9, 17, 23][i - 44]]
    else:  # Delaware-only hazards (Salado, Bell / Cherry Canyon)
        w = WELLS[DELAWARE[(i * 7 + 3) % len(DELAWARE)]]
    d = well_dates(w)
    start = datetime.combine(d["spud"] + timedelta(days=(3 if fcode in ("BELL", "CHER", "SALD") else 8)), datetime.min.time()) + timedelta(hours=ctx.int_(0, 20))
    rate = 4200.0
    rig_i = (w.idx * 7) % 12 if w.idx != S.KICK_WELL else 3
    if cat.startswith("equipment failure - top drive"):
        rig_i = 3   # Rig R104 is the bad actor (top drive)
    fm = fcode or w.formation
    md = 11420.0 if i == 0 else float(FORMATIONS[FORM_IDX[fm]][5] + ctx.int_(20, 500))
    r.update(event_number=f"NPT-{start.year}-{i + 1:04d}", event_category=cat, event_subcategory={"WC": "kick", "LC": "partial/total losses", "SP": "differential/mechanical",
             "WBI": "tight hole", "EQ-TD": "IBOP actuator", "EQ-MP": "fluid end", "CMT": "squeeze", "WOW": "high wind"}[code],
             iadc_npt_code=code, operator_npt_code=f"OGX-{code}", drilling_well_id=drill_row_of_well(w.idx), rig_id=P("drilling.rig", rig_i),
             well_asset_id=asset_row_of_well(w.idx), zone_id=well_reservoir_zone(w)[1] if fm == w.formation else None,
             equipment_id=EQUIP_IDX["R104-TD"] if code == "EQ-TD" else (EQUIP_IDX["R104-MP-2"] if code == "EQ-MP" else None),
             well_control_event_id=P("drilling.well_control_event", i) if code == "WC" else None,
             event_start_timestamp=start, event_end_timestamp=start + timedelta(hours=hours), duration_hours=hours,
             estimated_cost_impact_usd=cost or round(hours * rate * ctx.num(0.9, 1.6), 0), measured_depth_ft=md,
             true_vertical_depth_ft=min(md, float(FORMATIONS[FORM_IDX[fm]][5] + 10)), well_control_event_flag=code == "WC",
             pit_gain_volume_bbl=18.0 if i == 0 else (ctx.num(4, 20, 1) if code == "WC" else None), sidpp_psi=650.0 if i == 0 else None, sicp_psi=980.0 if i == 0 else None,
             kill_method="wait_and_weight" if code == "WC" else None, kill_mud_weight_ppg=13.6 if code == "WC" else None,
             preventability_flag=code not in ("WOW",), responsible_party=resp, root_cause_analysis_completed_flag=hours > 12 or i == 0,
             root_cause_summary=("Pore pressure ramp 300 ft shallower than modelled; trip sheet not updated at connection." if i == 0 else
                                 f"{cat.capitalize()} in {FORMATIONS[FORM_IDX[fm]][1]}." if fcode else f"{cat.capitalize()} on rig R{101 + rig_i}."),
             corrective_action_taken="Killed well, raised MW, flared under monitoring." if i == 0 else
             {"WC": "Circulated out influx, weighted up.", "LC": "Pumped LCM pills, reduced ECD.", "SP": "Jarred free / backed off and sidetracked.",
              "WBI": "Reamed and raised MW.", "EQ-TD": "Replaced IBOP actuator.", "EQ-MP": "Replaced liners and pistons.", "CMT": "Squeeze cemented, re-ran CBL.",
              "WOW": "Waited on weather."}[code],
             lessons_learned=LESSONS[cat], reporting_status="closed", bsee_incident_notification_status="not_required", bsee_incident_number=None,
             incident_id=P("hse.incident", S.INC_KICK) if i == 0 else None, _anchor=start)


def well_test(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    expl = [0, 1, 8, 9, 15, 16, 21, 22, 26, 27, 42, 43, 44, 45]
    if i < len(expl):
        w, ttype = WELLS[expl[i]], "DST" if WELLS[expl[i]].kind == "wildcat" else "initial potential test"
    else:
        w, ttype = WELLS[[k for k in range(44) if k not in (30,) and k not in expl][(i - len(expl)) % 28]], ctx.pick(["production test", "buildup"])
    d = well_dates(w)
    start = datetime.combine(d["first_prod"] + timedelta(days=(i * 13) % 200), datetime.min.time()) if ttype != "DST" else datetime.combine(d["td"], datetime.min.time())
    start = min(start, datetime(2026, 9, 20))
    dry = w.result == "dry_hole"
    oil = 0.0 if dry else (ctx.num(900, 2300, 0) if ttype in ("DST", "initial potential test") else ctx.num(150, 900, 0))
    if w.idx == 0:
        oil = 2480.0
    _, zn = well_reservoir_zone(w)
    ex_row = P("exploration.exploration_well", EXPLORATION.index(w.idx)) if w.idx in EXPLORATION else None
    r.update(test_number=f"WT-{start.year}-{i + 1:03d}", test_type=ttype, test_objective="deliverability and fluid sampling" if ttype != "buildup" else "reservoir pressure and skin",
             test_status="completed", test_start_date=start, test_end_date=start + timedelta(hours=24 if ttype != "buildup" else 96),
             test_duration_hours=24.0 if ttype != "buildup" else 96.0, zone_id=zn, well_asset_id=asset_row_of_well(w.idx) if w.idx in ASSETS else None,
             exploration_well_id=ex_row, prospect_id=P("exploration.prospect", w.prospect),
             crude_grade_id=P("product.crude_grade", GRADE_OF_FIELD[w.field]) if w.field is not None else None,
             oil_flow_rate_bopd=oil, gas_flow_rate_mcfd=0.0 if dry else round(oil * ctx.num(1.2, 3.2), 0), water_flow_rate_bwpd=ctx.num(300, 2400, 0) if not dry else 1850.0,
             gor_scf_stb=0.0 if dry else ctx.num(1100, 3600, 0), wor_ratio=ctx.num(0.4, 2.5), choke_size_64ths_inch=str(ctx.pick([24, 28, 32, 40])),
             flowing_bottomhole_pressure_psi=ctx.num(1800, 4200, 0), static_bottomhole_pressure_psi=ctx.num(4500, 7800, 0),
             reservoir_pressure_psi=ctx.num(4500, 7800, 0), isip_psi=ctx.num(3000, 6000, 0), fsip_psi=ctx.num(2500, 5500, 0),
             permeability_md=ctx.num(0.0005, 0.02, 4), permeability_thickness_md_ft=ctx.num(0.1, 4.0, 2), skin_factor=ctx.num(-4.5, 2.0, 1),
             productivity_index_stb_day_psi=ctx.num(0.2, 1.6, 2), drainage_radius_ft=ctx.num(600, 1400, 0), wellbore_storage_coefficient=ctx.num(0.005, 0.05, 3),
             test_temperature_f=ctx.num(150, 205, 1), test_quality_flag="good" if not dry else "fair",
             reserves_classification="PDP" if ttype != "DST" else ("unclassified" if dry else "probable"),
             interpretation_model="horizontal well, infinite-acting, dual porosity" if ttype == "buildup" else None,
             interpretation_software=None, flow_period_count=str(2 if ttype == "DST" else 1), shutin_period_count=str(2 if ttype == "DST" else 1),
             test_comments=("Recovered formation water with oil film; no moveable hydrocarbons." if dry else
                            ("Best test in the field: 2,480 BOPD on 32/64 in choke from Wolfcamp A." if w.idx == 0 else f"{ttype.capitalize()} on {w.name}; stable rates.")),
             data_source_system="production database", work_order_id=None, permit_to_work_id=None, process_safety_event_id=None, permit_id=None,
             _anchor=start)
