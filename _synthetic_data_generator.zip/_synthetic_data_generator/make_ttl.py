"""One-time authoring helper: writes the standards-alignment TTL inputs for the oil_gas model.

The files are inputs of the application (data_model/ontology), like the oil_gas RDF ontology; the app only reads them.
"""

from __future__ import annotations

import sys
from pathlib import Path

OUT = Path(sys.argv[1])

HEADER = """@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .
@prefix skos: <http://www.w3.org/2004/02/skos/core#> .
@prefix dcterms: <http://purl.org/dc/terms/> .
@prefix ind: <http://datamodel.lakehouse.org/business/oil_gas#> .
@prefix std: <urn:ogkg:std#> .
@prefix ogx: <urn:ogkg:annotation#> .
@prefix ogsa: <urn:ogkg:subject-area#> .
"""

# name, parent, label, package, standard, comment, reference url
CLASSES = [
    ("Entity", None, "Industry entity", "root", "OGKG standards reference", "Root of the hand-curated standards reference subset.", None),
    ("Facility", "Entity", "Facility", "OSDU AbstractFacility", "OSDU Data Platform well-known schemas", "Physical facility with an identity, location and lifecycle.", "https://community.opengroup.org/osdu/data/data-definitions"),
    ("Well", "Facility", "Well", "OSDU master-data--Well", "OSDU Data Platform; PPDM 'What is a Well' / US Well Number Standard", "The origin of a set of wellbores; identified by the API / US Well Number (API-10 core).", "https://ppdm.org/ppdm/PPDM/IEDS/Well_Identification/US_Well_Number_Standard/PPDM/US_Well_Number_Standard.aspx"),
    ("Wellbore", "Facility", "Wellbore", "OSDU master-data--Wellbore", "OSDU Data Platform; PPDM US Well Number (wellbore code)", "A borehole drilled from a well origin, including sidetracks.", "https://community.opengroup.org/osdu/data/data-definitions"),
    ("Installation", "Facility", "Installation", "ISO 14224 taxonomy level 3", "ISO 14224:2016", "Production installation (tank battery, compressor station, terminal).", "https://www.iso.org/standard/64076.html"),
    ("DrillingRig", "Facility", "Drilling rig", "IADC rig classification", "IADC Drilling Lexicon; OSDU AbstractFacility", "Drilling unit with its well-control equipment.", "https://iadclexicon.org/"),
    ("PipelineSegment", "Facility", "Pipeline segment", "49 CFR 192/195", "PHMSA pipeline safety regulations", "Discrete pipeline segment managed for integrity.", "https://www.phmsa.dot.gov/"),
    ("MeteringStation", "Facility", "Metering station", "API MPMS", "API Manual of Petroleum Measurement Standards", "Fiscal, allocation or custody-transfer metering station.", None),
    ("MeasurementPoint", "Facility", "Measurement point", "API MPMS", "API Manual of Petroleum Measurement Standards", "Physical or fiscal measurement location.", None),
    ("DeliveryPoint", "Facility", "Delivery point", "custody transfer point", "API MPMS; UN/LOCODE", "Point where title and custody of product transfer.", None),
    ("GeoContext", "Entity", "Geographic context", "OSDU AbstractGeoContext", "OSDU Data Platform", "Geo-political or geological context of master data.", "https://accenture.github.io/OSDU-Ontology/"),
    ("Basin", "GeoContext", "Basin", "OSDU master-data--Basin", "OSDU Data Platform", "Sedimentary basin.", None),
    ("Play", "GeoContext", "Play", "OSDU geo-context Play", "OSDU Data Platform", "Petroleum play concept within a basin.", None),
    ("Prospect", "GeoContext", "Prospect", "OSDU geo-context Prospect", "OSDU Data Platform; SPE-PRMS prospective resources", "Drillable prospect within a play.", None),
    ("Field", "GeoContext", "Field", "OSDU master-data--Field", "OSDU Data Platform", "Producing field.", None),
    ("LicenseBlock", "GeoContext", "Licence block", "lease / licence area", "PPDM land; regulator licence blocks", "Licence or concession block.", None),
    ("SubsurfaceUnit", "Entity", "Subsurface unit", "RESQML", "Energistics RESQML v2", "Subsurface feature or interpretation.", None),
    ("Reservoir", "SubsurfaceUnit", "Reservoir", "SPE-PRMS accumulation", "SPE-PRMS 2018; Energistics RESQML", "Subsurface accumulation of petroleum.", "https://spe.org/industry/reserves/prms-faqs/"),
    ("StratigraphicUnit", "SubsurfaceUnit", "Stratigraphic unit", "RESQML StratigraphicUnitInterpretation", "Energistics RESQML v2", "Formation or stratigraphic interval.", None),
    ("ReservoirZone", "StratigraphicUnit", "Reservoir zone", "RESQML StratigraphicUnitInterpretation", "Energistics RESQML v2", "Pay interval within a reservoir.", None),
    ("Equipment", "Entity", "Equipment unit", "ISO 14224 taxonomy level 6", "ISO 14224:2016; CFIHOS (IOGP JIP36) tag classes", "Equipment unit with reliability and maintenance data.", "https://www.iso.org/standard/64076.html"),
    ("ArtificialLiftSystem", "Equipment", "Artificial lift system", "ISO 14224 equipment class (ESP, pumps)", "ISO 14224:2016", "Downhole or surface lift equipment of a producing well.", None),
    ("FunctionalLocation", "Entity", "Functional location", "ISO 14224 taxonomy levels 3-6", "ISO 14224:2016", "Node of the equipment taxonomy / functional location tree.", None),
    ("Activity", "Entity", "Activity", "activity", "OGKG standards reference", "Planned or executed work.", None),
    ("MaintenanceActivity", "Activity", "Maintenance activity", "ISO 14224 maintenance data", "ISO 14224:2016", "Corrective or preventive maintenance record.", None),
    ("MaintenanceProgram", "Activity", "Maintenance programme", "ISO 14224 / ISO 55001", "ISO 14224:2016; ISO 55001", "Scheduled maintenance strategy and plan.", None),
    ("IntegrityProgram", "MaintenanceProgram", "Integrity programme", "ISO 55001 / API RP 580", "ISO 55001; API RP 580/581", "Asset integrity management programme.", None),
    ("Inspection", "Activity", "Inspection", "API 510 / 570 / 653 / RP 576", "API inspection codes", "Inspection of equipment or piping with fitness-for-service result.", None),
    ("WellProgram", "Activity", "Well program", "well planning", "OSDU Well Delivery; IADC", "Approved drilling and completion program.", None),
    ("CasingString", "Activity", "Casing string", "WITSML Tubular / API 5CT", "Energistics WITSML 2.x; API Spec 5CT", "Casing or liner string design and installation.", None),
    ("CementJob", "Activity", "Cement job", "WITSML CementJob", "Energistics WITSML 2.x", "Primary or remedial cementing job.", None),
    ("DrillingReport", "Activity", "Daily drilling report", "WITSML DrillReport / OpsReport", "Energistics WITSML 2.x", "24-hour drilling operations report.", None),
    ("WellTest", "Activity", "Well test", "PRODML WellTest", "Energistics PRODML", "DST, production or pressure-transient test.", None),
    ("DevelopmentProject", "Activity", "Development project", "SPE-PRMS project", "SPE-PRMS 2018", "Field development plan / project.", None),
    ("PermitToWork", "Activity", "Permit to work", "permit-to-work system", "UK HSE HSG250; IOGP guidance", "Authorisation of high-risk work with isolations and gas tests.", None),
    ("LeakSurvey", "Activity", "Leak survey (LDAR)", "LDAR", "US EPA NSPS OOOOa/b; OGMP 2.0", "Leak detection and repair survey.", None),
    ("Allocation", "Activity", "Production allocation", "PRODML / API MPMS allocation", "Energistics PRODML; API MPMS", "Allocation of measured volumes back to wells.", None),
    ("CustodyTransfer", "Activity", "Custody transfer", "API MPMS custody transfer", "API Manual of Petroleum Measurement Standards", "Transfer of title and custody at a measurement point (GOV, GSV, NSV).", None),
    ("Event", "Entity", "Event", "event", "OGKG standards reference", "Something that happened at a point or period in time.", None),
    ("FailureEvent", "Event", "Failure event", "ISO 14224 failure data", "ISO 14224:2016", "Equipment failure with failure mode, cause and impact.", None),
    ("NptEvent", "Event", "Non-productive time event", "IADC NPT classification", "IADC DDR / NPT practice", "Unplanned drilling downtime.", None),
    ("WellControlEvent", "Event", "Well control event", "API RP 59 / IADC well control", "API RP 59; IADC WellSharp", "Kick, influx or loss of well control.", None),
    ("WellStatusEvent", "Event", "Well status event", "PPDM well status and classification", "PPDM Well Status & Classification", "Lifecycle status transition of a well.", None),
    ("DeferredProductionEvent", "Event", "Deferred production event", "production deferment", "Energistics PRODML", "Downtime with deferred volumes.", None),
    ("ProductionVolume", "Event", "Production volume", "PRODML ProductVolume", "Energistics PRODML", "Daily allocated production volumes.", None),
    ("FlaringEvent", "Event", "Flaring event", "flaring and venting", "US EPA 40 CFR 98 Subpart W; OGMP 2.0", "Flared or vented gas volume.", None),
    ("Incident", "Event", "HSE incident", "IOGP Report 456 / OSHA recordkeeping", "IOGP Report 456; OSHA 29 CFR 1904", "Health, safety or environmental event.", None),
    ("ProcessSafetyEvent", "Event", "Process safety event", "API RP 754 Tier 1-4", "API RP 754; IOGP Report 456", "Loss of primary containment or process safety event.", "https://www.iogp.org/bookstore/product/process-safety-recommended-practice-on-key-performance-indicators/"),
    ("Investigation", "Event", "Incident investigation", "root cause analysis", "CCPS / IOGP investigation practice", "Investigation with root and contributing causes.", None),
    ("CorrectiveAction", "Event", "Corrective action (CAPA)", "ISO 45001 clause 10.2", "ISO 45001:2018", "Corrective or preventive action with effectiveness review.", None),
    ("Release", "Event", "Release / spill", "release reporting", "40 CFR 112; state release rules", "Unplanned release to the environment.", None),
    ("Discovery", "Event", "Discovery", "SPE-PRMS discovered status", "SPE-PRMS 2018", "Declaration of a discovered accumulation.", None),
    ("Violation", "Event", "Regulatory violation", "notice of violation", "regulator enforcement", "Notice of violation or non-compliance finding.", None),
    ("Estimate", "Entity", "Estimate", "estimate", "OGKG standards reference", "Estimated or calculated quantity.", None),
    ("ReservesEstimate", "Estimate", "Reserves estimate", "SPE-PRMS 2018 / SEC", "SPE-PRMS 2018; SEC Regulation S-X 4-10", "Reserves booking (1P/2P/3P, PDP/PDNP/PUD).", "https://spe.org:443/media/filer_public/63/13/6313c8f3-d065-4b07-9f57-7f2507430780/prms2018keychanges.pdf"),
    ("EmissionQuantity", "Estimate", "GHG emission quantity", "GHG inventory", "US EPA 40 CFR 98 Subpart W; GHG Protocol; OGMP 2.0", "Emission of a greenhouse gas with GWP and CO2e.", "https://www.ogmpartnership.org/solution-methane-challenge"),
    ("EmissionSource", "Entity", "Emission source", "Subpart W source category", "US EPA 40 CFR 98 Subpart W", "Stationary, vented, flared or fugitive emission source.", None),
    ("Authority", "Entity", "Regulatory authority", "regulator", "public administration", "Regulatory authority issuing permits and enforcement.", None),
    ("Permit", "Entity", "Permit", "regulatory permit", "regulator permits (APD, air, UIC)", "Permit or authorisation issued by a regulator.", None),
    ("ProductGrade", "Entity", "Crude grade", "crude assay", "ASTM D287 (API gravity); crude assay practice", "Crude stream with quality and pricing benchmark.", None),
]

# table -> (std class, match)
ALIGN = {
    "Basin": ("Basin", "exact"), "Play": ("Play", "exact"), "Prospect": ("Prospect", "exact"), "Block": ("LicenseBlock", "close"),
    "Formation": ("StratigraphicUnit", "close"), "Discovery": ("Discovery", "close"), "ExplorationWell": ("Well", "close"),
    "Reservoir": ("Reservoir", "close"), "Zone": ("ReservoirZone", "close"), "WellTest": ("WellTest", "close"),
    "ReservesEstimate": ("ReservesEstimate", "exact"), "DevelopmentPlan": ("DevelopmentProject", "close"),
    "DrillingWell": ("Wellbore", "close"), "Rig": ("DrillingRig", "exact"), "WellProgram": ("WellProgram", "close"),
    "DailyDrillingReport": ("DrillingReport", "close"), "NptEvent": ("NptEvent", "close"), "CasingDesign": ("CasingString", "close"),
    "CementingJob": ("CementJob", "close"), "WellControlEvent": ("WellControlEvent", "close"), "WellStatusHistory": ("WellStatusEvent", "close"),
    "Field": ("Field", "exact"), "ProductionWell": ("Well", "close"), "ProductionFacility": ("Installation", "close"),
    "DailyProduction": ("ProductionVolume", "close"), "ProductionAllocation": ("Allocation", "close"),
    "DowntimeEvent": ("DeferredProductionEvent", "close"), "ArtificialLift": ("ArtificialLiftSystem", "close"),
    "MeterStation": ("MeteringStation", "close"), "FlareRecord": ("FlaringEvent", "close"),
    "AssetFacility": ("Installation", "close"), "Equipment": ("Equipment", "exact"), "Hierarchy": ("FunctionalLocation", "close"),
    "PipelineSegment": ("PipelineSegment", "close"), "InspectionEvent": ("Inspection", "close"), "FailureReport": ("FailureEvent", "close"),
    "WorkOrder": ("MaintenanceActivity", "close"), "PreventiveMaintenancePlan": ("MaintenanceProgram", "close"),
    "IntegrityProgram": ("IntegrityProgram", "close"), "WellAsset": ("Well", "broad"),
    "Incident": ("Incident", "close"), "IncidentInvestigation": ("Investigation", "close"), "HseCorrectiveAction": ("CorrectiveAction", "close"),
    "PermitToWork": ("PermitToWork", "exact"), "ProcessSafetyEvent": ("ProcessSafetyEvent", "exact"), "SpillEvent": ("Release", "close"),
    "EmissionSource": ("EmissionSource", "close"), "GhgEmission": ("EmissionQuantity", "close"), "LdarSurvey": ("LeakSurvey", "close"),
    "RegulatoryAuthority": ("Authority", "close"), "Permit": ("Permit", "close"), "Violation": ("Violation", "close"),
    "CustodyTransfer": ("CustodyTransfer", "close"), "MeasurementPoint": ("MeasurementPoint", "close"),
    "DeliveryPoint": ("DeliveryPoint", "close"), "CrudeGrade": ("ProductGrade", "close"),
}

# property (ind local name) -> (std attribute "Class.attr", match, label)
ATTRS = {
    "apiNumber": ("Well.uwi", "exact", "API / US Well Number"), "uwi": ("Well.uwi", "exact", "API / US Well Number"),
    "apiWellNumber": ("Wellbore.uwi", "close", "API / US Well Number incl. wellbore code"), "wellName": ("Well.name", "close", "Well name"),
    "spudDate": ("Wellbore.spudDate", "exact", "Spud date"), "measuredDepthFt": ("Wellbore.measuredDepth", "close", "Measured depth"),
    "trueVerticalDepthFt": ("Wellbore.trueVerticalDepth", "close", "True vertical depth"),
    "surfaceLatitude": ("SpatialLocation.latitude", "close", "Latitude (WGS84)"), "surfaceLongitude": ("SpatialLocation.longitude", "close", "Longitude (WGS84)"),
    "latitude": ("SpatialLocation.latitude", "close", "Latitude (WGS84)"), "longitude": ("SpatialLocation.longitude", "close", "Longitude (WGS84)"),
    "grossOilVolumeBbl": ("ProductVolume.grossOilVolume", "close", "Gross oil volume"), "netOilVolumeBbl": ("ProductVolume.netOilVolume", "close", "Net oil volume"),
    "grossGasVolumeMcf": ("ProductVolume.grossGasVolume", "close", "Gross gas volume"), "boeVolume": ("ProductVolume.barrelsOfOilEquivalent", "close", "BOE"),
    "oilFlowRateBopd": ("WellTest.oilRate", "close", "Oil rate"), "gasFlowRateMcfd": ("WellTest.gasRate", "close", "Gas rate"),
    "reservesCategory": ("ReservesEstimate.category", "exact", "PRMS reserves category"), "reservesSubCategory": ("ReservesEstimate.subCategory", "exact", "PRMS reserves sub-category"),
    "provedReservesVolume": ("ReservesEstimate.provedVolume", "close", "Proved reserves volume"),
    "pseTierClassification": ("ProcessSafetyEvent.tier", "exact", "API RP 754 tier"), "lopcFlag": ("ProcessSafetyEvent.lossOfPrimaryContainment", "exact", "LOPC"),
    "failureMode": ("FailureEvent.failureMode", "close", "Failure mode (ISO 14224)"), "failureCause": ("FailureEvent.failureCause", "close", "Failure cause (ISO 14224)"),
    "mtbfHours": ("Equipment.meanTimeBetweenFailures", "close", "MTBF"), "mttrHours": ("Equipment.meanTimeToRepair", "close", "MTTR"),
    "equipmentType": ("Equipment.equipmentClass", "close", "Equipment class (ISO 14224)"), "tag": ("Equipment.tag", "close", "Equipment tag (CFIHOS)"),
    "criticalityRanking": ("Equipment.criticality", "close", "Criticality"), "iadcNptCode": ("NptEvent.nptCode", "close", "NPT code"),
    "co2eTonnes": ("EmissionQuantity.co2e", "close", "CO2-equivalent"), "ghgGasType": ("EmissionQuantity.gas", "exact", "Greenhouse gas"),
    "globalWarmingPotential": ("EmissionQuantity.gwp", "exact", "Global warming potential"), "flareVolumeMcf": ("FlaringEvent.flaredVolume", "close", "Flared volume"),
    "leaksDetectedCount": ("LeakSurvey.leakCount", "close", "Leaks detected"), "netStandardVolume": ("CustodyTransfer.netStandardVolume", "exact", "Net standard volume"),
    "grossObservedVolume": ("CustodyTransfer.grossObservedVolume", "exact", "Gross observed volume"),
    "grossStandardVolume": ("CustodyTransfer.grossStandardVolume", "exact", "Gross standard volume"), "bswPercentage": ("CustodyTransfer.basicSedimentAndWater", "close", "BS&W"),
    "meterFactor": ("MeteringStation.meterFactor", "exact", "Meter factor"), "apiGravity": ("ProductGrade.apiGravity", "exact", "API gravity"),
    "sulfurContentPercent": ("ProductGrade.sulfurContent", "close", "Sulfur content"), "formationName": ("StratigraphicUnit.name", "close", "Formation name"),
    "pitGainVolumeBbl": ("WellControlEvent.pitGain", "close", "Pit gain"), "sidppPsi": ("WellControlEvent.shutInDrillPipePressure", "exact", "SIDPP"),
    "sicpPsi": ("WellControlEvent.shutInCasingPressure", "exact", "SICP"), "killMudWeightPpg": ("WellControlEvent.killMudWeight", "close", "Kill mud weight"),
    "fitnessForServiceResult": ("Inspection.fitnessForService", "close", "Fitness-for-service result (API 579)"),
    "inspectionDate": ("Inspection.date", "close", "Inspection date"), "nextInspectionDueDate": ("Inspection.nextDueDate", "close", "Next inspection due"),
    "allocationMethod": ("Allocation.method", "close", "Allocation method"), "oilAllocationVarianceBbl": ("Allocation.oilVariance", "close", "Oil allocation variance"),
    "durationHours": ("Event.duration", "broad", "Duration"), "rootCauseDescription": ("Investigation.rootCause", "close", "Root cause"),
    "effectivenessReviewStatus": ("CorrectiveAction.effectiveness", "close", "Effectiveness review"),
}

# FK object property (ind local name) -> standard association role
ASSOC = {
    "wellAssetId": "Wellbore.Well (OSDU WellID)", "parentWellboreDrillingWellId": "Wellbore.ParentWellbore",
    "reservoirId": "Wellbore.Reservoir", "zoneId": "WellTest.Zone", "formationId": "Wellbore.TargetFormation",
    "prospectId": "Well.Prospect (geo-context)", "playId": "Prospect.Play (geo-context)", "basinId": "Play.Basin (geo-context)",
    "fieldId": "Well.Field (geo-context)", "equipmentId": "Event.Equipment (ISO 14224)", "inspectionEventId": "FailureEvent.PrecedingInspection",
    "workOrderId": "FailureEvent.MaintenanceActivity (ISO 14224)", "previousFailureReportId": "FailureEvent.PreviousFailure",
    "incidentId": "Event.Incident", "processSafetyEventId": "Incident.ProcessSafetyEvent (API RP 754)",
    "permitToWorkId": "Activity.PermitToWork", "violationId": "Event.Violation", "custodyTransferId": "Allocation.CustodyTransfer (API MPMS)",
    "meterStationId": "Allocation.MeteringStation", "measurementPointId": "MeteringStation.MeasurementPoint", "deliveryPointId": "CustodyTransfer.DeliveryPoint",
    "emissionSourceId": "EmissionQuantity.Source (Subpart W)", "ldarSurveyId": "EmissionQuantity.LeakSurvey", "wellControlEventId": "Event.WellControlEvent",
    "productionWellId": "Allocation.Well", "drillingWellId": "Event.Wellbore", "rigId": "Wellbore.Rig", "regulatoryAuthorityId": "Permit.Authority",
}

DOMAINS = {
    "exploration": ("Exploration", "Upstream exploration: basins, plays, prospects, discoveries and exploration wells."),
    "reservoir": ("Reservoir", "Reservoir characterisation, zones, well tests, reserves and development plans."),
    "drilling": ("Drilling", "Drilling and well construction: wellbores, rigs, programs, reports, NPT, well control."),
    "production": ("Production", "Production operations, facilities, allocation, measurement, deferment and flaring."),
    "asset": ("Asset", "Asset integrity and maintenance: facilities, equipment, inspections, failures, work orders."),
    "hse": ("HSE", "Health, safety and environment: incidents, investigations, CAPA, permits to work, emissions."),
    "compliance": ("Compliance", "Regulators, permits and violations."),
    "logistics": ("Logistics", "Measurement points and custody transfer."),
    "customer": ("Customer", "Delivery points."),
    "product": ("Product", "Crude grades and quality."),
}
USE_CASES = {
    "UC1": ("Well & subsurface 360 / well identity", ["Basin", "Play", "Prospect", "Block", "Formation", "Discovery", "ExplorationWell", "Reservoir", "Zone",
                                                       "WellTest", "ReservesEstimate", "DevelopmentPlan", "DrillingWell", "Field", "ProductionWell", "WellAsset"]),
    "UC2": ("Drilling performance & lessons learned", ["DrillingWell", "Rig", "WellProgram", "DailyDrillingReport", "NptEvent", "CasingDesign", "CementingJob",
                                                        "WellControlEvent", "WellStatusHistory", "Formation", "Zone"]),
    "UC3": ("Asset integrity & reliability", ["AssetFacility", "Equipment", "Hierarchy", "PipelineSegment", "InspectionEvent", "FailureReport", "WorkOrder",
                                               "PreventiveMaintenancePlan", "IntegrityProgram", "WellAsset", "DowntimeEvent", "ArtificialLift"]),
    "UC4": ("HSE & process-safety incident intelligence", ["Incident", "IncidentInvestigation", "HseCorrectiveAction", "PermitToWork", "ProcessSafetyEvent",
                                                            "SpillEvent", "RegulatoryAuthority", "Permit", "Violation"]),
    "UC5": ("Production-to-market & emissions traceability", ["ProductionFacility", "DailyProduction", "ProductionAllocation", "MeterStation", "FlareRecord",
                                                               "CustodyTransfer", "MeasurementPoint", "DeliveryPoint", "CrudeGrade", "EmissionSource",
                                                               "GhgEmission", "LdarSurvey"]),
}
DOMAIN_OF = {
    "exploration": ["Basin", "Play", "Prospect", "Block", "Formation", "Discovery", "ExplorationWell"],
    "reservoir": ["Reservoir", "Zone", "WellTest", "ReservesEstimate", "DevelopmentPlan"],
    "drilling": ["DrillingWell", "Rig", "WellProgram", "DailyDrillingReport", "NptEvent", "CasingDesign", "CementingJob", "WellControlEvent", "WellStatusHistory"],
    "production": ["Field", "ProductionWell", "ProductionFacility", "DailyProduction", "ProductionAllocation", "DowntimeEvent", "ArtificialLift", "MeterStation", "FlareRecord"],
    "asset": ["AssetFacility", "Equipment", "Hierarchy", "PipelineSegment", "InspectionEvent", "FailureReport", "WorkOrder", "PreventiveMaintenancePlan", "IntegrityProgram", "WellAsset"],
    "hse": ["Incident", "IncidentInvestigation", "HseCorrectiveAction", "PermitToWork", "ProcessSafetyEvent", "SpillEvent", "EmissionSource", "GhgEmission", "LdarSurvey"],
    "compliance": ["RegulatoryAuthority", "Permit", "Violation"],
    "logistics": ["CustodyTransfer", "MeasurementPoint"],
    "customer": ["DeliveryPoint"],
    "product": ["CrudeGrade"],
}


def lit(s: str) -> str:
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    # 1. standards reference subset
    out = [HEADER, "# Hand-curated reference subset of oil & gas industry standards used to align the oil_gas ontology.",
           "# INFORMATIVE: names the standard concept a table/column corresponds to; it is not an official ontology of",
           "# OSDU, PPDM, Energistics, SPE, ISO, API, IOGP or US EPA. See docs/01_OilGas_KG_Research_and_Use_Cases.md section 6.",
           "",
           "<urn:ogkg:std> a owl:Ontology ; rdfs:label \"OGKG oil & gas standards reference subset\" ; owl:versionInfo \"1.0\" .",
           "",
           "ogx:stdPackage a owl:AnnotationProperty ; rdfs:label \"standard package\" .",
           "ogx:stdStandard a owl:AnnotationProperty ; rdfs:label \"standard\" .",
           "ogx:stdReference a owl:AnnotationProperty ; rdfs:label \"standard reference URL\" .",
           "ogx:stdExactMatch a owl:AnnotationProperty ; rdfs:label \"exact match to a standard term\" .",
           "ogx:stdCloseMatch a owl:AnnotationProperty ; rdfs:label \"close match to a standard term\" .",
           "ogx:stdBroadMatch a owl:AnnotationProperty ; rdfs:label \"broad match to a standard term\" .",
           "ogx:stdAssociation a owl:AnnotationProperty ; rdfs:label \"standard association role\" .",
           ""]
    for name, parent, label, pkg, std, comment, ref in CLASSES:
        lines = [f"std:{name} a owl:Class ;", f"    rdfs:label {lit(label)} ;", f"    rdfs:comment {lit(comment)} ;",
                 f"    ogx:stdPackage {lit(pkg)} ;", f"    ogx:stdStandard {lit(std)}"]
        if parent:
            lines[-1] += " ;"
            lines.append(f"    rdfs:subClassOf std:{parent}")
        if ref:
            lines[-1] += " ;"
            lines.append(f"    ogx:stdReference {lit(ref)}")
        out.append("\n".join(lines) + " .\n")
    seen = set()
    for _, (attr, _, label) in ATTRS.items():
        if attr in seen:
            continue
        seen.add(attr)
        cls = attr.split(".")[0]
        dom = f"std:{cls}" if any(c[0] == cls for c in CLASSES) else "std:Entity"
        out.append(f"std:{attr} a owl:DatatypeProperty ;\n    rdfs:label {lit(label)} ;\n    rdfs:domain {dom} .\n")
    (OUT / "og_standards_reference.ttl").write_text("\n".join(out), encoding="utf-8")

    # 2. alignment of oil_gas classes / properties
    out = [HEADER, "# Alignment of the in-scope oil_gas ontology classes and properties to the standards reference subset.",
           "# Informative mapping maintained with the model; match levels: exact | close | broad.", ""]
    pred = {"exact": "ogx:stdExactMatch", "close": "ogx:stdCloseMatch", "broad": "ogx:stdBroadMatch"}
    for cls, (stdc, m) in ALIGN.items():
        out.append(f"ind:{cls} {pred[m]} std:{stdc} .")
    out.append("")
    for prop, (attr, m, _) in ATTRS.items():
        out.append(f"ind:{prop} {pred[m]} std:{attr} .")
    out.append("")
    for prop, role in ASSOC.items():
        out.append(f"ind:{prop} ogx:stdAssociation {lit(role)} .")
    (OUT / "og_standards_alignment.ttl").write_text("\n".join(out) + "\n", encoding="utf-8")

    # 3. SKOS subject areas and use cases
    out = [HEADER, "# Subject areas (DDL schemas) and knowledge-graph use cases as SKOS concepts; dcterms:subject links classes to both.", "",
           "ogsa:scheme a skos:ConceptScheme ; skos:prefLabel \"oil_gas subject areas and use cases\" .", "",
           "ogsa:domains a skos:Concept ; skos:inScheme ogsa:scheme ; skos:prefLabel \"Subject areas\" .",
           "ogsa:usecases a skos:Concept ; skos:inScheme ogsa:scheme ; skos:prefLabel \"Knowledge-graph use cases\" .", ""]
    for d, (label, definition) in DOMAINS.items():
        out.append(f"ogsa:{d} a skos:Concept ; skos:inScheme ogsa:scheme ; skos:prefLabel {lit(label)} ; skos:definition {lit(definition)} ; skos:broader ogsa:domains .")
    for u, (label, _) in USE_CASES.items():
        out.append(f"ogsa:{u} a skos:Concept ; skos:inScheme ogsa:scheme ; skos:prefLabel {lit(u + ' ' + label)} ; "
                   f"skos:scopeNote {lit('See docs/01_OilGas_KG_Research_and_Use_Cases.md, section 9.')} ; skos:broader ogsa:usecases .")
    out.append("")
    for d, classes in DOMAIN_OF.items():
        for c in classes:
            ucs = [u for u, (_, cl) in USE_CASES.items() if c in cl]
            out.append(f"ind:{c} dcterms:subject ogsa:{d}" + "".join(f", ogsa:{u}" for u in ucs) + " .")
    (OUT / "og_subject_areas.skos.ttl").write_text("\n".join(out) + "\n", encoding="utf-8")
    print("wrote", [p.name for p in OUT.glob("og_*.ttl")])


if __name__ == "__main__":
    main()
