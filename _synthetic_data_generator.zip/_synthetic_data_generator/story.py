"""Fixed indices of the planted stories behind the 15 demo questions (see input_data/README.md)."""

# UC1 well identity
Q1_WELL = 0                      # Falcon Draw 10-1H: present in all four well registers
# UC2 drilling
KICK_WELL = 9                    # Red Mesa 12-2H: Wolfcamp B kick -> incident -> violation -> NPT -> flaring -> PSE
STUCK_WELL = 2                   # Falcon Draw 10-3H: Salado washout + stuck pipe -> sidetrack ST01
PLANNED_PROGRAM = 21             # well_program row: planned Red Mesa 13-4H into Wolfcamp B (offset-well brief)
# UC3 asset integrity (equipment tags)
K201 = "FD1-K-201"
ESP09 = "RM-ESP-09"
V110 = "CF2-V-110"
LCV110 = "CF2-LCV-110"
PIPE_FD07 = 6                    # pipeline_segment row FD gathering line 07
TOPDRIVE = "R104-TD"
# UC4 HSE: row indices
INC_KICK, INC_LOPC, INC_K201, INC_PIPE = 0, 1, 2, 3
VIO_KICK, VIO_LOPC, VIO_PIPE = 0, 1, 2
PSE_LOPC, PSE_KICK, PSE_K201 = 0, 1, 2
PTW_LOPC = 0
# UC5
CT_FD_AUG = 0                    # custody transfer CT-2026-0815
