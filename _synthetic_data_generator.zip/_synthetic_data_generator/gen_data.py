"""One-time synthetic data generator for the oil_gas knowledge graph (NOT part of the application).

Usage (from this folder):
    python -I gen_data.py <oil-and-gas-kg-app/backend> <oil-and-gas-kg-app/data_model/ddl> <output dir>

Writes <output>/<schema>/<table>.csv for the 56 in-scope tables of the oil_gas v1 MVM model and
<output>/manifest.json, using the DDL parser of the app (app.kg.model.ddl). Deterministic: the same
seed always produces the same files as oil-and-gas-kg-app/input_data. All records are synthetic.
"""

from __future__ import annotations

import csv
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, sys.argv[1])

try:
    from app.kg.model.ddl import load_data_model  # noqa: E402  (oil-and-gas-kg-app/backend)
except ImportError:
    from ukg.model.ddl import load_data_model  # noqa: E402  (utility-knowledge-graph-v3 root)

import b_ops as O  # noqa: E402
import b_subsurface as B  # noqa: E402
from gen_core import TABLES, Generator, build_wells  # noqa: E402
from genlib import AS_OF, Ctx, fmt  # noqa: E402

exec((HERE / "scope.py").read_text())  # SCOPE, IDS

BUILDERS = {
    "asset.hierarchy": (50, O.hierarchy), "compliance.regulatory_authority": (10, B.regulatory_authority),
    "customer.delivery_point": (15, B.delivery_point), "exploration.formation": (18, B.formation),
    "product.crude_grade": (10, B.crude_grade), "asset.asset_facility": (20, O.asset_facility),
    "compliance.permit": (40, B.permit), "exploration.basin": (6, B.basin), "asset.equipment": (50, O.equipment),
    "asset.pipeline_segment": (25, O.pipeline_segment), "exploration.block": (15, B.block), "exploration.play": (10, B.play),
    "drilling.rig": (12, B.rig), "exploration.prospect": (20, B.prospect), "production.field": (10, B.field),
    "reservoir.reservoir": (15, B.reservoir), "asset.well_asset": (50, B.well_asset), "drilling.well_program": (25, B.well_program),
    "reservoir.development_plan": (12, B.development_plan), "reservoir.zone": (30, B.zone),
    "asset.integrity_program": (20, O.integrity_program), "compliance.violation": (25, O.violation),
    "drilling.casing_design": (50, B.casing_design), "drilling.drilling_well": (50, B.drilling_well),
    "exploration.discovery": (12, B.discovery), "exploration.exploration_well": (25, B.exploration_well),
    "production.production_well": (50, B.production_well), "reservoir.reserves_estimate": (50, B.reserves_estimate),
    "drilling.cementing_job": (50, B.cementing_job), "drilling.well_status_history": (50, B.well_status_history),
    "hse.emission_source": (40, O.emission_source), "hse.permit_to_work": (50, O.permit_to_work),
    "logistics.custody_transfer": (40, O.custody_transfer), "production.artificial_lift": (40, O.artificial_lift),
    "logistics.measurement_point": (25, O.measurement_point), "production.production_facility": (15, O.production_facility),
    "asset.preventive_maintenance_plan": (40, O.preventive_maintenance_plan), "hse.incident": (50, O.incident),
    "hse.ldar_survey": (30, O.ldar_survey), "hse.process_safety_event": (20, O.process_safety_event),
    "production.meter_station": (25, O.meter_station), "asset.work_order": (50, O.work_order),
    "drilling.daily_drilling_report": (50, B.daily_drilling_report), "hse.ghg_emission": (50, O.ghg_emission),
    "hse.incident_investigation": (30, O.incident_investigation), "hse.spill_event": (20, O.spill_event),
    "asset.inspection_event": (50, O.inspection_event), "drilling.well_control_event": (25, B.well_control_event),
    "hse.hse_corrective_action": (50, O.hse_corrective_action), "reservoir.well_test": (50, B.well_test),
    "asset.failure_report": (50, O.failure_report), "drilling.npt_event": (50, B.npt_event),
    "production.daily_production": (50, O.daily_production), "production.downtime_event": (50, O.downtime_event),
    "production.flare_record": (50, O.flare_record), "production.production_allocation": (50, O.production_allocation),
}


def validate(model, rows) -> list[str]:
    problems = []
    pks = {}
    for tid, t in model.tables.items():
        pk = t.primary_key[0]
        c = Counter(r[pk] for r in rows[tid])
        dups = [k for k, n in c.items() if n > 1]
        if dups:
            problems.append(f"{tid}: duplicate PKs {dups[:3]}")
        pks[tid] = set(c)
        for col in t.columns:
            if not col.nullable and any(r.get(col.name) is None for r in rows[tid]):
                problems.append(f"{tid}.{col.name}: NULL in NOT NULL column")
            if col.enum_values:
                bad = {str(r[col.name]) for r in rows[tid] if r.get(col.name) is not None and str(r[col.name]) not in col.enum_values}
                if bad:
                    problems.append(f"{tid}.{col.name}: values not in enum {sorted(bad)[:4]}")
    for fk in model.foreign_keys:
        orphans = [r[fk.column] for r in rows[fk.table_id] if r.get(fk.column) is not None and r[fk.column] not in pks[fk.ref_table_id]]
        if orphans:
            problems.append(f"{fk.table_id}.{fk.column} -> {fk.ref_table_id}: {len(orphans)} orphans e.g. {orphans[0]}")
    return problems


def main() -> int:
    ddl_dir, out_dir = Path(sys.argv[2]), Path(sys.argv[3])
    full = load_data_model(["*_schema_v1_mvm.sql", "oil_gas_cross_domain_foreign_keys_v1_mvm.sql"], ddl_dir)
    model = full.scoped(IDS)
    assert set(TABLES) == set(IDS), set(TABLES) ^ set(IDS)
    ctx = Ctx()
    wells = build_wells(ctx)
    api10 = Counter(w.api10 for w in wells)
    assert max(api10.values()) == 1, [k for k, v in api10.items() if v > 1]
    B.setup(wells)
    rows = Generator(model, IDS, ctx, BUILDERS, full).run()
    leaked = [(tid, fk.column) for tid in IDS for fk in full.fks_from(tid)
              if fk.ref_table_id not in set(IDS) and any(r.get(fk.column) is not None for r in rows[tid])]
    assert not leaked, f"out-of-scope FK columns must stay empty: {leaked[:5]}"
    problems = validate(model, rows)
    for p in problems:
        print("VALIDATION:", p)
    if problems:
        return 1
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest = {"generator": "one-time synthetic generator (kept outside the application)", "seed": 20261030, "as_of": AS_OF.isoformat(),
                "data_model": "oil_gas v1 MVM (Databricks Industry Data Models)", "operator": "OGX Energy (synthetic)",
                "tables": {}, "rows": 0}
    for tid in TABLES:
        t = model.tables[tid]
        schema, table = tid.split(".")
        path = out_dir / schema / f"{table}.csv"
        path.parent.mkdir(parents=True, exist_ok=True)
        cols = [c.name for c in t.columns]
        with path.open("w", encoding="utf-8", newline="") as fh:
            wr = csv.writer(fh)
            wr.writerow(cols)
            for r in rows[tid]:
                wr.writerow([fmt(r.get(c)) for c in cols])
        populated = sum(1 for c in cols if any(r.get(c) is not None for r in rows[tid]))
        manifest["tables"][tid] = {"file": f"{schema}/{table}.csv", "rows": len(rows[tid]), "columns": len(cols),
                                   "populated_columns": populated,
                                   "sha256": hashlib.sha256(path.read_bytes()).hexdigest()[:16]}
        manifest["rows"] += len(rows[tid])
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"Wrote {len(TABLES)} files, {manifest['rows']} rows to {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
