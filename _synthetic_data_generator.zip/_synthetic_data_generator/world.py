"""Reference world of the synthetic dataset: a fictional operator ("OGX Energy") in the Permian
Basin (Delaware and Midland sub-basins, Texas and New Mexico).

Geology names (basins, formations) and regulator names are real public names; every record,
number, well, facility and event is synthetic. API well numbers use real state/county codes
(Texas 42, New Mexico 30) with fictional unique numbers, formatted per the PPDM US Well
Number Standard (API-10 core + 2-digit wellbore + 2-digit event).
"""

from __future__ import annotations

OPERATOR = "OGX Energy (synthetic)"

# code, name, state, state_api, county, county_api, lat, lon, basin_idx, play_idx
FIELDS = [
    ("FD", "Falcon Draw", "TX", "42", "Reeves", "389", 31.45, -103.65, 0, 0),
    ("RM", "Red Mesa", "TX", "42", "Loving", "301", 31.85, -103.55, 0, 0),
    ("CF", "Coyote Flats", "NM", "30", "Eddy", "015", 32.35, -104.05, 0, 1),
    ("SR", "Sandhill Ridge", "TX", "42", "Ward", "475", 31.55, -103.15, 0, 0),
    ("MB", "Mesquite Bend", "TX", "42", "Martin", "317", 32.30, -101.95, 1, 4),
    ("PB", "Pecos Bend", "TX", "42", "Pecos", "371", 31.20, -103.35, 0, 0),
    ("TW", "Tumbleweed", "NM", "30", "Lea", "025", 32.55, -103.45, 0, 1),
    ("LB", "Lone Butte", "TX", "42", "Culberson", "109", 31.75, -104.05, 0, 3),
    ("YR", "Yucca Ridge", "TX", "42", "Midland", "329", 31.95, -102.10, 1, 5),
    ("OC", "Ocotillo", "TX", "42", "Howard", "227", 32.25, -101.45, 1, 4),
]

# name, code, type, tectonic setting, status, lat-range note
BASINS = [
    ("Delaware Basin", "DLW", "foreland", "Permian foreland sub-basin, deep-water clastics and carbonates", "producing"),
    ("Midland Basin", "MDL", "foreland", "Permian intracratonic sub-basin", "producing"),
    ("Central Basin Platform", "CBP", "platform", "uplifted carbonate platform between the Delaware and Midland basins", "mature"),
    ("Val Verde Basin", "VVB", "foreland", "southern Permian foreland extension", "frontier"),
    ("Palo Duro Basin", "PDB", "intracratonic", "northern Permian intracratonic basin", "frontier"),
    ("Marfa Basin", "MRF", "foreland", "small south-western Permian sub-basin", "relinquished"),
]

# code, name, period, epoch/stage, lithology, typical top TVD ft (Delaware), hazard note, hydrocarbon
FORMATIONS = [
    ("RUST", "Rustler", "Permian", "Lopingian (Ochoan)", "anhydrite and dolomite", 900,
     "Shallow water flows and fresh-water aquifer protection; set surface casing below the Rustler.", "unknown"),
    ("SALD", "Salado", "Permian", "Lopingian (Ochoan)", "halite with anhydrite stringers", 1200,
     "Salt washouts and hole enlargement with water-based mud; use saturated brine or oil-based mud.", "unknown"),
    ("CAST", "Castile", "Permian", "Lopingian (Ochoan)", "laminated anhydrite and halite", 2900,
     "Pressurised brine pockets with H2S; be ready to weight up and keep H2S monitoring on.", "unknown"),
    ("BELL", "Bell Canyon", "Permian", "Guadalupian", "fine-grained sandstone", 4300,
     "Severe lost circulation in fractured sands; pre-treat with LCM and manage ECD.", "oil"),
    ("CHER", "Cherry Canyon", "Permian", "Guadalupian", "sandstone and siltstone", 5200,
     "Partial losses; watch for ballooning versus true losses.", "oil"),
    ("BRSH", "Brushy Canyon", "Permian", "Guadalupian", "sandstone", 6400,
     "Loss and gain cycles; flow-check before trips.", "oil"),
    ("AVLN", "Avalon", "Permian", "Cisuralian (Leonardian)", "organic-rich shale and carbonate", 7600,
     "Moderate overpressure in the lower Avalon.", "oil"),
    ("BS1", "1st Bone Spring Sand", "Permian", "Cisuralian (Leonardian)", "sandstone", 8300,
     "Generally benign; minor seepage losses.", "oil"),
    ("BS2", "2nd Bone Spring Sand", "Permian", "Cisuralian (Leonardian)", "sandstone", 9200,
     "Differential sticking across depleted sands.", "oil"),
    ("BS3", "3rd Bone Spring Sand", "Permian", "Cisuralian (Leonardian)", "sandstone", 10100,
     "Gas shows at the base; keep mud weight above pore pressure.", "oil"),
    ("WCA", "Wolfcamp A", "Permian", "Cisuralian (Wolfcampian)", "calcareous shale and carbonate debris flows", 10800,
     "Wellbore instability and tight hole in the curve; ream stands and control ROP.", "oil"),
    ("WCB", "Wolfcamp B", "Permian", "Cisuralian (Wolfcampian)", "siliceous shale", 11400,
     "Overpressure transition with kick risk; pressure-while-drilling monitoring and trip-sheet discipline required.",
     "oil"),
    ("WCC", "Wolfcamp C", "Permian", "Cisuralian (Wolfcampian)", "shale and carbonate", 12000,
     "High pore pressure; casing seat selection is critical.", "condensate"),
    ("WCD", "Wolfcamp D", "Pennsylvanian", "Virgilian (Cline)", "shale", 12600,
     "Hot hole above 230 F; check tool temperature ratings.", "gas"),
    ("USPB", "Upper Spraberry", "Permian", "Cisuralian (Leonardian)", "siltstone and sandstone", 7200,
     "Natural fractures with partial losses (Midland Basin).", "oil"),
    ("LSPB", "Lower Spraberry", "Permian", "Cisuralian (Leonardian)", "siltstone", 7900,
     "Benign; occasional tight hole.", "oil"),
    ("DEAN", "Dean", "Permian", "Cisuralian (Leonardian)", "sandstone and siltstone", 8600,
     "Differential sticking risk.", "oil"),
    ("STRN", "Strawn", "Pennsylvanian", "Desmoinesian", "limestone", 10500,
     "Sour gas zones; H2S contingency plan required.", "gas"),
]

# name, basin_idx, formation code, type, hydrocarbon
PLAYS = [
    ("Delaware Wolfcamp Shale Oil", 0, "WCA", "shale_oil", "oil"),
    ("Delaware Bone Spring Sands", 0, "BS2", "unconventional", "oil"),
    ("Delaware Avalon Shale", 0, "AVLN", "shale_oil", "oil"),
    ("Delaware Strawn Gas", 0, "STRN", "conventional", "gas"),
    ("Midland Wolfcamp Shale Oil", 1, "WCA", "shale_oil", "oil"),
    ("Midland Spraberry Tight Oil", 1, "USPB", "unconventional", "oil"),
    ("Central Basin Platform Strawn", 2, "STRN", "conventional", "gas"),
    ("Val Verde Wolfcamp Gas", 3, "WCC", "shale_gas", "gas"),
    ("Delaware Wolfcamp Condensate", 0, "WCC", "shale_gas", "condensate"),
    ("Palo Duro Pennsylvanian", 4, "WCD", "conventional", "mixed"),
]

# reservoir: field idx, formation code
RESERVOIRS = [
    (0, "WCA"), (0, "WCB"), (0, "BS3"), (1, "WCA"), (1, "WCB"), (2, "BS2"), (2, "AVLN"), (3, "WCA"),
    (4, "LSPB"), (4, "WCB"), (5, "WCA"), (6, "BS2"), (7, "STRN"), (8, "USPB"), (9, "WCA"),
]

# Exploration-only prospects (beyond the 10 field prospects)
NEW_PROSPECTS = ["Javelina", "Roadrunner", "Salt Cedar", "Agave", "Caliche", "Dune Crest", "Antelope Draw",
                 "Sage Hollow", "Copper Flat", "Cholla"]

# wells per field (development + appraisal), 42 in total
WELLS_PER_FIELD = [8, 7, 6, 5, 4, 3, 3, 2, 2, 2]

CRUDE_GRADES = [
    # code, name, api, sulfur %, band, sulfur class, classification, differential USD/bbl
    ("WTIM", "WTI Midland", 42.5, 0.20, "light", "sweet", "benchmark", 0.85),
    ("WTIC", "WTI Cushing", 40.8, 0.34, "light", "sweet", "benchmark", 0.0),
    ("WTS", "West Texas Sour", 33.0, 1.60, "medium", "sour", "benchmark", -1.40),
    ("FDL", "Falcon Draw Light (equity)", 44.1, 0.12, "light", "sweet", "equity", 0.65),
    ("RMC", "Red Mesa Condensate (equity)", 52.3, 0.05, "light", "sweet", "equity", -2.10),
    ("CFS", "Coyote Flats Sweet (equity)", 41.2, 0.25, "light", "sweet", "equity", 0.40),
    ("MBL", "Mesquite Bend Light (equity)", 39.6, 0.30, "light", "sweet", "equity", 0.55),
    ("DBL", "Delaware Basin Light Blend", 43.0, 0.18, "light", "sweet", "blend", 0.30),
    ("LBG", "Lone Butte Sour Condensate (equity)", 47.5, 0.95, "light", "sour", "equity", -3.20),
    ("PBX", "Permian Basin Export Blend", 41.5, 0.28, "light", "sweet", "blend", 0.20),
]

REGULATORS = [
    # name, abbreviation, type, jurisdiction, scope, parent index or None
    ("US Environmental Protection Agency", "EPA", "federal", "United States", "air, water, GHG reporting (40 CFR 98)", None),
    ("US EPA Region 6", "EPA-R6", "federal regional office", "TX, NM, OK, AR, LA", "air and water permits, enforcement", 0),
    ("Railroad Commission of Texas", "RRC", "state", "Texas", "oil and gas permitting, spills, well integrity, flaring", None),
    ("Texas Commission on Environmental Quality", "TCEQ", "state", "Texas", "air permits and emissions events", None),
    ("New Mexico Oil Conservation Division", "NMOCD", "state", "New Mexico", "drilling permits, spills, venting and flaring", None),
    ("New Mexico Environment Department", "NMED", "state", "New Mexico", "air quality permits", None),
    ("Pipeline and Hazardous Materials Safety Administration", "PHMSA", "federal", "United States", "pipeline safety (49 CFR 192/195)", None),
    ("Bureau of Land Management - Carlsbad Field Office", "BLM-CFO", "federal", "New Mexico federal lands", "federal leases and APDs", None),
    ("Occupational Safety and Health Administration", "OSHA", "federal", "United States", "worker safety", None),
    ("National Response Center (USCG)", "NRC", "federal", "United States", "release notifications", None),
]

DELIVERY_POINTS = [
    # code, name, type, mode, state, county, lat, lon, custody
    ("DP-01", "Pecos River Crude Terminal", "terminal", "pipeline", "TX", "Reeves", 31.42, -103.50, True),
    ("DP-02", "Mesa Junction Pipeline Interconnect", "pipeline_interconnect", "pipeline", "TX", "Loving", 31.80, -103.48, True),
    ("DP-03", "Falcon Draw LACT Delivery", "lact", "pipeline", "TX", "Reeves", 31.46, -103.64, True),
    ("DP-04", "Coyote Flats Truck Rack", "truck_rack", "truck", "NM", "Eddy", 32.36, -104.03, True),
    ("DP-05", "Midland Hub Interconnect", "pipeline_interconnect", "pipeline", "TX", "Midland", 31.99, -102.08, True),
    ("DP-06", "Red Mesa Gas Plant Inlet", "gas_plant_inlet", "pipeline", "TX", "Loving", 31.84, -103.52, True),
    ("DP-07", "Tumbleweed Gas Interconnect", "pipeline_interconnect", "pipeline", "NM", "Lea", 32.56, -103.40, True),
    ("DP-08", "Martin County Crude Station", "pipeline_station", "pipeline", "TX", "Martin", 32.28, -101.90, True),
    ("DP-09", "Pecos Bend Truck Station", "truck_rack", "truck", "TX", "Pecos", 31.21, -103.30, True),
    ("DP-10", "Gulf Coast Export Dock (via pipeline)", "export_terminal", "tanker", "TX", "Nueces", 27.81, -97.40, True),
    ("DP-11", "Lone Butte Sales Meter", "sales_meter", "pipeline", "TX", "Culberson", 31.74, -104.02, True),
    ("DP-12", "Howard County NGL Interconnect", "ngl_interconnect", "pipeline", "TX", "Howard", 32.24, -101.46, True),
    ("DP-13", "Sandhill Ridge LACT Delivery", "lact", "pipeline", "TX", "Ward", 31.56, -103.12, True),
    ("DP-14", "Yucca Ridge Truck Rack", "truck_rack", "truck", "TX", "Midland", 31.96, -102.12, True),
    ("DP-15", "Permian Rail Transload (inactive)", "rail_transload", "rail", "TX", "Ward", 31.60, -103.05, False),
]
