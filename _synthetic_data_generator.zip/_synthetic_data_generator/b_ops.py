"""Builders: asset integrity, HSE, compliance, production operations, measurement and custody transfer."""

from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Any

import story as S
from assets_world import EQUIP_IDX, EQUIP_ROW, EQUIPMENT, FACILITIES, FACILITY_OF_FIELD, PIPELINES
from b_subsurface import (GRADE_OF_FIELD, WELLS, asset_row_of_well, drill_row_of_well, facility_of_well, well_dates,
                          well_reservoir_zone)
from gen_core import EXPLORATION, PRODUCING, P
from genlib import AS_OF, Ctx
from world import CRUDE_GRADES, DELIVERY_POINTS, FIELDS, RESERVOIRS

AIR_PERMIT_FACS = [0, 2, 5, 6, 7, 10, 15, 16]          # facilities of the air permits (permit rows 25-32)


def fd_aug_gross(widx: int) -> float:
    """Allocated gross oil (bbl) of a Falcon Draw well for August 2026 (shared by allocation and custody transfer)."""
    return 13650.0 + (widx * 211) % 4400

DP_OF_FIELD = [2, 1, 3, 12, 7, 8, 6, 10, 13, 11]          # delivery point row per field
FAC_DP = {0: 2, 1: 2, 2: 1, 3: 1, 4: 3, 5: 3, 6: 12, 7: 7, 8: 7, 9: 8, 10: 6, 11: 10, 12: 13, 13: 11, 14: None,
          15: 1, 16: 3, 17: 0, 18: None, 19: None}
FAC_STATE = {i: ("NM" if f[3] in (2, 6) else "TX") for i, f in enumerate(FACILITIES)}


def fac(i: int) -> int:
    return P("asset.asset_facility", i)


def pfac(i: int) -> int:
    return P("production.production_facility", i)


def prod_fac_of_field(fi: int) -> int:
    return FACILITY_OF_FIELD[fi]


def eq(tag: str) -> int:
    return EQUIP_IDX[tag]


def pw_row(widx: int) -> int:
    return P("production.production_well", PRODUCING.index(widx))


def kick_time() -> datetime:
    d = well_dates(WELLS[S.KICK_WELL])
    return datetime.combine(d["spud"] + timedelta(days=7), datetime.min.time()) + timedelta(hours=3, minutes=40)


LOPC_TIME = datetime(2026, 3, 14, 10, 40)
K201_TIME = datetime(2025, 9, 18, 14, 20)
PIPE_TIME = datetime(2026, 5, 6, 6, 50)


def inc_time(k: int) -> datetime:
    fixed = {S.INC_KICK: kick_time(), S.INC_LOPC: LOPC_TIME, S.INC_K201: K201_TIME, S.INC_PIPE: PIPE_TIME}
    if k in fixed:
        return fixed[k]
    return datetime(2024, 3, 4, 8, 15) + timedelta(days=(k * 19.7) % 930, hours=(k * 5) % 10)


# ---------------------------------------------------------------------------
# asset integrity
# ---------------------------------------------------------------------------
SYSTEMS = [(0, "COMP", "Gas compression"), (0, "SEP", "Separation and treating"), (0, "FLR", "Flare and vapour recovery"),
           (5, "SEP", "Separation and treating"), (5, "FLR", "Flare"), (2, "COMP", "Gas compression"),
           (15, "COMP", "Gas compression"), (11, "TRT", "Sour gas treating"), (19, "R104", "Rig R104 drilling equipment"),
           (17, "STOR", "Crude storage")]
UNIT_TAGS = ["FD1-K-201", "FD1-PSV-201A", "FD1-V-101", "FD1-H-301", "FD1-VRU-501", "FD1-FL-601", "CF2-V-110", "CF2-LCV-110",
             "CF2-SDV-110", "CF2-FL-615", "RM1-K-211", "MJ-K-901", "MJ-K-902", "LB1-AMN-171", "LB1-GD-01", "R104-TD",
             "R104-MP-2", "R104-BOP", "PT-TK-951", "PT-P-952"]
UNIT_SYSTEM = {"FD1-K-201": 0, "FD1-PSV-201A": 0, "FD1-V-101": 1, "FD1-H-301": 1, "FD1-VRU-501": 2, "FD1-FL-601": 2,
               "CF2-V-110": 3, "CF2-LCV-110": 3, "CF2-SDV-110": 3, "CF2-FL-615": 4, "RM1-K-211": 5, "MJ-K-901": 6,
               "MJ-K-902": 6, "LB1-AMN-171": 7, "LB1-GD-01": 7, "R104-TD": 8, "R104-MP-2": 8, "R104-BOP": 8,
               "PT-TK-951": 9, "PT-P-952": 9}


def hierarchy(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i < 20:
        code, name = FACILITIES[i][0], FACILITIES[i][1]
        flc, path, level, cls, parent_note = code, f"OGX/PERMIAN/{code}", "3", "installation", "Permian business unit"
    elif i < 30:
        fi, sys, sname = SYSTEMS[i - 20]
        code = FACILITIES[fi][0]
        flc, path, level, cls, name = f"{code}-{sys}", f"OGX/PERMIAN/{code}/{code}-{sys}", "5", "system", f"{FACILITIES[fi][1]} - {sname}"
    else:
        tag = UNIT_TAGS[i - 30]
        fi, sys, _ = SYSTEMS[UNIT_SYSTEM[tag]]
        code = FACILITIES[fi][0]
        e = EQUIPMENT[EQUIP_ROW[tag]]
        flc, path, level, cls, name = tag, f"OGX/PERMIAN/{code}/{code}-{sys}/{tag}", "6", "equipment unit", e[1]
    crit = "critical" if i >= 30 and EQUIPMENT[EQUIP_ROW[flc]][4] == "critical" else ("high" if level != "6" else "medium")
    r.update(functional_location_code=flc, path=path, hierarchy_level=level, depth=str(path.count("/")),
             hierarchy_type="functional_location", relationship_type=f"ISO 14224 taxonomy level {level} ({cls})",
             asset_class=cls if level != "6" else EQUIPMENT[EQUIP_ROW[flc]][2], criticality_rating=crit,
             hse_classification="safety_critical" if level == "6" and EQUIPMENT[EQUIP_ROW[flc]][5] else "standard",
             hierarchy_status="active", primary_hierarchy_flag=True, cost_rollup_flag=True, performance_rollup_flag=True,
             operating_unit="Permian Operations", planner_group=f"PG-{code[:2]}", geographic_location_code=code,
             notes=f"{name}", effective_date=date(2023, 1, 1), end_date=None, approved_by=ctx.person(),
             approval_date=date(2022, 12, 15), change_reason="initial load from CMMS functional location tree",
             moc_required_flag=False, moc_reference_number=None, sort_sequence=str(i + 1), joint_venture_code=None,
             integrity_management_program="RBI" if level == "6" else None, working_interest_percentage=100.0, cost_center=f"CC-41{i % 10:02d}",
             _anchor=date(2023, 1, 1))


def asset_facility(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    code, name, kind, fi, lat, lon, prod = FACILITIES[i]
    st = FAC_STATE[i]
    county = FIELDS[fi][4] if fi is not None else "Reeves"
    r.update(facility_code=code, facility_name=name, facility_type=kind, latitude=lat, longitude=lon, state_province=st,
             county_district=county, country_code="US", operational_status="operating", record_status="active",
             commissioning_date=date(2019, 6, 1) + timedelta(days=i * 61), hse_tier="tier_2" if "compressor" in kind or "gas" in kind else "tier_3",
             process_safety_tier="pst_2" if i in (5, 11, 15, 17) else "pst_3", iso_55001_classification="critical" if i in (5, 11, 15, 17) else "essential",
             capacity_unit="mmcfd" if "compressor" in kind or "gas" in kind else ("bpd" if "disposal" in kind else "bopd"),
             design_capacity=ctx.num(8000, 40000, 0) if "battery" in kind or "terminal" in kind else ctx.num(20, 180),
             delivery_point_id=P("customer.delivery_point", FAC_DP[i]) if FAC_DP[i] is not None else None,
             gis_feature_code=f"GIS-{code}", maximo_location_code=code, pi_system_tag_prefix=f"OGX.{code}",
             scada_integration_status="integrated" if i < 18 else "partial", regulatory_jurisdiction="state",
             environmental_permit_number=None, capex_opex_designation="capex", depreciation_method="units_of_production",
             original_cost=ctx.num(4e6, 60e6, 0), useful_life_years="25", next_turnaround_date=date(2027, 4, 1) + timedelta(days=i * 13),
             last_integrity_assessment_date=date(2026, 2, 1) + timedelta(days=i * 5), planned_decommissioning_date=date(2049, 12, 31),
             actual_decommissioning_date=None, _state=st, _county=county, _anchor=date(2026, 2, 1))


OVERDUE = {"R107-BOP": date(2026, 8, 15), "LB1-GD-01": date(2026, 7, 1), "CF2-SDV-110": date(2026, 9, 1), "FD1-FL-601": date(2026, 6, 30)}


def equipment(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    tag, name, etype, fi, crit, safety, env, parent, strat = EQUIPMENT[i]
    inst = date(2014, 1, 1) + timedelta(days=(i * 97) % 3800)
    last = date(2025, 9, 1) + timedelta(days=(i * 11) % 300)
    nxt = OVERDUE.get(tag, last + timedelta(days=365))
    mtbf = {"compressor": 4200, "electric submersible pump": 2900, "valve": 26000, "vessel": 60000, "top drive": 1800,
            "pump": 9000, "flare": 30000, "storage tank": 80000, "meter": 15000, "heater": 22000, "blowout preventer": 40000,
            "fire and gas detector": 35000}[etype]
    if tag in (S.ESP09, S.TOPDRIVE):
        mtbf = int(mtbf * 0.45)
    r.update(tag=tag, equipment_name=name, equipment_type=etype, api_equipment_class=etype, asset_facility_id=fac(fi),
             parent_equipment_id=eq(parent) if parent else None, criticality_ranking=crit, is_safety_critical=safety,
             is_environmental_critical=env, maintenance_strategy="reliability_centered" if strat == "risk_based" else strat, installation_date=inst, last_inspection_date=last,
             next_inspection_due_date=nxt, operational_status="in service", mtbf_hours=float(mtbf), mttr_hours=ctx.num(4, 36, 1),
             serial_number=f"SN-{tag.replace('-', '')}-{1000 + i}", model_number=f"MDL-{etype[:3].upper()}-{200 + i}",
             design_pressure_psi=ctx.num(285, 1480, 0) if etype in ("vessel", "valve", "compressor") else None,
             design_temperature_f=ctx.num(150, 300, 0) if etype in ("vessel", "compressor", "heater") else None,
             motor_rating_hp=float(name.split(" hp")[0].split()[-1].replace(",", "").lstrip("(")) if " hp" in name else None,
             design_code="ASME VIII Div 1" if etype == "vessel" else ("API 618" if etype == "compressor" and "reciprocating" in name else
                                                                      ("API 650" if etype == "storage tank" else ("API 16A" if etype == "blowout preventer" else None))),
             capex_classification="sustaining", depreciation_method="straight_line", acquisition_cost_usd=ctx.num(15000, 4.5e6, 0),
             useful_life_years="20", pm_frequency_days=str(90 if etype in ("compressor", "top drive") else 365), moc_required=False,
             permit_id=None, delivery_point_id=None, vendor_datasheet_reference=f"DS-{tag}", warranty_expiration_date=None,
             _anchor=last)


def pipeline_segment(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    num, name, kind, f_from, f_to, dia = PIPELINES[i]
    water = "water" in name or kind == "injection"
    fluid = "produced water" if water else ("natural gas" if "gas" in name else "crude oil")
    r.update(segment_number=num, pipeline_name=name, segment_type=kind, nominal_diameter_inches=dia,
             from_node_location=FACILITIES[f_from][1] if f_from is not None else "well pad manifold",
             to_node_location=FACILITIES[f_to][1] if f_to is not None else "third-party interconnect",
             fluid_service_type=fluid, segment_length_miles=ctx.num(0.6, 14), wall_thickness_inches=ctx.pick([0.188, 0.25, 0.322, 0.375]),
             material_grade="API 5L X52" if not water else "API 5L X42 internally coated", coating_type="FBE" if not water else "FBE + internal plastic liner",
             cathodic_protection_type="impressed_current" if dia >= 8 else "sacrificial_anode", design_pressure_psi=ctx.num(720, 1440, 0),
             maximum_operating_pressure_psi=ctx.num(600, 1200, 0), phmsa_regulatory_class="class_1", hca_flag=i in (3, 23),
             integrity_status="poor" if i == S.PIPE_FD07 else ctx.pick(["good", "good", "fair"]), risk_score=78.0 if i == S.PIPE_FD07 else ctx.num(15, 55),
             inspection_method="ILI (MFL) + direct assessment" if dia >= 8 else "external corrosion direct assessment",
             installation_date=date(2017, 3, 1) + timedelta(days=i * 70), installation_year=str(2017 + i // 6),
             last_inspection_date=date(2026, 3, 30) if i == S.PIPE_FD07 else date(2025, 5, 1) + timedelta(days=i * 9),
             next_inspection_due_date=date(2027, 3, 30) + timedelta(days=i * 9), operational_status="active",
             permit_id=P("compliance.permit", 37) if num.startswith("FD") else None,
             delivery_point_id=P("customer.delivery_point", 0) if num in ("FD-04", "PT-01") else None,
             maximo_asset_number=f"PL-{num}", scada_tag_code=f"OGX.PL.{num}", geographic_region="Permian - Delaware Basin" if not num.startswith(("MB", "YR", "OC")) else "Permian - Midland Basin",
             state_province="NM" if num.startswith(("CF", "TW")) else "TX", country_code="US", depreciation_method="straight_line",
             acquisition_cost_usd=ctx.num(0.3e6, 6e6, 0), book_value_usd=ctx.num(0.1e6, 4e6, 0), useful_life_years="30",
             working_interest_percentage=100.0, decommission_date=None, _anchor=date(2025, 6, 1))


PROGRAMS = [
    ("CMP-FD", "Falcon Draw gathering corrosion management", "corrosion management", "API RP 1160 / 49 CFR 195 IMP", None, 6, "internal and external corrosion"),
    ("CUI-01", "Corrosion under insulation programme", "corrosion management", "API RP 583", 0, None, "corrosion under insulation"),
    ("RBI-VES", "Risk-based inspection - pressure vessels", "risk-based inspection", "API RP 580 / 581", 5, None, "general and localised corrosion"),
    ("TNK-653", "Storage tank integrity", "tank integrity", "API 653", 17, None, "floor and shell corrosion"),
    ("PSV-TST", "Pressure relief device testing", "safety device testing", "API RP 576", 0, None, "set-pressure drift, seat leakage"),
    ("PIM-195", "Pipeline integrity management", "pipeline integrity", "49 CFR 195.452", None, 3, "external corrosion, third-party damage"),
    ("WIM-01", "Well integrity management", "well integrity", "API RP 90-2 / NORSOK D-010 principles", None, None, "annular pressure, casing wear"),
    ("BOP-53", "BOP certification and testing", "well control equipment", "API Standard 53", 19, None, "elastomer degradation"),
    ("RCM-ROT", "Rotating equipment condition monitoring", "condition monitoring", "ISO 13374 / ISO 14224", 0, None, "valve wear, vibration"),
    ("ESP-MON", "ESP run-life surveillance", "condition monitoring", "ISO 14224 (ESP class)", 2, None, "motor insulation, scale"),
    ("FLR-REL", "Flare system reliability", "reliability", "API 537", 0, None, "pilot and tip degradation"),
    ("SIS-FT", "Safety instrumented system function testing", "functional safety", "IEC 61511", 5, None, "dangerous undetected failures"),
    ("FGS-01", "Fire and gas detection testing", "functional safety", "IEC 61511 / NFPA 72", 11, None, "sensor drift, poisoning"),
    ("AMN-01", "Amine unit integrity", "corrosion management", "API RP 945", 11, None, "amine stress corrosion cracking"),
    ("CMP-RM", "Red Mesa gathering corrosion management", "corrosion management", "API RP 1160", None, 8, "internal corrosion"),
    ("CMP-CF", "Coyote Flats gathering corrosion management", "corrosion management", "API RP 1160", None, 11, "internal corrosion"),
    ("SWD-01", "SWD injection integrity", "well integrity", "UIC Class II MIT", 14, None, "tubing leak, annulus pressure"),
    ("MTR-PRV", "Custody meter proving", "measurement integrity", "API MPMS Ch. 4 / Ch. 12", 0, None, "meter factor drift"),
    ("CS-VIB", "Compressor station vibration programme", "condition monitoring", "API 618 / ISO 10816", 15, None, "pulsation, foundation"),
    ("TERM-PIP", "Terminal piping inspection", "risk-based inspection", "API 570", 17, None, "external corrosion"),
]


def integrity_program(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    code, name, kind, std, fi, pipe, mech = PROGRAMS[i]
    r.update(program_number=code, program_name=name, program_type=kind, applicable_standard=std, regulatory_basis=std,
             damage_mechanism=mech, asset_facility_id=fac(fi) if fi is not None else None,
             pipeline_segment_id=P("asset.pipeline_segment", pipe) if pipe is not None else None,
             equipment_id=eq("FD1-K-201") if code == "RCM-ROT" else (eq("CF2-V-110") if code == "RBI-VES" else (eq("PT-TK-951") if code == "TNK-653" else None)),
             well_asset_id=None, program_status="active", inspection_strategy="risk-based" if "RBI" in code or code == "TERM-PIP" else "time-based",
             rbi_methodology="API 581" if "RBI" in code else "qualitative", acceptable_risk_threshold="medium",
             inspection_interval_months=str(ctx.pick([6, 12, 24, 36])), annual_budget_amount=ctx.num(80000, 900000, 0), budget_currency_code="USD",
             program_owner=ctx.person(), operating_unit="Permian Operations", capex_opex_classification="OPEX",
             monitoring_method={"condition monitoring": "online vibration and temperature", "corrosion management": "UT thickness and coupons"}.get(kind, "periodic inspection"),
             cml_registry_flag=kind in ("corrosion management", "risk-based inspection"), fitness_for_service_flag=True,
             turnaround_alignment_flag=kind == "risk-based inspection", moc_required_flag=False,
             program_description=f"{name} per {std}; covers {mech}.", effective_date=date(2023, 1, 1), expiration_date=date(2028, 12, 31),
             last_review_date=date(2026, 1, 20), next_review_date=date(2027, 1, 20), permit_id=None, asset_class=kind, _anchor=date(2026, 1, 20))


# ---------------------------------------------------------------------------
# compliance
# ---------------------------------------------------------------------------
VIOLATIONS = [
    # authority idx, category, type, regulation, description, severity, penalty, facility idx, equipment tag, pipeline idx, root cause cat
    (2, "safety", "late notification", "RRC Statewide Rule 20 (16 TAC 3.20) - notification of fires, leaks or blowouts",
     "Well control event on Red Mesa 12-2H with gas release at the shakers was reported 31 hours after the event (requirement: immediately/24 h).",
     "major", 18500.0, None, None, None, "procedural"),
    (4, "environmental", "release", "19.15.29 NMAC - releases",
     "Release of 46 bbl crude oil from separator V-110 at Coyote Flats CTB-2; high-level trip bypassed during maintenance.",
     "critical", 48500.0, 5, "CF2-V-110", None, "management_system"),
    (2, "environmental", "release", "RRC Statewide Rule 8 (16 TAC 3.8) - water protection",
     "12 bbl produced-water release from gathering line FD-07 (external corrosion pinhole) reached a dry wash.",
     "major", 12000.0, 0, None, S.PIPE_FD07, "equipment_failure"),
]


def violation(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i < len(VIOLATIONS):
        auth, cat, vtype, reg, desc, sev, pen, fi, tag, pipe, rcc = VIOLATIONS[i]
        when = [kick_time(), LOPC_TIME, PIPE_TIME][i].date()
        well = asset_row_of_well(S.KICK_WELL) if i == 0 else None
    else:
        k = i - len(VIOLATIONS)
        auth = [3, 3, 5, 0, 8, 6, 2, 4, 3, 5, 8, 2][k % 12]
        cat = {3: "environmental", 5: "environmental", 0: "reporting", 8: "safety", 6: "operational", 2: "environmental", 4: "environmental"}[auth]
        reg = {3: "30 TAC 101.201 - emissions event reporting", 5: "20.2.50 NMAC - oil and gas sector ozone precursor pollutants",
               0: "40 CFR 98 Subpart W - petroleum and natural gas systems reporting", 8: "29 CFR 1910.147 - control of hazardous energy (lockout/tagout)",
               6: "49 CFR 195 - integrity management records", 2: "RRC Statewide Rule 32 - flaring authorisation exceeded",
               4: "19.15.27 NMAC - venting and flaring"}[auth]
        vtype = {3: "emissions event", 5: "permit deviation", 0: "reporting error", 8: "lockout/tagout", 6: "records", 2: "flaring", 4: "flaring"}[auth]
        fi = [5, 2, 4, 7, 0, 15, 2, 5, 10, 16, 6, 3][k % 12]
        desc = {"emissions event": f"Unreported emissions event at {FACILITIES[fi][1]} during compressor trip.",
                "permit deviation": f"Tank vapour control downtime above permitted hours at {FACILITIES[fi][1]}.",
                "reporting error": "Subpart W pneumatic device counts under-reported for reporting year 2024.",
                "lockout/tagout": f"Energy isolation not verified before work on pump at {FACILITIES[fi][1]}.",
                "records": "Integrity management records incomplete for two gathering segments.",
                "flaring": f"Flared volume above the authorised limit at {FACILITIES[fi][1]} during takeaway constraint."}[vtype]
        sev = ctx.pick(["minor", "moderate", "major"])
        pen = ctx.num(1500, 32000, 0)
        tag, pipe, rcc, well = None, None, "human_error" if vtype == "lockout/tagout" else ctx.pick(["equipment_failure", "procedural", "management_system"]), None
        when = date(2024, 5, 1) + timedelta(days=k * 33)
    r.update(nov_number=f"NOV-{['EPA', 'EPA6', 'RRC', 'TCEQ', 'OCD', 'NMED', 'PHMSA', 'BLM', 'OSHA', 'NRC'][auth]}-{when.year}-{i + 1:04d}",
             regulatory_authority_id=P("compliance.regulatory_authority", auth), violation_category=cat, violation_type=vtype,
             regulation_cited=reg, violation_description=desc, severity_level=sev, penalty_amount=pen, penalty_currency="USD",
             penalty_payment_status="paid_in_full" if when < date(2026, 4, 1) else "assessed_unpaid",
             penalty_paid_date=when + timedelta(days=75) if when < date(2026, 4, 1) else None,
             asset_facility_id=fac(fi) if fi is not None else None, equipment_id=eq(tag) if tag else None,
             pipeline_segment_id=P("asset.pipeline_segment", pipe) if pipe is not None else None, well_asset_id=well,
             permit_id=P("compliance.permit", 25 + AIR_PERMIT_FACS.index(fi)) if fi in AIR_PERMIT_FACS and cat == "environmental" and i >= 3 else None,
             discovery_date=when, nov_issue_date=when + timedelta(days=21), start_date=when, end_date=when + timedelta(days=1),
             discovery_source="regulatory_inspection" if i in (0, 2) else ("self_disclosure" if i == 1 else ctx.pick(["regulatory_inspection", "internal_audit", "self_disclosure"])),
             issuing_authority_type="federal" if auth in (0, 1, 6, 7, 8, 9) else "state", jurisdiction="New Mexico" if auth in (4, 5) else "Texas",
             resolution_status="closed" if when < date(2026, 1, 1) else "in_progress", closure_date=when + timedelta(days=120) if when < date(2026, 1, 1) else None,
             root_cause=desc.split(";")[-1].strip() if ";" in desc else "See investigation.", root_cause_category=rcc,
             capa_description="Implement corrective actions from the investigation and verify effectiveness.", capa_responsible_party=ctx.person(),
             capa_target_date=when + timedelta(days=90), capa_completion_date=when + timedelta(days=110) if when < date(2026, 3, 1) else None,
             capa_effectiveness_review="effective" if when < date(2026, 1, 1) else "in_progress", repeat_violation=vtype == "flaring" and k > 6,
             ghg_related=vtype in ("emissions event", "flaring", "reporting error", "permit deviation"), appeal_status="not_appealed",
             response_due_date=when + timedelta(days=30), regulatory_program=reg.split(" - ")[0], internal_reference_number=f"VIO-{i + 1:03d}",
             sec_disclosure_required=False, _anchor=when)


# ---------------------------------------------------------------------------
# HSE
# ---------------------------------------------------------------------------
EMISSION_PRIMARY = {i: ("flare", "flared_emissions") for i in range(14)}
EMISSION_PRIMARY.update({14: ("pump engine", "stationary_combustion"), 15: ("compressor engines", "stationary_combustion"),
                         16: ("compressor engines", "stationary_combustion"), 17: ("tank vapours", "vented_emissions"),
                         18: ("pump engine", "stationary_combustion"), 19: ("fugitive components", "fugitive_emissions")})
FLARE_TAG = {0: "FD1-FL-601", 2: "RM1-FL-611", 5: "CF2-FL-615"}
COMP_TAG = {15: "MJ-K-901", 16: "CF-CS-K-911"}
PNEU_FACS = [0, 2, 4, 5, 7, 10]


def emission_source(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i < 20:
        fi = i
        kind, cat = EMISSION_PRIMARY[i]
        tag = FLARE_TAG.get(fi) or COMP_TAG.get(fi)
    elif i < 34:
        fi, kind, cat, tag = i - 20, "fugitive components", "fugitive_emissions", None
    else:
        fi, kind, cat, tag = PNEU_FACS[i - 34], "pneumatic controllers", "vented_emissions", None
    code = FACILITIES[fi][0]
    r.update(source_number=f"ES-{code}-{i + 1:03d}", source_name=f"{FACILITIES[fi][1]} {kind}", source_type=kind, source_category=cat,
             equipment_type=kind, asset_facility_id=fac(fi), equipment_id=eq(tag) if tag else None,
             permit_id=P("compliance.permit", 25 + AIR_PERMIT_FACS.index(fi)) if fi in AIR_PERMIT_FACS else None,
             operational_status="active", esg_reporting_scope="scope_1", ghg_reporting_required=True, data_quality_tier="tier_2",
             emission_factor_source="EPA 40 CFR 98 Subpart W Table W-1" if cat != "stationary_combustion" else "EPA 40 CFR 98 Subpart C",
             monitoring_methodology="OGI survey + component count" if cat == "fugitive_emissions" else ("flow meter + combustion efficiency 98%" if cat == "flared_emissions" else "fuel metering"),
             control_device_installed=cat in ("flared_emissions",) or kind == "tank vapours", control_device_type="flare" if cat == "flared_emissions" else ("VRU" if kind == "tank vapours" else None),
             control_efficiency_percent=98.0 if cat == "flared_emissions" else (95.0 if kind == "tank vapours" else None),
             ldar_program_applicable=cat == "fugitive_emissions", ldar_component_count=str(ctx.int_(600, 2400)) if cat == "fugitive_emissions" else None,
             cems_installed=False, title_v_major_source=fi in (15, 16), nsps_subpart_applicable="OOOOb" if fi < 17 else None,
             neshap_subpart_applicable="HH" if fi in (15, 16) else None, regulatory_threshold_applicable=True,
             permit_emission_limit=ctx.num(10, 95), permit_emission_limit_unit="tons/year",
             geographic_coordinates=f"{FACILITIES[fi][4]},{FACILITIES[fi][5]}", commissioning_date=date(2019, 6, 1) + timedelta(days=fi * 61),
             decommissioning_date=None, h2s_concentration_ppm=ctx.num(300, 1500) if fi == 11 else 0.0, norm_present=False,
             fuel_heating_value=1.05 if cat == "stationary_combustion" else None, fuel_heating_value_unit="MMBtu/scf" if cat == "stationary_combustion" else None,
             rated_capacity=ctx.num(5, 60), rated_capacity_unit="MMscfd" if cat == "flared_emissions" else "hp", _anchor=date(2025, 1, 1))


PTW_TYPES = ["hot_work", "electrical_isolation", "confined_space_entry", "hot_work", "working_at_height", "electrical_isolation", "hot_work",
             "simops", "excavation", "electrical_isolation", "hot_work", "confined_space_entry", "working_at_height", "electrical_isolation"]
PTW_FAC = [0, 2, 5, 15, 17, 7, 4, 19, 6, 10, 2, 17, 15, 11]


def permit_to_work(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i == S.PTW_LOPC:
        ptype, fi, start, tag = "electrical_isolation", 5, datetime(2026, 3, 14, 7, 0), "CF2-V-110"
        desc = "Replace level transmitter LT-110 on separator V-110; isolate LT-110 power and signal loop; high-level trip in bypass during the work."
        iso = "Electrical isolation of LT-110 loop at MCC-2; SDV-110 trip bypassed (no MOC, no time limit recorded)."
    elif i <= 14:
        ptype, fi = PTW_TYPES[i - 1], PTW_FAC[i - 1]
        t = inc_time(i + 3)
        start, tag = t - timedelta(hours=3), None
        desc = {"hot_work": "Welding repair on piping support", "electrical_isolation": "Motor and MCC work on pump drive",
                "confined_space_entry": "Tank / vessel internal inspection", "working_at_height": "Flare and stack maintenance at height",
                "simops": "Simultaneous operations: rig move next to producing wells", "excavation": "Excavation to expose buried flowline"}[ptype]
        iso = "Isolation per LOTO procedure; try-out step recorded" if ptype != "electrical_isolation" or i not in (2, 6, 10, 14) else \
            "Isolation points listed but try-out step not recorded"
    else:
        ptype, fi = ctx.pick(["hot_work", "electrical_isolation", "confined_space_entry", "working_at_height", "excavation", "simops"]), ctx.pick(range(20))
        start = datetime(2024, 4, 1, 7, 0) + timedelta(days=(i * 17) % 900)
        tag, desc, iso = None, "Routine maintenance work", "Isolation per LOTO procedure"
    end = start + timedelta(hours=12)
    r.update(permit_number=f"PTW-{start.year}-{i + 1:04d}", permit_type=ptype, permit_status="closed", work_description=desc,
             work_location=FACILITIES[fi][1], asset_facility_id=fac(fi), equipment_id=eq(tag) if tag else None,
             rig_id=P("drilling.rig", 3) if fi == 19 else None, issued_timestamp=start - timedelta(minutes=30), activated_timestamp=start,
             valid_from_timestamp=start, valid_until_timestamp=end, closed_timestamp=end, isolation_requirements=iso,
             energy_sources_isolated="electrical" if ptype == "electrical_isolation" else ("process" if ptype in ("hot_work", "confined_space_entry") else None),
             hazard_identification_summary={"hot_work": "flammable atmosphere, fire", "electrical_isolation": "stored electrical energy, unexpected start-up",
                                            "confined_space_entry": "oxygen deficiency, H2S, engulfment", "working_at_height": "falls, dropped objects",
                                            "simops": "dropped objects, gas release near rig", "excavation": "buried services, cave-in"}[ptype],
             gas_test_lel_percent=ctx.num(0, 4) if ptype in ("hot_work", "confined_space_entry") else None,
             gas_test_h2s_ppm=ctx.num(0, 2) if ptype in ("hot_work", "confined_space_entry") else None,
             gas_test_oxygen_percent=20.9 if ptype == "confined_space_entry" else None, gas_test_co_ppm=0.0 if ptype == "confined_space_entry" else None,
             gas_test_timestamp=start if ptype in ("hot_work", "confined_space_entry") else None,
             concurrent_permit_check_flag=ptype == "simops", jsa_reference_number=f"JSA-{start.year}-{i + 1:04d}",
             ppe_requirements="FRC, H2S monitor, hard hat, glasses, gloves" + (", harness" if ptype == "working_at_height" else ""),
             emergency_contact_name=ctx.person(), emergency_contact_phone=f"+1-432-555-{100 + i:04d}",
             work_completion_notes="Work completed; site returned to operations." if i != S.PTW_LOPC else "Work suspended after the LOPC; trip bypass removed at 11:05.",
             cancellation_reason=None, cancelled_timestamp=None, suspended_timestamp=None, suspension_reason=None,
             environmental_conditions=ctx.pick(["clear, 72F", "windy, 25 mph", "overcast, 58F"]), _anchor=start.date())


def custody_ct(i: int) -> tuple[int, int]:
    """(month, field idx) of custody transfer i (0-29 field transfers, Aug/Jul/Jun x 10 fields)."""
    return [8, 7, 6][i // 10], i % 10


def custody_transfer(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i < 30:
        mm, fi = custody_ct(i)
        dp = DP_OF_FIELD[fi]
        grade = GRADE_OF_FIELD[fi]
        res = P("reservoir.reservoir", [k for k, (f, _) in enumerate(RESERVOIRS) if f == fi][0])
        ref = "CT-2026-0815" if i == S.CT_FD_AUG else f"CT-2026-{mm:02d}{fi + 20:02d}"
        when = date(2026, mm, 28) if mm != 8 else date(2026, 8, 31)
    else:
        k = i - 30
        mm, fi = 0, None
        dp, grade, res = (0 if k < 6 else 9), 9 if k >= 6 else 7, None
        when = date(2026, 3 + k // 2, 10 + (k % 2) * 12)
        ref = f"CT-2026-T{k + 1:03d}"
    gas = DELIVERY_POINTS[dp][2] in ("gas_plant_inlet",) or dp in (6, 10)
    gov = ctx.num(28000, 160000, 0) if not gas else ctx.num(150000, 900000, 0)
    if i == S.CT_FD_AUG:
        # LACT ticket total equals the allocated gross oil of the eight Falcon Draw wells plus 0.4% BS&W
        gov = round(sum(fd_aug_gross(k) for k in range(8)) * 1.004, 0)
    gsv = round(gov * 0.996, 0)
    nsv = round(gsv * (1 - 0.0035), 0)
    r.update(transfer_reference_number=ref, transfer_date=when, transfer_timestamp=datetime.combine(when, datetime.min.time()) + timedelta(hours=23, minutes=59),
             delivery_point_id=P("customer.delivery_point", dp), crude_grade_id=P("product.crude_grade", grade), reservoir_id=res,
             drilling_well_id=None, gross_observed_volume=gov, gross_standard_volume=gsv, net_standard_volume=nsv,
             volume_unit_of_measure="mcf" if gas else "bbl", bsw_percentage=0.0 if gas else 0.35, api_gravity=None if gas else CRUDE_GRADES[grade][2],
             sulfur_content_percentage=None if gas else CRUDE_GRADES[grade][3], observed_temperature=ctx.num(70, 98, 1),
             temperature_unit_of_measure="F", observed_pressure=ctx.num(20, 120, 0), pressure_unit_of_measure="psi",
             meter_ticket_number=f"MT-{ref[3:]}", inspection_type="quantity", inspection_date=when, independent_inspector_company="Permian Measurement Services (synthetic)",
             inspector_name=ctx.person(), inspection_certificate_number=f"IC-{ref[3:]}", transfer_status="completed",
             seal_verification_status="intact", seal_numbers=f"S{ctx.int_(100000, 999999)}", tariff_rate=ctx.num(0.45, 1.85),
             currency_code="USD", quantity_variance_flag=fi == 2 if i < 30 else False, quality_claim_flag=False, royalty_calculation_flag=True,
             jib_allocation_status="allocated" if mm != 8 or i >= 30 else "pending", draft_survey_result=None, _anchor=when)


ESP_WELLS = {10: "RM-ESP-09", 3: "FD-ESP-03", 16: "CF-ESP-04", 22: "SR-ESP-02"}


def artificial_lift(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    widx = PRODUCING[i]
    w = WELLS[widx]
    fi = w.field
    if widx in ESP_WELLS:
        lt = "ESP"
    elif fi in (4, 8, 9):
        lt = "Rod Pump"
    elif fi == 7:
        lt = "Plunger Lift"
    else:
        lt = "Gas Lift"
    d = well_dates(w)
    inst = d["first_prod"] + timedelta(days=90 if lt != "ESP" else 1)
    failed = widx == 10
    r.update(installation_number=f"AL-{w.api10[-5:]}-{i + 1:02d}", production_well_id=pw_row(widx), lift_type=lt,
             equipment_id=eq(ESP_WELLS[widx]) if widx in ESP_WELLS else None, lift_status="Operating" if not failed else "Operating",
             installation_date=min(inst, AS_OF - timedelta(days=30)), removal_date=None, failure_date=date(2026, 3, 5) if failed else None,
             failure_mode="motor burnout (winding insulation failure)" if failed else None, run_life_days=str(205 if failed else ctx.int_(300, 900)),
             design_rate_bopd=ctx.num(400, 1200, 0), actual_rate_bopd=ctx.num(150, 900, 0), pump_depth_ft=ctx.num(8500, 10400, 0),
             pump_intake_pressure_psi=ctx.num(350, 1200, 0), discharge_pressure_psi=ctx.num(2800, 4200, 0),
             motor_horsepower=ctx.num(150, 450, 0) if lt == "ESP" else (ctx.num(40, 125, 0) if lt == "Rod Pump" else None),
             motor_current_amps=ctx.num(40, 95) if lt == "ESP" else None, motor_temperature_f=ctx.num(220, 290, 0) if lt == "ESP" else None,
             motor_voltage="2300" if lt == "ESP" else None, operating_frequency_hz=ctx.num(48, 62) if lt == "ESP" else None, target_frequency_hz=55.0 if lt == "ESP" else None,
             pump_stages=str(ctx.int_(120, 260)) if lt == "ESP" else None, strokes_per_minute=ctx.num(5, 9) if lt == "Rod Pump" else None,
             stroke_length_inches=ctx.num(144, 216, 0) if lt == "Rod Pump" else None, gas_injection_rate_mcfd=ctx.num(450, 1200, 0) if lt == "Gas Lift" else None,
             target_gas_injection_rate_mcfd=900.0 if lt == "Gas Lift" else None, power_consumption_kwh=ctx.num(2500, 9000, 0) if lt in ("ESP", "Rod Pump") else None,
             operating_cost_per_day_usd=ctx.num(90, 420, 0), installation_cost_usd=ctx.num(45000, 260000, 0),
             optimization_target="Extend Run Life" if lt == "ESP" else "Maximize Production",
             last_maintenance_date=date(2026, 3, 8) if failed else date(2026, 5, 1) + timedelta(days=i * 3), next_maintenance_date=date(2026, 11, 1) + timedelta(days=i * 3),
             work_order_number=None, comments="Third ESP failure on this well in 13 months; scale and high motor temperature." if failed else None,
             _anchor=inst)


def measurement_point(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i < 15:
        code, name = FACILITIES[i][0], FACILITIES[i][1]
        mp_code = METER_CODES[i]
        ltype, ptype = ("processing_plant" if i == 11 else ("wellhead" if i == 14 else "pipeline")), ("custody_transfer_meter" if i not in (14,) else "allocation_meter")
        fi, dp = i, FAC_DP[i]
    else:
        k = i - 15
        fi = [17, 17, 15, 15, 16, 0, 2, 5, 7, 10][k]
        name = FACILITIES[fi][1]
        mp_code = f"MP-{FACILITIES[fi][0]}-{['TG1', 'TG2', 'CHK1', 'CHK2', 'CHK1', 'CHK3', 'CHK3', 'CHK3', 'CHK3', 'CHK3'][k]}"
        ltype, ptype, dp = ("terminal" if fi == 17 else "pipeline"), ("tank_gauge" if fi == 17 else "check_meter"), FAC_DP[fi]
    gas = i == 11 or (i >= 15 and fi in (15, 16))
    code_out = mp_code if mp_code.startswith("MP-") else f"MP-{mp_code}"
    r.update(measurement_point_code=code_out, measurement_point_name=f"{name} {ptype.replace('_', ' ')}",
             location_type=ltype, point_type=ptype, asset_facility_id=fac(fi), delivery_point_id=P("customer.delivery_point", dp) if dp is not None else None,
             pipeline_segment_id=None, permit_id=None, block_id=None, exploration_well_id=None, emission_source_id=None,
             custody_transfer_flag=ptype == "custody_transfer_meter", fiscal_measurement_flag=ptype == "custody_transfer_meter",
             meter_type="ultrasonic" if gas else ("coriolis" if ptype != "tank_gauge" else "positive_displacement"),
             product_type="natural gas" if gas else "crude oil", flow_rate_unit_of_measure="mcf_per_day" if gas else "bbl_per_day",
             maximum_flow_rate=ctx.num(5000, 60000, 0), minimum_flow_rate=ctx.num(100, 900, 0), meter_size_inches=ctx.pick([3.0, 4.0, 6.0]),
             meter_factor=ctx.num(0.9985, 1.0015, 4), uncertainty_percentage=ctx.num(0.15, 0.5), base_pressure_psi=14.696 if not gas else 14.73,
             base_temperature_fahrenheit=60.0, proving_method="master_meter" if not gas else "volumetric_prover", operational_status="active",
             meter_manufacturer=None, meter_model_number=None, meter_serial_number=f"MSN-{20000 + i}",
             last_calibration_date=date(2026, 1, 10) + timedelta(days=i * 4), calibration_due_date=date(2026, 7, 10) + timedelta(days=i * 4) if i != 5 else date(2026, 6, 30),
             calibration_certificate_number=f"CAL-{2026}-{i + 1:03d}", installation_date=date(2019, 6, 1) + timedelta(days=fi * 61),
             scada_integration_flag=True, scada_tag_code=f"OGX.{FACILITIES[fi][0]}.MP{i + 1:02d}", temperature_compensation_flag=True,
             pressure_compensation_flag=True, flow_direction="forward", ferc_reporting_flag=False, phmsa_meter_code=None, remarks=None,
             decommission_date=None, _anchor=date(2026, 1, 10))


METER_CODES = ["FD-LACT-01", "FD-LACT-02", "RM-LACT-01", "RM-LACT-02", "CF-LACT-01", "CF-LACT-02", "SR-LACT-01", "MB-LACT-01",
               "MB-LACT-02", "PB-LACT-01", "TW-LACT-01", "LB-SALES-01", "YR-LACT-01", "OC-LACT-01", "FD-SWD-M-01"]
SUB_METERS = [(0, "FD-TEST-01"), (0, "FD-ALLOC-02"), (2, "RM-TEST-01"), (2, "RM-ALLOC-02"), (4, "CF-TEST-01"), (5, "CF-TEST-02"),
              (5, "CF-ALLOC-02"), (6, "SR-TEST-01"), (7, "MB-TEST-01"), (10, "TW-TEST-01")]


def production_facility(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    code, name, kind, fi, lat, lon, _ = FACILITIES[i]
    st = FAC_STATE[i]
    r.update(facility_code=code, facility_name=name, facility_type=kind, field_id=P("production.field", fi), latitude=lat, longitude=lon,
             crude_grade_id=P("product.crude_grade", GRADE_OF_FIELD[fi]), installation_type="onshore", operational_status="operating",
             state_province=st, county_parish=FIELDS[fi][4], country_code="US", water_depth_ft=0.0,
             design_capacity_bopd=ctx.num(12000, 35000, 0) if i not in (11, 14) else (0.0 if i == 14 else 2500.0),
             design_capacity_mmcfd=ctx.num(15, 60) if i != 14 else 0.0, design_capacity_bwpd=ctx.num(15000, 60000, 0),
             current_throughput_bopd=ctx.num(3000, 14000, 0) if i not in (11, 14) else (0.0 if i == 14 else 800.0),
             current_throughput_mmcfd=ctx.num(5, 40) if i != 14 else 0.0, flare_capacity_mmcfd=ctx.num(10, 45) if i != 14 else 0.0,
             storage_capacity_bbl=ctx.num(4000, 12000, 0), separator_count=str(ctx.int_(2, 6)), processing_train_count=str(ctx.int_(1, 3)),
             h2s_present_flag=i == 11, norm_present_flag=False, commissioning_date=date(2019, 6, 1) + timedelta(days=i * 61),
             decommissioning_date=None, last_inspection_date=date(2026, 3, 1) + timedelta(days=i * 4), next_inspection_due_date=date(2027, 3, 1) + timedelta(days=i * 4),
             manager_name=ctx.person(), pi_system_tag_prefix=f"OGX.{code}", ownership_interest_pct=ctx.pick([100.0, 87.5, 75.0]), cost_center=f"CC-42{i:02d}",
             permit_to_work_id=None, address=None, postal_code=None, emergency_contact_phone=f"+1-432-555-{200 + i:04d}",
             _state=st, _county=FIELDS[fi][4], _anchor=date(2026, 3, 1))


PM_EQUIP = ["FD1-K-201", "FD1-PSV-201A", "FD1-V-101", "FD1-FL-601", "FD1-LACT-701", "FD2-K-202", "RM1-K-211", "RM1-FL-611",
            "CF2-V-110", "CF2-LCV-110", "CF2-SDV-110", "CF2-FL-615", "CF2-K-215", "MB1-K-241", "TW1-K-261", "LB1-AMN-171", "LB1-GD-01",
            "MJ-K-901", "MJ-K-902", "CF-CS-K-911", "PT-TK-951", "PT-P-952", "R101-BOP", "R104-BOP", "R107-BOP", "R104-TD", "R104-MP-2",
            "RM-ESP-09", "FD-ESP-03", "FD-SWD-P-801"]


def preventive_maintenance_plan(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i < 30:
        tag = PM_EQUIP[i]
        e = EQUIPMENT[EQUIP_ROW[tag]]
        etype = e[2]
        name, freq, unit, strat, trig = {
            "compressor": ("4,000-hour valve and packing overhaul", "4000", "hours", "condition_based", "meter"),
            "valve": ("Annual function / pop test", "12", "months", "time_based", "calendar"),
            "vessel": ("RBI external inspection and level bridle cleaning", "24", "months", "risk_based", "calendar"),
            "flare": ("Pilot and igniter check", "3", "months", "time_based", "calendar"),
            "meter": ("Meter proving", "1", "months", "time_based", "calendar"),
            "storage tank": ("API 653 external inspection", "60", "months", "risk_based", "calendar"),
            "pump": ("Vibration route and seal check", "1", "months", "condition_based", "condition"),
            "blowout preventer": ("BOP pressure test (API 53)", "21", "days", "time_based", "calendar"),
            "top drive": ("500-hour top drive inspection", "500", "hours", "time_based", "meter"),
            "electric submersible pump": ("ESP surveillance review", "1", "months", "predictive", "condition"),
            "fire and gas detector": ("Gas detector calibration and bump test", "3", "months", "time_based", "calendar"),
        }[etype]
        eq_id, pipe, fi = eq(tag), None, e[3]
        label = f"{tag} {name}"
    else:
        k = i - 30
        pipe = [0, 2, 3, 6, 8, 9, 11, 12, 15, 23][k]
        name, freq, unit, strat, trig = "Maintenance pigging and corrosion inhibitor review", "3", "months", "time_based", "calendar"
        eq_id, fi, tag = None, PIPELINES[pipe][4] or 0, None
        label = f"{PIPELINES[pipe][0]} {name}"
    last = date(2026, 4, 1) + timedelta(days=(i * 9) % 150)
    r.update(plan_code=f"PM-{i + 1:03d}", plan_name=label, equipment_id=eq_id, pipeline_segment_id=P("asset.pipeline_segment", pipe) if pipe is not None else None,
             production_facility_id=pfac(fi) if fi is not None and fi < 15 else None, maintenance_strategy_type=strat, trigger_type=trig,
             frequency_value=freq, frequency_unit=unit, plan_status="active", priority_level="critical" if tag and EQUIPMENT[EQUIP_ROW[tag]][4] == "critical" else "high",
             safety_critical_flag=bool(tag and EQUIPMENT[EQUIP_ROW[tag]][5]), environmental_critical_flag=bool(tag and EQUIPMENT[EQUIP_ROW[tag]][6]),
             last_completed_date=last, next_scheduled_date=last + timedelta(days=90), effective_start_date=date(2023, 1, 1), effective_end_date=None,
             estimated_duration_hours=ctx.num(2, 48, 1), estimated_labor_cost=ctx.num(400, 9000, 0), estimated_material_cost=ctx.num(200, 25000, 0),
             estimated_contractor_cost=ctx.num(0, 18000, 0), mean_time_between_failures=None, mean_time_to_repair=None, ptw_required_flag=True,
             moc_required_flag=False, turnaround_planning_flag=False, capex_opex_classification="OPEX",
             rcm_analysis_reference=f"RCM-{tag}" if tag else None, task_list_reference=f"TL-{i + 1:03d}", required_craft_skills="mechanical, instrumentation",
             spare_parts_list="valve kits, packing rings" if tag and "K-" in tag else None, regulatory_inspection_requirement=None,
             condition_monitoring_requirement="online vibration" if strat == "condition_based" else None, cost_benefit_justification=None,
             work_order_type="preventive", production_well_id=pw_row(10) if tag == "RM-ESP-09" else (pw_row(3) if tag == "FD-ESP-03" else None),
             _anchor=last)


INC_TYPES = (["near miss"] * 12 + ["first aid"] * 8 + ["recordable injury"] * 6 + ["lost time injury"] * 2 + ["environmental release"] * 6 +
             ["vehicle incident"] * 4 + ["dropped object"] * 4 + ["H2S alarm"] * 2 + ["small fire"] * 2)


def incident(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    t = inc_time(i)
    ptw = None
    if i == S.INC_KICK:
        itype, fi, desc, tier, lopc, spill, sev = ("well control", None, "Kick in Wolfcamp B on Red Mesa 12-2H (18 bbl pit gain); brief gas release at the shakers "
                                                   "before the well was shut in on the annular. Six crew members mustered upwind; no injuries.", "tier_2", True, False, "high")
        rig, well, pf, viol = P("drilling.rig", 3), asset_row_of_well(S.KICK_WELL), None, P("compliance.violation", S.VIO_KICK)
        immediate = "Shut in well, mustered crew, H2S and LEL monitoring, notified RRC."
    elif i == S.INC_LOPC:
        itype, fi, desc, tier, lopc, spill, sev = ("process safety event", 5, "Separator V-110 overfilled when level control valve LCV-110 failed open while the high-level "
                                                   "trip SDV-110 was bypassed for LT-110 replacement; 46 bbl crude released to the lined containment and 6 bbl beyond it.",
                                                   "tier_1", True, True, "critical")
        rig, well, pf, viol, ptw = None, None, pfac(5), P("compliance.violation", S.VIO_LOPC), P("hse.permit_to_work", S.PTW_LOPC)
        immediate = "Closed inlet ESD, removed trip bypass, deployed sorbent boom, notified NMOCD within 24 hours."
    elif i == S.INC_K201:
        itype, fi, desc, tier, lopc, spill, sev = ("process safety event", 0, "Gas leak from a thinned discharge elbow on compressor K-201; fixed gas detection alarmed and the "
                                                   "unit tripped and blew down to flare.", "tier_2", True, False, "high")
        rig, well, pf, viol = None, None, pfac(0), None
        immediate = "Compressor tripped automatically; isolated and blown down to flare; area barricaded."
    elif i == S.INC_PIPE:
        itype, fi, desc, tier, lopc, spill, sev = ("environmental release", 0, "Pinhole leak on produced-water gathering line FD-07 released 12 bbl that reached a dry wash.",
                                                   "tier_3", True, True, "medium")
        rig, well, pf, viol = None, None, pfac(1), P("compliance.violation", S.VIO_PIPE)
        immediate = "Shut in line FD-07, vacuum truck recovery, soil sampling, notified RRC."
    else:
        itype = INC_TYPES[i - 4]
        fi = PTW_FAC[i - 4] if 4 <= i <= 17 else [0, 2, 4, 5, 6, 7, 10, 15, 16, 17, 19, 11][i % 12]
        if 4 <= i <= 17:
            ptw = P("hse.permit_to_work", i - 3)
            ptype = PTW_TYPES[i - 4]
            desc = {"hot_work": "Spark from grinding ignited residue on a drain; extinguished immediately.",
                    "electrical_isolation": "Pump motor energised during maintenance; isolation try-out step had not been done.",
                    "confined_space_entry": "Gas detector alarm (H2S 12 ppm) during tank entry; entrants evacuated.",
                    "working_at_height": "Hand tool dropped 25 ft from the flare platform into a barricaded area.",
                    "simops": "Rig move truck contacted a wellhead flowline during SIMOPS; no release.",
                    "excavation": "Excavator exposed an unmarked fibre cable while uncovering a flowline."}[ptype]
            itype = {"hot_work": "small fire", "electrical_isolation": "near miss", "confined_space_entry": "H2S alarm",
                     "working_at_height": "dropped object", "simops": "near miss", "excavation": "near miss"}[ptype]
            if ptype == "electrical_isolation" and i in (5, 13):
                itype, desc = "recordable injury", "Technician received a minor electrical burn when a motor circuit thought to be isolated was live."
        else:
            desc = {"near miss": "Unsecured load shifted on a trailer at the yard.", "first aid": "Hand laceration while changing a gauge.",
                    "recordable injury": "Wrist sprain from slipping on an iced stair.", "lost time injury": "Fractured foot from a pipe joint rolling off a rack.",
                    "environmental release": "Small crude spill from a truck loading hose at the rack.", "vehicle incident": "Pickup slid off a caliche lease road.",
                    "dropped object": "Wrench dropped from the rig floor.", "H2S alarm": "Personal H2S monitor alarm near amine unit.",
                    "small fire": "Grass fire from a vehicle exhaust on the lease."}[itype]
        tier = "tier_3" if itype in ("environmental release", "small fire") else "not_applicable"
        lopc, spill, sev = itype == "environmental release", itype == "environmental release", "medium" if "injury" in itype else "low"
        rig = P("drilling.rig", 3) if fi == 19 else None
        well, pf, viol = None, pfac(fi) if fi < 15 else None, None
        immediate = "Made safe, reported to supervisor, area inspected."
    r.update(incident_number=f"INC-{t.year}-{i + 1:04d}", incident_type=itype, incident_timestamp=t, incident_date=t.date(),
             discovery_timestamp=t + timedelta(minutes=5), reported_timestamp=t + timedelta(minutes=40), initial_description=desc,
             immediate_action_taken=immediate, severity_classification=sev, pse_tier_classification=tier, lopc_flag=lopc,
             spill_to_environment_flag=spill, fatality_flag=False, lost_time_incident_flag=itype == "lost time injury",
             osha_recordable_flag=itype in ("recordable injury", "lost time injury"), days_away_from_work=str(14 if itype == "lost time injury" else 0),
             days_of_restricted_work=str(5 if itype == "recordable injury" else 0), injured_party_type="employee" if "injury" in itype or itype == "first aid" else "not_applicable",
             h2s_exposure_flag=itype == "H2S alarm", simops_flag=itype == "near miss" and ptw is not None and i == 11,
             investigation_required_flag=sev in ("critical", "high") or "injury" in itype or tier in ("tier_1", "tier_2"),
             incident_status="closed" if t.date() < date(2026, 6, 1) else "under_investigation", regulatory_notification_required_flag=tier in ("tier_1", "tier_2") or spill,
             regulatory_notification_timestamp=t + timedelta(hours=31 if i == S.INC_KICK else 6) if tier in ("tier_1", "tier_2") or spill else None,
             permit_to_work_id=ptw, rig_id=rig, well_asset_id=well, production_facility_id=pf, violation_id=viol,
             location_type="drilling rig" if rig else ("pipeline" if i == S.INC_PIPE else "facility"),
             geographic_area=FACILITIES[fi][1] if fi is not None else WELLS[S.KICK_WELL].name, work_activity_type="drilling" if rig else ("maintenance" if ptw else "operations"),
             country_code="US", norm_involvement_flag=False, _anchor=t.date())
    r["_facility"] = fi


def ldar_survey(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    facs = [0, 2, 4, 5, 6, 7, 10, 11, 1, 3]
    fi = facs[i % 10]
    q = i // 10                              # 2025Q4, 2026Q1, 2026Q2
    d = [date(2025, 11, 12), date(2026, 2, 18), date(2026, 5, 20)][q] + timedelta(days=fi)
    leaks = {5: [9, 14, 11], 4: [5, 6, 4], 2: [4, 5, 3]}.get(fi, [ctx.int_(0, 3), ctx.int_(0, 3), ctx.int_(0, 2)])[q]
    src = 20 + fi if fi < 14 else None
    r.update(survey_number=f"LDAR-{d.year}-{i + 1:03d}", survey_date=d, survey_start_timestamp=datetime.combine(d, datetime.min.time()) + timedelta(hours=8),
             survey_end_timestamp=datetime.combine(d, datetime.min.time()) + timedelta(hours=14), survey_completion_date=d, survey_type="scheduled",
             survey_status="approved", monitoring_method="ogi_camera", regulatory_program="EPA NSPS OOOOb / NMED 20.2.50 NMAC" if FAC_STATE[fi] == "NM" else "EPA NSPS OOOOb",
             emission_source_id=P("hse.emission_source", src) if src is not None else None, production_facility_id=pfac(fi),
             components_surveyed_count=str(ctx.int_(700, 2300)), leaks_detected_count=str(leaks), leak_detection_threshold_ppm="500",
             maximum_leak_concentration_ppm=str(ctx.int_(800, 9000) if leaks else 0), total_estimated_emissions_mcf=round(leaks * ctx.num(6, 14), 1),
             total_estimated_emissions_co2e_metric_tons=round(leaks * ctx.num(2.5, 6.5), 1), corrective_actions_required=leaks > 0,
             corrective_action_deadline_date=d + timedelta(days=30) if leaks else None, equipment_component_type="valves, connectors, thief hatches",
             instrument_serial_number=f"OGI-{4400 + i % 3}", instrument_calibration_date=d - timedelta(days=20), ambient_temperature_f=ctx.num(35, 98, 0),
             wind_speed_mph=ctx.num(2, 15), weather_conditions="clear", hse_review_date=d + timedelta(days=5), hse_review_comments=None,
             survey_notes=(f"{leaks} leaks found; thief hatch and separator dump valve leaks recur at {FACILITIES[fi][1]}." if leaks > 4 else
                           f"{leaks} leaks found and tagged for repair." if leaks else "No leaks detected."),
             rig_id=None, regulatory_reporting_required=True, _anchor=d)


PSE_OTHER = [("Tier 2", "LOPC", 2), ("Tier 2", "Fire", 15), ("Tier 2", "LOPC", 11), ("Tier 2", "Toxic Release", 11),
             ("Tier 3", "LOPC", 4), ("Tier 3", "Overpressure", 15), ("Tier 3", "LOPC", 7), ("Tier 3", "LOPC", 10),
             ("Tier 3", "Overpressure", 2), ("Tier 3", "LOPC", 6), ("Tier 3", "LOPC", 17), ("Tier 3", "Fire", 16),
             ("Tier 4", "Overpressure", 0), ("Tier 4", "LOPC", 5), ("Tier 4", "Overpressure", 7), ("Tier 4", "LOPC", 9), ("Tier 4", "LOPC", 3)]


def process_safety_event(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i == S.PSE_LOPC:
        tier, etype, fi, t, tag = "Tier 1", "LOPC", 5, LOPC_TIME, "CF2-V-110"
        qty, unit, cause = 52.0, "bbl", "LCV-110 failed open while the high-level trip SDV-110 was bypassed for maintenance without MOC."
        resp, sys = "Failed to Respond", "SDV-110 high-level shutdown (bypassed)"
    elif i == S.PSE_KICK:
        tier, etype, fi, t, tag = "Tier 2", "LOPC", None, kick_time(), "R104-BOP"
        qty, unit, cause = 85.0, "mscf", "Gas released at the shakers before shut-in after a Wolfcamp B kick."
        resp, sys = "Responded as Designed", "BOP annular preventer"
    elif i == S.PSE_K201:
        tier, etype, fi, t, tag = "Tier 2", "LOPC", 0, K201_TIME, "FD1-K-201"
        qty, unit, cause = 140.0, "mscf", "Through-wall corrosion at the K-201 discharge elbow (wall loss reported at the August inspection)."
        resp, sys = "Responded as Designed", "fixed gas detection and compressor ESD"
    else:
        tier, etype, fi = PSE_OTHER[i - 3]
        t = datetime(2024, 6, 2, 9, 30) + timedelta(days=(i * 41) % 820)
        tag = None
        qty, unit, cause = ctx.num(1, 30, 1), ctx.pick(["bbl", "mscf"]), ctx.pick(["gasket failure on a flange", "PSV lift at set pressure",
                                                                                 "dump valve stuck open", "tank thief hatch left open",
                                                                                 "corrosion pinhole on a drain line"])
        resp, sys = ctx.pick(["Responded as Designed", "Partial Response", "Not Applicable"]), ctx.pick(["PSV", "ESD", "none"])
    r.update(pse_number=f"PSE-{t.year}-{i + 1:03d}", pse_tier_classification=tier, event_type=etype, event_timestamp=t, event_date=t.date(),
             discovery_timestamp=t + timedelta(minutes=3), event_status="Confirmed" if t.date() < date(2026, 6, 1) else "Under Review",
             equipment_id=eq(tag) if tag else None, production_facility_id=pfac(fi) if fi is not None and fi < 15 else None,
             drilling_well_id=drill_row_of_well(S.KICK_WELL) if i == S.PSE_KICK else None, rig_id=P("drilling.rig", 3) if i == S.PSE_KICK else None,
             well_asset_id=asset_row_of_well(S.KICK_WELL) if i == S.PSE_KICK else None,
             pipeline_segment_id=None, violation_id=P("compliance.violation", S.VIO_LOPC) if i == S.PSE_LOPC else (P("compliance.violation", S.VIO_KICK) if i == S.PSE_KICK else None),
             crude_grade_id=P("product.crude_grade", 5) if i == S.PSE_LOPC else None, lopc_flag=etype == "LOPC", release_quantity=qty,
             release_unit_of_measure=unit, release_rate=round(qty / 0.5, 1), release_rate_unit="BBL/HR" if unit == "bbl" else "MSCF/HR",
             release_duration_minutes=25.0 if i == S.PSE_LOPC else ctx.num(2, 40, 0), consequence_category="Environmental" if i == S.PSE_LOPC else "Near Miss",
             immediate_cause_description=cause, equipment_involved=EQUIPMENT[EQUIP_ROW[tag]][1] if tag else None, process_unit="separation" if fi in (5,) else None,
             safety_system_demand_flag=True, safety_system_involved=sys, safety_system_response=resp, ignition_source=None,
             fatality_count="0", injury_count="0", production_loss_boe=3100.0 if i == S.PSE_LOPC else ctx.num(0, 900, 0),
             property_damage_usd=185000.0 if i == S.PSE_LOPC else ctx.num(0, 60000, 0), environmental_impact_flag=i == S.PSE_LOPC,
             regulatory_notification_required=tier in ("Tier 1", "Tier 2"), regulatory_notification_timestamp=t + timedelta(hours=6) if tier in ("Tier 1", "Tier 2") else None,
             investigation_required_flag=tier in ("Tier 1", "Tier 2"), esg_reportable_flag=tier in ("Tier 1", "Tier 2"), sec_reportable_flag=False,
             wind_speed_mph=ctx.num(3, 22), weather_conditions="clear", _anchor=t.date())


def meter_station(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i < 15:
        fi, code, parent = i, METER_CODES[i], None
        stype = "custody_transfer" if i not in (11, 14) else ("fiscal" if i == 11 else "allocation")
    else:
        fi, code = SUB_METERS[i - 15]
        parent, stype = P("production.meter_station", fi), "test" if "TEST" in code else "allocation"
    gas = fi == 11
    last_cal = date(2026, 3, 1) + timedelta(days=i * 5)
    due = last_cal + timedelta(days=90)
    if code == "CF-LACT-02":
        last_cal, due = date(2026, 1, 20), date(2026, 4, 20)       # calibration overdue at the allocation month
    r.update(station_code=code, station_name=f"{FACILITIES[fi][1]} {code}", station_type=stype, production_facility_id=pfac(fi),
             parent_meter_station_id=parent, measurement_point_id=P("logistics.measurement_point", i) if i < 15 else None,
             delivery_point_id=P("customer.delivery_point", FAC_DP[fi]) if i < 15 and FAC_DP[fi] is not None else None,
             equipment_id=eq({0: "FD1-LACT-701", 2: "RM1-LACT-711", 6: "SR1-LACT-731"}[i]) if i in (0, 2, 6) else None,
             meter_type="ultrasonic" if gas else ("coriolis" if stype != "test" else "turbine"), measurement_fluid="natural_gas" if gas else ("water" if fi == 14 else "crude_oil"),
             capacity_uom="mcf_per_day" if gas else "bbl_per_day", design_capacity=ctx.num(4000, 30000, 0), custody_transfer_flag=stype == "custody_transfer",
             fiscal_measurement_flag=stype in ("custody_transfer", "fiscal"), measurement_accuracy_class="class_1" if stype in ("custody_transfer", "fiscal") else "class_3",
             measurement_uncertainty_percent=0.25 if stype in ("custody_transfer", "fiscal") else 2.0, meter_factor=ctx.num(0.998, 1.002, 4) if code != "CF-LACT-02" else 1.01,
             proving_method="master_meter" if not gas else "small_volume_prover", calibration_frequency_days="90", last_calibration_date=last_cal,
             next_calibration_due_date=due, last_proving_date=last_cal, operational_status="active", scada_integration_flag=True,
             pi_system_tag=f"OGX.{FACILITIES[fi][0]}.{code}", regulatory_reporting_flag=stype in ("custody_transfer", "fiscal"),
             latitude=FACILITIES[fi][4], longitude=FACILITIES[fi][5], state_province=FAC_STATE[fi], county_parish=FIELDS[FACILITIES[fi][3]][4],
             country_code="US", installation_date=date(2019, 7, 1) + timedelta(days=fi * 61), commissioning_date=date(2019, 7, 15) + timedelta(days=fi * 61),
             decommissioning_date=None, ownership_interest_pct=100.0, asset_code=5000 + i, cost_center=f"CC-43{i:02d}",
             comments="Meter factor drifted to 1.01 (the other custody meters prove at 1.00); proving overdue since 2026-04-20." if code == "CF-LACT-02" else None,
             permit_id=None, _anchor=last_cal)


# ---------------------------------------------------------------------------
# work orders, inspections, failures
# ---------------------------------------------------------------------------
WO_PLAN = {
    0: ("FD1-K-201", "corrective", "Replace thinned discharge elbow and spool on K-201; UT survey of discharge piping", K201_TIME.date(), "critical", 0, None),
    1: ("RM-ESP-09", "corrective", "Pull and replace ESP-09 on Red Mesa 12-3H (motor burnout); install scale inhibitor squeeze", date(2026, 3, 6), "high", 2, None),
    2: ("CF2-LCV-110", "corrective", "Replace LCV-110 trim and actuator; function test SDV-110 high-level trip after LOPC", LOPC_TIME.date(), "critical", 5, None),
    3: (None, "corrective", "Repair FD-07 pinhole leak with a 20 ft pipe replacement; close-interval survey", PIPE_TIME.date(), "high", 1, S.PIPE_FD07),
    4: ("RM-ESP-09", "corrective", "Replace ESP-09 after first failure (scale-plugged pump stages)", date(2025, 2, 12), "high", 2, None),
    5: ("RM-ESP-09", "corrective", "Replace ESP-09 after second failure (motor over-temperature trip)", date(2025, 8, 3), "high", 2, None),
    6: ("FD1-K-201", "corrective", "Replace broken suction valve plate on K-201 cylinder 2", date(2024, 11, 20), "high", 0, None),
    7: ("R104-TD", "corrective", "Replace IBOP actuator on R104 top drive (hydraulic leak)", date(2025, 4, 2), "high", 19, None),
    8: ("R104-TD", "corrective", "Replace IBOP actuator on R104 top drive (second leak)", date(2025, 10, 9), "high", 19, None),
    9: ("R104-TD", "corrective", "Rebuild R104 top drive gearbox seal and IBOP actuator", date(2026, 6, 14), "high", 19, None),
}


def work_order(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i in WO_PLAN:
        tag, wtype, desc, d, prio, fi, pipe = WO_PLAN[i]
    else:
        tag = PM_EQUIP[i % len(PM_EQUIP)] if i % 5 else None
        wtype = ctx.pick(["preventive", "preventive", "inspection", "corrective", "predictive"])
        fi = EQUIPMENT[EQUIP_ROW[tag]][3] if tag else [0, 2, 4, 5, 7][i % 5]
        pipe = None if tag else [0, 2, 8, 11, 15][i % 5]
        desc = {"preventive": "Scheduled PM per plan", "inspection": "Scheduled inspection", "corrective": "Repair minor leak / defect",
                "predictive": "Vibration route follow-up"}[wtype] + (f" on {tag}" if tag else f" on line {PIPELINES[pipe][0]}")
        d = date(2024, 2, 1) + timedelta(days=(i * 23) % 960)
        prio = ctx.pick(["medium", "high", "low"])
    start = datetime.combine(d, datetime.min.time()) + timedelta(hours=7)
    dur = ctx.num(4, 60, 1)
    labor = ctx.num(8, 160, 1)
    mat = 48000.0 if i == 1 else (36500.0 if i == 0 else ctx.num(500, 25000, 0))
    r.update(work_order_number=f"WO-{d.year}-{i + 1:05d}", work_type=wtype, work_order_description=desc, priority=prio,
             work_order_status="closed" if d < date(2026, 9, 1) else "in_progress", equipment_id=eq(tag) if tag else None,
             pipeline_segment_id=P("asset.pipeline_segment", pipe) if pipe is not None else None,
             production_facility_id=pfac(fi) if fi is not None and fi < 15 else None,
             incident_id=P("hse.incident", {0: S.INC_K201, 2: S.INC_LOPC, 3: S.INC_PIPE}[i]) if i in (0, 2, 3) else None,
             process_safety_event_id=P("hse.process_safety_event", S.PSE_LOPC) if i == 2 else (P("hse.process_safety_event", S.PSE_K201) if i == 0 else None),
             permit_to_work_id=None, permit_id=None, well_asset_id=asset_row_of_well(10) if tag == "RM-ESP-09" else None,
             scheduled_start_date=d, scheduled_finish_date=d + timedelta(days=2), actual_start_timestamp=start,
             actual_finish_timestamp=start + timedelta(hours=dur), actual_labor_hours=labor, estimated_labor_hours=round(labor * 0.9, 1),
             actual_material_cost=mat, estimated_material_cost=round(mat * 0.9, 0), actual_contractor_cost=ctx.num(0, 60000, 0) if wtype == "corrective" else 0.0,
             estimated_contractor_cost=ctx.num(0, 50000, 0), downtime_hours=dur if wtype == "corrective" else 0.0,
             production_impact_boe={0: 1850.0, 1: 2400.0, 2: 3100.0, 3: 640.0}.get(i, 0.0), assigned_craft="mechanical" if tag and "K-" in tag else "multi_discipline",
             isolation_required=True, isolation_plan="LOTO per site procedure", equipment_condition_before="poor" if wtype == "corrective" else "good",
             equipment_condition_after="good", capex_opex_classification="OPEX", safety_incident_flag=i in (0, 2, 3), regulatory_inspection_flag=wtype == "inspection",
             completion_notes=(desc + " - completed and returned to service.") if d < date(2026, 9, 1) else None, inspection_due_date=None,
             moc_reference_number="MOC-2026-118" if i == 2 else None, joint_venture_allocation_flag=False, _anchor=d)


INSPECTIONS = {
    0: ("FD1-K-201", None, date(2025, 8, 20), "UT thickness survey", "Wall loss of 38% at the K-201 discharge elbow (min 0.19 in vs 0.31 in nominal); corrosion rate 0.42 mm/yr. Recommend replacement within 30 days.",
        "major", "fit_with_repair", 8, 0.42, 4.8, 7.6),
    1: ("RM-ESP-09", None, date(2026, 2, 2), "ESP surveillance review", "Motor winding temperature trending +18 F above baseline with rising amps; scale suspected at the intake. Recommend chemical treatment and planned pull.",
        "moderate", "fit_with_monitoring", 9, None, None, None),
    2: ("CF2-LCV-110", None, date(2026, 1, 15), "RBI external visual", "LCV-110 actuator stem corroded and sticky on stroke test; level bridle on V-110 partially fouled. Recommend actuator overhaul at next window.",
        "moderate", "fit_with_repair", 2, None, None, None),
    3: (None, S.PIPE_FD07, date(2026, 3, 30), "external corrosion direct assessment", "Coating disbondment with external pitting up to 62% wall at a girth weld near the dry-wash crossing. Recommend repair before summer.",
        "major", "fit_with_monitoring", 0, 0.55, 3.1, 4.4),
    4: ("PT-TK-951", None, date(2026, 6, 10), "API 653 out-of-service inspection", "Floor plate soil-side corrosion with remaining thickness below the minimum; tank removed from service.",
        "critical", "not_fit_for_service", 3, 0.31, 3.9, 5.0),
    5: ("FD1-PSV-201A", None, date(2026, 7, 22), "PSV bench test", "PSV-201A popped at 12% above set pressure; seat damaged. Valve not fit for service until rebuilt.",
        "critical", "not_fit_for_service", 4, None, None, None),
}


def inspection_event(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i in INSPECTIONS:
        tag, pipe, d, method, finding, sev, ffs, prog, cr, meas, minimum = INSPECTIONS[i]
    else:
        tag = PM_EQUIP[(i * 3) % len(PM_EQUIP)] if i % 4 else None
        pipe = None if tag else [0, 2, 8, 11, 15, 9][i % 6]
        d = date(2024, 3, 1) + timedelta(days=(i * 29) % 930)
        method = ctx.pick(["visual", "UT thickness survey", "vibration analysis", "infrared thermography"])
        sev = ctx.pick(["none", "none", "minor", "moderate"])
        ffs = "fit_for_service" if sev in ("none", "minor") else "fit_with_monitoring"
        finding = {"none": "No significant findings.", "minor": "Minor coating damage; touch-up scheduled.",
                   "moderate": "Localised corrosion within corrosion allowance; monitor at next interval."}[sev]
        prog, cr, meas, minimum = (8 if tag and "K-" in tag else (0 if pipe is not None else 2)), ctx.num(0.02, 0.2, 2), None, None
    fi = EQUIPMENT[EQUIP_ROW[tag]][3] if tag else (PIPELINES[pipe][4] or 0)
    r.update(inspection_number=f"INS-{d.year}-{i + 1:04d}", inspection_type=method, inspection_method=method, inspection_date=d, scheduled_date=d,
             inspection_status="completed", equipment_id=eq(tag) if tag else None, pipeline_segment_id=P("asset.pipeline_segment", pipe) if pipe is not None else None,
             integrity_program_id=P("asset.integrity_program", prog), production_facility_id=pfac(fi) if fi < 15 else None,
             production_well_id=pw_row(10) if tag == "RM-ESP-09" else None, well_asset_id=asset_row_of_well(10) if tag == "RM-ESP-09" else None,
             preventive_maintenance_plan_id=P("asset.preventive_maintenance_plan", PM_EQUIP.index(tag)) if tag in PM_EQUIP else None,
             work_order_id=None, permit_id=None, permit_to_work_id=None, process_safety_event_id=None,
             inspection_findings=finding, defect_severity=sev, fitness_for_service_result=ffs,
             corrective_action_required_flag=sev in ("major", "critical", "moderate"), corrective_action_description=finding.split("Recommend")[-1].strip() if "Recommend" in finding else None,
             corrective_action_due_date=d + timedelta(days=30) if sev in ("major", "critical") else None, corrosion_rate_mm_per_year=cr,
             measured_thickness_mm=meas, minimum_required_thickness_mm=minimum, remaining_life_years=ctx.num(0.2, 1.5) if sev in ("major", "critical") else ctx.num(5, 20),
             risk_based_inspection_priority="high" if sev in ("major", "critical") else "medium", inspection_interval_months=str(12 if sev in ("major", "critical") else 24),
             next_inspection_due_date=d + timedelta(days=180 if sev in ("major", "critical") else 365), inspection_cost=ctx.num(800, 18000, 0),
             inspection_duration_hours=ctx.num(2, 16, 1), regulatory_compliance_status="non_compliant" if ffs == "not_fit_for_service" else "compliant",
             regulatory_reference={"UT thickness survey": "API 570", "API 653 out-of-service inspection": "API 653", "PSV bench test": "API RP 576",
                                   "external corrosion direct assessment": "49 CFR 195.588 / NACE SP0502"}.get(method, "company standard"),
             hse_incident_flag=False, approved_timestamp=datetime.combine(d + timedelta(days=2), datetime.min.time()) + timedelta(hours=10),
             inspection_scope="external and accessible internal" if tag else "pipeline segment", inspection_report_document_code=7000 + i,
             inspection_pressure_bar=None, inspection_temperature_c=None, moc_reference_number=None, _anchor=d)


FAIL_PLAN = {
    0: ("FD1-K-201", None, K201_TIME, "external leakage - process medium", "erosion-corrosion at discharge elbow",
        "Gas leak from a thinned discharge elbow on K-201; unit tripped on gas detection.", 0, 0, S.INC_K201, S.PSE_K201, None, 12, 1850.0, 27500.0),
    1: ("RM-ESP-09", None, datetime(2026, 3, 5, 2, 10), "breakdown", "motor winding insulation failure from overheating (scale at intake)",
        "ESP-09 tripped on motor ground fault; megger test failed. Third failure on this well.", 1, 1, None, None, None, 11, 2400.0, 52000.0),
    2: ("CF2-LCV-110", None, LOPC_TIME, "fail to close on demand", "actuator stem corrosion and sticking (reported at January inspection)",
        "LCV-110 failed open, overfilling V-110 while the high-level trip was bypassed.", 2, 2, S.INC_LOPC, S.PSE_LOPC, 0, None, 3100.0, 22000.0),
    3: (None, S.PIPE_FD07, PIPE_TIME, "external leakage - process medium", "external pitting corrosion at disbonded coating",
        "Pinhole leak on FD-07 at a girth weld near the dry-wash crossing.", 3, 3, S.INC_PIPE, None, 1, None, 640.0, 41000.0),
    10: ("RM-ESP-09", None, datetime(2025, 2, 11, 4, 0), "low output", "pump stages plugged with calcium carbonate scale",
         "ESP-09 production fell 60% then tripped on underload.", None, 4, None, None, None, None, 1500.0, 46000.0),
    11: ("RM-ESP-09", None, datetime(2025, 8, 2, 13, 30), "overheating", "motor over-temperature from low fluid level and scale",
         "ESP-09 tripped on motor over-temperature.", None, 5, None, None, None, 10, 1700.0, 49000.0),
    12: ("FD1-K-201", None, datetime(2024, 11, 20, 9, 0), "vibration", "broken suction valve plate (fatigue)",
         "High vibration and loss of capacity on K-201 cylinder 2.", None, 6, None, None, None, None, 600.0, 14500.0),
    13: ("R104-TD", None, datetime(2025, 4, 1, 22, 0), "external leakage - utility medium", "IBOP actuator seal wear",
         "Hydraulic leak at the R104 top drive IBOP actuator.", None, 7, None, None, None, None, 0.0, 18000.0),
    14: ("R104-TD", None, datetime(2025, 10, 8, 3, 0), "external leakage - utility medium", "IBOP actuator seal wear (repeat)",
         "Repeat hydraulic leak at the R104 top drive IBOP actuator.", None, 8, None, None, None, 13, 0.0, 21000.0),
    15: ("R104-TD", None, datetime(2026, 6, 13, 18, 0), "abnormal instrument reading", "gearbox seal leak and IBOP actuator wear",
         "R104 top drive gearbox oil pressure low; IBOP actuator leaking again.", None, 9, None, None, None, 14, 0.0, 64000.0),
}
OTHER_FAIL_EQUIP = [e[0] for e in EQUIPMENT if e[0] not in ("FD1-K-201", "RM-ESP-09", "CF2-LCV-110", "R104-TD")]


def failure_report(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i in FAIL_PLAN:
        tag, pipe, t, mode, cause, desc, ins, wo, inc, pse, spill, prev, boe, cost = FAIL_PLAN[i]
    else:
        k = [x for x in range(50) if x not in FAIL_PLAN].index(i)
        tag = OTHER_FAIL_EQUIP[k % len(OTHER_FAIL_EQUIP)]
        pipe = None
        t = datetime(2024, 4, 3, 10, 0) + timedelta(days=(k * 31) % 880, hours=k % 9)
        mode = ctx.pick(["external leakage - process medium", "fail to start on demand", "spurious stop", "vibration", "structural deficiency",
                         "abnormal instrument reading", "plugged / choked"])
        cause = ctx.pick(["wear", "corrosion", "fatigue", "instrument failure", "maintenance error", "design deficiency"])
        desc = f"{EQUIPMENT[EQUIP_ROW[tag]][1]}: {mode}."
        ins = wo = inc = pse = spill = prev = None
        boe, cost = ctx.num(0, 400, 0), ctx.num(1500, 30000, 0)
    fi = EQUIPMENT[EQUIP_ROW[tag]][3] if tag else 1
    r.update(failure_report_number=f"FR-{t.year}-{i + 1:04d}", failure_timestamp=t, failure_date=t.date(), detection_timestamp=t + timedelta(minutes=10),
             reported_timestamp=t + timedelta(hours=1), equipment_id=eq(tag) if tag else None, pipeline_segment_id=P("asset.pipeline_segment", pipe) if pipe is not None else None,
             production_facility_id=pfac(fi) if fi < 15 else None, production_well_id=pw_row(10) if tag == "RM-ESP-09" else None,
             well_asset_id=asset_row_of_well(10) if tag == "RM-ESP-09" else None,
             inspection_event_id=P("asset.inspection_event", ins) if ins is not None else None, work_order_id=P("asset.work_order", wo) if wo is not None else None,
             incident_id=P("hse.incident", inc) if inc is not None else None, process_safety_event_id=P("hse.process_safety_event", pse) if pse is not None else None,
             spill_event_id=P("hse.spill_event", spill) if spill is not None else None, previous_failure_report_id=P("asset.failure_report", prev) if prev is not None else None,
             preventive_maintenance_plan_id=P("asset.preventive_maintenance_plan", PM_EQUIP.index(tag)) if tag in PM_EQUIP else None,
             failure_mode=mode, failure_cause=cause, failure_description=desc, affected_system=EQUIPMENT[EQUIP_ROW[tag]][2] if tag else "pipeline",
             failure_classification="critical" if i in (0, 2) else ("major" if i in (1, 3, 15) else "minor"), failure_type="functional" if i != 2 else "catastrophic",
             failure_status="closed" if t.date() < date(2026, 7, 1) else "corrective_action_pending",
             recurrence_flag=prev is not None, mtbf_impact_flag=True, downtime_hours=ctx.num(6, 72, 1) if boe else ctx.num(2, 20, 1),
             mttr_hours=ctx.num(4, 40, 1), npt_hours=ctx.num(4, 12, 1) if tag == "R104-TD" else 0.0, production_impact_boe=boe,
             production_impact_bopd=round(boe / 3, 0) if boe else 0.0, production_impact_mcfd=round(boe * 2.2, 0) if boe else 0.0,
             production_loss_cost=round(boe * 68.0, 0), repair_cost=cost,
             safety_impact="major" if i in (0, 2) else "none", environmental_impact="moderate" if i in (2, 3) else "none",
             corrective_action_taken={0: "Replaced elbow and spool; added discharge piping to the CML register.", 1: "Replaced ESP; scale inhibitor squeeze; lowered frequency.",
                                      2: "Replaced LCV-110 trim/actuator; SDV-110 retested; bypass removed.", 3: "Replaced 20 ft of pipe; recoated; CIS survey."}.get(i, "Repaired and returned to service."),
             preventive_action_recommended={0: "Shorten UT interval on reciprocating compressor discharge piping to 6 months.",
                                            1: "Continuous scale inhibition and ESP surveillance alarms on motor temperature.",
                                            2: "Enforce SIF bypass management (MOC, time limit, compensating measure).",
                                            3: "Recoat and add the dry-wash crossing to the high-consequence monitoring list."}.get(i, None),
             investigated_by=ctx.person(), investigation_completed_date=t.date() + timedelta(days=20) if t.date() < date(2026, 8, 1) else None,
             closure_date=t.date() + timedelta(days=30) if t.date() < date(2026, 7, 1) else None, operating_unit="Permian Operations", _anchor=t.date())


INV_ROOT = {
    0: ("bypass", "SIF bypass management", "High-level trip SDV-110 bypassed for maintenance without MOC, time limit or compensating measure; LCV-110 actuator defect from the January inspection not repaired."),
    1: ("procedure", "Pressure prediction and trip-sheet discipline", "Wolfcamp B pressure ramp 300 ft shallower than modelled; trip sheet not updated at the connection."),
    2: ("cui", "Inspection interval", "Discharge elbow wall loss reported in August was not repaired before failure; UT interval too long for erosion-corrosion."),
    3: ("cui", "External corrosion", "Coating disbondment and external pitting at the dry-wash crossing not prioritised after the March assessment."),
}
RC_TEXT = {
    "isolation": "Inadequate energy isolation: isolation points were listed but the try-out (verification) step was not done before work started.",
    "procedure": "Procedure not followed under time pressure; supervision gap.",
    "fatigue": "Fatigue and shift handover gap during the 14-day rotation.",
    "dropped": "Tools at height not tethered; dropped-object check not performed.",
    "driving": "Journey management not followed on lease roads.",
    "cui": "External corrosion not detected or not acted on by the inspection plan.",
}


def incident_investigation(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    # investigation 0 -> Tier 1 LOPC (incident 1), 1 -> well-control incident (incident 0), others 1:1
    inc = {0: S.INC_LOPC, 1: S.INC_KICK}.get(i, i)
    inc_row = ctx.rows["hse.incident"][inc]
    t = inc_row["incident_timestamp"]
    if i in INV_ROOT:
        fam, contrib, root = INV_ROOT[i]
        rca, typ = "Bow-Tie + 5-Why" if i == 0 else "TapRooT", "root_cause_analysis"
    else:
        it = inc_row["incident_type"]
        ptw_link = inc_row.get("permit_to_work_id")
        ptype = PTW_TYPES[i - 4] if 4 <= i <= 17 else None
        if ptype == "electrical_isolation":
            fam = "isolation"
        elif it == "dropped object":
            fam = "dropped"
        elif it == "vehicle incident":
            fam = "driving"
        elif it in ("lost time injury", "recordable injury"):
            fam = "fatigue"
        else:
            fam = "procedure"
        root, contrib, rca, typ = RC_TEXT[fam], fam, "5-Why", "detailed"
        del ptw_link
    fi = inc_row.get("_facility")
    r.update(investigation_number=f"INV-{t.year}-{i + 1:04d}", incident_id=P("hse.incident", inc), investigation_type=typ,
             investigation_status="completed" if t.date() < date(2026, 6, 1) else "in_progress", investigation_priority="critical" if i == 0 else ("high" if i < 4 else "medium"),
             rca_methodology=rca, root_cause_description=root, immediate_cause_description=inc_row["initial_description"][:200],
             contributing_factors=contrib if i in INV_ROOT else {"isolation": "LOTO try-out step skipped; production pressure",
                                                                 "procedure": "time pressure", "fatigue": "long shift", "dropped": "no tool lanyards", "driving": "speed, dust"}[fam],
             systemic_causes="Management of change and bypass control not embedded in daily operations." if i == 0 else
             ("Isolation verification not audited across sites." if fam == "isolation" else None),
             human_factors_analysis="Task saturation during maintenance window." if i in (0, 1) else None,
             equipment_failure_analysis={0: "LCV-110 actuator stem corrosion; SDV-110 in bypass.", 2: "Erosion-corrosion at K-201 discharge elbow.",
                                         3: "External pitting at disbonded coating."}.get(i),
             procedural_deficiencies="Bypass procedure lacks time limit and approval level." if i == 0 else None,
             findings_summary=f"{root}", lessons_learned={"bypass": "Never bypass a safety trip without MOC, a time limit and a compensating measure.",
                                                          "isolation": "Always do the try-out step: verify zero energy before touching equipment.",
                                                          "cui": "Act on inspection findings within the recommended window.",
                                                          "procedure": "Stop the job when the procedure cannot be followed.",
                                                          "fatigue": "Manage fatigue at shift handover.", "dropped": "Tether tools at height.",
                                                          "driving": "Follow journey management."}[fam],
             recommendations_summary="See corrective actions.", asset_facility_id=fac(fi) if fi is not None else None,
             equipment_id=eq({0: "CF2-V-110", 2: "FD1-K-201"}[i]) if i in (0, 2) else None,
             violation_id=inc_row.get("violation_id"), investigation_start_date=t.date() + timedelta(days=1),
             investigation_completion_date=t.date() + timedelta(days=28) if t.date() < date(2026, 6, 1) else None,
             investigation_closure_date=t.date() + timedelta(days=40) if t.date() < date(2026, 6, 1) else None,
             investigation_team_members="; ".join(ctx.person() for _ in range(3)), witness_count=str(ctx.int_(0, 4)), capa_count=str(3 if i == 0 else ctx.int_(1, 2)),
             business_unit="upstream", management_review_required=i < 4, management_review_date=t.date() + timedelta(days=45) if i < 4 else None,
             external_consultant_used=i == 0, external_consultant_name="Process Safety Partners (synthetic)" if i == 0 else None,
             regulatory_notification_required=i in (0, 1, 3), regulatory_report_submitted=i in (0, 1, 3), investigation_cost_usd=ctx.num(2000, 65000, 0),
             evidence_collected="DCS trends, PTW, interviews, photos" if i < 4 else "interviews, photos", investigation_report_url=None,
             approval_date=t.date() + timedelta(days=35) if t.date() < date(2026, 6, 1) else None, _anchor=t.date())
    r["_family"] = fam


SPILLS = {
    0: (5, "CF2-V-110", None, LOPC_TIME, "crude oil", 52.0, 46.0, "Overfill of separator V-110 (LCV-110 failed open, trip bypassed).", S.INC_LOPC, S.VIO_LOPC),
    1: (1, None, S.PIPE_FD07, PIPE_TIME, "produced water", 12.0, 9.5, "External corrosion pinhole on gathering line FD-07.", S.INC_PIPE, S.VIO_PIPE),
}


def spill_event(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i in SPILLS:
        fi, tag, pipe, t, mat, est, conf, cause, inc, vio = SPILLS[i]
    else:
        fi = [0, 2, 4, 6, 7, 9, 10, 12, 13, 3, 5, 1, 8, 2, 4, 17, 0, 6][i - 2]
        t = datetime(2024, 5, 9, 11, 0) + timedelta(days=(i * 47) % 860)
        mat = ctx.pick(["crude oil", "produced water", "produced water", "condensate"])
        est = ctx.num(0.5, 9, 1)
        conf, tag, pipe, inc, vio = round(est * 0.9, 1), None, None, None, None
        cause = ctx.pick(["truck loading hose failure", "tank overflow during high-rate flowback", "flowline corrosion pinhole", "valve packing leak"])
    rec = round(conf * 0.85, 1)
    r.update(spill_reference_number=f"SPL-{t.year}-{i + 1:04d}", spill_occurrence_timestamp=t, spill_discovery_timestamp=t + timedelta(minutes=20),
             spill_status="closed" if t.date() < date(2026, 4, 1) else "remediation", estimated_volume_barrels=est, confirmed_volume_barrels=conf,
             volume_recovered_barrels=rec, volume_unit_of_measure="barrels", release_cause_category="equipment failure" if i < 2 else "operational",
             release_cause_description=cause, receiving_environment="soil inside and outside lined containment" if i == 0 else ("dry wash (ephemeral)" if i == 1 else "soil on pad"),
             containment_actions_taken="Inlet ESD closed, sorbent boom, vacuum truck" if i == 0 else "Line shut in, vacuum truck recovery",
             cleanup_method="excavation and disposal at permitted facility", cleanup_start_date=t.date(), cleanup_completion_date=t.date() + timedelta(days=12) if i != 1 else None,
             remediation_status="completed" if t.date() < date(2026, 4, 1) else "in_progress", impacted_area_extent_acres=0.4 if i == 0 else ctx.num(0.01, 0.2),
             estimated_cleanup_cost_usd=96000.0 if i == 0 else ctx.num(2000, 40000, 0), onshore_offshore_indicator="onshore",
             spill_latitude=FACILITIES[fi][4], spill_longitude=FACILITIES[fi][5], spill_location_description=FACILITIES[fi][1] if pipe is None else f"{PIPELINES[pipe][1]} at dry-wash crossing",
             incident_id=P("hse.incident", inc) if inc is not None else None, violation_id=P("compliance.violation", vio) if vio is not None else None,
             equipment_id=eq(tag) if tag else None, pipeline_segment_id=P("asset.pipeline_segment", pipe) if pipe is not None else None,
             production_facility_id=pfac(fi) if fi < 15 else None, crude_grade_id=P("product.crude_grade", 5) if i == 0 else None,
             state_agency_notification_required=conf >= 5, state_agency_notification_timestamp=t + timedelta(hours=8) if conf >= 5 else None,
             nrc_notification_required=mat == "crude oil" and conf >= 25, nrc_notification_timestamp=t + timedelta(hours=4) if mat == "crude oil" and conf >= 25 else None,
             nrc_report_number=f"NRC-{1300000 + i}" if mat == "crude oil" and conf >= 25 else None, uscg_notification_required=False,
             bsee_notification_required=False, wildlife_impact_reported=False, environmental_impact_assessment_completed=i < 2,
             regulatory_closure_date=t.date() + timedelta(days=90) if t.date() < date(2026, 4, 1) else None, _anchor=t.date())
    r["_material"] = mat


def hse_corrective_action(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    inv_rows = ctx.rows["hse.incident_investigation"]
    plan = {
        0: (0, "corrective", "Replace LCV-110 trim and actuator; retest SDV-110 high-level trip.", "closed", "effective", None),
        1: (0, "preventive", "Introduce a SIF bypass register with MOC approval, time limit and compensating measures at all CTBs.", "closed", "partially_effective", None),
        2: (0, "improvement", "Monthly audit of the bypass register; escalate bypasses older than 24 h (follow-up of the partially effective action).", "in_progress", "pending", 1),
        3: (1, "preventive", "Update the Wolfcamp B pore-pressure model with offset-well data and set MW 13.4 ppg before the transition.", "closed", "effective", None),
        4: (1, "corrective", "Re-train drill crews on trip-sheet discipline and immediate notification to the RRC.", "closed", "effective", None),
        5: (2, "corrective", "Add compressor discharge piping to the CML register with a 6-month UT interval.", "closed", "effective", None),
        6: (2, "preventive", "Track inspection findings to closure in the CMMS with due-date alerts.", "closed", "effective", None),
        7: (3, "corrective", "Recoat FD-07 and install additional CP test stations at wash crossings.", "in_progress", "pending", None),
    }
    if i in plan:
        inv, atype, desc, status, eff, prev = plan[i]
        src = "incident"
    elif i < 34:
        inv = 4 + (i - 8)                       # one action per remaining investigation (4..29)
        fam = inv_rows[inv]["_family"]
        atype = "preventive" if fam == "isolation" else "corrective"
        desc = {"isolation": "Add a mandatory try-out step with a second-person check to the LOTO procedure.", "procedure": "Brief the procedure and add a stop-work prompt to the JSA.",
                "fatigue": "Review rotation and handover practice.", "dropped": "Issue tool lanyards and add dropped-object checks.",
                "driving": "Reinforce journey management and lease road speed limits."}[fam]
        status, eff, prev, src = "closed", "effective" if fam != "isolation" else "ineffective", None, "incident"
    else:
        inv, prev = None, None
        atype, src = "corrective", ctx.pick(["inspection", "audit", "observation"])
        desc = ctx.pick(["Repair leaking thief hatch gaskets found by OGI.", "Replace corroded handrail.", "Update emergency response plan contact list.",
                         "Install secondary containment liner repair."])
        status, eff = ctx.pick(["closed", "open", "overdue"]), "pending"
    inv_row = inv_rows[inv] if inv is not None else None
    inc = inv_row["incident_id"] if inv_row else None
    due = (inv_row["_anchor"] if inv_row else date(2025, 1, 15) + timedelta(days=i * 13)) + timedelta(days=45)
    r.update(action_number=f"CA-{due.year}-{i + 1:04d}", action_type=atype, action_description=desc, action_status=status,
             effectiveness_review_status=eff, previous_action_hse_corrective_action_id=P("hse.hse_corrective_action", prev) if prev is not None else None,
             incident_id=inc, incident_investigation_id=P("hse.incident_investigation", inv) if inv is not None else None,
             process_safety_event_id=P("hse.process_safety_event", S.PSE_LOPC) if inv == 0 else (P("hse.process_safety_event", S.PSE_K201) if inv == 2 else None),
             spill_event_id=P("hse.spill_event", 0) if inv == 0 else (P("hse.spill_event", 1) if inv == 3 else None),
             violation_id=inv_row.get("violation_id") if inv_row else None, ldar_survey_id=P("hse.ldar_survey", 13) if i == 40 else None,
             asset_facility_id=inv_row.get("asset_facility_id") if inv_row else fac(i % 14), equipment_id=eq("CF2-LCV-110") if i == 0 else (eq("FD1-K-201") if i == 5 else None),
             pipeline_segment_id=P("asset.pipeline_segment", S.PIPE_FD07) if i == 7 else None, source_type=src, source_reference_code=inv_row["investigation_number"] if inv_row else None,
             root_cause_description=inv_row["root_cause_description"] if inv_row else None, priority="critical" if inv == 0 else ("high" if inv in (1, 2, 3) else "medium"),
             assigned_date=due - timedelta(days=45), due_date=due, completion_date=due - timedelta(days=5) if status == "closed" else None,
             closure_date=due if status == "closed" else None, verification_date=due + timedelta(days=30) if eff != "pending" else None,
             verification_method="audit" if eff != "pending" else None, verified_by=ctx.person() if eff != "pending" else None,
             effectiveness_review_date=due + timedelta(days=60) if eff != "pending" else None,
             effectiveness_review_comments=("Two bypasses found without time limits in the June audit." if i == 1 else
                                            ("Repeat isolation incident at another site after this action closed." if eff == "ineffective" else None)),
             responsible_party=ctx.person(), cost_estimate=ctx.num(500, 90000, 0), actual_cost=ctx.num(500, 90000, 0) if status == "closed" else None,
             recurrence_flag=eff == "ineffective", escalation_flag=status == "overdue", escalation_date=due + timedelta(days=7) if status == "overdue" else None,
             regulatory_requirement=None, business_unit="Permian Operations", geographic_region="Permian Basin", _anchor=due)


# ---------------------------------------------------------------------------
# emissions, production, downtime, flaring, allocation
# ---------------------------------------------------------------------------
GHG_FACS = [0, 1, 2, 3, 4, 5, 6, 7, 9, 10, 11, 15]
QUARTERS = [(date(2025, 7, 1), date(2025, 9, 30)), (date(2025, 10, 1), date(2025, 12, 31)), (date(2026, 1, 1), date(2026, 3, 31)), (date(2026, 4, 1), date(2026, 6, 30))]
CO2E_BASE = {5: 2150.0, 2: 1680.0, 4: 1120.0, 0: 980.0, 3: 610.0, 1: 520.0, 10: 450.0, 11: 760.0, 15: 1390.0, 6: 380.0, 7: 240.0, 9: 210.0}


def ghg_emission(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i < 48:
        fi, q = GHG_FACS[i % 12], i // 12
        gas = "CO2" if fi in (15,) else ("CH4" if q % 2 else "CO2")
    else:
        fi, q, gas = 16, i - 46, "CO2"
    a, b = QUARTERS[q]
    base = CO2E_BASE.get(fi, 500.0) if fi != 16 else 900.0
    co2e = round(base * (1.25 if fi == 5 and q == 2 else 1.0) * ctx.num(0.9, 1.1), 1)
    gwp = 28.0 if gas == "CH4" else 1.0
    qty = round(co2e / gwp, 2)
    src = 20 + fi if gas == "CH4" and fi < 14 else fi
    r.update(emission_source_id=P("hse.emission_source", src), asset_facility_id=fac(fi), ghg_gas_type=gas, global_warming_potential=gwp,
             ghg_quantity_tonnes=qty, co2e_tonnes=co2e, net_emission_co2e_tonnes=co2e, carbon_offset_applied=False, carbon_offset_tonnes=0.0,
             emission_source_category="fugitive" if gas == "CH4" else ("combustion" if fi in (15, 16) else "flaring"),
             quantification_methodology="emission_factor" if gas == "CH4" else "direct_measurement", scope_classification="scope_1",
             reporting_period_start_date=a, reporting_period_end_date=b, emission_event_timestamp=datetime.combine(b, datetime.min.time()),
             activity_data_value=ctx.num(500, 40000, 0), activity_data_unit="Mscf" if gas == "CO2" else "component-hours",
             emission_factor_value=ctx.num(0.05, 60.0, 3), emission_factor_unit="kg/Mscf" if gas == "CO2" else "scf/hr/component",
             emission_factor_source="40 CFR 98 Subpart W", epa_subpart_code="W", data_quality_tier="tier_2" if gas == "CO2" else "tier_3",
             measurement_uncertainty_percent=ctx.num(5, 25), verification_status="verified" if q < 2 else "pending_verification",
             verifier_name="Independent GHG Verifier (synthetic)" if q < 2 else None, verification_date=b + timedelta(days=60) if q < 2 else None,
             ldar_survey_id=P("hse.ldar_survey", [0, 2, 4, 5, 6, 7, 10, 11, 1, 3].index(fi) + 10 * (q - 1)) if gas == "CH4" and fi in (0, 2, 4, 5, 6, 7, 10, 11, 1, 3) and q >= 1 else None,
             regulatory_reporting_required=True, esg_disclosure_included=True, data_source_system="emissions inventory",
             calculation_notes=(f"Q{(a.month - 1) // 3 + 1} {a.year} {gas} at {FACILITIES[fi][1]}" +
                                ("; flaring during takeaway constraint and LOPC response" if fi == 5 and q == 2 else "")),
             crude_grade_id=None, _anchor=b)


def daily_production(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    al_row, day = i // 5, i % 5
    widx = PRODUCING[al_row]
    w = WELLS[widx]
    fi = w.field
    fac_i = facility_of_well(widx)
    d = date(2026, 8, 1) + timedelta(days=day)
    oil = ctx.num(160, 820, 1)
    gas = round(oil * ctx.num(1.3, 3.2), 1)
    water = round(oil * ctx.num(0.8, 2.6), 1)
    down = 0.0 if not (widx == 3 and day == 2) else 6.5
    res, zn = well_reservoir_zone(w)
    r.update(production_date=d, artificial_lift_id=P("production.artificial_lift", al_row), production_facility_id=pfac(fac_i),
             meter_station_id=P("production.meter_station", fac_i), reservoir_id=res, zone_id=zn, crude_grade_id=P("product.crude_grade", GRADE_OF_FIELD[fi]),
             exploration_well_id=P("exploration.exploration_well", EXPLORATION.index(widx)) if widx in EXPLORATION else None, well_test_id=None,
             gross_oil_volume_bbl=oil, net_oil_volume_bbl=round(oil * 0.995, 1), gross_gas_volume_mcf=gas, net_gas_volume_mcf=round(gas * 0.97, 1),
             gross_water_volume_bbl=water, ngl_volume_bbl=round(gas * 0.09, 1), condensate_volume_bbl=0.0, boe_volume=round(oil + gas / 6.0, 1),
             gor=round(gas * 1000 / oil, 0), water_cut_percent=round(water / (water + oil) * 100, 1), wor=round(water / oil, 2), uptime_hours=round(24 - down, 1),
             downtime_hours=down, downtime_reason="equipment_failure" if down else None, production_status="artificial_lift",
             allocation_method="test_based", data_source="scada", data_quality_flag="validated", oil_gravity_api=CRUDE_GRADES_API[GRADE_OF_FIELD[fi]],
             tubing_pressure_psi=ctx.num(120, 600, 0), casing_pressure_psi=ctx.num(250, 900, 0), separator_pressure_psi=ctx.num(80, 180, 0),
             choke_size_64ths=str(ctx.pick([24, 32, 40])), oil_temperature_f=ctx.num(85, 115, 1), gas_temperature_f=ctx.num(80, 110, 1),
             gas_specific_gravity=ctx.num(0.68, 0.85, 3), btu_content=ctx.num(1150, 1350, 0), h2s_content_ppm=0.0, co2_content_percent=ctx.num(0.5, 3),
             gas_lift_injection_rate_mcfd=ctx.num(450, 1100, 0) if fi not in (4, 8, 9) and widx not in ESP_WELLS else None,
             pump_stroke_rate_spm=ctx.num(5, 9) if fi in (4, 8, 9) else None, run_ticket_number=f"RT-{d.strftime('%Y%m%d')}-{i + 1:03d}", _anchor=d)


CRUDE_GRADES_API = [g[2] for g in CRUDE_GRADES]

DT_PLAN = {
    0: ("equipment_failure", 0, None, "FD1-K-201", None, K201_TIME, 22.0, 1850.0, "K-201 tripped on gas detection after the discharge elbow leak; field gas shut in.", 0, S.INC_K201, S.PSE_K201, None, None),
    1: ("equipment_failure", 2, 10, "RM-ESP-09", None, datetime(2026, 3, 5, 2, 10), 96.0, 2400.0, "ESP-09 motor burnout on Red Mesa 12-3H; well shut in until ESP replaced.", 1, None, None, None, None),
    2: ("regulatory", 5, None, "CF2-V-110", None, LOPC_TIME, 60.0, 3100.0, "Coyote Flats CTB-2 shut in after the V-110 LOPC pending regulator release.", 2, S.INC_LOPC, S.PSE_LOPC, 0, S.VIO_LOPC),
    3: ("equipment_failure", 1, None, None, S.PIPE_FD07, PIPE_TIME, 30.0, 640.0, "Produced-water line FD-07 shut in after leak; pad 11 wells shut in for water handling.", 3, S.INC_PIPE, None, 1, S.VIO_PIPE),
    4: ("regulatory", 2, 8, None, None, None, 26.0, 420.0, "Red Mesa 12-1H shut in during the well control operation on the offset well Red Mesa 12-2H (SIMOPS).", None, S.INC_KICK, None, None, None),
}


def downtime_event(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    wce = None
    if i in DT_PLAN:
        cat, fi, widx, tag, pipe, t, hrs, boe, cause, wo, inc, pse, spill, vio = DT_PLAN[i]
        if i == 4:
            t, wce = kick_time(), P("drilling.well_control_event", 0)
    else:
        cat = ctx.pick(["planned_maintenance", "planned_maintenance", "equipment_failure", "weather", "pipeline_constraint", "market_curtailment"])
        fi = [0, 2, 4, 5, 6, 7, 9, 10, 12, 13, 1, 3][i % 12]
        widx, pipe, wo, inc, pse, spill, vio = None, None, None, None, None, None, None
        tag = ctx.pick([e[0] for e in EQUIPMENT if e[3] == fi] or [None]) if cat == "equipment_failure" else None
        t = datetime(2024, 3, 1, 6, 0) + timedelta(days=(i * 37) % 900, hours=i % 12)
        if cat == "weather":
            t = datetime(2026, 1, 21, 4, 0) + timedelta(hours=i)      # winter storm, January 2026 (synthetic)
        hrs = ctx.num(4, 72, 1)
        boe = round(hrs * ctx.num(8, 60), 0)
        cause = {"planned_maintenance": "Planned compressor / separator maintenance.", "equipment_failure": f"Unplanned trip of {tag or 'equipment'}.",
                 "weather": "Winter storm: frozen dump valves and power outage.", "pipeline_constraint": "Third-party gas takeaway constraint; wells choked back.",
                 "market_curtailment": "Curtailment for negative Waha gas price days."}[cat]
    fac_i = fi if fi < 15 else 0
    oil_def = round(boe * 0.62, 1)
    r.update(event_number=f"DT-{t.year}-{i + 1:04d}", downtime_category=cat, downtime_subcategory=cause.split(":")[0][:40], start_timestamp=t,
             end_timestamp=t + timedelta(hours=hrs), duration_hours=hrs, reported_timestamp=t + timedelta(hours=1), resolved_timestamp=t + timedelta(hours=hrs),
             production_facility_id=pfac(fac_i), field_id=P("production.field", FACILITIES[fac_i][3]),
             production_well_id=pw_row(widx) if widx is not None else None, equipment_id=eq(tag) if tag else None,
             pipeline_segment_id=P("asset.pipeline_segment", pipe) if pipe is not None else None, work_order_id=P("asset.work_order", wo) if wo is not None else None,
             incident_id=P("hse.incident", inc) if inc is not None else None, process_safety_event_id=P("hse.process_safety_event", pse) if pse is not None else None,
             spill_event_id=P("hse.spill_event", spill) if spill is not None else None, violation_id=P("compliance.violation", vio) if vio is not None else None,
             well_control_event_id=wce, rig_id=P("drilling.rig", 3) if wce else None, reservoir_id=well_reservoir_zone(WELLS[widx])[0] if widx is not None else None,
             permit_to_work_id=None, deferred_boe=boe, deferred_oil_volume_bbl=oil_def, deferred_gas_volume_mcf=round((boe - oil_def) * 6, 0),
             deferred_ngl_volume_bbl=round(boe * 0.05, 1), estimated_revenue_impact_usd=round(boe * 68, 0), estimated_cost_usd=ctx.num(2000, 90000, 0),
             root_cause_description=cause, corrective_action_taken="See work order." if wo is not None else "Restored production.",
             preventive_action_recommended=None, priority="critical" if boe > 1500 else ("high" if boe > 500 else "medium"),
             downtime_event_status="closed" if t.date() < date(2026, 9, 1) else "in_progress", hse_incident_flag=inc is not None,
             regulatory_reportable_flag=vio is not None, data_source="pi_system", reported_by=ctx.person(), resolved_by=ctx.person(),
             responsible_organization="Permian Operations", responsible_party="operator", operator_name=None, working_interest_pct=100.0,
             comments=cause, _anchor=t.date())


def flare_record(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    wce, dw, tag, prev = None, None, None, None
    if i == 0:
        fi, t, vol, ftype, reason, desc = 2, kick_time() + timedelta(hours=1), 2850.0, "emergency", "WC", "Gas circulated out of Red Mesa 12-2H during the well kill flared at the rig flare."
        wce, dw = P("drilling.well_control_event", 0), drill_row_of_well(S.KICK_WELL)
    elif i == 1:
        fi, t, vol, ftype, reason, desc, tag = 0, K201_TIME + timedelta(minutes=5), 1240.0, "emergency", "EQ-TRIP", "Field gas flared while K-201 was down after the discharge leak.", "FD1-K-201"
    elif i == 2:
        fi, t, vol, ftype, reason, desc, tag = 5, LOPC_TIME + timedelta(minutes=10), 900.0, "emergency", "ESD", "Emergency depressurisation of V-110 after the LOPC.", "CF2-V-110"
    else:
        fi = [5, 5, 5, 2, 2, 2, 4, 0, 1, 3, 6, 7, 10, 11, 9, 12][i % 16]
        t = datetime(2025, 7, 1, 8, 0) + timedelta(days=(i * 23) % 450)
        ftype = ctx.pick(["intermittent", "routine", "intermittent"])
        reason = "TAKEAWAY" if fi in (5, 2) else ctx.pick(["MAINT", "UPSET", "TAKEAWAY"])
        vol = ctx.num(400, 2400, 0) if fi in (5, 2) else ctx.num(50, 600, 0)
        desc = {"TAKEAWAY": "Third-party gas takeaway constraint; casinghead gas flared under authorisation.", "MAINT": "Planned maintenance blowdown.",
                "UPSET": "Compressor upset."}[reason]
        prev = P("production.flare_record", i - 16) if i >= 19 and fi in (5, 2) else None
    hrs = ctx.num(2, 30, 1) if i > 2 else {0: 14.0, 1: 22.0, 2: 1.5}[i]
    co2e = round(vol * 0.0606, 1)
    src = fi if fi < 14 else 0
    r.update(flare_event_number=f"FLR-{t.year}-{i + 1:04d}", flare_date=t.date(), flare_start_timestamp=t, flare_end_timestamp=t + timedelta(hours=hrs),
             flare_duration_hours=hrs, flare_type=ftype, flare_reason_code=reason, flare_reason_description=desc, flare_status="completed",
             flare_volume_mcf=vol, flare_volume_mscf=vol, flare_volume_boe=round(vol / 6, 1), vented_volume_mscf=round(vol * 0.02, 1),
             combustion_efficiency_pct=98.0, ghg_emissions_co2e_tonnes=co2e, gas_composition_methane_pct=ctx.num(70, 82), gas_composition_ethane_pct=ctx.num(9, 14),
             gas_composition_propane_pct=ctx.num(4, 7), gas_composition_co2_pct=ctx.num(0.5, 3), gas_composition_h2s_ppm=ctx.num(0, 10),
             heating_value_btu_per_scf=ctx.num(1150, 1320, 0), specific_gravity=ctx.num(0.7, 0.82, 3), gas_price_usd_per_mcf=ctx.num(0.8, 2.6),
             economic_loss_usd=round(vol * 1.9, 0), measurement_method="flow_meter" if fi in (0, 2, 5) else "engineering_calculation",
             allocation_method="direct_measurement" if fi in (0, 2, 5) else "estimated", data_quality_flag="verified", data_source="flare meter / historian",
             production_facility_id=pfac(fi), meter_station_id=None, emission_source_id=P("hse.emission_source", src), equipment_id=eq(tag) if tag else None,
             well_control_event_id=wce, drilling_well_id=dw, previous_flare_record_id=prev,
             ghg_emission_id=None, reservoir_id=None, zone_id=None, permit_number=("FLR-TX-2025-138" if fi == 2 else ("FLR-NM-2025-139" if fi == 5 else None)),
             regulatory_reportable_flag=vol > 1000 or ftype == "emergency", regulatory_submission_date=t.date() + timedelta(days=15) if vol > 1000 else None,
             comments=None, _anchor=t.date())


def production_allocation(ctx: Ctx, i: int, r: dict[str, Any]) -> None:
    if i < 43:
        widx, mm = PRODUCING[i], 8
    elif i < 49:
        widx, mm = [15, 16, 17, 18, 19, 20][i - 43], 7
    else:
        widx, mm = 42, 7
    w = WELLS[widx]
    fi = w.field if w.field is not None else 5
    fac_i = facility_of_well(widx)
    meter = fac_i
    ct_i = ([8, 7, 6].index(mm)) * 10 + fi
    gross = fd_aug_gross(widx) if widx < 8 and mm == 8 else ctx.num(4500, 21000, 0)
    gas = round(gross * ctx.num(1.4, 3.0), 0)
    nri = ctx.num(0.72, 0.8)
    var = ctx.num(180, 420, 0) * ctx.pick([1, -1]) if fac_i == 5 else ctx.num(5, 60, 0) * ctx.pick([1, -1])
    a = date(2026, mm, 1)
    b = date(2026, mm, 31)
    _, zn = well_reservoir_zone(w)
    r.update(production_month=f"2026-{mm:02d}", period_start_date=a, period_end_date=b, production_well_id=pw_row(widx), production_facility_id=pfac(fac_i),
             meter_station_id=P("production.meter_station", meter), custody_transfer_id=P("logistics.custody_transfer", ct_i), zone_id=zn,
             crude_grade_id=P("product.crude_grade", GRADE_OF_FIELD[fi]), well_test_id=None,
             allocation_method="test_ratio" if fac_i != 5 else "meter_based", allocation_status="final" if mm == 7 else "preliminary",
             gross_oil_volume_bbl=gross, net_oil_volume_bbl=round(gross * nri, 0), gross_gas_volume_mcf=gas, net_gas_volume_mcf=round(gas * nri, 0),
             gross_water_volume_bbl=round(gross * ctx.num(1.0, 2.4), 0), gross_ngl_volume_bbl=round(gas * 0.09, 0), net_ngl_volume_bbl=round(gas * 0.09 * nri, 0),
             total_boe=round(gross + gas / 6, 0), boe_conversion_factor=6.0, gas_oil_ratio=round(gas * 1000 / gross, 0), water_oil_ratio=ctx.num(1.0, 2.4),
             working_interest_decimal=1.0, net_revenue_interest_decimal=round(nri, 2), factor=ctx.num(0.03, 0.2, 3),
             facility_metered_oil_volume_bbl=ctx.num(80000, 160000, 0), facility_metered_gas_volume_mcf=ctx.num(150000, 400000, 0),
             oil_allocation_variance_bbl=var, gas_allocation_variance_mcf=round(var * 2.1, 0),
             reconciliation_status="in_progress" if abs(var) > 150 else "completed",
             reconciliation_notes=(f"Variance of {abs(var):.0f} bbl against the LACT; meter CF-LACT-02 factor 1.01 and proving overdue." if abs(var) > 150 else None),
             reconciliation_date=b + timedelta(days=12) if abs(var) <= 150 else None, run_timestamp=datetime.combine(b + timedelta(days=5), datetime.min.time()) + timedelta(hours=6),
             approval_timestamp=datetime.combine(b + timedelta(days=9), datetime.min.time()) if mm == 7 else None, jib_posting_date=b + timedelta(days=20) if mm == 7 else None,
             regulatory_reporting_flag=True, source_system="scada", _anchor=b)
